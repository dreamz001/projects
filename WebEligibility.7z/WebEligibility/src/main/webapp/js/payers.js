$(document).ready(function() {
  showpayerselect(false);
  payerDisabled(true);
  hidebackpayer();
  /*
   * $(document).on('click', '#payersaveid', function() { sessionStorage.tab =
   * 2; });
   */
  $('#payerBackButton').click(function() {
    sessionStorage.tab = 2;
  });
});

function showpayersavebutton() {
  $("#payersavespanid").show();
  $("#payeraddnewid").hide();

}
function showpayeraddbutton() {
  $("#payersavespanid").hide();
  $("#payeraddnewid").show();
}

function showbackpayer() {
  $("#backspanid").show();
}
function hidebackpayer() {
  $("#backspanid").hide();
}
function showpayerselect(show) {
  if (show == true) {
    $("#selectpayernamedivid").show();
  } else {
    $("#selectpayernamedivid").hide();
  }
}

function payersaveorupdatebutton(label) {
  $("#payersaveid").val(label);
}

function resetPayerId() {
  $("#payerid").val("");
}
function getPayerDetailsByIdAjax(payercode) {
  if (payercode == '-1') {
    $('#updatepayerformid')[0].reset();
    return false;
  }
  $.ajax({
    url : 'getpayerdetails?payercode=' + payercode,
    method : 'GET',
    success : function(data) {
      var jsonobj = JSON.parse(data);
      $("#inputpayernameid").val(jsonobj.PAYERDETAILS.PAYERNAME);
      $("#payerid").val(jsonobj.PAYERDETAILS.PAYERID);
      $("#inputpayerid").val(jsonobj.PAYERDETAILS.PAYERCODE);
      $("#identifiercodeid")
          .val(jsonobj.PAYERDETAILS.PAYERIDENTIFIERCODE);
      $("#typequalifierid").val(jsonobj.PAYERDETAILS.PAYERTYPEQUALIFIER);
      $("#codequalifierid")
          .val(jsonobj.PAYERDETAILS.PAYERIDCODEQUALIFIER);
    }
  });
}

function payerDisabled(data) {
    document.getElementById("selectpayernameid").disabled = data;
    document.getElementById("inputpayernameid").disabled = data;
    document.getElementById("inputpayerid").disabled = data;
    document.getElementById("identifiercodeid").disabled = data;
    document.getElementById("typequalifierid").disabled = data;
    document.getElementById("codequalifierid").disabled = data;
}