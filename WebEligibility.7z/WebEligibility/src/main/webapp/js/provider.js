$(document).ready(function() {
  showproviderselect(false);
  providerDisabled(true);
  hidebackprovider();
  $('#providerBackButton').click(function() {
    sessionStorage.tab = 3;
  });
});

function showprovidersavebutton() {
  $("#providersavespanid").show();
  $("#provideraddid").hide();

}
function showprovideraddbutton() {
  $("#providersavespanid").hide();
  $("#provideraddid").show();
}

function showbackprovider() {
  $("#backspanproviderid").show();
}
function hidebackprovider() {
  $("#backspanproviderid").hide();
}
function showproviderselect(show) {
  if (show == true) {
    $("#selectprovidernamedivid").show();
  } else {
    $("#selectprovidernamedivid").hide();
  }
}

function providersaveorupdatebutton(label) {
  $("#providersaveid").val(label);
}

function resetProviderId() {
  $("#providerid").val("");
}

function getProviderDetailsByIdAjax(providercode) {
  if (providercode == '-1') {
    $('#updateproviderformid')[0].reset();
    return false;
  }
  $
      .ajax({
        url : 'getproviderdetails?providercode=' + providercode,
        method : 'GET',
        success : function(data) {
          var jsonobj = JSON.parse(data);
          $("#inputprovidernameid").val(
              jsonobj.PROVIDERDETAILS.PROVIDERNAME);
          $("#providerid").val(jsonobj.PROVIDERDETAILS.PROVIDERID);
          $("#inputproviderid").val(
              jsonobj.PROVIDERDETAILS.PROVIDERCODE);
          $("#provideridentifiercodeid").val(
              jsonobj.PROVIDERDETAILS.PROVIDERIDENTIFIERCODE);
          $("#providertypequalifierid").val(
              jsonobj.PROVIDERDETAILS.PROVIDERTYPEQUALIFIER);
          $("#providercodequalifierid").val(
              jsonobj.PROVIDERDETAILS.PROVIDERIDCODEQUALIFIER);

        }
      });
}

function providerDisabled(data) {
  document.getElementById("selectprovidernameid").disabled = data;
  document.getElementById("inputprovidernameid").disabled = data;
  document.getElementById("inputproviderid").disabled = data;
  document.getElementById("provideridentifiercodeid").disabled = data;
  document.getElementById("providertypequalifierid").disabled = data;
  document.getElementById("providercodequalifierid").disabled = data;

}
