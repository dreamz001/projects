    var tabNumber ;
                    $(document).ready(function() {
                        tabNumber  = '${sessionScope.tab}';
                        var page='${sessionScope.page}';
                        $("#tabs").tabs();
                        $('#tabs-2').hide();
                        $('#tabs-3').hide();
                        $('#tabs-4').hide();
                        $('#tabs-5').hide();
                        $('#tabs-6').hide();
                        $('#dashboardBackButton').click(function (){
                            sessionStorage.tab = 1;
                        });
                        
                        $('#fullDescBackButton').click(function (){
                            sessionStorage.tab = 1;
                        });
                        
                        $('#shortDescBackButton').click(function (){
                            sessionStorage.tab = 11;
                        });
                        $('#longDescReportButton').click(function (){
                            sessionStorage.tab = 11;
                        });
                        $('#longDescReportBackButton').click(function (){
                            sessionStorage.tab = 11;
                        });
                        $('#payersaveid').click(function (){
                            if($('#payersaveid').val()=='UPDATE'){
                                sessionStorage.tab = 5;
                            }else if($('#payersaveid').val()=='SAVE'){
                                sessionStorage.tab = 6;
                            }else{
                                sessionStorage.tab = 2;
                            }
                        });
                         $('#providersaveid').click(function (){
                            if($('#providersaveid').val()=='UPDATE'){
                                sessionStorage.tab = 7;
                            }else if($('#providersaveid').val()=='SAVE'){
                                sessionStorage.tab = 8;
                            }else{
                                sessionStorage.tab = 3;
                            }
                        });
                        $(document).on('click', '#step1', function() {
                            sessionStorage.tab = 1;
                        });
                        $("#dateOfBirthId").datepicker({
                            maxDate : "0",
                            changeMonth : true,
                            changeYear : true,
                            dateFormat : "mm/dd/yy",
                        });

                        $(document).ready(function() {
                            $('#serviceperid').daterangepicker(null, function(start, end, label) {
                                console.log(start.toISOString(), end.toISOString(), label);
                            });
                        });

                        showLastTab();
                    });

                    function showLastTab() {
                        if ((tabNumber != '' || tabNumber == '2' || tabNumber == 2) && (sessionStorage.tab == 5 || sessionStorage.tab == 6)) {
                                sessionStorage.tab = 2;
                        }
                        if ((tabNumber != '' || tabNumber == '3' || tabNumber == 3) && (sessionStorage.tab == 7 || sessionStorage.tab == 8)) {
                            sessionStorage.tab = 3;
                        }
                        if ((tabNumber != '' || tabNumber == '9' || tabNumber == 9) && (sessionStorage.tab == 9 || sessionStorage.tab == 10)) {
                            sessionStorage.tab = 9;
                        }
                        if ((tabNumber != '' || tabNumber == '11' || tabNumber == 11) && (sessionStorage.tab == 11 || sessionStorage.tab == 12)) {
                            sessionStorage.tab = 11;
                        }
                        
                    if (sessionStorage.tab == 1) {
                            sessionStorage.tab = 0;
                            $('#tab-1').click();
                        } else if (sessionStorage.tab == 2) {
                            sessionStorage.tab = 0;
                            $('#tab-2').click();
                        } else if (sessionStorage.tab == 3) {
                            sessionStorage.tab = 0;
                            $('#tab-3').click();
                        } else if (sessionStorage.tab == 4) {
                            sessionStorage.tab = 0;
                            $('#tab-4').click();
                        }else if (sessionStorage.tab == 9) {//account setting
                            sessionStorage.tab = 0;
                            $('#tab-5').click();
                        } else if (sessionStorage.tab == 11) {//report
                            sessionStorage.tab = 0;
                            $('#tab-6').click();
                        }else if (sessionStorage.tab == 5) {//updatepayer
                            sessionStorage.tab = 0;
                            $('#tab-2').click();
                            showpayersavebutton();
                            showbackpayer();
                            payersaveorupdatebutton('UPDATE');
                            payerDisabled(false);
                            showpayerselect(true);
                        } else if (sessionStorage.tab == 6) {//add payer
                            sessionStorage.tab = 0;
                            $('#tab-2').click();
                            showpayersavebutton();
                            payersaveorupdatebutton('SAVE');
                            showbackpayer();
                            resetPayerId();
                            payerDisabled(false);
                            showpayerselect(false);
                        } else if (sessionStorage.tab == 7) {//update provider
                            sessionStorage.tab = 0;
                            $('#tab-3').click();
                            showprovidersavebutton();
                            providersaveorupdatebutton('UPDATE');
                            providerDisabled(false);
                            showbackprovider();
                            showproviderselect(true);
                        } else if (sessionStorage.tab == 8) {//add provider
                            sessionStorage.tab = 0;
                            $('#tab-3').click();
                            showprovidersavebutton();
                            providersaveorupdatebutton('SAVE');
                            resetProviderId();
                            showbackprovider();
                            providerDisabled(false);
                            showproviderselect(false);
                        } else {
                            $('#tab-1').click();
                        }
                    }

                    function changeRelationshipType(relationId) {
                        if(relationId=='' || relationId=='18'){
                            $('#firstnamelabelid').text("Primary First Name");
                            $('#lastnamelabelid').text("Primary Last Name");
                            $('#doblabelid').text("Primary DOB");
                            $('#genderlabelid').text("Primary Gender");
                        }
                        else{
                            $('#firstnamelabelid').text("Dependent First Name");
                            $('#lastnamelabelid').text("Dependent Last Name");
                            $('#doblabelid').text("Dependent DOB");
                            $('#genderlabelid').text("Dependent Gender");
                            }
                    }
