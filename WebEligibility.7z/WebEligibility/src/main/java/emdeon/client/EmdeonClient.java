package emdeon.client;

import java.io.IOException;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.client.core.WebServiceMessageCallback;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import org.springframework.ws.soap.SoapHeader;
import org.springframework.ws.soap.SoapMessage;
import org.springframework.ws.soap.client.SoapFaultClientException;
import org.springframework.xml.transform.StringSource;

import com.eligibility270.mastertables.entities.Deliverymethod;
import com.eligibility271.constants.Ack999Constants;
import com.eligibility271.dbentities.Emdeonrequestresponse;

import emdeon.wsdl.COREEnvelopeRealTimeRequest;
import emdeon.wsdl.COREEnvelopeRealTimeResponse;
/**
 * @author Manish
 * @date MAR 20,2015
 */
public class EmdeonClient extends WebServiceGatewaySupport {
    private static final Logger LOG = LoggerFactory.getLogger(EmdeonClient.class);

    public CoreEmdeonRequestResponse coreEnvelopeRealTimeResponse(CoreEmdeonRequestResponse emdeon, String payload, Deliverymethod deliverymethod) {
        LOG.debug("Requesting Emdeon for 270 EDI");

        COREEnvelopeRealTimeRequest request = new COREEnvelopeRealTimeRequest();

        request.setCORERuleVersion(deliverymethod.getRuleversion().trim());
        request.setReceiverID(deliverymethod.getReceiverid().trim()); // "263086998"
        request.setSenderID(deliverymethod.getSenderid().trim()); // "b2bup6479"
        request.setProcessingMode(deliverymethod.getProcessingmode().trim());
        request.setPayloadID(String.valueOf(emdeon.getEmdeon().getId()));
        request.setTimeStamp(new SimpleDateFormat("yyMMddhh:mm").format(new Date()));
        request.setPayloadType(deliverymethod.getPayloadtype().trim());
        request.setPayload(payload);
        //final String username ="B2B1324";// deliverymethod.getUsername().trim(); // "b2bup6479"
        //final String password ="PASS1324";// deliverymethod.getPassword().trim(); // "3ZDerm6479"
        final String username = deliverymethod.getUsername().trim(); // "b2bup6479"
        final String password = deliverymethod.getPassword().trim(); // "3ZDerm6479"
        COREEnvelopeRealTimeResponse response = null;
        Emdeonrequestresponse emdeonrequestresponse = emdeon.getEmdeon();
        try {
            JAXBContext contextReq = JAXBContext.newInstance(COREEnvelopeRealTimeRequest.class);
            StringWriter reqWriter = new StringWriter();
            Marshaller marshallerObj = contextReq.createMarshaller();
            marshallerObj.marshal(request, reqWriter);
            emdeonrequestresponse.setSoaprequest(reqWriter.toString());
            

            try {
                response = (COREEnvelopeRealTimeResponse) getWebServiceTemplate().marshalSendAndReceive(request, new WebServiceMessageCallback() {

                    public void doWithMessage(WebServiceMessage msg) throws IOException, TransformerException {
                        SoapMessage message = (SoapMessage) msg;
                        SoapHeader header = message.getSoapHeader();
                        StringSource source = new StringSource(
                                "<soapenv:Envelope xmlns:soapenv='http://www.w3.org/2003/05/soap-envelope'> <soapenv:Header><wsse:Security xmlns:wsse='http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd' soapenv:mustUnderstand='true'> <wsse:UsernameToken xmlns:wsu='http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd' wsu:Id='UsernameToken-21621663'> <wsse:Username>"
                                        + username
                                        + "</wsse:Username> <wsse:Password Type='http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText'>"
                                        + password + "</wsse:Password> </wsse:UsernameToken> </wsse:Security></soapenv:Header></soapenv:Envelope>");

                        Transformer transformer = TransformerFactory.newInstance().newTransformer();
                        transformer.transform(source, header.getResult());

                    }
                });
            } catch (SoapFaultClientException ex) {
                LOG.error("Invalid request EDI(270)", ex);
                emdeonrequestresponse.setResponsetype(Ack999Constants.ERROR);
                emdeon.setExceptionOccurred(true);
                emdeon.setDescription(ex.getFaultStringOrReason());
                emdeon.setEmdeon(emdeonrequestresponse);
                return emdeon;
            }
            catch(Exception eio){
                LOG.error("Invalid request EDI(270) Exception", eio);
                emdeonrequestresponse.setResponsetype(Ack999Constants.ERROR);
                emdeon.setExceptionOccurred(true);
                emdeon.setDescription("We can't process your request now, please try again later or contact administartor. The error discription is:"+eio.getMessage());
                emdeon.setEmdeon(emdeonrequestresponse);
                return emdeon;
            }
            

            emdeon.setResponse(response);

            if (response.getPayloadType() != null && !response.getPayloadType().trim().isEmpty()) {
                String type[] = response.getPayloadType().split("_");
                if (type.length > 1) {
                    emdeonrequestresponse.setResponsetype(type[1]);
                }else if(response.getErrorCode().equals(Ack999Constants.UNAUTHORIZED)){
                    emdeonrequestresponse.setResponsetype(Ack999Constants.UNAUTHORIZED);
                } 
                
                else {
                    emdeonrequestresponse.setResponsetype(Ack999Constants.ERROR);
                    
                }

            }

            emdeonrequestresponse.setResponsepayload(response.getPayload());
            JAXBContext contextRes = JAXBContext.newInstance(COREEnvelopeRealTimeResponse.class);
            StringWriter resWriter = new StringWriter();
            marshallerObj = contextRes.createMarshaller();
            // marshallerObj.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT,
            // true); // uncomment for multi lines
            marshallerObj.marshal(response, resWriter);
            emdeonrequestresponse.setEmdeonresponseedi271(resWriter.toString());
            emdeon.setEmdeon(emdeonrequestresponse);
        } catch (JAXBException ex) {
            LOG.error("Error while generating response for the 270 edi", ex);
        }
        LOG.debug("Requesting Emdeon for 270 EDI Completed");
        return emdeon;
    }
}
