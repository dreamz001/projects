package emdeon.client;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
/**
 * @author Manish
 * @date MAR 20,2015
 */
@Configuration
public class EmdeonConfiguration {

    @Bean
    public Jaxb2Marshaller marshaller() {
        Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
        marshaller.setContextPath("emdeon.wsdl");
        return marshaller;
    }

    @Bean
    public EmdeonClient emdeonClient(Jaxb2Marshaller marshaller) {
        EmdeonClient client = new EmdeonClient();
        client.setDefaultUri("https://webservices.capario.net/capariodataws/CAQH_CORE_WS_2_2_0");
        client.setMarshaller(marshaller);
        client.setUnmarshaller(marshaller);
        return client;
    }
}
