package emdeon.client;

import com.eligibility271.dbentities.Emdeonrequestresponse;

import emdeon.wsdl.COREEnvelopeRealTimeResponse;
/**
 * @author Manish
 * @date MAR 20,2015
 */
public class CoreEmdeonRequestResponse {

    private COREEnvelopeRealTimeResponse response;
    private Emdeonrequestresponse emdeon;
    private boolean exceptionOccurred = false;
    private String description;

    public COREEnvelopeRealTimeResponse getResponse() {
        return response;
    }

    public void setResponse(COREEnvelopeRealTimeResponse response) {
        this.response = response;
    }

    public Emdeonrequestresponse getEmdeon() {
        return emdeon;
    }

    public void setEmdeon(Emdeonrequestresponse emdeon) {
        this.emdeon = emdeon;
    }

    public boolean isExceptionOccurred() {
        return exceptionOccurred;
    }

    public void setExceptionOccurred(boolean exceptionOccurred) {
        this.exceptionOccurred = exceptionOccurred;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

}
