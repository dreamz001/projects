package com.eligibility.service;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.List;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.eligibility.base.dao.IBaseDao;
import com.eligibility270.dbentities.Edi271longdesc;
import com.eligibility270.dbentities.Eligibility270withack;
import com.eligibility270.dbentities.Eligibilitysummary;
import com.eligibility270.dbentities.Insurancesummary;
import com.eligibility270.dbentities.Providersummary;
import com.eligibility270.dbentities.Subscribersummary;
import com.eligibility270.header.entities.InterchangeControlHeader;
import com.eligibility270.mastertables.entities.Deliverymethod;
import com.eligibility270.mastertables.entities.ISAEntity;
import com.eligibility270.writer.DBSequenceType;
import com.eligibility271.dbentities.AaaFollowUpLookUp;
import com.eligibility271.dbentities.AaaRejectReason;
//import com.eligibility271.beans.Ack999ErrorCodeEntity;
import com.eligibility271.dbentities.DtpDefEntity;
import com.eligibility271.dbentities.EbLookUp;
import com.eligibility271.dbentities.Edi271shortdesc;
import com.eligibility271.dbentities.Emdeonrequestresponse;
import com.eligibility271.dbentities.Patientsummary;

@Service("eligibilityService")
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class EligibilityServiceImpl<T, PK extends Serializable> implements EligibilityService<T, PK> {

    @Autowired
    IBaseDao baseDao;

    @Override
    public Serializable save(T paramT) throws HibernateException {
        return baseDao.save(paramT);
    }

    @Override
    public ISAEntity getISA() throws HibernateException {
        return baseDao.getISA();
    }

    @Override
    public Deliverymethod byDeliveryMethodName(String name) {
        return baseDao.byDeliveryMethodName(name);
    }

    @Override
    public BigInteger nextVal(DBSequenceType sequenceType) throws Exception {
        return baseDao.nextVal(sequenceType);
    }

    @Override
    public void saveWithAck(InterchangeControlHeader interchangeCOntrolHeader, Eligibility270withack eligibility270withack) throws HibernateException {
        baseDao.saveWithAck(interchangeCOntrolHeader, eligibility270withack);

    }

    @Override
    public void saveWithShortDesc(Patientsummary patientsummary, Edi271shortdesc shEdi271shortdesc) throws HibernateException {
        baseDao.saveWithShortDesc(patientsummary, shEdi271shortdesc);        
    }

    @Override
    public Edi271shortdesc getShortDescByTraceNum(String traceNum) {
        return baseDao.getShortDescByTraceNum(traceNum);
    }

    @Override
    public void update(T paramT) throws HibernateException {
        baseDao.update(paramT);
    }

    @Override
    public void saveLongDecs(Edi271longdesc longDesc, Eligibilitysummary eligibilitysummary, Insurancesummary insurancesummary, Providersummary providersummary,
            Subscribersummary subscribersummary) throws HibernateException {
        baseDao.saveLongDecs(longDesc, eligibilitysummary, insurancesummary, providersummary, subscribersummary);
    }

    @Override
    public Edi271longdesc getEdi271longdescByTraceNum(String traceNum) {
        return baseDao.getEdi271longdescByTraceNum(traceNum);
    }

    @Override
    public Eligibility270withack getEligibility270withackByTraceNum(String traceNum) throws HibernateException {
        return baseDao.getEligibility270withackByTraceNum(traceNum);
    }

    @Override
    public List<DtpDefEntity> getDtpCodeList() throws HibernateException {
        return baseDao.getDtpCodeList();
    }

    @Override
    public void saveEmdeon(Emdeonrequestresponse emdeon) throws HibernateException {
        baseDao.saveEmdeon(emdeon);
    }

    @Override
    public EbLookUp getEbLookUp(String ebCode) throws HibernateException {
        return baseDao.getEbLookUp(ebCode);
    }

    @Override
    public AaaRejectReason getAaaRejectReason(String aaaCode) throws HibernateException {
        return baseDao.getAaaRejectReason(aaaCode);
    }

    @Override
    public AaaFollowUpLookUp getAaaFollowUpLookUp(String aaaCode) throws HibernateException {
        return baseDao.getAaaFollowUpLookUp(aaaCode);
    }

}
