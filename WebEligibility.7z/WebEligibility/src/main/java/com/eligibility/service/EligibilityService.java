package com.eligibility.service;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.List;

import org.hibernate.HibernateException;

import com.eligibility270.dbentities.Edi271longdesc;
import com.eligibility270.dbentities.Eligibility270withack;
import com.eligibility270.dbentities.Eligibilitysummary;
import com.eligibility270.dbentities.Insurancesummary;
import com.eligibility270.dbentities.Providersummary;
import com.eligibility270.dbentities.Subscribersummary;
import com.eligibility270.header.entities.InterchangeControlHeader;
import com.eligibility270.mastertables.entities.Deliverymethod;
import com.eligibility270.mastertables.entities.ISAEntity;
import com.eligibility270.writer.DBSequenceType;
import com.eligibility271.dbentities.AaaFollowUpLookUp;
import com.eligibility271.dbentities.AaaRejectReason;
//import com.eligibility271.beans.Ack999ErrorCodeEntity;
import com.eligibility271.dbentities.DtpDefEntity;
import com.eligibility271.dbentities.EbLookUp;
import com.eligibility271.dbentities.Edi271shortdesc;
import com.eligibility271.dbentities.Emdeonrequestresponse;
import com.eligibility271.dbentities.Patientsummary;


public interface EligibilityService<T, PK extends Serializable> {

    Serializable save(T paramT) throws HibernateException;

    ISAEntity getISA() throws HibernateException;

    Deliverymethod byDeliveryMethodName(String name);

    BigInteger nextVal(DBSequenceType sequenceType) throws Exception;

    void saveWithAck(InterchangeControlHeader interchangeCOntrolHeader, Eligibility270withack eligibility270withack) throws HibernateException;

    void saveWithShortDesc(Patientsummary patientsummary, Edi271shortdesc shEdi271shortdesc) throws HibernateException;

    Edi271shortdesc getShortDescByTraceNum(String traceNum);

    void update(T paramT) throws HibernateException;

    void saveLongDecs(Edi271longdesc longDesc, Eligibilitysummary eligibilitysummary, Insurancesummary insurancesummary, Providersummary providersummary,
            Subscribersummary subscribersummary) throws HibernateException;

    Edi271longdesc getEdi271longdescByTraceNum(String traceNum);

    Eligibility270withack getEligibility270withackByTraceNum(String traceNum) throws HibernateException;

    List<DtpDefEntity> getDtpCodeList() throws HibernateException;

    void saveEmdeon(Emdeonrequestresponse emdeon) throws HibernateException;
    
    EbLookUp getEbLookUp(String ebCode) throws HibernateException;
    
    AaaRejectReason getAaaRejectReason(String aaaCode) throws HibernateException;
    
    AaaFollowUpLookUp getAaaFollowUpLookUp(String aaaCode) throws HibernateException;
}
