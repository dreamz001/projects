
package com.eligibility.jsonschema270.beans;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.webeligibility.utils.GetPayersProvidersListUtil;
/**
 * It contains all property os Xselement for received JSON.
 * @author manishm3
 * @date Mar 11,2015
 */


public class XsElement_ {

    @Transient
    private String servicePeriod;
    
    private String systemErrorCode;
    private String systemErrorGenericDescription;
    private String responseMessage;
    private String deliveryMethod;
    private String eligibilityTracerCode;
    private String eligibilityTracerNumber;
    private String sourceEntityIdentifierCode;
    private String sourceEntityTypeQualifier;
    private String sourceNameLast;
    private String sourceNameFirst;
    private String sourceNameMiddle;
    private String sourceNameSuffix;
    private String sourceIdentificationCodeQualifier;
    private String sourceIdentificationCode;
    private String receiverEntityIdentifierCode;
    private String receiverEntityTypeQualifier;
    private String receiverLastName;
    private String receiverFirstName;
    private String receiverMiddleName;
    private String receiverSuffix;
    private String receiverIdentifierCodeQualifier;
    private String receiverIdentifierCode;
    private String receiverAddressLine1;
    private String receiverAddressLine2;
    private String receiverAddressCity;
    private String receiverAddressState;
    private String receiverAddressZipCode;
    private String receiverAddressCountry;
    private String receiverIdentificationQualifier;
    private String receiverIdentification;
    private String receiverDescription;
    private String receiverFunctionCode;
    private String receiverName;
    private String receiverCommNoQualifier1;
    private String receiverCommNo1;
    private String receiverCommNoQualifier2;
    private String receiverCommNo2;
    private String receiverCommNoQualifier3;
    private String receiverCommNo3;
    private String receiverProviderCode;
    private String receiverProviderIdentificationQualifier;
    private String receiverProviderIdentification;
    private String eligibilityEntityIdentifier;
    private String eligibilityEntityAdditionalIdentifier;
    private String primaryInsuredEntityIdentifierCode;
    private String primaryInsuredEntityTypeQualifier;
    private String primaryInsuredLastName;
    private String primaryInsuredFirstName;
    private String primaryInsuredMiddleInitial;
    private String primaryInsuredSuffix;
    private String primaryInsuredIdentifierCodeQualifier;
    private String primaryInsuredIdentifierCode;
    private String primaryInsuredAddressLine1;
    private String primaryInsuredAddressLine2;
    private String primaryInsuredAddressCity;
    private String primaryInsuredAddressState;
    private String primaryInsuredAddressZipCode;
    private String primaryInsuredAddressCountry;
    private String primaryInsuredIdentificationQualifier;
    private String primaryInsuredIdentification;
    private String primaryInsuredProviderCode;
    private String primaryInsuredProviderIdentificationQualifier;
    private String primaryInsuredProviderIdentification;
    private String primaryInsuredDemographicsDateQualifier;
    private String primaryInsuredDemographicsDateOfBirth;
    private String primaryInsuredDemographicsGenderCode;
    private String primaryInsuredIndicator;
   /* @JsonProperty("primary_insured_relationship_code")
    private String primaryInsuredRelationshipCode;*/
    private String primaryInsuredBirthSequenceNumber;
    private String primaryInsuredDateQualifier;
    private String primaryInsuredDateFormatQualifier;
    private String primaryInsuredDatePeriod;
    private String primaryInsuredServiceTypeCode;
    private String primaryInsuredServiceIdentificationQualifier;
    private String primaryInsuredProcedureCode;
    private String primaryInsuredProcedureMod1;
    private String primaryInsuredProcedureMod2;
    private String primaryInsuredProcedureMod3;
    private String primaryInsuredProcedureMod4;
    private String primaryInsuredDescription;
    private String primaryInsuredInsuranceType;
    private String primaryInsuredCoverageLevelCode;
    private String primaryInsuredSpendAmountQualifierCode;
    private String primaryInsuredSpendMonetaryAmount;
    private String primaryInsuredListQualifierCode;
    private String primaryInsuredIndustryCode;
    private String primaryInsuredInformationIdentificationQualifier;
    private String primaryInsuredInformationIdentification;
    private String primaryInsuredEligibilityDateQualifier;
    private String primaryInsuredEligibilityDateFormatQualifier;
    private String primaryInsuredEligibilityDatePeriod;
    private String dependentEntityIdentifierCode;
    private String dependentEntityTypeQualifier;
    private String dependentLastName;
    private String dependentFirstName;
    private String dependentMiddleInitial;
    private String dependentSuffix;
    private String dependentAddressLine1;
    private String dependentAddressLine2;
    private String dependentAddressCity;
    private String dependentAddressState;
    private String dependentAddressZipCode;
    private String dependentAddressCountry;
    private String dependentIdentificationQualifier;
    private String dependentIdentification;
    private String dependentProviderCode;
    private String dependentProviderIdentificationQualifier;
    private String dependentProviderIdentification;
    private String dependentDemographicsDateQualifier;
    private String dependentDemographicsDateOfBirth;
    private String dependentDemographicsGenderCode;
    private String dependentInsuredIndicator;
   /* @JsonProperty("dependent_individual_relationship_code")
    private String dependentIndividualRelationshipCode;*/
    private String dependentBirthSequenceNumber;
    private String dependentDateQualifier;
    private String dependentDateFormatQualifier;
    private String dependentDatePeriod;
    private String dependentServiceTypeCode;
    private String dependentServiceIdentificationQualifier;
    private String dependentProcedureCode;
    private String dependentProcedureMod1;
    private String dependentProcedureMod2;
    private String dependentProcedureMod3;
    private String dependentProcedureMod4;
    private String dependentDescription;
    private String dependentInsuranceType;
    private String dependentCoverageLevelCode;
    private String dependentListQualifierCode;
    private String dependentIndustryCode;
    private String dependentInformationIdentificationQualifier;
    private String dependentInformationIdentification;
    private String dependentEligibilityDateQualifier;
    private String dependentEligibilityDateFormatQualifier;
    private String dependentEligibilityDatePeriod;
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    private String relationShipCode;
    
    private List<String> payerNameList;


    public String getServicePeriod() {
        return servicePeriod.trim();
    }

    public void setServicePeriod(String servicePeriod) {
        this.servicePeriod = servicePeriod.trim();
    }

    public String getSystemErrorCode() {
        return systemErrorCode;
    }

    public void setSystemErrorCode(String systemErrorCode) {
        this.systemErrorCode = systemErrorCode;
    }

    public String getSystemErrorGenericDescription() {
        return systemErrorGenericDescription;
    }

    public void setSystemErrorGenericDescription(String systemErrorGenericDescription) {
        this.systemErrorGenericDescription = systemErrorGenericDescription;
    }

    public String getResponseMessage() {
        return responseMessage;
    }

    public void setResponseMessage(String responseMessage) {
        this.responseMessage = responseMessage;
    }

    public String getDeliveryMethod() {
        return deliveryMethod;
    }

    public void setDeliveryMethod(String deliveryMethod) {
        this.deliveryMethod = deliveryMethod;
    }

    public String getEligibilityTracerCode() {
        return eligibilityTracerCode;
    }

    public void setEligibilityTracerCode(String eligibilityTracerCode) {
        this.eligibilityTracerCode = eligibilityTracerCode;
    }

    public String getEligibilityTracerNumber() {
        return eligibilityTracerNumber;
    }

    public void setEligibilityTracerNumber(String eligibilityTracerNumber) {
        this.eligibilityTracerNumber = eligibilityTracerNumber;
    }

    public String getSourceEntityIdentifierCode() {
        return sourceEntityIdentifierCode;
    }

    public void setSourceEntityIdentifierCode(String sourceEntityIdentifierCode) {
        this.sourceEntityIdentifierCode = sourceEntityIdentifierCode;
    }

    public String getSourceEntityTypeQualifier() {
        return sourceEntityTypeQualifier;
    }

    public void setSourceEntityTypeQualifier(String sourceEntityTypeQualifier) {
        this.sourceEntityTypeQualifier = sourceEntityTypeQualifier;
    }

    public String getSourceNameLast() {
        return sourceNameLast.trim();
    }

    public void setSourceNameLast(String sourceNameLast) {
        this.sourceNameLast = sourceNameLast.trim();
    }

    public String getSourceNameFirst() {
        return sourceNameFirst.trim();
    }

    public void setSourceNameFirst(String sourceNameFirst) {
        this.sourceNameFirst = sourceNameFirst.trim();
    }

    public String getSourceNameMiddle() {
        return sourceNameMiddle;
    }

    public void setSourceNameMiddle(String sourceNameMiddle) {
        this.sourceNameMiddle = sourceNameMiddle;
    }

    public String getSourceNameSuffix() {
        return sourceNameSuffix;
    }

    public void setSourceNameSuffix(String sourceNameSuffix) {
        this.sourceNameSuffix = sourceNameSuffix;
    }

    public String getSourceIdentificationCodeQualifier() {
        return sourceIdentificationCodeQualifier;
    }

    public void setSourceIdentificationCodeQualifier(String sourceIdentificationCodeQualifier) {
        this.sourceIdentificationCodeQualifier = sourceIdentificationCodeQualifier;
    }

    public String getSourceIdentificationCode() {
        return sourceIdentificationCode;
    }

    public void setSourceIdentificationCode(String sourceIdentificationCode) {
        this.sourceIdentificationCode = sourceIdentificationCode;
    }

    public String getReceiverEntityIdentifierCode() {
        return receiverEntityIdentifierCode;
    }

    public void setReceiverEntityIdentifierCode(String receiverEntityIdentifierCode) {
        this.receiverEntityIdentifierCode = receiverEntityIdentifierCode;
    }

    public String getReceiverEntityTypeQualifier() {
        return receiverEntityTypeQualifier;
    }

    public void setReceiverEntityTypeQualifier(String receiverEntityTypeQualifier) {
        this.receiverEntityTypeQualifier = receiverEntityTypeQualifier;
    }

    public String getReceiverLastName() {
        return receiverLastName;
    }

    public void setReceiverLastName(String receiverLastName) {
        this.receiverLastName = receiverLastName;
    }

    public String getReceiverFirstName() {
        return receiverFirstName;
    }

    public void setReceiverFirstName(String receiverFirstName) {
        this.receiverFirstName = receiverFirstName;
    }

    public String getReceiverMiddleName() {
        return receiverMiddleName;
    }

    public void setReceiverMiddleName(String receiverMiddleName) {
        this.receiverMiddleName = receiverMiddleName;
    }

    public String getReceiverSuffix() {
        return receiverSuffix;
    }

    public void setReceiverSuffix(String receiverSuffix) {
        this.receiverSuffix = receiverSuffix;
    }

    public String getReceiverIdentifierCodeQualifier() {
        return receiverIdentifierCodeQualifier;
    }

    public void setReceiverIdentifierCodeQualifier(String receiverIdentifierCodeQualifier) {
        this.receiverIdentifierCodeQualifier = receiverIdentifierCodeQualifier;
    }

    public String getReceiverIdentifierCode() {
        return receiverIdentifierCode;
    }

    public void setReceiverIdentifierCode(String receiverIdentifierCode) {
        this.receiverIdentifierCode = receiverIdentifierCode;
    }

    public String getReceiverAddressLine1() {
        return receiverAddressLine1;
    }

    public void setReceiverAddressLine1(String receiverAddressLine1) {
        this.receiverAddressLine1 = receiverAddressLine1;
    }

    public String getReceiverAddressLine2() {
        return receiverAddressLine2;
    }

    public void setReceiverAddressLine2(String receiverAddressLine2) {
        this.receiverAddressLine2 = receiverAddressLine2;
    }

    public String getReceiverAddressCity() {
        return receiverAddressCity;
    }

    public void setReceiverAddressCity(String receiverAddressCity) {
        this.receiverAddressCity = receiverAddressCity;
    }

    public String getReceiverAddressState() {
        return receiverAddressState;
    }

    public void setReceiverAddressState(String receiverAddressState) {
        this.receiverAddressState = receiverAddressState;
    }

    public String getReceiverAddressZipCode() {
        return receiverAddressZipCode;
    }

    public void setReceiverAddressZipCode(String receiverAddressZipCode) {
        this.receiverAddressZipCode = receiverAddressZipCode;
    }

    public String getReceiverAddressCountry() {
        return receiverAddressCountry;
    }

    public void setReceiverAddressCountry(String receiverAddressCountry) {
        this.receiverAddressCountry = receiverAddressCountry;
    }

    public String getReceiverIdentificationQualifier() {
        return receiverIdentificationQualifier;
    }

    public void setReceiverIdentificationQualifier(String receiverIdentificationQualifier) {
        this.receiverIdentificationQualifier = receiverIdentificationQualifier;
    }

    public String getReceiverIdentification() {
        return receiverIdentification;
    }

    public void setReceiverIdentification(String receiverIdentification) {
        this.receiverIdentification = receiverIdentification;
    }

    public String getReceiverDescription() {
        return receiverDescription;
    }

    public void setReceiverDescription(String receiverDescription) {
        this.receiverDescription = receiverDescription;
    }

    public String getReceiverFunctionCode() {
        return receiverFunctionCode;
    }

    public void setReceiverFunctionCode(String receiverFunctionCode) {
        this.receiverFunctionCode = receiverFunctionCode;
    }

    public String getReceiverName() {
        return receiverName;
    }

    public void setReceiverName(String receiverName) {
        this.receiverName = receiverName;
    }

    public String getReceiverCommNoQualifier1() {
        return receiverCommNoQualifier1;
    }

    public void setReceiverCommNoQualifier1(String receiverCommNoQualifier1) {
        this.receiverCommNoQualifier1 = receiverCommNoQualifier1;
    }

    public String getReceiverCommNo1() {
        return receiverCommNo1;
    }

    public void setReceiverCommNo1(String receiverCommNo1) {
        this.receiverCommNo1 = receiverCommNo1;
    }

    public String getReceiverCommNoQualifier2() {
        return receiverCommNoQualifier2;
    }

    public void setReceiverCommNoQualifier2(String receiverCommNoQualifier2) {
        this.receiverCommNoQualifier2 = receiverCommNoQualifier2;
    }

    public String getReceiverCommNo2() {
        return receiverCommNo2;
    }

    public void setReceiverCommNo2(String receiverCommNo2) {
        this.receiverCommNo2 = receiverCommNo2;
    }

    public String getReceiverCommNoQualifier3() {
        return receiverCommNoQualifier3;
    }

    public void setReceiverCommNoQualifier3(String receiverCommNoQualifier3) {
        this.receiverCommNoQualifier3 = receiverCommNoQualifier3;
    }

    public String getReceiverCommNo3() {
        return receiverCommNo3;
    }

    public void setReceiverCommNo3(String receiverCommNo3) {
        this.receiverCommNo3 = receiverCommNo3;
    }

    public String getReceiverProviderCode() {
        return receiverProviderCode;
    }

    public void setReceiverProviderCode(String receiverProviderCode) {
        this.receiverProviderCode = receiverProviderCode;
    }

    public String getReceiverProviderIdentificationQualifier() {
        return receiverProviderIdentificationQualifier;
    }

    public void setReceiverProviderIdentificationQualifier(String receiverProviderIdentificationQualifier) {
        this.receiverProviderIdentificationQualifier = receiverProviderIdentificationQualifier;
    }

    public String getReceiverProviderIdentification() {
        return receiverProviderIdentification;
    }

    public void setReceiverProviderIdentification(String receiverProviderIdentification) {
        this.receiverProviderIdentification = receiverProviderIdentification;
    }

    public String getEligibilityEntityIdentifier() {
        return eligibilityEntityIdentifier;
    }

    public void setEligibilityEntityIdentifier(String eligibilityEntityIdentifier) {
        this.eligibilityEntityIdentifier = eligibilityEntityIdentifier;
    }

    public String getEligibilityEntityAdditionalIdentifier() {
        return eligibilityEntityAdditionalIdentifier;
    }

    public void setEligibilityEntityAdditionalIdentifier(String eligibilityEntityAdditionalIdentifier) {
        this.eligibilityEntityAdditionalIdentifier = eligibilityEntityAdditionalIdentifier;
    }

    public String getPrimaryInsuredEntityIdentifierCode() {
        return primaryInsuredEntityIdentifierCode;
    }

    public void setPrimaryInsuredEntityIdentifierCode(String primaryInsuredEntityIdentifierCode) {
        this.primaryInsuredEntityIdentifierCode = primaryInsuredEntityIdentifierCode;
    }

    public String getPrimaryInsuredEntityTypeQualifier() {
        return primaryInsuredEntityTypeQualifier;
    }

    public void setPrimaryInsuredEntityTypeQualifier(String primaryInsuredEntityTypeQualifier) {
        this.primaryInsuredEntityTypeQualifier = primaryInsuredEntityTypeQualifier;
    }

    public String getPrimaryInsuredLastName() {
        return primaryInsuredLastName;
    }

    public void setPrimaryInsuredLastName(String primaryInsuredLastName) {
        this.primaryInsuredLastName = primaryInsuredLastName;
    }

    public String getPrimaryInsuredFirstName() {
        return primaryInsuredFirstName;
    }

    /**
     * 
     * @param primaryInsuredFirstName
     *     The primary_insured_first_name
     */
    @JsonProperty("primary_insured_first_name")
    public void setPrimaryInsuredFirstName(String primaryInsuredFirstName) {
        this.primaryInsuredFirstName = primaryInsuredFirstName;
    }

    /**
     * 
     * @return
     *     The primaryInsuredMiddleInitial
     */
    @JsonProperty("primary_insured_middle_initial")
    public String getPrimaryInsuredMiddleInitial() {
        return primaryInsuredMiddleInitial;
    }

    /**
     * 
     * @param primaryInsuredMiddleInitial
     *     The primary_insured_middle_initial
     */
    @JsonProperty("primary_insured_middle_initial")
    public void setPrimaryInsuredMiddleInitial(String primaryInsuredMiddleInitial) {
        this.primaryInsuredMiddleInitial = primaryInsuredMiddleInitial;
    }

    /**
     * 
     * @return
     *     The primaryInsuredSuffix
     */
    @JsonProperty("primary_insured_suffix")
    public String getPrimaryInsuredSuffix() {
        return primaryInsuredSuffix;
    }

    /**
     * 
     * @param primaryInsuredSuffix
     *     The primary_insured_suffix
     */
    @JsonProperty("primary_insured_suffix")
    public void setPrimaryInsuredSuffix(String primaryInsuredSuffix) {
        this.primaryInsuredSuffix = primaryInsuredSuffix;
    }

    /**
     * 
     * @return
     *     The primaryInsuredIdentifierCodeQualifier
     */
    @JsonProperty("primary_insured_identifier_code_qualifier")
    public String getPrimaryInsuredIdentifierCodeQualifier() {
        return primaryInsuredIdentifierCodeQualifier.trim();
    }

    /**
     * 
     * @param primaryInsuredIdentifierCodeQualifier
     *     The primary_insured_identifier_code_qualifier
     */
    @JsonProperty("primary_insured_identifier_code_qualifier")
    public void setPrimaryInsuredIdentifierCodeQualifier(String primaryInsuredIdentifierCodeQualifier) {
        this.primaryInsuredIdentifierCodeQualifier = primaryInsuredIdentifierCodeQualifier.trim();
    }

    /**
     * 
     * @return
     *     The primaryInsuredIdentifierCode
     */
    @JsonProperty("primary_insured_identifier_code")
    public String getPrimaryInsuredIdentifierCode() {
        return primaryInsuredIdentifierCode.trim();
    }

    /**
     * 
     * @param primaryInsuredIdentifierCode
     *     The primary_insured_identifier_code
     */
    @JsonProperty("primary_insured_identifier_code")
    public void setPrimaryInsuredIdentifierCode(String primaryInsuredIdentifierCode) {
        this.primaryInsuredIdentifierCode = primaryInsuredIdentifierCode.trim();
    }

    /**
     * 
     * @return
     *     The primaryInsuredAddressLine1
     */
    @JsonProperty("primary_insured_address_line1")
    public String getPrimaryInsuredAddressLine1() {
        return primaryInsuredAddressLine1;
    }

    /**
     * 
     * @param primaryInsuredAddressLine1
     *     The primary_insured_address_line1
     */
    @JsonProperty("primary_insured_address_line1")
    public void setPrimaryInsuredAddressLine1(String primaryInsuredAddressLine1) {
        this.primaryInsuredAddressLine1 = primaryInsuredAddressLine1;
    }

    /**
     * 
     * @return
     *     The primaryInsuredAddressLine2
     */
    @JsonProperty("primary_insured_address_line2")
    public String getPrimaryInsuredAddressLine2() {
        return primaryInsuredAddressLine2;
    }

    /**
     * 
     * @param primaryInsuredAddressLine2
     *     The primary_insured_address_line2
     */
    @JsonProperty("primary_insured_address_line2")
    public void setPrimaryInsuredAddressLine2(String primaryInsuredAddressLine2) {
        this.primaryInsuredAddressLine2 = primaryInsuredAddressLine2;
    }

    /**
     * 
     * @return
     *     The primaryInsuredAddressCity
     */
    @JsonProperty("primary_insured_address_city")
    public String getPrimaryInsuredAddressCity() {
        return primaryInsuredAddressCity;
    }

    /**
     * 
     * @param primaryInsuredAddressCity
     *     The primary_insured_address_city
     */
    @JsonProperty("primary_insured_address_city")
    public void setPrimaryInsuredAddressCity(String primaryInsuredAddressCity) {
        this.primaryInsuredAddressCity = primaryInsuredAddressCity;
    }

    /**
     * 
     * @return
     *     The primaryInsuredAddressState
     */
    @JsonProperty("primary_insured_address_state")
    public String getPrimaryInsuredAddressState() {
        return primaryInsuredAddressState;
    }

    /**
     * 
     * @param primaryInsuredAddressState
     *     The primary_insured_address_state
     */
    @JsonProperty("primary_insured_address_state")
    public void setPrimaryInsuredAddressState(String primaryInsuredAddressState) {
        this.primaryInsuredAddressState = primaryInsuredAddressState;
    }

    /**
     * 
     * @return
     *     The primaryInsuredAddressZipCode
     */
    @JsonProperty("primary_insured_address_zip_code")
    public String getPrimaryInsuredAddressZipCode() {
        return primaryInsuredAddressZipCode;
    }

    /**
     * 
     * @param primaryInsuredAddressZipCode
     *     The primary_insured_address_zip_code
     */
    @JsonProperty("primary_insured_address_zip_code")
    public void setPrimaryInsuredAddressZipCode(String primaryInsuredAddressZipCode) {
        this.primaryInsuredAddressZipCode = primaryInsuredAddressZipCode;
    }

    /**
     * 
     * @return
     *     The primaryInsuredAddressCountry
     */
    @JsonProperty("primary_insured_address_country")
    public String getPrimaryInsuredAddressCountry() {
        return primaryInsuredAddressCountry;
    }

    /**
     * 
     * @param primaryInsuredAddressCountry
     *     The primary_insured_address_country
     */
    @JsonProperty("primary_insured_address_country")
    public void setPrimaryInsuredAddressCountry(String primaryInsuredAddressCountry) {
        this.primaryInsuredAddressCountry = primaryInsuredAddressCountry;
    }

    /**
     * 
     * @return
     *     The primaryInsuredIdentificationQualifier
     */
    @JsonProperty("primary_insured_identification_qualifier")
    public String getPrimaryInsuredIdentificationQualifier() {
        return primaryInsuredIdentificationQualifier;
    }

    /**
     * 
     * @param primaryInsuredIdentificationQualifier
     *     The primary_insured_identification_qualifier
     */
    @JsonProperty("primary_insured_identification_qualifier")
    public void setPrimaryInsuredIdentificationQualifier(String primaryInsuredIdentificationQualifier) {
        this.primaryInsuredIdentificationQualifier = primaryInsuredIdentificationQualifier;
    }

    /**
     * 
     * @return
     *     The primaryInsuredIdentification
     */
    @JsonProperty("primary_insured_identification")
    public String getPrimaryInsuredIdentification() {
        return primaryInsuredIdentification;
    }

    /**
     * 
     * @param primaryInsuredIdentification
     *     The primary_insured_identification
     */
    @JsonProperty("primary_insured_identification")
    public void setPrimaryInsuredIdentification(String primaryInsuredIdentification) {
        this.primaryInsuredIdentification = primaryInsuredIdentification;
    }

    /**
     * 
     * @return
     *     The primaryInsuredProviderCode
     */
    @JsonProperty("primary_insured_provider_code")
    public String getPrimaryInsuredProviderCode() {
        return primaryInsuredProviderCode;
    }

    /**
     * 
     * @param primaryInsuredProviderCode
     *     The primary_insured_provider_code
     */
    @JsonProperty("primary_insured_provider_code")
    public void setPrimaryInsuredProviderCode(String primaryInsuredProviderCode) {
        this.primaryInsuredProviderCode = primaryInsuredProviderCode;
    }

    /**
     * 
     * @return
     *     The primaryInsuredProviderIdentificationQualifier
     */
    @JsonProperty("primary_insured_provider_identification_qualifier")
    public String getPrimaryInsuredProviderIdentificationQualifier() {
        return primaryInsuredProviderIdentificationQualifier;
    }

    /**
     * 
     * @param primaryInsuredProviderIdentificationQualifier
     *     The primary_insured_provider_identification_qualifier
     */
    @JsonProperty("primary_insured_provider_identification_qualifier")
    public void setPrimaryInsuredProviderIdentificationQualifier(String primaryInsuredProviderIdentificationQualifier) {
        this.primaryInsuredProviderIdentificationQualifier = primaryInsuredProviderIdentificationQualifier;
    }

    /**
     * 
     * @return
     *     The primaryInsuredProviderIdentification
     */
    @JsonProperty("primary_insured_provider_identification")
    public String getPrimaryInsuredProviderIdentification() {
        return primaryInsuredProviderIdentification;
    }

    /**
     * 
     * @param primaryInsuredProviderIdentification
     *     The primary_insured_provider_identification
     */
    @JsonProperty("primary_insured_provider_identification")
    public void setPrimaryInsuredProviderIdentification(String primaryInsuredProviderIdentification) {
        this.primaryInsuredProviderIdentification = primaryInsuredProviderIdentification;
    }

    /**
     * 
     * @return
     *     The primaryInsuredDemographicsDateQualifier
     */
    @JsonProperty("primary_insured_demographics_date_qualifier")
    public String getPrimaryInsuredDemographicsDateQualifier() {
        return primaryInsuredDemographicsDateQualifier;
    }

    /**
     * 
     * @param primaryInsuredDemographicsDateQualifier
     *     The primary_insured_demographics_date_qualifier
     */
    @JsonProperty("primary_insured_demographics_date_qualifier")
    public void setPrimaryInsuredDemographicsDateQualifier(String primaryInsuredDemographicsDateQualifier) {
        this.primaryInsuredDemographicsDateQualifier = primaryInsuredDemographicsDateQualifier;
    }

    /**
     * 
     * @return
     *     The primaryInsuredDemographicsDateOfBirth
     */
    @JsonProperty("primary_insured_demographics_date_of_birth")
    public String getPrimaryInsuredDemographicsDateOfBirth() {
        return primaryInsuredDemographicsDateOfBirth.trim();
    }

    /**
     * 
     * @param primaryInsuredDemographicsDateOfBirth
     *     The primary_insured_demographics_date_of_birth
     */
    @JsonProperty("primary_insured_demographics_date_of_birth")
    public void setPrimaryInsuredDemographicsDateOfBirth(String primaryInsuredDemographicsDateOfBirth) {
        this.primaryInsuredDemographicsDateOfBirth = primaryInsuredDemographicsDateOfBirth.trim();
    }

    /**
     * 
     * @return
     *     The primaryInsuredDemographicsGenderCode
     */
    @JsonProperty("primary_insured_demographics_gender_code")
    public String getPrimaryInsuredDemographicsGenderCode() {
        return primaryInsuredDemographicsGenderCode.trim();
    }

    /**
     * 
     * @param primaryInsuredDemographicsGenderCode
     *     The primary_insured_demographics_gender_code
     */
    @JsonProperty("primary_insured_demographics_gender_code")
    public void setPrimaryInsuredDemographicsGenderCode(String primaryInsuredDemographicsGenderCode) {
        this.primaryInsuredDemographicsGenderCode = primaryInsuredDemographicsGenderCode.trim();
    }

    /**
     * 
     * @return
     *     The primaryInsuredIndicator
     */
    @JsonProperty("primary_insured_indicator")
    public String getPrimaryInsuredIndicator() {
        return primaryInsuredIndicator;
    }

    /**
     * 
     * @param primaryInsuredIndicator
     *     The primary_insured_indicator
     */
    @JsonProperty("primary_insured_indicator")
    public void setPrimaryInsuredIndicator(String primaryInsuredIndicator) {
        this.primaryInsuredIndicator = primaryInsuredIndicator;
    }

    /**
     * 
     * @return
     *     The primaryInsuredRelationshipCode
     */
    /*@JsonProperty("primary_insured_relationship_code")
    public String getPrimaryInsuredRelationshipCode() {
        return primaryInsuredRelationshipCode;
    }*/

    /**
     * 
     * @param primaryInsuredRelationshipCode
     *     The primary_insured_relationship_code
     */
   /* @JsonProperty("primary_insured_relationship_code")
    public void setPrimaryInsuredRelationshipCode(String primaryInsuredRelationshipCode) {
        this.primaryInsuredRelationshipCode = primaryInsuredRelationshipCode;
    }*/

    /**
     * 
     * @return
     *     The primaryInsuredBirthSequenceNumber
     */
    @JsonProperty("primary_insured_birth_sequence_number")
    public String getPrimaryInsuredBirthSequenceNumber() {
        return primaryInsuredBirthSequenceNumber;
    }

    /**
     * 
     * @param primaryInsuredBirthSequenceNumber
     *     The primary_insured_birth_sequence_number
     */
    @JsonProperty("primary_insured_birth_sequence_number")
    public void setPrimaryInsuredBirthSequenceNumber(String primaryInsuredBirthSequenceNumber) {
        this.primaryInsuredBirthSequenceNumber = primaryInsuredBirthSequenceNumber;
    }

    /**
     * 
     * @return
     *     The primaryInsuredDateQualifier
     */
    @JsonProperty("primary_insured_date_qualifier")
    public String getPrimaryInsuredDateQualifier() {
        return primaryInsuredDateQualifier;
    }

    /**
     * 
     * @param primaryInsuredDateQualifier
     *     The primary_insured_date_qualifier
     */
    @JsonProperty("primary_insured_date_qualifier")
    public void setPrimaryInsuredDateQualifier(String primaryInsuredDateQualifier) {
        this.primaryInsuredDateQualifier = primaryInsuredDateQualifier;
    }

    /**
     * 
     * @return
     *     The primaryInsuredDateFormatQualifier
     */
    @JsonProperty("primary_insured_date_format_qualifier")
    public String getPrimaryInsuredDateFormatQualifier() {
        return primaryInsuredDateFormatQualifier;
    }

    /**
     * 
     * @param primaryInsuredDateFormatQualifier
     *     The primary_insured_date_format_qualifier
     */
    @JsonProperty("primary_insured_date_format_qualifier")
    public void setPrimaryInsuredDateFormatQualifier(String primaryInsuredDateFormatQualifier) {
        this.primaryInsuredDateFormatQualifier = primaryInsuredDateFormatQualifier;
    }

    /**
     * 
     * @return
     *     The primaryInsuredDatePeriod
     */
    @JsonProperty("primary_insured_date_period")
    public String getPrimaryInsuredDatePeriod() {
        return primaryInsuredDatePeriod;
    }

    /**
     * 
     * @param primaryInsuredDatePeriod
     *     The primary_insured_date_period
     */
    @JsonProperty("primary_insured_date_period")
    public void setPrimaryInsuredDatePeriod(String primaryInsuredDatePeriod) {
        this.primaryInsuredDatePeriod = primaryInsuredDatePeriod;
    }

    /**
     * 
     * @return
     *     The primaryInsuredServiceTypeCode
     */
    @JsonProperty("primary_insured_service_type_code")
    public String getPrimaryInsuredServiceTypeCode() {
        return primaryInsuredServiceTypeCode;
    }

    /**
     * 
     * @param primaryInsuredServiceTypeCode
     *     The primary_insured_service_type_code
     */
    @JsonProperty("primary_insured_service_type_code")
    public void setPrimaryInsuredServiceTypeCode(String primaryInsuredServiceTypeCode) {
        this.primaryInsuredServiceTypeCode = primaryInsuredServiceTypeCode;
    }

    /**
     * 
     * @return
     *     The primaryInsuredServiceIdentificationQualifier
     */
    @JsonProperty("primary_insured_service_identification_qualifier")
    public String getPrimaryInsuredServiceIdentificationQualifier() {
        return primaryInsuredServiceIdentificationQualifier;
    }

    /**
     * 
     * @param primaryInsuredServiceIdentificationQualifier
     *     The primary_insured_service_identification_qualifier
     */
    @JsonProperty("primary_insured_service_identification_qualifier")
    public void setPrimaryInsuredServiceIdentificationQualifier(String primaryInsuredServiceIdentificationQualifier) {
        this.primaryInsuredServiceIdentificationQualifier = primaryInsuredServiceIdentificationQualifier;
    }

    /**
     * 
     * @return
     *     The primaryInsuredProcedureCode
     */
    @JsonProperty("primary_insured_procedure_code")
    public String getPrimaryInsuredProcedureCode() {
        return primaryInsuredProcedureCode;
    }

    /**
     * 
     * @param primaryInsuredProcedureCode
     *     The primary_insured_procedure_code
     */
    @JsonProperty("primary_insured_procedure_code")
    public void setPrimaryInsuredProcedureCode(String primaryInsuredProcedureCode) {
        this.primaryInsuredProcedureCode = primaryInsuredProcedureCode;
    }

    /**
     * 
     * @return
     *     The primaryInsuredProcedureMod1
     */
    @JsonProperty("primary_insured_procedure_mod1")
    public String getPrimaryInsuredProcedureMod1() {
        return primaryInsuredProcedureMod1;
    }

    /**
     * 
     * @param primaryInsuredProcedureMod1
     *     The primary_insured_procedure_mod1
     */
    @JsonProperty("primary_insured_procedure_mod1")
    public void setPrimaryInsuredProcedureMod1(String primaryInsuredProcedureMod1) {
        this.primaryInsuredProcedureMod1 = primaryInsuredProcedureMod1;
    }

    /**
     * 
     * @return
     *     The primaryInsuredProcedureMod2
     */
    @JsonProperty("primary_insured_procedure_mod2")
    public String getPrimaryInsuredProcedureMod2() {
        return primaryInsuredProcedureMod2;
    }

    /**
     * 
     * @param primaryInsuredProcedureMod2
     *     The primary_insured_procedure_mod2
     */
    @JsonProperty("primary_insured_procedure_mod2")
    public void setPrimaryInsuredProcedureMod2(String primaryInsuredProcedureMod2) {
        this.primaryInsuredProcedureMod2 = primaryInsuredProcedureMod2;
    }

    /**
     * 
     * @return
     *     The primaryInsuredProcedureMod3
     */
    @JsonProperty("primary_insured_procedure_mod3")
    public String getPrimaryInsuredProcedureMod3() {
        return primaryInsuredProcedureMod3;
    }

    /**
     * 
     * @param primaryInsuredProcedureMod3
     *     The primary_insured_procedure_mod3
     */
    @JsonProperty("primary_insured_procedure_mod3")
    public void setPrimaryInsuredProcedureMod3(String primaryInsuredProcedureMod3) {
        this.primaryInsuredProcedureMod3 = primaryInsuredProcedureMod3;
    }

    /**
     * 
     * @return
     *     The primaryInsuredProcedureMod4
     */
    @JsonProperty("primary_insured_procedure_mod4")
    public String getPrimaryInsuredProcedureMod4() {
        return primaryInsuredProcedureMod4;
    }

    /**
     * 
     * @param primaryInsuredProcedureMod4
     *     The primary_insured_procedure_mod4
     */
    @JsonProperty("primary_insured_procedure_mod4")
    public void setPrimaryInsuredProcedureMod4(String primaryInsuredProcedureMod4) {
        this.primaryInsuredProcedureMod4 = primaryInsuredProcedureMod4;
    }

    /**
     * 
     * @return
     *     The primaryInsuredDescription
     */
    @JsonProperty("primary_insured_description")
    public String getPrimaryInsuredDescription() {
        return primaryInsuredDescription;
    }

    /**
     * 
     * @param primaryInsuredDescription
     *     The primary_insured_description
     */
    @JsonProperty("primary_insured_description")
    public void setPrimaryInsuredDescription(String primaryInsuredDescription) {
        this.primaryInsuredDescription = primaryInsuredDescription;
    }

    /**
     * 
     * @return
     *     The primaryInsuredInsuranceType
     */
    @JsonProperty("primary_insured_insurance_type")
    public String getPrimaryInsuredInsuranceType() {
        return primaryInsuredInsuranceType;
    }

    /**
     * 
     * @param primaryInsuredInsuranceType
     *     The primary_insured_insurance_type
     */
    @JsonProperty("primary_insured_insurance_type")
    public void setPrimaryInsuredInsuranceType(String primaryInsuredInsuranceType) {
        this.primaryInsuredInsuranceType = primaryInsuredInsuranceType;
    }

    /**
     * 
     * @return
     *     The primaryInsuredCoverageLevelCode
     */
    @JsonProperty("primary_insured_coverage_level_code")
    public String getPrimaryInsuredCoverageLevelCode() {
        return primaryInsuredCoverageLevelCode;
    }

    /**
     * 
     * @param primaryInsuredCoverageLevelCode
     *     The primary_insured_coverage_level_code
     */
    @JsonProperty("primary_insured_coverage_level_code")
    public void setPrimaryInsuredCoverageLevelCode(String primaryInsuredCoverageLevelCode) {
        this.primaryInsuredCoverageLevelCode = primaryInsuredCoverageLevelCode;
    }

    /**
     * 
     * @return
     *     The primaryInsuredSpendAmountQualifierCode
     */
    @JsonProperty("primary_insured_spend_amount_qualifier_code")
    public String getPrimaryInsuredSpendAmountQualifierCode() {
        return primaryInsuredSpendAmountQualifierCode;
    }

    /**
     * 
     * @param primaryInsuredSpendAmountQualifierCode
     *     The primary_insured_spend_amount_qualifier_code
     */
    @JsonProperty("primary_insured_spend_amount_qualifier_code")
    public void setPrimaryInsuredSpendAmountQualifierCode(String primaryInsuredSpendAmountQualifierCode) {
        this.primaryInsuredSpendAmountQualifierCode = primaryInsuredSpendAmountQualifierCode;
    }

    /**
     * 
     * @return
     *     The primaryInsuredSpendMonetaryAmount
     */
    @JsonProperty("primary_insured_spend_monetary_amount")
    public String getPrimaryInsuredSpendMonetaryAmount() {
        return primaryInsuredSpendMonetaryAmount;
    }

    /**
     * 
     * @param primaryInsuredSpendMonetaryAmount
     *     The primary_insured_spend_monetary_amount
     */
    @JsonProperty("primary_insured_spend_monetary_amount")
    public void setPrimaryInsuredSpendMonetaryAmount(String primaryInsuredSpendMonetaryAmount) {
        this.primaryInsuredSpendMonetaryAmount = primaryInsuredSpendMonetaryAmount;
    }

    /**
     * 
     * @return
     *     The primaryInsuredListQualifierCode
     */
    @JsonProperty("primary_insured_list_qualifier_code")
    public String getPrimaryInsuredListQualifierCode() {
        return primaryInsuredListQualifierCode;
    }

    /**
     * 
     * @param primaryInsuredListQualifierCode
     *     The primary_insured_list_qualifier_code
     */
    @JsonProperty("primary_insured_list_qualifier_code")
    public void setPrimaryInsuredListQualifierCode(String primaryInsuredListQualifierCode) {
        this.primaryInsuredListQualifierCode = primaryInsuredListQualifierCode;
    }

    /**
     * 
     * @return
     *     The primaryInsuredIndustryCode
     */
    @JsonProperty("primary_insured_industry_code")
    public String getPrimaryInsuredIndustryCode() {
        return primaryInsuredIndustryCode;
    }

    /**
     * 
     * @param primaryInsuredIndustryCode
     *     The primary_insured_industry_code
     */
    @JsonProperty("primary_insured_industry_code")
    public void setPrimaryInsuredIndustryCode(String primaryInsuredIndustryCode) {
        this.primaryInsuredIndustryCode = primaryInsuredIndustryCode;
    }

    /**
     * 
     * @return
     *     The primaryInsuredInformationIdentificationQualifier
     */
    @JsonProperty("primary_insured_information_identification_qualifier")
    public String getPrimaryInsuredInformationIdentificationQualifier() {
        return primaryInsuredInformationIdentificationQualifier;
    }

    /**
     * 
     * @param primaryInsuredInformationIdentificationQualifier
     *     The primary_insured_information_identification_qualifier
     */
    @JsonProperty("primary_insured_information_identification_qualifier")
    public void setPrimaryInsuredInformationIdentificationQualifier(String primaryInsuredInformationIdentificationQualifier) {
        this.primaryInsuredInformationIdentificationQualifier = primaryInsuredInformationIdentificationQualifier;
    }

    /**
     * 
     * @return
     *     The primaryInsuredInformationIdentification
     */
    @JsonProperty("primary_insured_information_identification")
    public String getPrimaryInsuredInformationIdentification() {
        return primaryInsuredInformationIdentification;
    }

    /**
     * 
     * @param primaryInsuredInformationIdentification
     *     The primary_insured_information_identification
     */
    @JsonProperty("primary_insured_information_identification")
    public void setPrimaryInsuredInformationIdentification(String primaryInsuredInformationIdentification) {
        this.primaryInsuredInformationIdentification = primaryInsuredInformationIdentification;
    }

    /**
     * 
     * @return
     *     The primaryInsuredEligibilityDateQualifier
     */
    @JsonProperty("primary_insured_eligibility_date_qualifier")
    public String getPrimaryInsuredEligibilityDateQualifier() {
        return primaryInsuredEligibilityDateQualifier;
    }

    /**
     * 
     * @param primaryInsuredEligibilityDateQualifier
     *     The primary_insured_eligibility_date_qualifier
     */
    @JsonProperty("primary_insured_eligibility_date_qualifier")
    public void setPrimaryInsuredEligibilityDateQualifier(String primaryInsuredEligibilityDateQualifier) {
        this.primaryInsuredEligibilityDateQualifier = primaryInsuredEligibilityDateQualifier;
    }

    /**
     * 
     * @return
     *     The primaryInsuredEligibilityDateFormatQualifier
     */
    @JsonProperty("primary_insured_eligibility_date_format_qualifier")
    public String getPrimaryInsuredEligibilityDateFormatQualifier() {
        return primaryInsuredEligibilityDateFormatQualifier;
    }

    /**
     * 
     * @param primaryInsuredEligibilityDateFormatQualifier
     *     The primary_insured_eligibility_date_format_qualifier
     */
    @JsonProperty("primary_insured_eligibility_date_format_qualifier")
    public void setPrimaryInsuredEligibilityDateFormatQualifier(String primaryInsuredEligibilityDateFormatQualifier) {
        this.primaryInsuredEligibilityDateFormatQualifier = primaryInsuredEligibilityDateFormatQualifier;
    }

    public String getPrimaryInsuredEligibilityDatePeriod() {
        return primaryInsuredEligibilityDatePeriod;
    }

    public void setPrimaryInsuredEligibilityDatePeriod(String primaryInsuredEligibilityDatePeriod) {
        this.primaryInsuredEligibilityDatePeriod = primaryInsuredEligibilityDatePeriod;
    }

    /**
     * 
     * @return
     *     The dependentEntityIdentifierCode
     */
    @JsonProperty("dependent_entity_identifier_code")
    public String getDependentEntityIdentifierCode() {
        return dependentEntityIdentifierCode;
    }

    /**
     * 
     * @param dependentEntityIdentifierCode
     *     The dependent_entity_identifier_code
     */
    @JsonProperty("dependent_entity_identifier_code")
    public void setDependentEntityIdentifierCode(String dependentEntityIdentifierCode) {
        this.dependentEntityIdentifierCode = dependentEntityIdentifierCode;
    }

    /**
     * 
     * @return
     *     The dependentEntityTypeQualifier
     */
    @JsonProperty("dependent_entity_type_qualifier")
    public String getDependentEntityTypeQualifier() {
        return dependentEntityTypeQualifier;
    }

    /**
     * 
     * @param dependentEntityTypeQualifier
     *     The dependent_entity_type_qualifier
     */
    @JsonProperty("dependent_entity_type_qualifier")
    public void setDependentEntityTypeQualifier(String dependentEntityTypeQualifier) {
        this.dependentEntityTypeQualifier = dependentEntityTypeQualifier;
    }

    /**
     * 
     * @return
     *     The dependentLastName
     */
    @JsonProperty("dependent_last_name")
    public String getDependentLastName() {
        return dependentLastName;
    }

    /**
     * 
     * @param dependentLastName
     *     The dependent_last_name
     */
    @JsonProperty("dependent_last_name")
    public void setDependentLastName(String dependentLastName) {
        this.dependentLastName = dependentLastName;
    }

    /**
     * 
     * @return
     *     The dependentFirstName
     */
    @JsonProperty("dependent_first_name")
    public String getDependentFirstName() {
        return dependentFirstName;
    }

    /**
     * 
     * @param dependentFirstName
     *     The dependent_first_name
     */
    @JsonProperty("dependent_first_name")
    public void setDependentFirstName(String dependentFirstName) {
        this.dependentFirstName = dependentFirstName;
    }

    /**
     * 
     * @return
     *     The dependentMiddleInitial
     */
    @JsonProperty("dependent_middle_initial")
    public String getDependentMiddleInitial() {
        return dependentMiddleInitial;
    }

    /**
     * 
     * @param dependentMiddleInitial
     *     The dependent_middle_initial
     */
    @JsonProperty("dependent_middle_initial")
    public void setDependentMiddleInitial(String dependentMiddleInitial) {
        this.dependentMiddleInitial = dependentMiddleInitial;
    }

    /**
     * 
     * @return
     *     The dependentSuffix
     */
    @JsonProperty("dependent_suffix")
    public String getDependentSuffix() {
        return dependentSuffix;
    }

    /**
     * 
     * @param dependentSuffix
     *     The dependent_suffix
     */
    @JsonProperty("dependent_suffix")
    public void setDependentSuffix(String dependentSuffix) {
        this.dependentSuffix = dependentSuffix;
    }

    /**
     * 
     * @return
     *     The dependentAddressLine1
     */
    @JsonProperty("dependent_address_line1")
    public String getDependentAddressLine1() {
        return dependentAddressLine1;
    }

    /**
     * 
     * @param dependentAddressLine1
     *     The dependent_address_line1
     */
    @JsonProperty("dependent_address_line1")
    public void setDependentAddressLine1(String dependentAddressLine1) {
        this.dependentAddressLine1 = dependentAddressLine1;
    }

    /**
     * 
     * @return
     *     The dependentAddressLine2
     */
    @JsonProperty("dependent_address_line2")
    public String getDependentAddressLine2() {
        return dependentAddressLine2;
    }

    /**
     * 
     * @param dependentAddressLine2
     *     The dependent_address_line2
     */
    @JsonProperty("dependent_address_line2")
    public void setDependentAddressLine2(String dependentAddressLine2) {
        this.dependentAddressLine2 = dependentAddressLine2;
    }

    /**
     * 
     * @return
     *     The dependentAddressCity
     */
    @JsonProperty("dependent_address_city")
    public String getDependentAddressCity() {
        return dependentAddressCity;
    }

    /**
     * 
     * @param dependentAddressCity
     *     The dependent_address_city
     */
    @JsonProperty("dependent_address_city")
    public void setDependentAddressCity(String dependentAddressCity) {
        this.dependentAddressCity = dependentAddressCity;
    }

    /**
     * 
     * @return
     *     The dependentAddressState
     */
    @JsonProperty("dependent_address_state")
    public String getDependentAddressState() {
        return dependentAddressState;
    }

    /**
     * 
     * @param dependentAddressState
     *     The dependent_address_state
     */
    @JsonProperty("dependent_address_state")
    public void setDependentAddressState(String dependentAddressState) {
        this.dependentAddressState = dependentAddressState;
    }

    /**
     * 
     * @return
     *     The dependentAddressZipCode
     */
    @JsonProperty("dependent_address_zip_code")
    public String getDependentAddressZipCode() {
        return dependentAddressZipCode;
    }

    /**
     * 
     * @param dependentAddressZipCode
     *     The dependent_address_zip_code
     */
    @JsonProperty("dependent_address_zip_code")
    public void setDependentAddressZipCode(String dependentAddressZipCode) {
        this.dependentAddressZipCode = dependentAddressZipCode;
    }

    /**
     * 
     * @return
     *     The dependentAddressCountry
     */
    @JsonProperty("dependent_address_country")
    public String getDependentAddressCountry() {
        return dependentAddressCountry;
    }

    /**
     * 
     * @param dependentAddressCountry
     *     The dependent_address_country
     */
    @JsonProperty("dependent_address_country")
    public void setDependentAddressCountry(String dependentAddressCountry) {
        this.dependentAddressCountry = dependentAddressCountry;
    }

    /**
     * 
     * @return
     *     The dependentIdentificationQualifier
     */
    @JsonProperty("dependent_identification_qualifier")
    public String getDependentIdentificationQualifier() {
        return dependentIdentificationQualifier;
    }

    /**
     * 
     * @param dependentIdentificationQualifier
     *     The dependent_identification_qualifier
     */
    @JsonProperty("dependent_identification_qualifier")
    public void setDependentIdentificationQualifier(String dependentIdentificationQualifier) {
        this.dependentIdentificationQualifier = dependentIdentificationQualifier;
    }

    /**
     * 
     * @return
     *     The dependentIdentification
     */
    @JsonProperty("dependent_identification")
    public String getDependentIdentification() {
        return dependentIdentification;
    }

    /**
     * 
     * @param dependentIdentification
     *     The dependent_identification
     */
    @JsonProperty("dependent_identification")
    public void setDependentIdentification(String dependentIdentification) {
        this.dependentIdentification = dependentIdentification;
    }

    /**
     * 
     * @return
     *     The dependentProviderCode
     */
    @JsonProperty("dependent_provider_code")
    public String getDependentProviderCode() {
        return dependentProviderCode;
    }

    /**
     * 
     * @param dependentProviderCode
     *     The dependent_provider_code
     */
    @JsonProperty("dependent_provider_code")
    public void setDependentProviderCode(String dependentProviderCode) {
        this.dependentProviderCode = dependentProviderCode;
    }

    /**
     * 
     * @return
     *     The dependentProviderIdentificationQualifier
     */
    @JsonProperty("dependent_provider_identification_qualifier")
    public String getDependentProviderIdentificationQualifier() {
        return dependentProviderIdentificationQualifier;
    }

    /**
     * 
     * @param dependentProviderIdentificationQualifier
     *     The dependent_provider_identification_qualifier
     */
    @JsonProperty("dependent_provider_identification_qualifier")
    public void setDependentProviderIdentificationQualifier(String dependentProviderIdentificationQualifier) {
        this.dependentProviderIdentificationQualifier = dependentProviderIdentificationQualifier;
    }

    /**
     * 
     * @return
     *     The dependentProviderIdentification
     */
    @JsonProperty("dependent_provider_identification")
    public String getDependentProviderIdentification() {
        return dependentProviderIdentification;
    }

    /**
     * 
     * @param dependentProviderIdentification
     *     The dependent_provider_identification
     */
    @JsonProperty("dependent_provider_identification")
    public void setDependentProviderIdentification(String dependentProviderIdentification) {
        this.dependentProviderIdentification = dependentProviderIdentification;
    }

    /**
     * 
     * @return
     *     The dependentDemographicsDateQualifier
     */
    @JsonProperty("dependent_demographics_date_qualifier")
    public String getDependentDemographicsDateQualifier() {
        return dependentDemographicsDateQualifier;
    }

    /**
     * 
     * @param dependentDemographicsDateQualifier
     *     The dependent_demographics_date_qualifier
     */
    @JsonProperty("dependent_demographics_date_qualifier")
    public void setDependentDemographicsDateQualifier(String dependentDemographicsDateQualifier) {
        this.dependentDemographicsDateQualifier = dependentDemographicsDateQualifier;
    }

    /**
     * 
     * @return
     *     The dependentDemographicsDateOfBirth
     */
    @JsonProperty("dependent_demographics_date_of_birth")
    public String getDependentDemographicsDateOfBirth() {
        return dependentDemographicsDateOfBirth;
    }

    /**
     * 
     * @param dependentDemographicsDateOfBirth
     *     The dependent_demographics_date_of_birth
     */
    @JsonProperty("dependent_demographics_date_of_birth")
    public void setDependentDemographicsDateOfBirth(String dependentDemographicsDateOfBirth) {
        this.dependentDemographicsDateOfBirth = dependentDemographicsDateOfBirth;
    }

    /**
     * 
     * @return
     *     The dependentDemographicsGenderCode
     */
    @JsonProperty("dependent_demographics_gender_code")
    public String getDependentDemographicsGenderCode() {
        return dependentDemographicsGenderCode;
    }

    /**
     * 
     * @param dependentDemographicsGenderCode
     *     The dependent_demographics_gender_code
     */
    @JsonProperty("dependent_demographics_gender_code")
    public void setDependentDemographicsGenderCode(String dependentDemographicsGenderCode) {
        this.dependentDemographicsGenderCode = dependentDemographicsGenderCode;
    }

    /**
     * 
     * @return
     *     The dependentInsuredIndicator
     */
    @JsonProperty("dependent_insured_indicator")
    public String getDependentInsuredIndicator() {
        return dependentInsuredIndicator;
    }

    /**
     * 
     * @param dependentInsuredIndicator
     *     The dependent_insured_indicator
     */
    @JsonProperty("dependent_insured_indicator")
    public void setDependentInsuredIndicator(String dependentInsuredIndicator) {
        this.dependentInsuredIndicator = dependentInsuredIndicator;
    }

    /**
     * 
     * @return
     *     The dependentIndividualRelationshipCode
     */
  /*  @JsonProperty("dependent_individual_relationship_code")
    public String getDependentIndividualRelationshipCode() {
        return dependentIndividualRelationshipCode;
    }*/

    /**
     * 
     * @param dependentIndividualRelationshipCode
     *     The dependent_individual_relationship_code
     */
    /*@JsonProperty("dependent_individual_relationship_code")
    public void setDependentIndividualRelationshipCode(String dependentIndividualRelationshipCode) {
        this.dependentIndividualRelationshipCode = dependentIndividualRelationshipCode;
    }*/

    /**
     * 
     * @return
     *     The dependentBirthSequenceNumber
     */
    @JsonProperty("dependent_birth_sequence_number")
    public String getDependentBirthSequenceNumber() {
        return dependentBirthSequenceNumber;
    }

    /**
     * 
     * @param dependentBirthSequenceNumber
     *     The dependent_birth_sequence_number
     */
    @JsonProperty("dependent_birth_sequence_number")
    public void setDependentBirthSequenceNumber(String dependentBirthSequenceNumber) {
        this.dependentBirthSequenceNumber = dependentBirthSequenceNumber;
    }

    /**
     * 
     * @return
     *     The dependentDateQualifier
     */
    @JsonProperty("dependent_date_qualifier")
    public String getDependentDateQualifier() {
        return dependentDateQualifier;
    }

    /**
     * 
     * @param dependentDateQualifier
     *     The dependent_date_qualifier
     */
    @JsonProperty("dependent_date_qualifier")
    public void setDependentDateQualifier(String dependentDateQualifier) {
        this.dependentDateQualifier = dependentDateQualifier;
    }

    /**
     * 
     * @return
     *     The dependentDateFormatQualifier
     */
    @JsonProperty("dependent_date_format_qualifier")
    public String getDependentDateFormatQualifier() {
        return dependentDateFormatQualifier;
    }

    /**
     * 
     * @param dependentDateFormatQualifier
     *     The dependent_date_format_qualifier
     */
    @JsonProperty("dependent_date_format_qualifier")
    public void setDependentDateFormatQualifier(String dependentDateFormatQualifier) {
        this.dependentDateFormatQualifier = dependentDateFormatQualifier;
    }

    /**
     * 
     * @return
     *     The dependentDatePeriod
     */
    @JsonProperty("dependent_date_period")
    public String getDependentDatePeriod() {
        return dependentDatePeriod;
    }

    /**
     * 
     * @param dependentDatePeriod
     *     The dependent_date_period
     */
    @JsonProperty("dependent_date_period")
    public void setDependentDatePeriod(String dependentDatePeriod) {
        this.dependentDatePeriod = dependentDatePeriod;
    }

    /**
     * 
     * @return
     *     The dependentServiceTypeCode
     */
    @JsonProperty("dependent_service_type_code")
    public String getDependentServiceTypeCode() {
        return dependentServiceTypeCode;
    }

    /**
     * 
     * @param dependentServiceTypeCode
     *     The dependent_service_type_code
     */
    @JsonProperty("dependent_service_type_code")
    public void setDependentServiceTypeCode(String dependentServiceTypeCode) {
        this.dependentServiceTypeCode = dependentServiceTypeCode;
    }

    /**
     * 
     * @return
     *     The dependentServiceIdentificationQualifier
     */
    @JsonProperty("dependent_service_identification_qualifier")
    public String getDependentServiceIdentificationQualifier() {
        return dependentServiceIdentificationQualifier;
    }

    /**
     * 
     * @param dependentServiceIdentificationQualifier
     *     The dependent_service_identification_qualifier
     */
    @JsonProperty("dependent_service_identification_qualifier")
    public void setDependentServiceIdentificationQualifier(String dependentServiceIdentificationQualifier) {
        this.dependentServiceIdentificationQualifier = dependentServiceIdentificationQualifier;
    }

    /**
     * 
     * @return
     *     The dependentProcedureCode
     */
    @JsonProperty("dependent_procedure_code")
    public String getDependentProcedureCode() {
        return dependentProcedureCode;
    }

    /**
     * 
     * @param dependentProcedureCode
     *     The dependent_procedure_code
     */
    @JsonProperty("dependent_procedure_code")
    public void setDependentProcedureCode(String dependentProcedureCode) {
        this.dependentProcedureCode = dependentProcedureCode;
    }

    /**
     * 
     * @return
     *     The dependentProcedureMod1
     */
    @JsonProperty("dependent_procedure_mod1")
    public String getDependentProcedureMod1() {
        return dependentProcedureMod1;
    }

    /**
     * 
     * @param dependentProcedureMod1
     *     The dependent_procedure_mod1
     */
    @JsonProperty("dependent_procedure_mod1")
    public void setDependentProcedureMod1(String dependentProcedureMod1) {
        this.dependentProcedureMod1 = dependentProcedureMod1;
    }

    /**
     * 
     * @return
     *     The dependentProcedureMod2
     */
    @JsonProperty("dependent_procedure_mod2")
    public String getDependentProcedureMod2() {
        return dependentProcedureMod2;
    }

    /**
     * 
     * @param dependentProcedureMod2
     *     The dependent_procedure_mod2
     */
    @JsonProperty("dependent_procedure_mod2")
    public void setDependentProcedureMod2(String dependentProcedureMod2) {
        this.dependentProcedureMod2 = dependentProcedureMod2;
    }

    /**
     * 
     * @return
     *     The dependentProcedureMod3
     */
    @JsonProperty("dependent_procedure_mod3")
    public String getDependentProcedureMod3() {
        return dependentProcedureMod3;
    }

    public void setDependentProcedureMod3(String dependentProcedureMod3) {
        this.dependentProcedureMod3 = dependentProcedureMod3;
    }

    public String getDependentProcedureMod4() {
        return dependentProcedureMod4;
    }

    public void setDependentProcedureMod4(String dependentProcedureMod4) {
        this.dependentProcedureMod4 = dependentProcedureMod4;
    }

    public String getDependentDescription() {
        return dependentDescription;
    }

    public void setDependentDescription(String dependentDescription) {
        this.dependentDescription = dependentDescription;
    }

    public String getDependentInsuranceType() {
        return dependentInsuranceType;
    }

    public void setDependentInsuranceType(String dependentInsuranceType) {
        this.dependentInsuranceType = dependentInsuranceType;
    }

    public String getDependentCoverageLevelCode() {
        return dependentCoverageLevelCode;
    }

    public void setDependentCoverageLevelCode(String dependentCoverageLevelCode) {
        this.dependentCoverageLevelCode = dependentCoverageLevelCode;
    }

    public String getDependentListQualifierCode() {
        return dependentListQualifierCode;
    }

    public void setDependentListQualifierCode(String dependentListQualifierCode) {
        this.dependentListQualifierCode = dependentListQualifierCode;
    }

    public String getDependentIndustryCode() {
        return dependentIndustryCode;
    }

    public void setDependentIndustryCode(String dependentIndustryCode) {
        this.dependentIndustryCode = dependentIndustryCode;
    }

    public String getDependentInformationIdentificationQualifier() {
        return dependentInformationIdentificationQualifier;
    }

    public void setDependentInformationIdentificationQualifier(String dependentInformationIdentificationQualifier) {
        this.dependentInformationIdentificationQualifier = dependentInformationIdentificationQualifier;
    }

    public String getDependentInformationIdentification() {
        return dependentInformationIdentification;
    }

    public void setDependentInformationIdentification(String dependentInformationIdentification) {
        this.dependentInformationIdentification = dependentInformationIdentification;
    }

    public String getDependentEligibilityDateQualifier() {
        return dependentEligibilityDateQualifier;
    }

    public void setDependentEligibilityDateQualifier(String dependentEligibilityDateQualifier) {
        this.dependentEligibilityDateQualifier = dependentEligibilityDateQualifier;
    }

    public String getDependentEligibilityDateFormatQualifier() {
        return dependentEligibilityDateFormatQualifier;
    }

    public void setDependentEligibilityDateFormatQualifier(String dependentEligibilityDateFormatQualifier) {
        this.dependentEligibilityDateFormatQualifier = dependentEligibilityDateFormatQualifier;
    }

    public String getDependentEligibilityDatePeriod() {
        return dependentEligibilityDatePeriod;
    }

    public void setDependentEligibilityDatePeriod(String dependentEligibilityDatePeriod) {
        this.dependentEligibilityDatePeriod = dependentEligibilityDatePeriod;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public String getRelationShipCode() {
        return relationShipCode;
    }
    
    public void setRelationShipCode(String relationShipCode) {
        this.relationShipCode = relationShipCode;
    }
  
    
}
