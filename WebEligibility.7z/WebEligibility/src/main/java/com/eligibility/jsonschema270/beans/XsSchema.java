
package com.eligibility.jsonschema270.beans;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * It contains xs xselement  property of received JSON. 
 * @author manishm3
 * @date Mar 11,2015
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "-xmlns:xs",
    "xs:element"
})
public class XsSchema {

    @JsonProperty("-xmlns:xs")
    private String XmlnsXs;
    @JsonProperty("xs:element")
    private XsElement xsElement;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * 
     * @return
     *     The XmlnsXs
     */
    @JsonProperty("-xmlns:xs")
    public String getXmlnsXs() {
        return XmlnsXs;
    }

    /**
     * 
     * @param XmlnsXs
     *     The -xmlns:xs
     */
    @JsonProperty("-xmlns:xs")
    public void setXmlnsXs(String XmlnsXs) {
        this.XmlnsXs = XmlnsXs;
    }

    /**
     * 
     * @return
     *     The xsElement
     */
    @JsonProperty("xs:element")
    public XsElement getXsElement() {
        return xsElement;
    }

    /**
     * 
     * @param xsElement
     *     The xs:element
     */
    @JsonProperty("xs:element")
    public void setXsElement(XsElement xsElement) {
        this.xsElement = xsElement;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
