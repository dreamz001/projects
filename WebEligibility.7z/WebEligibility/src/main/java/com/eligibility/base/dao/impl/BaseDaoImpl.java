package com.eligibility.base.dao.impl;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.eligibility.base.dao.IBaseDao;
import com.eligibility270.dbentities.Edi271longdesc;
import com.eligibility270.dbentities.Eligibility270withack;
import com.eligibility270.dbentities.Eligibilitysummary;
import com.eligibility270.dbentities.Insurancesummary;
import com.eligibility270.dbentities.Providersummary;
import com.eligibility270.dbentities.Subscribersummary;
import com.eligibility270.header.entities.InterchangeControlHeader;
import com.eligibility270.mastertables.entities.Deliverymethod;
import com.eligibility270.mastertables.entities.ISAEntity;
import com.eligibility270.writer.DBSequenceType;
import com.eligibility271.dbentities.AaaFollowUpLookUp;
import com.eligibility271.dbentities.AaaRejectReason;
import com.eligibility271.dbentities.DtpDefEntity;
import com.eligibility271.dbentities.EbLookUp;
import com.eligibility271.dbentities.Edi271shortdesc;
import com.eligibility271.dbentities.Emdeonrequestresponse;
import com.eligibility271.dbentities.Patientsummary;

/**
 * Purpose : base DAO methods implementation for corresponding to 270 & 271
 * eligibility request and response.
 * 
 * @author Manish
 * @date MAR 20,2015
 */

@Repository("baseDao") 
public class BaseDaoImpl<T, PK extends Serializable> /*extends HibernateDaoSupport*/  implements IBaseDao<T, PK> {

    private static final Logger LOGGER = LoggerFactory.getLogger(BaseDaoImpl.class);

    @Autowired  
    private SessionFactory sessionFactory;  

    /**
     * Save entity object related to edi schema
     * 
     * @param T
     * @throws <code>HibernateException</code>
     */
    @Override
    public Serializable save(T paramT) throws HibernateException {
        LOGGER.debug("SAVE OPERATION");
        Session currentSession = sessionFactory.getCurrentSession();
        Transaction tx=currentSession.beginTransaction();
        Serializable serializable = currentSession.save(paramT);
        currentSession.flush();
        tx.commit();
        LOGGER.debug("SAVE OPERATION COMPLETE");
        return serializable;

    }

    /**
     * set session factory object available in application context
     */
    /*@Resource(name="sessionFactory")
    public void setBaseDaoSessionFactory(SessionFactory sessionFactory) {
            super.setSessionFactory(sessionFactory);
    }*/
    
    /**
     * Execute sql query pass as an argument to database
     * 
     * @param sql
     *            string
     * @return Resultant <code>Object</code>
     * @throws <code>Exception</code>
     */
    public Object executSQL(String sql) throws Exception {
        LOGGER.debug("EXECUTE SQL");
        Session currentSession = sessionFactory.getCurrentSession();
        Transaction tx=currentSession.beginTransaction();
        SQLQuery query = currentSession.createSQLQuery(sql);
        Object result = query.uniqueResult();
        tx.commit();
        LOGGER.debug("EXECUTE SQL COMPLETE");
        return result;
    }

    /**
     * It gets ISA entity.
     * 
     * @return <code>ISAEntity</code>
     * @throws <code>HibernateException</code>
     */
    public ISAEntity getISA() throws HibernateException {
        LOGGER.debug("GET ISA ENTITY TEMPLATE.");
        Session currentSession = sessionFactory.getCurrentSession();
        Transaction tx=currentSession.beginTransaction();
        Criteria criteria = currentSession.createCriteria(ISAEntity.class);
        
        ISAEntity isa= (ISAEntity) criteria.uniqueResult();
        tx.commit();
        return isa;
    }

    /**
     * It returns delivery method refrence by deliviry method name like -
     * EMDEON, AVAILITY.
     * 
     * @param name
     * @return <code>Deliverymethod</code> reference
     */
   
    @Override
    public Deliverymethod byDeliveryMethodName(String name) {
        LOGGER.debug("Get Delivery Method by delivery method name.");
        Session session = sessionFactory.getCurrentSession();
        Transaction tx=session.beginTransaction();
        
        Criteria cr = session.createCriteria(Deliverymethod.class);
        cr.add(Restrictions.eq("deliverymethod", name));
        cr.add(Restrictions.like("deliverymethod", name.concat("%")));
        Deliverymethod method= (Deliverymethod)cr.uniqueResult();
        tx.commit();
        return method;  
    }

    /**
     * This method return the next value of DB sequence.
     * 
     * @param sequenceType
     * @return DB sequence value as <code>BigInteger</code>
     * @throws <code>Exception</code>
     */
    public BigInteger nextVal(DBSequenceType sequenceType) throws Exception {
        LOGGER.debug("HIT DB SEQUENCE " + sequenceType.value());
        String sql = "select nextVal('" + sequenceType.value() + "')";
        return (BigInteger) executSQL(sql);
    }

    /**
     * It returns the current session.
     * 
     * @return hibernate current <code>Session</code>
     */
    

    /**
     * It saves the <code>Eligibility270withack</code> reference into DB with
     * ISA entity and all its dependent entity like GS, ST.
     * 
     * @param <code>InterchangeControlHeader</code>
     * @param <code>Eligibility270withack</code>
     * @throws <code>HibernateException</code>
     */
    @Override
    public void saveWithAck(InterchangeControlHeader interchangeCOntrolHeader, Eligibility270withack eligibility270withack) throws HibernateException {
        LOGGER.debug("SAVE OPERATION");
        Session currentSession = sessionFactory.getCurrentSession();
        Transaction tx=currentSession.beginTransaction();
        currentSession.save(interchangeCOntrolHeader);
        currentSession.save(eligibility270withack);        
        currentSession.flush();
        tx.commit();
        LOGGER.debug("SAVE OPERATION COMPLETE");
    }

    /**
     * It saves the short description with patient summary from 271 eligibility
     * response EDI.
     * 
     * @param <code>Patientsummary</code>
     * @param <code>Edi271shortdesc</code>
     * @throws <code>HibernateException</code>
     */
    @Override
    public void saveWithShortDesc(Patientsummary patientsummary, Edi271shortdesc shEdi271shortdesc) throws HibernateException {
        LOGGER.debug("SAVE OPERATION");
        Session currentSession = sessionFactory.getCurrentSession();
        Transaction tx=currentSession.beginTransaction();
        currentSession.save(patientsummary);
        currentSession.save(shEdi271shortdesc);
        currentSession.flush();
        tx.commit();
        LOGGER.debug("SAVE OPERATION COMPLETE");
    }

    /**
     * It returns the short description by trace number.
     * 
     * @param trace
     *            number
     * @return <code>Edi271shortdesc</code> reference.
     */
    @Override
    public Edi271shortdesc getShortDescByTraceNum(String traceNum) {
        LOGGER.debug("GET SHORT DESCRIPTION BY TRACE NUMBER");
        Session currentSession = sessionFactory.getCurrentSession();
        Transaction tx=currentSession.beginTransaction();
        Criteria criteria = currentSession.createCriteria(Edi271shortdesc.class);
        criteria.add(Restrictions.eq("eligibilitytracernumber", traceNum));
        Object record = criteria.uniqueResult();
        tx.commit();
        if (record != null && record instanceof Edi271shortdesc) {
            LOGGER.debug("GET SHORT DESCRIPTION BY TRACE NUMBER COMPLETE");
            return (Edi271shortdesc) record;
        }
        LOGGER.debug("GET SHORT DESCRIPTION BY TRACE NUMBER COMPLETE");
        return null;
    }

    /**
     * It updates the database entity.
     * 
     * @param T
     * @throws <code>HibernateException</code>
     */
    @Override
    public void update(T paramT) throws HibernateException {
        LOGGER.debug("SAVE OR UPDATE OPERATION");
        Session currentSession = sessionFactory.getCurrentSession();
        Transaction tx=currentSession.beginTransaction();
        currentSession.update(paramT);
        currentSession.flush();
        tx.commit();
        LOGGER.info("SAVE OR UPDATE OPERATION COMPLETE");
    }

    /**
     * It saves the long description into DB with eligibility and insurance
     * summary and all its dependent summary.
     * 
     * @param Edi271longdesc
     * @param Eligibilitysummary
     * @param Insurancesummary
     * @throws <code>HibernateException</code>
     */
    @Override
    public int saveLongDecs(Edi271longdesc longDesc, Eligibilitysummary eligibilitysummary, Insurancesummary insurancesummary, Providersummary providersummary,
            Subscribersummary subscribersummary) throws HibernateException {
        LOGGER.debug("START SAVE LONG DESCRIPTION OPERATION");
        Session currentSession = sessionFactory.getCurrentSession();
        Transaction tx=currentSession.beginTransaction();
        if (eligibilitysummary != null) {
            currentSession.save(eligibilitysummary);
        }
        if (insurancesummary != null) {
            currentSession.save(insurancesummary);
        }
        if (subscribersummary != null) {
            currentSession.save(subscribersummary);
        }
        if (providersummary != null) {
            currentSession.save(providersummary);
        }
        
        int longdesc=(Integer) currentSession.save(longDesc);
        currentSession.flush();
        tx.commit();
        LOGGER.debug("SAVE LONG DESCRIPTION OPERATION COMPLETE");
        return longdesc;
    }

    /**
     * It returns the long description from Db on behalf of tracenumber.
     * 
     * @param traceNum
     * @return <code>Edi271longdesc</code>
     */
    @Override
    public Edi271longdesc getEdi271longdescByTraceNum(String traceNum) {
        LOGGER.debug("GET LONG DESCRIPTION BY TRACENUMBER");
        Session currentSession = sessionFactory.getCurrentSession();
        Transaction tx=currentSession.beginTransaction();
        Criteria criteria = currentSession.createCriteria(Edi271longdesc.class);
        criteria.add(Restrictions.eq("eligibilitytracernumber", traceNum));
        List<Edi271longdesc> longDescList=criteria.list();
        Edi271longdesc longDesc=null;
        if(longDescList.size()>0){
            longDesc=longDescList.get(0);
            longDesc.getBenefitsinformations().size();
            longDesc.getRequestvalidations().size();
        }
        tx.commit();
        
        LOGGER.debug("GET LONG DESCRIPTION BY TRACENUMBER COMPLETE");
        return longDesc;
    }

    /**
     * It returns the <code>Eligibility270withack</code> by trace number.
     * 
     * @param traceNum
     * @return <code>Eligibility270withack</code>
     * @throws <code>HibernateException</code>
     */
    @Override
    public Eligibility270withack getEligibility270withackByTraceNum(String traceNum) throws HibernateException {
        LOGGER.debug("GET ELIGIBILITY ACK BY TRACE NUMBER");
        Session currentSession = sessionFactory.getCurrentSession();
        Transaction tx=currentSession.beginTransaction();
        Criteria criteria = currentSession.createCriteria(Eligibility270withack.class);
        criteria.add(Restrictions.eq("eligibilitytracenumber", traceNum));
        Object record = criteria.uniqueResult();
        tx.commit();
        if (record != null && record instanceof Eligibility270withack) {
            LOGGER.debug("GET ELIGIBILITY ACK BY TRACE NUMBER COMPLETE");
            return (Eligibility270withack) record;
        }
        LOGGER.debug("GET ELIGIBILITY ACK BY TRACE NUMBER COMPLETE");
        return null;
    }

    /**
     * It return list of DTP codes from DB.
     * 
     * @return List of <code>List<DtpDefEntity></code>
     * @throws <code>HibernateException</code>
     */
    @Override
    @SuppressWarnings("unchecked")
    public List<DtpDefEntity> getDtpCodeList() throws HibernateException {
        LOGGER.debug("GET DTP CODE LIST");
        Session currentSession = sessionFactory.getCurrentSession();
        Transaction tx=currentSession.beginTransaction();
        Criteria criteria = currentSession.createCriteria(DtpDefEntity.class);
        List<DtpDefEntity> result = criteria.list();
        tx.commit();
        LOGGER.debug("GET DTP CODE LIST COMPLETE");
        return result;
    }

    @Override
    public void saveEmdeon(Emdeonrequestresponse emdeon) throws HibernateException {
        LOGGER.debug("SAVE OPERATION");
        Session currentSession = sessionFactory.getCurrentSession();
        Transaction tx=currentSession.beginTransaction();
        currentSession.save(emdeon);
        currentSession.flush();
        tx.commit();
        LOGGER.debug("SAVE OPERATION COMPLETE");
    }
    
    /**
     * It return  EBcode, defination from DB.
     * @param ebCode
     * @return EbLookUp
     * @throws <code>HibernateException</code>
     */
    @Override
    public EbLookUp getEbLookUp(String ebCode) throws HibernateException{
        LOGGER.debug("GET EB CODE DEFINATION FROM LIST");
        Session currentSession = sessionFactory.getCurrentSession();
        Transaction tx=currentSession.beginTransaction();
        Criteria criteria = currentSession.createCriteria(EbLookUp.class);
        criteria.add(Restrictions.eq("ebcode", ebCode));
        Object record = criteria.uniqueResult();
        tx.commit();
        if(record!=null && record instanceof EbLookUp)
            return (EbLookUp) record;
        LOGGER.debug("GET EB CODE DEFINATION FROM LIST COMPLETE");
        return null;
    }
    
    /**
     * It return  AaaRejectReason from DB.
     * @param aaaCode
     * @return AaaRejectReason
     * @throws <code>HibernateException</code>
     */
    @Override
    public AaaRejectReason getAaaRejectReason(String aaaCode) throws HibernateException{
        LOGGER.debug("GET AAA CODE DEFINATION FROM LIST");
        Session currentSession = sessionFactory.getCurrentSession();
        Transaction tx=currentSession.beginTransaction();
        Criteria criteria = currentSession.createCriteria(AaaRejectReason.class);
        criteria.add(Restrictions.eq("aaacode", aaaCode));
        Object record = criteria.uniqueResult();
        tx.commit();
        if(record!=null && record instanceof AaaRejectReason)
            return (AaaRejectReason) record;
        LOGGER.debug("GET AAA CODE DEFINATION FROM LIST COMPLETE");
        return null;
    }
    
    /**
     * It return  AaaRejectReason from DB.
     * @param aaaCode
     * @return AaaRejectReason
     * @throws <code>HibernateException</code>
     */
    @Override
    public AaaFollowUpLookUp getAaaFollowUpLookUp(String aaaCode) throws HibernateException{
        LOGGER.debug("GET AAA FOLLOW UP CODE DEFINATION FROM LIST");
        Session currentSession = sessionFactory.getCurrentSession();
        Transaction tx=currentSession.beginTransaction();
        Criteria criteria = currentSession.createCriteria(AaaFollowUpLookUp.class);
        criteria.add(Restrictions.eq("aaacode", aaaCode));
        Object record = criteria.uniqueResult();
        tx.commit();
        if(record!=null && record instanceof AaaFollowUpLookUp)
            return (AaaFollowUpLookUp) record;
        LOGGER.debug("GET AAA FOLLOW UP CODE DEFINATION FROM LIST COMPLETE");
        return null;
    }
    
    @Override
    public List<Insurancesummary> getPayerInfo() throws Exception {
        Session currentSession = sessionFactory.getCurrentSession();
        Transaction tx=currentSession.beginTransaction();
        Criteria criteria=currentSession.createCriteria(Insurancesummary.class);
        criteria.setProjection(Projections.distinct(Projections.property("payeridentificationcode")));
        List<Insurancesummary> payerList=criteria.list();
        tx.commit();
        return payerList;
    }
    
}
