package com.eligibility.common.utility;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.eligibility270.writer.IConstants;
import com.eligibility271.beans.IEligibility271Constants;

/**
 * It contains method to manipulate String.
 * 
 * @author manishm3
 */
public class StringUtil {
    private static final Logger LOG = LoggerFactory.getLogger(StringUtil.class);
    public static final String US = "US";
    public static final String CA = "CA";

    /**
     * It fills space.
     * 
     * @param limit
     * @return
     */
    public static String space(int limit) {
        String space = "";
        for (int i = 0; i < limit; i++) {
            space = space.concat(" ");
        }
        return space;
    }

    /**
     * It fills zeros.
     * 
     * @param limit
     * @return
     */
    public static String zeros(int limit) {
        String zero = "";
        for (int i = 0; i < limit; i++) {
            zero = zero.concat("0");
        }
        return zero;
    }

    /**
     * It removes unused asterik from string.
     * 
     * @param str
     * @return
     * @throws ArrayIndexOutOfBoundsException
     */
    public static String removeUnusedAsterik(String str) throws ArrayIndexOutOfBoundsException {
        LOG.debug("StringUtil", "removeUnusedAsterik");
        if (str == null || "".equals(str.trim())) {
            return "";
        }
        str = str.replace("~", "");
        String newstr = str.replaceAll("\\*", "");
        char lastChar = newstr.charAt(newstr.length() - 1);
        StringBuilder sb = new StringBuilder(str);
        int lastindex = str.lastIndexOf(lastChar);
        sb.delete(lastindex + 1, str.length());
        LOG.debug("StringUtil", "removeUnusedAsterik");
        return sb.append(IConstants.TERMINATOR).toString();
    }

    /**
     * it checks whether segment contains data or not.
     * 
     * @param value
     * @param segmentag
     * @return
     */
    public static boolean isSegmentContainsData(String value, String segmentag) {
        LOG.debug("StringUtil", "isSegmentContainsData");
        StringBuilder edi = new StringBuilder(value);
        edi.delete(IConstants.START_INDEX, segmentag.length());
        String newedi = edi.toString();
        String s = newedi.replace('*', ' ');
        s = s.replace('~', ' ');
        if (s.contains("^")) {
            s = s.replace('^', ' ');
        }
        if (s.trim().isEmpty()) {
            return false;
        }
        LOG.debug("StringUtil", "isSegmentContainsData");
        return true;
    }

    /**
     * It adds terminator(~) if segment string doesn't end with this.
     * 
     * @param segmentStr
     * @return
     * @throws ArrayIndexOutOfBoundsException
     */
    public static String appendTerminatorIfNotFound(String segmentStr) throws ArrayIndexOutOfBoundsException {
        if (segmentStr == null) {
            return new String("");
        }
        if (!segmentStr.contains(IConstants.TERMINATOR)) {
            segmentStr = segmentStr.concat(IConstants.TERMINATOR);
        }

        return removeUnusedAsterik(segmentStr);
    }

    /**
     * It checks whether the string is null or not.
     * 
     * @param value
     * @return
     */
    public static boolean isNullOrEmpty(String value) {
        if (value == null || value.trim().isEmpty()) {
            return true;
        }
        return false;
    }

    /**
     * It checks the string length.
     * 
     * @param min
     * @param max
     * @param val
     * @return
     */
    public static boolean isLengthExceeds(int min, int max, String val) {
        if (val.length() < min || val.length() > max) {
            return true;
        }
        return false;
    }

    /**
     * It removes unused comma
     * 
     * @param val
     * @return
     */
    public static String removeUnusedComma(String val) {
        if (val == null || val.isEmpty()) {
            return val;
        }

        int lastComma = val.lastIndexOf(IEligibility271Constants.COMMA);
        if (lastComma > 0) {
            StringBuilder sb = new StringBuilder(val);
            sb.deleteCharAt(lastComma);
            return sb.toString();
        }
        return val;
    }

    /**
     * It removes the spaces from string.
     * 
     * @param val
     * @return
     */
    public static String removeSpace(String val) {
        if (val == null || val.trim().isEmpty()) {
            return "";
        }
        return val.trim();
    }
}
