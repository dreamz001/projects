package com.eligibility.common.utility;


/**
 * It has HL level info and method to get HL level values. 
 * @author manishm3
 * @date Mar 13,2015
 */
public class HLUtil {
    public static int VALUE=1;
    
    public static int HL_PARENT=0;
    
    public static final int YES_CHILD=1;
    public static final int NO_CHILD=0;
    
    //Hierarchical Level Code
    public static final int LEVEL_ONE=20;
    public static final int LEVEL_TWO=21;
    /*Subscriebr*/
    public static final int LEVEL_THREE=22;
    
    /************************************************************** 
     * The code DEPENDENT conveys that the information in this HL 
     * applies to the patient when the subscriber and the patient 
     * are not the same person.
     * *************************************************************/
    public static final int LEVEL_FOUR=23;
    
    public static boolean isSelf=false;
    
    /**
     * @author manishm3
     * It returns new integer value incremented by 1. 
     * @return int value
     */
    public static int nextVal(){
        return VALUE++;
        
    }
    
    /**
     * It reset the HL level.
     */
    public static void resetValue(){
        VALUE=1;
        HL_PARENT=0;
        isSelf=false;
    }
}
