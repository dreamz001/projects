package com.eligibility.common.utility;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Calendar;
import java.util.GregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * It has file related operation like save, copy etc.
 * 
 * @author manishm3
 * @date Mar 12,2014
 */
public class FileUtil {

    private static final Logger LOG = LoggerFactory.getLogger(FileUtil.class);

    public static final String INBOX_DIR = "INBOX";
    public static final String OUTBOX_DIR = "OutBox";

    /**
     * To save and create file corresponding to 837p edi
     */
    public static void save(String edi, String deliveryMethodType, String path) throws IOException {
        LOG.debug("SAVE FILE METHOD");
        String inboxPath = inboxPath(path);
        if (edi != null && !edi.isEmpty()) {
            String filename = "270_" + deliveryMethodType + System.currentTimeMillis();
            File file = new File(inboxPath + File.separator + filename + ".txt");
            FileWriter fw = new FileWriter(file);
            fw.write(edi);
            fw.flush();
            fw.close();
        } else {
            LOG.error("EDI TO BE WRITE HAVING NULL OR EMPTY CONTENT");
        }
        LOG.debug("SAVE FILE METHOD COMPLETE");
    }

    /**
     * generate inbox directory path
     */
    public static String inboxPath(String path) throws IOException {
        LOG.debug("INBOX PATH");
        if (path == null || path.isEmpty()) {
            path = "..";
        }
        GregorianCalendar gc = new GregorianCalendar();
        int year = gc.get(Calendar.YEAR);
        int month = gc.get(Calendar.MONTH) + 1;
        int day = gc.get(Calendar.DATE);

        String dirYear = "" + year;
        String dirMonth = "" + month;
        String dirDay = "" + day;

        File file = new File(path + File.separator + INBOX_DIR + File.separator + dirYear + File.separator + dirMonth + File.separator + dirDay);
        if (!file.exists() && file.mkdirs()) {
            LOG.info("Created Path is " + path + File.separator + INBOX_DIR + File.separator + dirYear + File.separator + dirMonth + File.separator + dirDay);
        }
        LOG.debug("INBOX PATH COMPLETE");
        return path + File.separator + INBOX_DIR + File.separator + dirYear + File.separator + dirMonth + File.separator + dirDay;
    }

}
