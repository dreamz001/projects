package com.eligibility.shared.constants;

/**
 * It contains list of all loops for 270-eligibility.
 * 
 * @author manishm3
 * @date March 5,2015
 */
public enum EligibilityLoopEnum {
    
    LOOP2000A("INFORMATION SOURCE LEVEL"),
    LOOP2100A("INFORMATION SOURCE NAME"),
    LOOP2000B("INFORMATION RECEIVER LEVEL"),
    LOOP2100B("INFORMATION RECEIVER NAME"),
    LOOP2000C("SUBSCRIBER LEVEL"),
    LOOP2100C("SUBSCRIBER NAME"),
    LOOP2110C("SUBSCRIBER ELIGIBILITY OR BENEFIT"),
    /*271-specific Loop*/
    LOOP2115C("SUBSCRIBER ELIGIBILITY OR BENEFIT ADDITIONAL INFORMATION"),
    LOOP2120C("SUBSCRIBER BENEFIT RELATED ENTITY"),
    /*END*/
    LOOP2000D("DEPENDENT LEVEL"),
    LOOP2100D("DEPENDENT NAME"),
    LOOP2110D("DEPENDENT ELIGIBILITY OR BENEFIT"),
    
    /*271-specific Loop*/
    LOOP2115D("DEPENDENT ELIGIBILITY OR BENEFIT ADDITIONAL INFORMATION"),
    LOOP2120D("DEPENDENT BENEFIT RELATED ENTITY"),
    /*END*/
    
    LOOP2000A_N("2000A"),
    LOOP2100A_N("2100A"),
    LOOP2000B_N("2000B"),
    LOOP2100B_N("2100B"),
    LOOP2000C_N("2000C"),
    LOOP2100C_N("2100C"),
    LOOP2110C_N("2110C"),
    /*271-specific Loop*/
    LOOP2115C_N("2115C"),
    LOOP2120C_N("2120C"),
    /*END*/
    LOOP2000D_N("2000D"),
    LOOP2100D_N("2100D"),
    LOOP2110D_N("2110D"),
    
    /*271-specific Loop*/
    LOOP2115D_N("2115D"),
    LOOP2120D_N("2120D");
    /*END*/
    
    private String loop;
    
    private EligibilityLoopEnum(String loop){
        this.loop=loop;
    }
    
    public String value(){
        return loop;
    }
    
    public boolean equals(EligibilityLoopEnum loop){
        return this.loop.equals(loop.value());
    }
}
