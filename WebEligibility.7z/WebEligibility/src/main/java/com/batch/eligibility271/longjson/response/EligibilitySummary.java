package com.batch.eligibility271.longjson.response;

/**
 * @author Manish
 * @date MAR 20,2015
 */
public class EligibilitySummary {
	private String policy_type;
	private String policy_description;
	private String eligibility_status;
	private String eligibility_begin_date;
	private String eligibility_request_date;
	private String eligibility_request_date_of_service;

	public String getPolicy_type() {
		return policy_type;
	}

	public void setPolicy_type(String policy_type) {
		this.policy_type = policy_type;
	}

	public String getPolicy_description() {
		return policy_description;
	}

	public void setPolicy_description(String policy_description) {
		this.policy_description = policy_description;
	}

	public String getEligibility_status() {
		return eligibility_status;
	}

	public void setEligibility_status(String eligibility_status) {
		this.eligibility_status = eligibility_status;
	}

	public String getEligibility_begin_date() {
		return eligibility_begin_date;
	}

	public void setEligibility_begin_date(String eligibility_begin_date) {
		this.eligibility_begin_date = eligibility_begin_date;
	}

	public String getEligibility_request_date() {
		return eligibility_request_date;
	}

	public void setEligibility_request_date(String eligibility_request_date) {
		this.eligibility_request_date = eligibility_request_date;
	}

	public String getEligibility_request_date_of_service() {
		return eligibility_request_date_of_service;
	}

	public void setEligibility_request_date_of_service(
			String eligibility_request_date_of_service) {
		this.eligibility_request_date_of_service = eligibility_request_date_of_service;
	}

}
