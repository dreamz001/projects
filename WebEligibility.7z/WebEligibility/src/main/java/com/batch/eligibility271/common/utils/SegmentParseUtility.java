package com.batch.eligibility271.common.utils;

import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.batch.eligibility.shared.constants.EligibilityTagEnum;
import com.batch.eligibility271.beans.FieldWithValueBean;
import com.batch.eligibility271.beans.SegmentBean;

/***
 * @author shailendras4 Segment Parsing Utility method usefull for spliting and
 *         preparing memory bean
 */
public class SegmentParseUtility {

	private static final Logger LOG = LoggerFactory
			.getLogger(SegmentParseUtility.class);

	public static SegmentBean parseSegment(String segmentString,
			EligibilityTagEnum ackSegmentTag) {
		LOG.debug("Entering in to  SegmentParseUtility  ::  parseSegment");
		SegmentBean segmentBean = new SegmentBean();
		if (segmentString != null && !segmentString.isEmpty()) {
			segmentBean.setSegmentName(ackSegmentTag);
			ArrayList<FieldWithValueBean> beanList = new ArrayList<FieldWithValueBean>();
			String[] segmentParts = segmentString.split("\\*");
			int fieldPos = 1;
			if (segmentParts != null && segmentParts.length > 0) {
				for (String fieldValue : segmentParts) {
					if (fieldValue.toUpperCase().equals(
							ackSegmentTag.toString())) {
						continue;
					} else {
						FieldWithValueBean refDesigBean = new FieldWithValueBean();
						String refDesigName = getRefDesigName(ackSegmentTag,
								fieldPos);
						refDesigBean.setFieldDesginator(refDesigName);
						refDesigBean.setFieldValue(fieldValue);
						beanList.add(refDesigBean);
						fieldPos++;
					}
				}
				segmentBean.setSegmentFieldList(beanList);
			}
		}
		LOG.debug("Exiting from SegmentParseUtility :: parseSegment");
		return segmentBean;
	}

	public static String getRefDesigName(EligibilityTagEnum segmentTagName,
			int fieldPos) {
		StringBuilder refDesigName = new StringBuilder(
				segmentTagName.toString());
		if (fieldPos < 10) {
			refDesigName.append("0");
		}
		refDesigName.append(fieldPos);
		return refDesigName.toString();
	}

	public static ArrayList<SegmentBean> parseEligibility271String(
			String ackString) {
		LOG.debug("Entering in to  SegmentParseUtility  ::  parseSegment");
		ArrayList<SegmentBean> ackSegmentList = new ArrayList<SegmentBean>();
		String[] segmentStrList = ackString.split("~");
		if (segmentStrList != null && segmentStrList.length > 0) {
			for (String segmentString : segmentStrList) {
				String segmentName = getSegmentNameFromSegmentString(segmentString);
				EligibilityTagEnum tagEnum = EligibilityTagEnum
						.getSegmentEnum(segmentName);
				SegmentBean segmentBean = parseSegment(segmentString, tagEnum);
				if (segmentBean.getSegmentName() != null
						&& !segmentBean.getSegmentFieldList().isEmpty()) {
					ackSegmentList.add(segmentBean);
				}
			}
		}
		LOG.debug("Exiting from SegmentParseUtility :: parseSegment");
		return ackSegmentList;
	}

	public static String getSegmentNameFromSegmentString(String segmentString) {
		String segmentName = null;
		if (segmentString != null && !segmentString.isEmpty()) {
			int firstSeperatorIndex = segmentString.indexOf("*");
			segmentName = segmentString.substring(0, firstSeperatorIndex);
		}
		return segmentName;
	}

}
