package com.batch.eligibility271.constants;

/**
 * @author Manish
 * @date MAR 20,2015
 */
public class Ack999Constants {
	public static final String ACK999 = "999";
	public static final String EDI270 = "270";
	public static final String EDI271 = "271";
	public static final String ACCEPTED_EDI = "A";
	public static final String REJECTED_EDI = "R";
	public static final String ERROR = "ERROR";
	public static final String INVALID_REQUEST = "Invalid Request";
	public static final String UNAUTHORIZED = "UnAuthorized";
	public static final String SEMICOLON_SEPRATOR = "; ";
	public static final String DIRECTORY_SEPARATOR = "/";
}
