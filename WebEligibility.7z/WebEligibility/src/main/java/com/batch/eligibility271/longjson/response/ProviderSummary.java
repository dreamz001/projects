package com.batch.eligibility271.longjson.response;

/**
 * @author Manish
 * @date MAR 20,2015
 */
public class ProviderSummary {
	private String provider_name;
	private String provider_identification_qualifier;
	private String provider_identification_code;
	private String provider_address;

	public String getProvider_name() {
		return provider_name;
	}

	public void setProvider_name(String provider_name) {
		this.provider_name = provider_name;
	}

	public String getProvider_identification_qualifier() {
		return provider_identification_qualifier;
	}

	public void setProvider_identification_qualifier(
			String provider_identification_qualifier) {
		this.provider_identification_qualifier = provider_identification_qualifier;
	}

	public String getProvider_identification_code() {
		return provider_identification_code;
	}

	public void setProvider_identification_code(
			String provider_identification_code) {
		this.provider_identification_code = provider_identification_code;
	}

	public String getProvider_address() {
		return provider_address;
	}

	public void setProvider_address(String provider_address) {
		this.provider_address = provider_address;
	}

}
