package com.batch.eligibility271.parser;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.eligibility271.dbentities.DtpDefEntity;

/**
 * @author Manish
 * @date MAR 20,2015
 */
@Component
public class BatchDtpDefinationLookUp {

	private List<DtpDefEntity> dtpList;

	public List<DtpDefEntity> getDtpList() {
		if (dtpList == null) {
			dtpList = new ArrayList<DtpDefEntity>();
		}
		return dtpList;
	}

	public void setDtpList(List<DtpDefEntity> dtpList) {
		this.dtpList = dtpList;
	}

}
