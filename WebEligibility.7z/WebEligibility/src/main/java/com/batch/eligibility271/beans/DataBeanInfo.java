package com.batch.eligibility271.beans;

import java.util.ArrayList;

/**
 * @author manishm3
 * @date MAR 30,2014
 */
public class DataBeanInfo {
	public ArrayList<EbMSG> ebMSGs;
	public SegmentBean nm1Bean;
	public ArrayList<SegmentBean> refs;
	public SegmentBean dmgBean;

	public ArrayList<EbMSG> getEbMSGs() {
		return ebMSGs;
	}

	public void setEbMSGs(ArrayList<EbMSG> ebMSGs) {
		this.ebMSGs = ebMSGs;
	}

	public SegmentBean getNm1Bean() {
		return nm1Bean;
	}

	public void setNm1Bean(SegmentBean nm1Bean) {
		this.nm1Bean = nm1Bean;
	}

	public ArrayList<SegmentBean> getRefs() {
		if (refs == null) {
			refs = new ArrayList<SegmentBean>();
		}
		return refs;
	}

	public void setRefs(ArrayList<SegmentBean> refs) {
		this.refs = refs;
	}

	public SegmentBean getDmgBean() {
		return dmgBean;
	}

	public void setDmgBean(SegmentBean dmgBean) {
		this.dmgBean = dmgBean;
	}

}
