package com.batch.eligibility271.parser;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.hibernate.HibernateException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.batch.eligibility.base.dao.BatchIBaseDao;
import com.batch.eligibility.common.utility.HLUtil;
import com.batch.eligibility.common.utility.StringUtil;
import com.batch.eligibility.shared.constants.EligibilityLoopEnum;
import com.batch.eligibility.shared.constants.EligibilityTagEnum;
import com.batch.eligibility270.writer.BatchEligibility270Writer;
import com.batch.eligibility271.beans.BeanIndex;
import com.batch.eligibility271.beans.DataBeanInfo;
import com.batch.eligibility271.beans.DataBeanLongDesc;
import com.batch.eligibility271.beans.EbMSG;
import com.batch.eligibility271.beans.FieldWithValueBean;
import com.batch.eligibility271.beans.IEligibility271Constants;
import com.batch.eligibility271.beans.LoopLevelRequiredInfo;
import com.batch.eligibility271.beans.SegmentBean;
import com.batch.eligibility271.constants.Ack999Constants;
import com.eligibility.shared.constants.RefDesgEnum;
import com.eligibility270.dbentities.Benefitsinformation;
import com.eligibility270.dbentities.Edi271longdesc;
import com.eligibility270.dbentities.Eligibility270withack;
import com.eligibility270.dbentities.Eligibilitysummary;
import com.eligibility270.dbentities.Insurancesummary;
import com.eligibility270.dbentities.Providersummary;
import com.eligibility270.dbentities.Requestvalidation;
import com.eligibility270.dbentities.Subscribersummary;
import com.eligibility270.writer.IConstants;
import com.eligibility271.dbentities.DtpDefEntity;
import com.eligibility271.dbentities.Edi271shortdesc;
import com.eligibility271.dbentities.EligibilityBatchOutput;
import com.eligibility271.dbentities.Patientsummary;
import com.eligibility271.longjson.response.BenifitsInformation;
import com.eligibility271.longjson.response.EligibilitySummary;
import com.eligibility271.longjson.response.FullDetailResponse;
import com.eligibility271.longjson.response.GeneralEligibilityInformation;
import com.eligibility271.longjson.response.InsuranceSummary;
import com.eligibility271.longjson.response.ProviderSummary;
import com.eligibility271.longjson.response.RequestValidation;
import com.eligibility271.longjson.response.RowItem;
import com.eligibility271.longjson.response.SubscriberSummary;
import com.eligibility271.shortjson.response.EligibilityResponseNotification;
import com.eligibility271.shortjson.response.PatientSummary;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author Manish
 * @date MAR 20,2015
 */
@Component
public class BatchEligibility271Parser {

	@SuppressWarnings("rawtypes")
	@Autowired
	BatchIBaseDao batchBaseDao;
	@Autowired
	BatchDtpDefinationLookUp batchDtpLookUp;

	// private List<String> shortDescList;

	private int longDescId;
	private String insuranceId;
	private String idCodeQual;

	private static final Logger LOG = LoggerFactory
			.getLogger(BatchEligibility271Parser.class);

	private BatchEligibility270Writer eligibility270Writer;

	public BatchEligibility270Writer getEligibility270Writer() {
		return eligibility270Writer;
	}

	public void setEligibility270Writer(
			BatchEligibility270Writer eligibility270Writer) {
		this.eligibility270Writer = eligibility270Writer;
	}

	public String getInsuranceId() {
		return insuranceId;
	}

	public void setInsuranceId(String insuranceId) {
		this.insuranceId = insuranceId;
	}

	public void getShortDesc(ArrayList<SegmentBean> segmentBeans,
			String eligibility271, Eligibility270withack eligibility270withack,
			SegmentBean aaa) {
		LOG.debug("Entering in to BatchEligibility271Parser :: getShortDesc");
		String traceNumber = getFieldByRefDesg(RefDesgEnum.TRN02,
				EligibilityTagEnum.TRN, segmentBeans);
		if (traceNumber == null || traceNumber.isEmpty()) {
			traceNumber = eligibility270withack.getEligibilitytracenumber();
		}
		String st02 = getFieldByRefDesg(RefDesgEnum.ST02,
				EligibilityTagEnum.ST, segmentBeans);

		BeanIndex subscriberLevel = getBeanIndexByHLLevel(segmentBeans,
				HLUtil.LEVEL_THREE, 0);
		BeanIndex dependentLevel = null;
		if (subscriberLevel != null) {
			dependentLevel = getBeanIndexByHLLevel(segmentBeans,
					HLUtil.LEVEL_FOUR, subscriberLevel.getIndex());
		}

		if (dependentLevel != null) {

			DataBeanInfo dataBeanInfo = getDataBeanInfo(segmentBeans,
					dependentLevel.getIndex(), EligibilityLoopEnum.LOOP2000D);
			processShortDesc(traceNumber, st02, dataBeanInfo, eligibility271,
					aaa);

		} else if (subscriberLevel != null) {
			DataBeanInfo dataBeanInfo = getDataBeanInfo(segmentBeans,
					subscriberLevel.getIndex(), EligibilityLoopEnum.LOOP2000C);
			processShortDesc(traceNumber, st02, dataBeanInfo, eligibility271,
					aaa);
		} else {
			processShortDesc(traceNumber, st02, eligibility271, aaa);
		}

		// if()
		LOG.debug("Exiting from BatchEligibility271Parser :: getShortDesc");
	}

	public void getLongDesc(ArrayList<SegmentBean> segmentBeans,
			String eligibility271, Eligibility270withack eligibility270withack) {
		LOG.debug("Entering in to BatchEligibility271Parser :: getLongDesc");
		DataBeanLongDesc dataBeanLongDesc = new DataBeanLongDesc();
		SegmentBean nm1BeanInfoSource = null;
		SegmentBean nm1BeanInfoReceiver = null;
		SegmentBean perBeanInfoSource = null;

		Map<String, ArrayList<SegmentBean>> aaaMap2000A = new HashMap<String, ArrayList<SegmentBean>>();
		Map<String, ArrayList<SegmentBean>> aaaMap2000B = new HashMap<String, ArrayList<SegmentBean>>();

		String traceNumber = getFieldByRefDesg(RefDesgEnum.TRN02,
				EligibilityTagEnum.TRN, segmentBeans);
		if (traceNumber == null || traceNumber.isEmpty()) {
			traceNumber = eligibility270withack.getEligibilitytracenumber();
		}
		dataBeanLongDesc.setTraceNumber(traceNumber);
		BeanIndex inforSourceNameInd = getBeanIndexByHLLevel(segmentBeans,
				HLUtil.LEVEL_ONE, IConstants.START_INDEX);
		BeanIndex infoReceiverInd = null;
		BeanIndex subscriberLevelInd = null;

		if (inforSourceNameInd != null) {
			nm1BeanInfoSource = getNm1BeanByLoopId(
					inforSourceNameInd.getIndex(), segmentBeans);
			perBeanInfoSource = getPerBeanByLoopId(
					inforSourceNameInd.getIndex(), segmentBeans);
			infoReceiverInd = getBeanIndexByHLLevel(segmentBeans,
					HLUtil.LEVEL_TWO, inforSourceNameInd.getIndex());
			aaaMap2000A = getAAAMap(inforSourceNameInd.getIndex(),
					segmentBeans, EligibilityLoopEnum.LOOP2000A);
		} else {
			infoReceiverInd = getBeanIndexByHLLevel(segmentBeans,
					HLUtil.LEVEL_ONE, IConstants.START_INDEX);
		}

		if (infoReceiverInd != null) {
			nm1BeanInfoReceiver = getNm1BeanByLoopId(
					infoReceiverInd.getIndex(), segmentBeans);
			subscriberLevelInd = getBeanIndexByHLLevel(segmentBeans,
					HLUtil.LEVEL_THREE, infoReceiverInd.getIndex());
			aaaMap2000B = getAAAMap(infoReceiverInd.getIndex(), segmentBeans,
					EligibilityLoopEnum.LOOP2000B);
		} else {
			subscriberLevelInd = getBeanIndexByHLLevel(segmentBeans,
					HLUtil.LEVEL_THREE, IConstants.START_INDEX);
		}

		BeanIndex dependentLevel = null;
		if (subscriberLevelInd != null) {
			dependentLevel = getBeanIndexByHLLevel(segmentBeans,
					HLUtil.LEVEL_FOUR, subscriberLevelInd.getIndex());
		}
		Edi271longdesc longDesc = null;
		if (dependentLevel != null) {
			LoopLevelRequiredInfo loopLevelRequiredInfo = getDataBeanInfoLongDesc(
					segmentBeans, dependentLevel.getIndex(),
					EligibilityLoopEnum.LOOP2100D);
			dataBeanLongDesc.setLoopLevelRequiredInfo(loopLevelRequiredInfo);
			dataBeanLongDesc.setNm1Bean2100A(nm1BeanInfoSource);
			dataBeanLongDesc.setPerBean2100A(perBeanInfoSource);
			dataBeanLongDesc.setNm1Bean2100B(nm1BeanInfoReceiver);
			longDesc = processLongDesc(dataBeanLongDesc, eligibility271,
					aaaMap2000A, aaaMap2000B, perBeanInfoSource);
		} else if (subscriberLevelInd != null) {
			LoopLevelRequiredInfo loopLevelRequiredInfo = getDataBeanInfoLongDesc(
					segmentBeans, subscriberLevelInd.getIndex(),
					EligibilityLoopEnum.LOOP2100C);
			dataBeanLongDesc.setLoopLevelRequiredInfo(loopLevelRequiredInfo);
			dataBeanLongDesc.setNm1Bean2100A(nm1BeanInfoSource);
			dataBeanLongDesc.setPerBean2100A(perBeanInfoSource);
			dataBeanLongDesc.setNm1Bean2100B(nm1BeanInfoReceiver);
			longDesc = processLongDesc(dataBeanLongDesc, eligibility271,
					aaaMap2000A, aaaMap2000B, perBeanInfoSource);
		} else if (nm1BeanInfoReceiver != null) {
			longDesc = processLongDesc(nm1BeanInfoReceiver, nm1BeanInfoSource,
					eligibility271, aaaMap2000A, aaaMap2000B, traceNumber,
					perBeanInfoSource);
		}
		if (longDesc != null) {
			FullDetailResponse fullDetailResponse = getFullresponse(longDesc,
					traceNumber);
			fullDetailResponse.setEligibility_tracer_number(traceNumber);
			fullDetailResponse.setLongDescrId(longDescId);

			ObjectMapper objectMapper = new ObjectMapper();
			String jsonStr;
			try {
				jsonStr = objectMapper.writeValueAsString(fullDetailResponse);
				System.out
						.println("<<<<<<<<<<<<<<< JSON Long Desc Response >>>>>>>>>>>>>>>>");
				System.out.println(jsonStr);
				System.out.println("Long JSON END");
			} catch (JsonProcessingException e) {
				LOG.error("Exception while writing long description", e);
			}

		}
		LOG.debug("Exiting from BatchEligibility271Parser :: getLongDesc");
	}

	public SegmentBean getSegmentBean(ArrayList<SegmentBean> segmentBeans,
			EligibilityTagEnum tagEnum) {
		LOG.debug("Entering in to BatchEligibility271Parser :: getSegmentBean");
		for (SegmentBean sb : segmentBeans) {
			if (sb.getSegmentName().equals(tagEnum)) {
				return sb;
			}
		}
		LOG.debug("Exiting from BatchEligibility271Parser :: getSegmentBean");
		return null;
	}

	public String getFieldByRefDesg(RefDesgEnum refDesig,
			EligibilityTagEnum tagEnum, ArrayList<SegmentBean> segmentBeans) {
		LOG.debug("Entering in to BatchEligibility271Parser :: getFieldByRefDesg");
		SegmentBean segmentBean = getSegmentBean(segmentBeans, tagEnum);
		if (segmentBean == null) {
			return new String();
		}
		FieldWithValueBean fieldWithValueBean = segmentBean
				.getFieldBeanByFieldName(refDesig.value());
		if (fieldWithValueBean != null) {
			String desgValue = fieldWithValueBean.getFieldValue();
			if (desgValue != null && !desgValue.isEmpty()) {
				return desgValue;
			}
		}
		LOG.debug("Exiting from BatchEligibility271Parser :: getFieldByRefDesg");
		return new String();
	}

	public String getFieldByRefDesg(RefDesgEnum refDesig,
			SegmentBean segmentBean) {
		LOG.debug("Entering in to BatchEligibility271Parser :: getFieldByRefDesg");
		FieldWithValueBean fieldWithValueBean = segmentBean
				.getFieldBeanByFieldName(refDesig.value());
		if (fieldWithValueBean != null) {
			String value = fieldWithValueBean.getFieldValue();
			if (value != null && !value.isEmpty()) {
				return value;
			}
		}
		LOG.debug("Exiting from BatchEligibility271Parser :: getFieldByRefDesg");
		return new String();
	}

	public BeanIndex getBeanIndexByHLLevel(ArrayList<SegmentBean> segmentBeans,
			int hlLevel, int startIndex) {
		LOG.debug("Entering in to BatchEligibility271Parser :: getFieldByRefDesg");
		for (int i = startIndex; i < segmentBeans.size(); i++) {
			SegmentBean segmentBean = segmentBeans.get(i);
			EligibilityTagEnum eligibilityTagEnum = segmentBean
					.getSegmentName();
			if (eligibilityTagEnum.equals(EligibilityTagEnum.HL)) {
				String hl03 = getFieldByRefDesg(RefDesgEnum.HL03, segmentBean);
				try {
					Integer hl03Value = Integer.valueOf(hl03);
					if (hl03Value == hlLevel) {
						BeanIndex bi = new BeanIndex(i, segmentBean,
								eligibilityTagEnum);
						return bi;
					}
				} catch (NumberFormatException ne) {
					LOG.error("Exception while casting String to int", ne);
				}
			}
		}
		LOG.debug("Exiting from BatchEligibility271Parser :: getFieldByRefDesg");
		return null;
	}

	public DataBeanInfo getDataBeanInfo(ArrayList<SegmentBean> segmentBeans,
			int startIndex, EligibilityLoopEnum loopid) {
		LOG.debug("Entering in to BatchEligibility271Parser :: getDataBeanInfo");
		DataBeanInfo dataBeanInfo = new DataBeanInfo();
		ArrayList<EbMSG> ebMsgs = new ArrayList<EbMSG>();
		if (startIndex + 1 >= segmentBeans.size()) {
			return null;
		}
		SegmentBean nm1Bean = null;
		boolean isEB = false;

		EbMSG ebMSG = null;
		for (int i = startIndex + 2; i < segmentBeans.size(); i++) {
			SegmentBean segmentBean = segmentBeans.get(i);
			if (segmentBean.getSegmentName().equals(EligibilityTagEnum.SE)
					|| segmentBean.getSegmentName().equals(
							EligibilityTagEnum.HL)) {
				break;
			}

			if (segmentBean.getSegmentName().equals(EligibilityTagEnum.EB)) {
				isEB = true;
				if (ebMSG != null) {
					ebMsgs.add(ebMSG);
				}
				ebMSG = new EbMSG();
				ebMSG.setEb(segmentBean);
			} else if (segmentBean.getSegmentName().equals(
					EligibilityTagEnum.MSG)) {
				if (ebMSG != null) {
					ebMSG.getSegmentBeansMSGList().add(segmentBean);
				}
			} else if (segmentBean.getSegmentName().equals(
					EligibilityTagEnum.DTP)) {
				if (ebMSG != null) {
					ebMSG.getSegmentBeansDTPList().add(segmentBean);
				}
			} else if (segmentBean.getSegmentName().equals(
					EligibilityTagEnum.NM1)) {
				String nm101 = getFieldByRefDesg(RefDesgEnum.NM101, segmentBean);
				if (nm101.equals(IEligibility271Constants.IL)
						&& loopid.equals(EligibilityLoopEnum.LOOP2000C)) {
					nm1Bean = segmentBean;
					String insId = nm1Bean.getFieldBeanByFieldName(
							RefDesgEnum.NM109.value()).getFieldValue();
					if (insId != null) {
						insuranceId = insId;
						idCodeQual = nm1Bean.getFieldBeanByFieldName(
								RefDesgEnum.NM108.value()).getFieldValue();
					}
				} else if (nm101.equals(IEligibility271Constants.ZERO_3)
						&& loopid.equals(EligibilityLoopEnum.LOOP2000D)) {
					nm1Bean = segmentBean;
				}
			} else if (!isEB
					&& (segmentBean.getSegmentName()
							.equals(EligibilityTagEnum.REF))
					&& (getFieldByRefDesg(RefDesgEnum.REF01, segmentBean)
							.equals(IEligibility271Constants.ONE_W) || getFieldByRefDesg(
							RefDesgEnum.REF01, segmentBean).equals(
							IEligibility271Constants.SY))) {
				dataBeanInfo.getRefs().add(segmentBean);
			} else if (segmentBean.getSegmentName().equals(
					EligibilityTagEnum.DMG)) {
				dataBeanInfo.setDmgBean(segmentBean);
			}// end if

		}
		if (ebMSG != null) {
			ebMsgs.add(ebMSG);
		}
		dataBeanInfo.setEbMSGs(ebMsgs);
		dataBeanInfo.setNm1Bean(nm1Bean);
		LOG.debug("Exiting from BatchEligibility271Parser :: getDataBeanInfo");
		return dataBeanInfo;
	}// end

	public Patientsummary getPatientSummury(SegmentBean nm1Bean,
			SegmentBean dmgBean) {
		LOG.debug("Entering in to BatchEligibility271Parser :: getPatientSummury");
		if (nm1Bean == null && dmgBean == null) {
			return null;
		}
		Patientsummary patientsummary = new Patientsummary();

		String lastName = "";
		String firstName = "";
		String middleInitial = "";
		String memberNumber = "";
		if (nm1Bean != null) {
			lastName = getFieldByRefDesg(RefDesgEnum.NM103, nm1Bean);
			firstName = getFieldByRefDesg(RefDesgEnum.NM104, nm1Bean);
			middleInitial = getFieldByRefDesg(RefDesgEnum.NM105, nm1Bean);
			memberNumber = getFieldByRefDesg(RefDesgEnum.NM109, nm1Bean);
			if (memberNumber == null || memberNumber.isEmpty()) {
				memberNumber = insuranceId;
			}
		}

		patientsummary.setFirstname(firstName);
		patientsummary.setLastname(lastName);
		patientsummary.setMiddleinitial(middleInitial);
		patientsummary.setMembernumber(memberNumber);

		String genderCode = "";
		String dateOfBirth = "";

		if (dmgBean != null) {
			genderCode = getFieldByRefDesg(RefDesgEnum.DMG03, dmgBean);
			dateOfBirth = getFieldByRefDesg(RefDesgEnum.DMG02, dmgBean);

			patientsummary.setDateofbirth(dateOfBirth);
			patientsummary.setGender(genderCode);
		}

		if (!lastName.isEmpty() || !firstName.isEmpty()
				|| !middleInitial.isEmpty() || !genderCode.isEmpty()
				|| !dateOfBirth.isEmpty()) {
			return patientsummary;
		}
		LOG.debug("Exiting from BatchEligibility271Parser :: getPatientSummury");
		return null;
	}

	public void processShortDesc(String traceNumber, String st02,
			DataBeanInfo dataBeanInfo, String eligibility271, SegmentBean aaa) {
		LOG.debug("Entering in to BatchEligibility271Parser :: processShortDesc");
		Edi271shortdesc shortdesc = new Edi271shortdesc();
		shortdesc.setEligibilitytracernumber(traceNumber);
		try {
			shortdesc.setTransactionsetcontrolnumber(Integer.valueOf(st02));
		} catch (NumberFormatException ne) {
			LOG.error("Exception while casting String to int", ne);
		}
		Patientsummary patientsummary = getPatientSummury(
				dataBeanInfo.getNm1Bean(), dataBeanInfo.getDmgBean());
		if (patientsummary != null) {
			shortdesc.setPatientsummary(patientsummary);
		}
		setMsgEB(shortdesc, dataBeanInfo.getEbMSGs(), traceNumber);
		shortdesc.setEdimessage(eligibility271);
		if (shortdesc.getEligibilityoutcomemessage() == null
				|| shortdesc.getEligibilityoutcomemessage().isEmpty()) {
			processAAA(shortdesc, aaa);
		}
		try {
			batchBaseDao.saveWithShortDesc(patientsummary, shortdesc);
		} catch (HibernateException he) {
			LOG.error("Exception saving short description", he);
		}

		EligibilityBatchOutput output = new EligibilityBatchOutput();
		output.setEdimessage(eligibility271);
		output.setDateofbirth(patientsummary.getDateofbirth());
		output.setLastname(patientsummary.getLastname());
		output.setFirstname(patientsummary.getFirstname());
		output.setGender(patientsummary.getGender());
		output.setSsn(patientsummary.getSsn());
		output.setMembernumber(patientsummary.getMembernumber());
		output.setMiddleinitial(patientsummary.getMiddleinitial());
		output.setEligibilityoutcomecode(shortdesc.getEligibilityoutcomecode());
		output.setEligibilityoutcomemessage(shortdesc
				.getEligibilityoutcomemessage());
		output.setEligibilitytracenumber(traceNumber);
		output.setTransactionsetcontrolnumber(shortdesc
				.getTransactionsetcontrolnumber());

		processShortDescBatch(output);

		LOG.debug("Exiting from BatchEligibility271Parser :: processShortDesc");
	}

	public EligibilityResponseNotification getELiEligibilityResponseNotification(
			Edi271shortdesc shortdesc) {
		LOG.debug("Entering in to BatchEligibility271Parser :: getELiEligibilityResponseNotification");
		EligibilityResponseNotification responseNotification = new EligibilityResponseNotification();
		responseNotification.setEdiMessage(shortdesc.getEdimessage());
		responseNotification.setEligibilityOutcomeCode(shortdesc
				.getEligibilityoutcomecode());
		responseNotification.setEligibilityOutcomeMessage(shortdesc
				.getEligibilityoutcomemessage());
		responseNotification.setEligibilityTracerNumber(shortdesc
				.getEligibilitytracernumber());
		responseNotification.setMspType(shortdesc.getMspType());
		responseNotification.setTransactionSetControlNumber(String
				.valueOf(shortdesc.getTransactionsetcontrolnumber()));

		Patientsummary patientsummaryDB = shortdesc.getPatientsummary();

		if (patientsummaryDB != null) {
			PatientSummary patientSummaryJSON = new PatientSummary();
			patientSummaryJSON.setDateOfBirth(StringUtil
					.removeSpace(patientsummaryDB.getDateofbirth()));
			patientSummaryJSON.setFirstName(StringUtil
					.removeSpace(patientsummaryDB.getFirstname()));
			patientSummaryJSON.setGender(StringUtil
					.removeSpace(patientsummaryDB.getGender()));
			patientSummaryJSON.setLastName(StringUtil
					.removeSpace(patientsummaryDB.getLastname()));
			patientSummaryJSON.setMemberNumber(StringUtil
					.removeSpace(patientsummaryDB.getMembernumber()));
			patientSummaryJSON.setMiddleInitial(StringUtil
					.removeSpace(patientsummaryDB.getMiddleinitial()));
			patientSummaryJSON.setSsn(StringUtil.removeSpace(patientsummaryDB
					.getSsn()));

			ArrayList<PatientSummary> patientSummaries = new ArrayList<PatientSummary>();
			patientSummaries.add(patientSummaryJSON);
			responseNotification.setPatientSummary(patientSummaries);
		}
		LOG.debug("Exiting from BatchEligibility271Parser :: getELiEligibilityResponseNotification");
		return responseNotification;
	}

	public LoopLevelRequiredInfo getDataBeanInfoLongDesc(
			ArrayList<SegmentBean> segmentBeans, int startIndex,
			EligibilityLoopEnum loopid) {
		LOG.debug("Entering in to BatchEligibility271Parser :: getDataBeanInfoLongDesc");
		LoopLevelRequiredInfo loopLevelRequiredInfo = new LoopLevelRequiredInfo();

		if (startIndex + 1 >= segmentBeans.size()) {
			return null;
		}
		Map<String, ArrayList<SegmentBean>> aaaMap = new HashMap<String, ArrayList<SegmentBean>>();
		ArrayList<SegmentBean> aaaF = new ArrayList<SegmentBean>();
		ArrayList<SegmentBean> aaaS = new ArrayList<SegmentBean>();

		ArrayList<EbMSG> ebMsgs = new ArrayList<EbMSG>();
		ArrayList<SegmentBean> dtpBeans = new ArrayList<SegmentBean>();
		boolean isEB = false;
		EbMSG ebMSG = null;
		for (int i = startIndex + 2; i < segmentBeans.size(); i++) {
			SegmentBean segmentBean = segmentBeans.get(i);
			if (segmentBean.getSegmentName().equals(EligibilityTagEnum.SE)
					|| segmentBean.getSegmentName().equals(
							EligibilityTagEnum.HL)) {
				break;
			} else if (segmentBean.getSegmentName().equals(
					EligibilityTagEnum.NM1)) {
				// if(loopid.equals(EligibilityLoopEnum.LOOP2100C) ){
				String nm101 = getFieldByRefDesg(RefDesgEnum.NM101, segmentBean);
				if (nm101.equals(IEligibility271Constants.IL)) {
					String nm109 = getFieldByRefDesg(RefDesgEnum.NM109,
							segmentBean);
					if (nm109 != null) {
						insuranceId = nm109;
					}
				}
				if (nm101.equals(IEligibility271Constants.IL)
						&& loopid.equals(EligibilityLoopEnum.LOOP2100C)) {
					loopLevelRequiredInfo.setNm1Bean(segmentBean);
				} else if (nm101.equals(IEligibility271Constants.ZERO_3)
						&& loopid.equals(EligibilityLoopEnum.LOOP2100D)) {
					loopLevelRequiredInfo.setNm1Bean(segmentBean);
				}
				// }
			} else if (segmentBean.getSegmentName().equals(
					EligibilityTagEnum.N3)) {
				loopLevelRequiredInfo.setN3Bean(segmentBean);
			} else if (segmentBean.getSegmentName().equals(
					EligibilityTagEnum.N4)) {
				loopLevelRequiredInfo.setN4Bean(segmentBean);
			} else if (segmentBean.getSegmentName().equals(
					EligibilityTagEnum.DMG)) {
				loopLevelRequiredInfo.setDmgBean(segmentBean);
			} else if (segmentBean.getSegmentName().equals(
					EligibilityTagEnum.INS)) {
				loopLevelRequiredInfo.setIsnBean(segmentBean);
			} else if (segmentBean.getSegmentName().equals(
					EligibilityTagEnum.REF)) {
				loopLevelRequiredInfo.getRefBean().add(segmentBean);
			} else if (segmentBean.getSegmentName().equals(
					EligibilityTagEnum.DTP)) {
				if (!isEB) {
					dtpBeans.add(segmentBean);
				}
			} else if (segmentBean.getSegmentName().equals(
					EligibilityTagEnum.EB)) {
				isEB = true;
				if (ebMSG != null) {
					ebMsgs.add(ebMSG);
				}
				ebMSG = new EbMSG();
				ebMSG.setEb(segmentBean);
			} else if (segmentBean.getSegmentName().equals(
					EligibilityTagEnum.MSG)) {
				if (ebMSG != null) {
					ebMSG.getSegmentBeansMSGList().add(segmentBean);
				}
			} else if (segmentBean.getSegmentName().equals(
					EligibilityTagEnum.AAA)) {
				if (isEB) {
					aaaS.add(segmentBean);
				} else
					aaaF.add(segmentBean);
			}

		}// end for
		if (ebMSG != null) {
			ebMsgs.add(ebMSG);
		}
		if (!dtpBeans.isEmpty()) {
			loopLevelRequiredInfo.setDtpBean(dtpBeans);
		}
		if (loopid.equals(EligibilityLoopEnum.LOOP2100C)) {
			if (!aaaF.isEmpty())
				aaaMap.put(EligibilityLoopEnum.LOOP2100C.value(), aaaF);
			else if (!aaaS.isEmpty())
				aaaMap.put(EligibilityLoopEnum.LOOP2110C.value(), aaaS);
		} else if (loopid.equals(EligibilityLoopEnum.LOOP2100D)) {
			if (!aaaF.isEmpty())
				aaaMap.put(EligibilityLoopEnum.LOOP2100D.value(), aaaF);
			else if (!aaaS.isEmpty())
				aaaMap.put(EligibilityLoopEnum.LOOP2110D.value(), aaaS);
		}

		if (!aaaMap.isEmpty()) {
			loopLevelRequiredInfo.setAaaSegments(aaaMap);
		}
		loopLevelRequiredInfo.setEbMSGs(ebMsgs);
		LOG.debug("Exiting from BatchEligibility271Parser :: getDataBeanInfoLongDesc");
		return loopLevelRequiredInfo;
	}

	public SegmentBean getNm1BeanByLoopId(int startIndex,
			ArrayList<SegmentBean> segmentBeans) {
		LOG.debug("Entering in to BatchEligibility271Parser :: getNm1BeanByLoopId");
		if (segmentBeans == null || segmentBeans.isEmpty()) {
			return null;
		}

		for (int i = startIndex + 1; i < segmentBeans.size(); i++) {
			SegmentBean segmentBean = segmentBeans.get(i);
			if (segmentBean.getSegmentName().equals(EligibilityTagEnum.NM1)) {
				return segmentBean;
			} else if (segmentBean.getSegmentName().equals(
					EligibilityTagEnum.HL)
					|| segmentBean.getSegmentName().equals(
							EligibilityTagEnum.SE)) {
				break;
			}
		}
		LOG.debug("Exiting from BatchEligibility271Parser :: getNm1BeanByLoopId");
		return null;
	}

	private Edi271longdesc processLongDesc(DataBeanLongDesc dataBeanLongDesc,
			String eligibility271,
			Map<String, ArrayList<SegmentBean>> aaaMap2000A,
			Map<String, ArrayList<SegmentBean>> aaaMap2000B,
			SegmentBean perBeanInfoSource) {
		LOG.debug("Entering in to BatchEligibility271Parser :: processLongDesc");
		if (dataBeanLongDesc == null) {
			return null;
		}
		Edi271longdesc edi271longdesc = new Edi271longdesc();
		edi271longdesc.setEligibilitytracernumber(dataBeanLongDesc
				.getTraceNumber());

		Eligibilitysummary eligibilitysummary = getEligibilitysumm(dataBeanLongDesc
				.getLoopLevelRequiredInfo());
		Insurancesummary insurancesummary = getInsuranceSummDB(
				dataBeanLongDesc.getNm1Bean2100A(),
				dataBeanLongDesc.getPerBean2100A());
		Providersummary providersummary = getProviderSumm(dataBeanLongDesc
				.getNm1Bean2100B());
		Subscribersummary subscribersummary = getSubscriberSumm(dataBeanLongDesc
				.getLoopLevelRequiredInfo());
		ArrayList<Benefitsinformation> benefitsinformations = getBenefitsInfo(dataBeanLongDesc
				.getLoopLevelRequiredInfo());
		ArrayList<Requestvalidation> requestvalidations = getRequestValidations(
				dataBeanLongDesc.getLoopLevelRequiredInfo(), aaaMap2000A,
				aaaMap2000B);

		if (eligibilitysummary != null) {
			edi271longdesc.setEligibilitysummary(eligibilitysummary);
		}
		if (insurancesummary != null) {
			edi271longdesc.setInsurancesummary(insurancesummary);
		}
		if (providersummary != null) {
			edi271longdesc.setProvidersummary(providersummary);
		}
		if (subscribersummary != null) {
			edi271longdesc.setSubscribersummary(subscribersummary);
		}
		if (!benefitsinformations.isEmpty()) {
			for (Benefitsinformation binfo : benefitsinformations) {
				edi271longdesc.addBenefitsinformation(binfo);
			}
		}
		if (!requestvalidations.isEmpty()) {
			for (Requestvalidation reqVal : requestvalidations) {
				edi271longdesc.addRequestvalidation(reqVal);
			}
		}
		try {
			batchBaseDao.saveLongDecs(edi271longdesc, eligibilitysummary,
					insurancesummary, providersummary, subscribersummary);
		} catch (HibernateException he) {
			LOG.error("Exception while saving long description", he);
		}
		LOG.debug("Exiting from BatchEligibility271Parser :: processLongDesc");
		return edi271longdesc;
	}

	public Insurancesummary getInsuranceSummDB(SegmentBean nm1SourceInfo,
			SegmentBean perBeanInfo) {
		LOG.debug("Entering in to BatchEligibility271Parser :: getInsuranceSummDB");
		if (nm1SourceInfo == null) {
			return null;
		}
		Insurancesummary insurancesummary = new Insurancesummary();
		String payerName = nm1SourceInfo.getFieldBeanByFieldName(
				RefDesgEnum.NM103.value()).getFieldValue();
		if (payerName != null && !payerName.isEmpty()) {
			insurancesummary.setPayername(payerName);
		}

		String payerIdenQual = nm1SourceInfo.getFieldBeanByFieldName(
				RefDesgEnum.NM108.value()).getFieldValue();
		if (payerIdenQual == null) {
			payerIdenQual = idCodeQual;
		}
		if (payerIdenQual != null && !payerIdenQual.isEmpty()) {
			insurancesummary.setPayeridentificationqualifier(payerIdenQual);
		}

		String payerIdenCode = nm1SourceInfo.getFieldBeanByFieldName(
				RefDesgEnum.NM109.value()).getFieldValue();
		if (payerIdenCode != null && !payerIdenCode.isEmpty()) {
			insurancesummary.setPayeridentificationcode(payerIdenCode);
		}
		if (perBeanInfo != null) {
			String telephone = perBeanInfo.getFieldBeanByFieldName(
					RefDesgEnum.PER04.value()).getFieldValue();
			if (telephone != null && !telephone.isEmpty()) {
				insurancesummary.setTelephone(telephone);
			}

			String url = perBeanInfo.getFieldBeanByFieldName(
					RefDesgEnum.PER06.value()).getFieldValue();
			if (url != null && !url.isEmpty()) {
				insurancesummary.setUrl(url);
			}
		}
		@SuppressWarnings("unused")
		String payerAdd = ""; // mapping not found in excel sheet.
		LOG.debug("Exiting from BatchEligibility271Parser :: getInsuranceSummDB");
		return insurancesummary;
	}

	public Providersummary getProviderSumm(SegmentBean nm1Bean) {
		LOG.debug("Entering in to BatchEligibility271Parser :: getProviderSumm");
		if (nm1Bean == null) {
			return null;
		}
		Providersummary providersummary = new Providersummary();

		String providerName = nm1Bean.getFieldBeanByFieldName(
				RefDesgEnum.NM103.value()).getFieldValue();
		if (providerName != null && !providerName.isEmpty()) {
			providersummary.setProvidername(providerName);
		}

		String providerIdenQual = nm1Bean.getFieldBeanByFieldName(
				RefDesgEnum.NM108.value()).getFieldValue();
		if (providerIdenQual != null && !providerIdenQual.isEmpty()) {
			providersummary
					.setProvideridentificationqualifier(providerIdenQual);
		}

		String providerIdenCode = nm1Bean.getFieldBeanByFieldName(
				RefDesgEnum.NM109.value()).getFieldValue();
		if (providerIdenCode != null && !providerIdenCode.isEmpty()) {
			providersummary.setProvideridentificationcode(providerIdenCode);
		}
		@SuppressWarnings("unused")
		String provAdd = ""; // mapping not found in excel sheet.
		LOG.debug("Exiting from BatchEligibility271Parser :: getProviderSumm");
		return providersummary;
	}

	@SuppressWarnings("unused")
	public Eligibilitysummary getEligibilitysumm(
			LoopLevelRequiredInfo loopLevelRequiredInfo) {
		LOG.debug("Entering in to BatchEligibility271Parser :: getEligibilitysumm");
		if (loopLevelRequiredInfo == null) {
			return null;
		}
		Eligibilitysummary eligibilitysummary = new Eligibilitysummary();

		ArrayList<SegmentBean> dtps = loopLevelRequiredInfo.getDtpBean();
		if (dtps != null && !dtps.isEmpty()) {
			SegmentBean dtpBean = dtps.get(0);
			FieldWithValueBean dtpFieldWithValueBean = dtpBean
					.getFieldBeanByFieldName(RefDesgEnum.DTP03.value());
			if (dtpFieldWithValueBean != null) {
				String eligibilityBeginDate = dtpFieldWithValueBean
						.getFieldValue();
				eligibilitysummary
						.setEligibilitybegindate(eligibilityBeginDate);
			}
		}

		StringBuilder eb01 = new StringBuilder();
		StringBuilder eb04 = new StringBuilder();
		StringBuilder eb05 = new StringBuilder();

		ArrayList<EbMSG> ebMSGs = loopLevelRequiredInfo.getEbMSGs();
		if (ebMSGs != null && !ebMSGs.isEmpty()) {
			for (EbMSG ebMSG : ebMSGs) {
				SegmentBean ebBean = ebMSG.getEb();
				if (ebBean != null) {
					FieldWithValueBean eb01Val = ebBean
							.getFieldBeanByFieldName(RefDesgEnum.EB01.value());
					if (eb01Val != null) {
						String eb01Str = eb01Val.getFieldValue();
						if (eb01Str != null && !eb01Str.isEmpty()) {
							eb01.append(eb01Str);
							eb01.append(IConstants.COMMA);
						}
					}
					FieldWithValueBean eb04Val = ebBean
							.getFieldBeanByFieldName(RefDesgEnum.EB04.value());
					if (eb04Val != null) {
						String eb04Str = eb04Val.getFieldValue();
						if (eb04Str != null && !eb04Str.isEmpty()) {
							eb04.append(eb04Str);
							eb04.append(IConstants.COMMA);
						}
					}

					FieldWithValueBean eb05Val = ebBean
							.getFieldBeanByFieldName(RefDesgEnum.EB05.value());
					if (eb05Val != null) {
						String eb05Str = eb05Val.getFieldValue();
						if (eb05Str != null && !eb05Str.isEmpty()) {
							eb04.append(eb05Str);
							eb05.append(IConstants.COMMA);
						}
					}
				}// end if ebBean
			}// end for
		}// end if

		if (!eb01.toString().isEmpty()) {
			String eligibilityStatus = StringUtil.removeUnusedComma(eb01
					.toString());
			eligibilitysummary.setEligibilitystatus(eligibilityStatus);
		}

		if (!eb04.toString().isEmpty()) {
			String policyType = StringUtil.removeUnusedComma(eb04.toString());
			eligibilitysummary.setPolicytype(policyType);
		}

		if (!eb05.toString().isEmpty()) {
			String policyDesc = StringUtil.removeUnusedComma(eb05.toString());
			eligibilitysummary.setPolicydescription(policyDesc);
		}

		String eligibilityRequestDate = "";
		String eligibilityRequestDatOfServ = "";
		LOG.debug("Exiting from BatchEligibility271Parser :: getEligibilitysumm");
		return eligibilitysummary;
	}

	public Subscribersummary getSubscriberSumm(
			LoopLevelRequiredInfo loopLevelRequiredInfo) {
		LOG.debug("Entering in to BatchEligibility271Parser :: getSubscriberSumm");
		Subscribersummary subscribersummary = new Subscribersummary();

		SegmentBean nm1Bean = loopLevelRequiredInfo.getNm1Bean();
		if (nm1Bean != null) {
			FieldWithValueBean nm103FieldWithValueBean = nm1Bean
					.getFieldBeanByFieldName(RefDesgEnum.NM103.value());
			StringBuilder subscriberName = new StringBuilder();

			if (nm103FieldWithValueBean != null) {
				String nm103Val = nm103FieldWithValueBean.getFieldValue();
				if (nm103Val != null && !nm103Val.isEmpty()) {
					subscriberName.append(nm103Val);
					subscriberName.append(" ");
				}
			}

			FieldWithValueBean nm104FieldWithValueBean = nm1Bean
					.getFieldBeanByFieldName(RefDesgEnum.NM104.value());
			if (nm104FieldWithValueBean != null) {
				String nm104Val = nm104FieldWithValueBean.getFieldValue();
				if (nm104Val != null && !nm104Val.isEmpty()) {
					subscriberName.append(nm104Val);
					subscriberName.append(" ");
				}
			}

			FieldWithValueBean nm105FieldWithValueBean = nm1Bean
					.getFieldBeanByFieldName(RefDesgEnum.NM105.value());
			if (nm105FieldWithValueBean != null) {
				String nm105Val = nm105FieldWithValueBean.getFieldValue();
				if (nm105Val != null && !nm105Val.isEmpty()) {
					subscriberName.append(nm105Val);
				}
			}

			FieldWithValueBean nm109FieldWithValueBean = nm1Bean
					.getFieldBeanByFieldName(RefDesgEnum.NM109.value());
			if (nm109FieldWithValueBean == null) {
				subscribersummary.setMemberid(insuranceId);
			} else {
				String nm109Val = nm109FieldWithValueBean.getFieldValue();
				if (nm109Val != null && !nm109Val.isEmpty()) {
					subscribersummary.setMemberid(nm109Val);
				}
			}

			if (!subscriberName.toString().trim().isEmpty()) {
				subscribersummary.setSubscribername(subscriberName.toString());
			}
		}

		ArrayList<SegmentBean> refs = loopLevelRequiredInfo.getRefBean();
		if (refs != null && !refs.isEmpty()) {
			for (SegmentBean refBean : refs) {
				FieldWithValueBean ref01FieldWithValueBean = refBean
						.getFieldBeanByFieldName(RefDesgEnum.REF01.value());
				if (ref01FieldWithValueBean != null) {
					String ref01Str = ref01FieldWithValueBean.getFieldValue();
					FieldWithValueBean ref02FieldWithValueBean = refBean
							.getFieldBeanByFieldName(RefDesgEnum.REF02.value());
					if (ref01Str.equals(IConstants.ONE_W)) {
						String memberid = getFieldWithBeanValue(ref02FieldWithValueBean);
						subscribersummary.setMemberid(memberid);
					} else if (ref01Str.equals(IConstants.SIX_P)) {
						String groupNum = getFieldWithBeanValue(ref02FieldWithValueBean);
						subscribersummary.setGroupnumber(groupNum);
						FieldWithValueBean ref03FieldWithValueBean = refBean
								.getFieldBeanByFieldName(RefDesgEnum.REF03
										.value());
						String groupname = getFieldWithBeanValue(ref03FieldWithValueBean);
						subscribersummary.setGroupname(groupname);
					} else if (ref01Str.equals(IConstants.ONE_L)) {
						String policyNum = getFieldWithBeanValue(ref02FieldWithValueBean);
						subscribersummary.setPolicynumber(policyNum);
					} else if (ref01Str.equals(IConstants.Q4)) {
						String priorId = getFieldWithBeanValue(ref02FieldWithValueBean);
						subscribersummary.setNewmemberid(priorId);
					} else if (ref01Str.equals(IConstants.SY)) {

						String ssn = getFieldWithBeanValue(ref02FieldWithValueBean);
						subscribersummary.setSsn(ssn);
					}

				}
			}// end for
		}

		@SuppressWarnings("unused")
		String newMemId = "";

		SegmentBean n3Bean = loopLevelRequiredInfo.getN3Bean();
		if (n3Bean != null) {
			FieldWithValueBean n301 = n3Bean
					.getFieldBeanByFieldName(RefDesgEnum.N301.value());
			FieldWithValueBean n302 = n3Bean
					.getFieldBeanByFieldName(RefDesgEnum.N302.value());

			StringBuilder subsAddr = new StringBuilder();
			subsAddr.append(getFieldWithBeanValue(n301));
			subsAddr.append(" ");
			subsAddr.append(getFieldWithBeanValue(n302));
			subscribersummary.setAddressline1(subsAddr.toString());
		}

		SegmentBean n4Bean = loopLevelRequiredInfo.getN4Bean();
		FieldWithValueBean n401 = n4Bean
				.getFieldBeanByFieldName(RefDesgEnum.N401.value());
		subscribersummary.setCity(getFieldWithBeanValue(n401));
		FieldWithValueBean n402 = n4Bean
				.getFieldBeanByFieldName(RefDesgEnum.N402.value());
		subscribersummary.setState(getFieldWithBeanValue(n402));
		FieldWithValueBean n403 = n4Bean
				.getFieldBeanByFieldName(RefDesgEnum.N403.value());
		subscribersummary.setZipcode(getFieldWithBeanValue(n403));

		SegmentBean dmgBean = loopLevelRequiredInfo.getDmgBean();
		FieldWithValueBean dmg02 = dmgBean
				.getFieldBeanByFieldName(RefDesgEnum.DMG02.value());
		subscribersummary.setDateofbirth(getFieldWithBeanValue(dmg02));
		FieldWithValueBean dmg03 = dmgBean
				.getFieldBeanByFieldName(RefDesgEnum.DMG03.value());
		subscribersummary.setGender(getFieldWithBeanValue(dmg03));

		SegmentBean insBean = loopLevelRequiredInfo.getIsnBean();
		if (insBean != null) {
			FieldWithValueBean ins02 = insBean
					.getFieldBeanByFieldName(RefDesgEnum.INS02.value());
			subscribersummary
					.setRelationshiptopatient(getFieldWithBeanValue(ins02));
		}

		ArrayList<SegmentBean> dtbBeans = loopLevelRequiredInfo.getDtpBean();
		if (dtbBeans != null && !dtbBeans.isEmpty()) {
			SegmentBean dtpBean = dtbBeans.get(0);
			FieldWithValueBean dtp01 = dtpBean
					.getFieldBeanByFieldName(RefDesgEnum.DTP01.value());
			subscribersummary
					.setSubscriberdatequalifier(getFieldWithBeanValue(dtp01));
			FieldWithValueBean dtp02 = dtpBean
					.getFieldBeanByFieldName(RefDesgEnum.DTP02.value());
			subscribersummary
					.setSubscriberdatetimequalifier(getFieldWithBeanValue(dtp02));
			FieldWithValueBean dtp03 = dtpBean
					.getFieldBeanByFieldName(RefDesgEnum.DTP03.value());
			subscribersummary.setSubscriberdate(getFieldWithBeanValue(dtp03));
		}
		LOG.debug("Exiting from BatchEligibility271Parser :: getSubscriberSumm");
		return subscribersummary;
	}

	private String getFieldWithBeanValue(
			FieldWithValueBean ref01FieldWithValueBean) {
		LOG.debug("Entering in to BatchEligibility271Parser :: getFieldWithBeanValue");
		if (ref01FieldWithValueBean == null
				|| ref01FieldWithValueBean.getFieldValue() == null
				|| ref01FieldWithValueBean.getFieldValue().isEmpty()) {
			return "";
		}
		LOG.debug("Exiting from BatchEligibility271Parser :: getFieldWithBeanValue");
		return ref01FieldWithValueBean.getFieldValue();
	}

	private ArrayList<Benefitsinformation> getBenefitsInfo(
			LoopLevelRequiredInfo loopLevelRequiredInfo) {
		LOG.debug("Entering in to BatchEligibility271Parser :: getBenefitsInfo");
		if (loopLevelRequiredInfo == null) {
			return null;
		}
		ArrayList<EbMSG> ebMSGs = loopLevelRequiredInfo.getEbMSGs();
		if (ebMSGs == null || ebMSGs.isEmpty()) {
			return null;
		}

		ArrayList<Benefitsinformation> benefitsinformations = new ArrayList<Benefitsinformation>();
		for (EbMSG ebMSG : ebMSGs) {
			SegmentBean ebBean = ebMSG.getEb();
			if (ebBean != null) {
				Benefitsinformation benefitsinformation = new Benefitsinformation();

				FieldWithValueBean eb01 = ebBean
						.getFieldBeanByFieldName(RefDesgEnum.EB01.value());
				String eligibilitystatusinfo = getFieldWithBeanValue(eb01);
				if (!eligibilitystatusinfo.trim().isEmpty()) {
					benefitsinformation
							.setEligibilitystatusinfo(eligibilitystatusinfo);
				}

				FieldWithValueBean eb02 = ebBean
						.getFieldBeanByFieldName(RefDesgEnum.EB02.value());
				String coverageCode = getFieldWithBeanValue(eb02);
				if (!coverageCode.trim().isEmpty()) {
					benefitsinformation.setCoveragecode(coverageCode);
				}

				FieldWithValueBean eb03 = ebBean
						.getFieldBeanByFieldName(RefDesgEnum.EB03.value());
				String servicetypecodelist = getFieldWithBeanValue(eb03);
				if (!servicetypecodelist.trim().isEmpty()) {
					benefitsinformation
							.setServicetypecodelist(servicetypecodelist);
				}

				StringBuilder plan = new StringBuilder();
				FieldWithValueBean eb05 = ebBean
						.getFieldBeanByFieldName(RefDesgEnum.EB05.value());
				plan.append(getFieldWithBeanValue(eb05));
				plan.append(" ");
				StringBuilder sbtimeperiodqualifierMonetaryamountPercentageasdecimal = new StringBuilder();
				FieldWithValueBean eb06 = ebBean
						.getFieldBeanByFieldName(RefDesgEnum.EB06.value());
				String eb06Val = getFieldWithBeanValue(eb06);
				sbtimeperiodqualifierMonetaryamountPercentageasdecimal
						.append(eb06Val);
				plan.append(eb06Val);
				if (!plan.toString().trim().isEmpty()) {
					benefitsinformation.setPlan(plan.toString());
				}

				FieldWithValueBean eb07 = ebBean
						.getFieldBeanByFieldName(RefDesgEnum.EB07.value());
				String monetaryamount = getFieldWithBeanValue(eb07);
				if (!monetaryamount.trim().isEmpty()) {
					try {
						BigDecimal monetaryAmt = new BigDecimal(monetaryamount);
						benefitsinformation.setMonetaryamount(monetaryAmt);
						sbtimeperiodqualifierMonetaryamountPercentageasdecimal
								.append(" ".concat(monetaryAmt.toString()));
					} catch (NumberFormatException nf) {
						LOG.error("Exception while casting monetaryamount", nf);
					}
				}

				FieldWithValueBean eb08 = ebBean
						.getFieldBeanByFieldName(RefDesgEnum.EB08.value());
				String percentage = getFieldWithBeanValue(eb08);
				if (!percentage.trim().isEmpty()) {
					try {
						BigDecimal percentageVal = new BigDecimal(percentage);
						benefitsinformation.setPercentage(percentageVal);
						sbtimeperiodqualifierMonetaryamountPercentageasdecimal
								.append(" ".concat(percentageVal.toString()));
					} catch (NumberFormatException nf) {
						LOG.error("Exception while casting percentageVal", nf);
					}
				}
				if (!sbtimeperiodqualifierMonetaryamountPercentageasdecimal
						.toString().trim().isEmpty()) {
					benefitsinformation
							.setTimeperiodqualifiermonetaryamountpercentageasdecimal(sbtimeperiodqualifierMonetaryamountPercentageasdecimal
									.toString());
				}

				StringBuilder quantityAndQualifier = new StringBuilder();
				FieldWithValueBean eb09 = ebBean
						.getFieldBeanByFieldName(RefDesgEnum.EB09.value());
				quantityAndQualifier.append(getFieldWithBeanValue(eb09));
				quantityAndQualifier.append(" ");
				FieldWithValueBean eb10 = ebBean
						.getFieldBeanByFieldName(RefDesgEnum.EB10.value());
				quantityAndQualifier.append(getFieldWithBeanValue(eb10));
				if (!quantityAndQualifier.toString().trim().isEmpty()) {
					benefitsinformation
							.setQuantityandqualifier(quantityAndQualifier
									.toString());
				}

				FieldWithValueBean eb11 = ebBean
						.getFieldBeanByFieldName(RefDesgEnum.EB11.value());
				String authorizationIndicator = getFieldWithBeanValue(eb11);
				if (!authorizationIndicator.trim().isEmpty()) {
					benefitsinformation
							.setAuthorizationindicator(authorizationIndicator);
				}

				FieldWithValueBean eb12 = ebBean
						.getFieldBeanByFieldName(RefDesgEnum.EB12.value());
				String networkIndicator = getFieldWithBeanValue(eb12);
				if (!networkIndicator.trim().isEmpty()) {
					benefitsinformation.setNetworkindicator(networkIndicator);
				}

				FieldWithValueBean eb13 = ebBean
						.getFieldBeanByFieldName(RefDesgEnum.EB13.value());
				String eb13Val = getFieldWithBeanValue(eb13);

				String industrycode = "";
				String procedurecode = "";
				String modifier1 = "";
				String modifier2 = "";
				String modifier3 = "";
				String modifier4 = "";
				String subEb13Vals[] = eb13Val.trim().split(
						IEligibility271Constants.CARET);
				if (subEb13Vals != null && subEb13Vals.length > 0) {
					for (int i = 0; i < subEb13Vals.length; i++) {
						if (i == 0) {
							industrycode = subEb13Vals[i];
						} else if (i == 1) {
							procedurecode = subEb13Vals[i];
						} else if (i == 2) {
							modifier1 = subEb13Vals[i];
						} else if (i == 3) {
							modifier2 = subEb13Vals[i];
						} else if (i == 4) {
							modifier3 = subEb13Vals[i];
						} else if (i == 5) {
							modifier4 = subEb13Vals[i];
						}
					}
				}// end if
				if (!modifier1.trim().isEmpty()) {
					benefitsinformation.setModifier1(modifier1);
				}
				if (!modifier2.trim().isEmpty()) {
					benefitsinformation.setModifier1(modifier2);
				}
				if (!modifier3.trim().isEmpty()) {
					benefitsinformation.setModifier1(modifier3);
				}
				if (!modifier4.trim().isEmpty()) {
					benefitsinformation.setModifier1(modifier4);
				}
				if (!procedurecode.trim().isEmpty()) {
					benefitsinformation.setProcedurecode(procedurecode);
				}
				if (!industrycode.trim().isEmpty()) {
					benefitsinformation.setProcedurecode(procedurecode);
				}
				benefitsinformations.add(benefitsinformation);
			}

		}
		LOG.debug("Exiting from BatchEligibility271Parser :: getBenefitsInfo");
		return benefitsinformations;
	}

	private FullDetailResponse getFullresponse(Edi271longdesc longDesc,
			String traceNumber) {
		LOG.debug("Entering in to BatchEligibility271Parser :: getFullresponse");
		if (longDesc == null) {
			return null;
		}

		Eligibilitysummary eligibilitysummary = longDesc
				.getEligibilitysummary();
		Insurancesummary insSumm = longDesc.getInsurancesummary();
		Providersummary provSumm = longDesc.getProvidersummary();
		Subscribersummary subsSumm = longDesc.getSubscribersummary();
		List<Benefitsinformation> benefitsinformations = longDesc
				.getBenefitsinformations();

		EligibilitySummary jsonliEligibilitySummary = new EligibilitySummary();
		jsonliEligibilitySummary
				.setEligibility_begin_date(eligibilitysummary == null ? ""
						: StringUtil.removeSpace(eligibilitysummary
								.getEligibilitybegindate()));
		jsonliEligibilitySummary.setEligibility_request_date("");
		jsonliEligibilitySummary.setEligibility_request_date_of_service("");
		jsonliEligibilitySummary.setEligibility_status(StringUtil
				.removeSpace(eligibilitysummary == null ? ""
						: eligibilitysummary.getEligibilitystatus()));
		jsonliEligibilitySummary
				.setPolicy_description(eligibilitysummary == null ? ""
						: StringUtil.removeSpace(eligibilitysummary
								.getPolicydescription()));
		jsonliEligibilitySummary.setPolicy_type(eligibilitysummary == null ? ""
				: StringUtil.removeSpace(eligibilitysummary.getPolicytype()));

		InsuranceSummary jsonInsuranceSummary = new InsuranceSummary();
		jsonInsuranceSummary.setPayer_address("");
		jsonInsuranceSummary.setPayer_identification_code(insSumm == null ? ""
				: StringUtil.removeSpace(insSumm.getPayeridentificationcode()));
		jsonInsuranceSummary
				.setPayer_identification_qualifier(insSumm == null ? ""
						: StringUtil.removeSpace(insSumm
								.getPayeridentificationqualifier()));
		jsonInsuranceSummary.setPayer_name(insSumm == null ? "" : StringUtil
				.removeSpace(insSumm.getPayername()));
		jsonInsuranceSummary.setTelephone(insSumm == null ? "" : StringUtil
				.removeSpace(insSumm.getTelephone()));
		jsonInsuranceSummary.setUrl(insSumm == null ? "" : StringUtil
				.removeSpace(insSumm.getUrl()));

		ProviderSummary jsonProviderSummary = new ProviderSummary();
		if (provSumm != null) {
			jsonProviderSummary.setProvider_address(provSumm == null ? ""
					: StringUtil.removeSpace(provSumm.getAddressline1()));
			jsonProviderSummary
					.setProvider_identification_code(provSumm == null ? ""
							: StringUtil.removeSpace(provSumm
									.getProvideridentificationcode()));
			jsonProviderSummary
					.setProvider_identification_qualifier(provSumm == null ? ""
							: StringUtil.removeSpace(provSumm
									.getProvideridentificationqualifier()));
			jsonProviderSummary.setProvider_name(provSumm == null ? ""
					: StringUtil.removeSpace(provSumm.getProvidername()));
		}

		SubscriberSummary jsonSubscriberSummary = new SubscriberSummary();
		jsonSubscriberSummary.setDate_of_birth(subsSumm == null ? ""
				: StringUtil.removeSpace(subsSumm.getDateofbirth()));
		jsonSubscriberSummary.setGender(subsSumm == null ? "" : StringUtil
				.removeSpace(subsSumm.getGender()));
		jsonSubscriberSummary.setGroup_name(subsSumm == null ? "" : StringUtil
				.removeSpace(subsSumm.getGroupname()));
		jsonSubscriberSummary.setGroup_number(subsSumm == null ? ""
				: StringUtil.removeSpace(subsSumm.getGroupnumber()));
		jsonSubscriberSummary.setMember_id(subsSumm == null ? "" : StringUtil
				.removeSpace(subsSumm.getMemberid()));
		jsonSubscriberSummary.setNew_member_id(subsSumm == null ? ""
				: StringUtil.removeSpace(subsSumm.getNewmemberid()));
		jsonSubscriberSummary.setPolicy_number(subsSumm == null ? ""
				: StringUtil.removeSpace(subsSumm.getPolicynumber()));
		jsonSubscriberSummary.setRelationship_to_patient(subsSumm == null ? ""
				: StringUtil.removeSpace(subsSumm.getRelationshiptopatient()));
		jsonSubscriberSummary.setSsn(subsSumm == null ? "" : StringUtil
				.removeSpace(subsSumm.getSsn()));
		jsonSubscriberSummary.setSubscriber_address(subsSumm == null ? ""
				: StringUtil.removeSpace(subsSumm.getAddressline1()));
		jsonSubscriberSummary.setSubscriber_date(subsSumm == null ? ""
				: StringUtil.removeSpace(subsSumm.getSubscriberdate()));
		jsonSubscriberSummary
				.setSubscriber_date_qualifier(subsSumm == null ? ""
						: StringUtil.removeSpace(subsSumm
								.getSubscriberdatequalifier()));
		jsonSubscriberSummary
				.setSubscriber_datetime_qualifier(subsSumm == null ? ""
						: StringUtil.removeSpace(subsSumm
								.getSubscriberdatetimequalifier()));
		jsonSubscriberSummary.setSubscriber_name(subsSumm == null ? ""
				: StringUtil.removeSpace(subsSumm.getSubscribername()));
		jsonSubscriberSummary.setSubscriber_postal_code(subsSumm == null ? ""
				: StringUtil.removeSpace(subsSumm.getZipcode()));
		jsonSubscriberSummary.setSubscriber_state_code(subsSumm == null ? ""
				: StringUtil.removeSpace(subsSumm.getState()));
		jsonSubscriberSummary.setSusbcriber_city(subsSumm == null ? ""
				: StringUtil.removeSpace(subsSumm.getCity()));

		BenifitsInformation jsonBenInfo = new BenifitsInformation();
		if (benefitsinformations != null && !benefitsinformations.isEmpty()) {
			ArrayList<RowItem> rowItems = new ArrayList<RowItem>();
			for (Benefitsinformation beneInfo : benefitsinformations) {
				RowItem ri = new RowItem();
				ri.setAuthorization_indicator(StringUtil.removeSpace(beneInfo
						.getAuthorizationindicator()));
				ri.setCoverage_code(StringUtil.removeSpace(beneInfo
						.getCoveragecode()));
				ri.setEligibility_status_info(StringUtil.removeSpace(beneInfo
						.getEligibilitystatusinfo()));
				ri.setIndustry_code(StringUtil.removeSpace(beneInfo
						.getIndustryCode()));
				ri.setModifier1(StringUtil.removeSpace(beneInfo.getModifier1()));
				ri.setModifier2(StringUtil.removeSpace(beneInfo.getModifier2()));
				ri.setModifier3(StringUtil.removeSpace(beneInfo.getModifier3()));
				ri.setModifier4(StringUtil.removeSpace(beneInfo.getModifier4()));
				if (beneInfo.getMonetaryamount() != null) {
					ri.setMonetary_amount(beneInfo.getMonetaryamount()
							.toString());
				} else {
					ri.setMonetary_amount("");
				}
				ri.setNetwork_indicator(StringUtil.removeSpace(beneInfo
						.getNetworkindicator()));
				if (beneInfo.getPercentage() != null) {
					ri.setPercentage(beneInfo.getPercentage().toString());
				} else {
					ri.setPercentage("");
				}
				ri.setPlan(StringUtil.removeSpace(beneInfo.getPlan()));
				ri.setProcedure_code(StringUtil.removeSpace(beneInfo
						.getProcedurecode()));
				ri.setQuantity_and_qualifier(StringUtil.removeSpace(beneInfo
						.getQuantityandqualifier()));
				ri.setService_type_code_list(StringUtil.removeSpace(beneInfo
						.getServicetypecodelist()));

				ri.setTimeperiodqualifier_monetaryamount_percentageasdecimal(StringUtil.removeSpace(beneInfo
						.getTimeperiodqualifiermonetaryamountpercentageasdecimal()));

				rowItems.add(ri);
			}
			jsonBenInfo.setRow_items(rowItems);
			jsonBenInfo.setRow_item_Count(rowItems.size());
		}

		List<Requestvalidation> requestvalidations = longDesc
				.getRequestvalidations();
		ArrayList<RequestValidation> jsonRequestValidations = new ArrayList<RequestValidation>();
		if (requestvalidations != null && !requestvalidations.isEmpty()) {
			for (Requestvalidation reqVal : requestvalidations) {
				RequestValidation jsonreqVal = new RequestValidation();
				jsonreqVal.setFollow_up_code(StringUtil.removeSpace(reqVal
						.getFollowupcode()));
				jsonreqVal.setReject_reason_code(StringUtil.removeSpace(reqVal
						.getRejectreasoncode()));
				jsonreqVal.setResponse_code(StringUtil.removeSpace(reqVal
						.getResponsecode()));
				jsonreqVal.setValidation_level(StringUtil.removeSpace(reqVal
						.getValidationlevel()));
				jsonRequestValidations.add(jsonreqVal);
			}
		}

		FullDetailResponse fullDetailResponse = new FullDetailResponse();
		jsonBenInfo.setRequest_validations(jsonRequestValidations);
		jsonBenInfo.setRequest_validations_count(jsonRequestValidations.size());
		fullDetailResponse.setBenefits_information(jsonBenInfo);
		fullDetailResponse.setLongDescrId(longDescId);

		GeneralEligibilityInformation generalEligibilityInformation = new GeneralEligibilityInformation();
		generalEligibilityInformation
				.setEligibility_summary(jsonliEligibilitySummary);
		generalEligibilityInformation
				.setInsurance_summary(jsonInsuranceSummary);
		generalEligibilityInformation.setProvider_summary(jsonProviderSummary);
		generalEligibilityInformation
				.setSubscriber_summary(jsonSubscriberSummary);
		fullDetailResponse
				.setGeneral_eligibility_information(generalEligibilityInformation);

		fullDetailResponse.setEligibility_tracer_number(StringUtil
				.removeSpace(longDesc.getEligibilitytracernumber()));

		LOG.debug("Exiting from BatchEligibility271Parser :: getFullresponse");
		return fullDetailResponse;
	}

	private Map<String, ArrayList<SegmentBean>> getAAAMap(int startindex,
			ArrayList<SegmentBean> segmentBeans, EligibilityLoopEnum loopid) {
		LOG.debug("Entering in to BatchEligibility271Parser :: getAAAMap");
		boolean isNm = false;

		Map<String, ArrayList<SegmentBean>> aaaMap = new HashMap<String, ArrayList<SegmentBean>>();
		ArrayList<SegmentBean> aaaF = new ArrayList<SegmentBean>();
		ArrayList<SegmentBean> aaaS = new ArrayList<SegmentBean>();

		for (int i = startindex + 1; i < segmentBeans.size(); i++) {
			SegmentBean segmentBean = segmentBeans.get(i);
			if (segmentBean.getSegmentName().equals(EligibilityTagEnum.AAA)) {
				if (isNm) {
					aaaS.add(segmentBean);
				} else
					aaaF.add(segmentBean);
			} else if (segmentBean.getSegmentName().equals(
					EligibilityTagEnum.NM1)) {
				isNm = true;
			} else if (segmentBean.getSegmentName().equals(
					EligibilityTagEnum.HL)
					|| segmentBean.getSegmentName().equals(
							EligibilityTagEnum.SE)) {
				break;
			}
		}

		if (loopid.equals(EligibilityLoopEnum.LOOP2000A)) {
			if (!aaaF.isEmpty())
				aaaMap.put(EligibilityLoopEnum.LOOP2000A.value(), aaaF);
			else if (!aaaS.isEmpty())
				aaaMap.put(EligibilityLoopEnum.LOOP2100A.value(), aaaS);
		} else if (loopid.equals(EligibilityLoopEnum.LOOP2000B)) {
			if (!aaaF.isEmpty())
				aaaMap.put(EligibilityLoopEnum.LOOP2000B.value(), aaaF);
			else if (!aaaS.isEmpty())
				aaaMap.put(EligibilityLoopEnum.LOOP2100B.value(), aaaS);
		}
		LOG.debug("Exiting from BatchEligibility271Parser :: getAAAMap");
		return aaaMap;
	}

	private ArrayList<Requestvalidation> getRequestValidations(
			LoopLevelRequiredInfo loopLevelRequiredInfo,
			Map<String, ArrayList<SegmentBean>> aaaMap2000A,
			Map<String, ArrayList<SegmentBean>> aaaMap2000B) {
		LOG.debug("Entering in to BatchEligibility271Parser :: getRequestValidations");
		ArrayList<Requestvalidation> requestvalidations = new ArrayList<Requestvalidation>();
		getReqValidationList(loopLevelRequiredInfo.getAaaSegments(),
				requestvalidations);
		getReqValidationList(aaaMap2000A, requestvalidations);
		getReqValidationList(aaaMap2000B, requestvalidations);
		LOG.debug("Exiting from BatchEligibility271Parser :: getRequestValidations");
		return requestvalidations;
	}

	public void getReqValidationList(
			Map<String, ArrayList<SegmentBean>> aaaSegMap,
			ArrayList<Requestvalidation> requestvalidations) {
		LOG.debug("Entering in to BatchEligibility271Parser :: getReqValidationList");
		if (aaaSegMap != null && !aaaSegMap.isEmpty()) {
			Set<Map.Entry<String, ArrayList<SegmentBean>>> aaaSegSet = aaaSegMap
					.entrySet();
			for (Map.Entry<String, ArrayList<SegmentBean>> aaaSeg : aaaSegSet) {
				String key = aaaSeg.getKey();
				ArrayList<SegmentBean> aaaBean = aaaSeg.getValue();
				for (SegmentBean aaa : aaaBean) {
					Requestvalidation reqvalidation = new Requestvalidation();
					FieldWithValueBean aaa01 = aaa
							.getFieldBeanByFieldName(RefDesgEnum.AAA01.value());
					String aaa01Val = getFieldWithBeanValue(aaa01);
					if (!aaa01Val.isEmpty()) {
						reqvalidation.setResponsecode(aaa01Val);
					}

					FieldWithValueBean aaa03 = aaa
							.getFieldBeanByFieldName(RefDesgEnum.AAA03.value());
					String aaa03Val = getFieldWithBeanValue(aaa03);
					if (!aaa03Val.isEmpty()) {
						reqvalidation.setRejectreasoncode(aaa03Val);
					}

					FieldWithValueBean aaa04 = aaa
							.getFieldBeanByFieldName(RefDesgEnum.AAA04.value());
					String aaa04Val = getFieldWithBeanValue(aaa04);
					if (!aaa04Val.isEmpty()) {
						reqvalidation.setFollowupcode(aaa04Val);
					}
					reqvalidation.setValidationlevel(key);
					requestvalidations.add(reqvalidation);
				}
			}
		}// end if
		LOG.debug("Exiting from BatchEligibility271Parser :: getReqValidationList");
	}

	private Edi271longdesc processLongDesc(SegmentBean nm1BeanInfoReceiver,
			SegmentBean nm1BeanInfoSource, String eligibility271,
			Map<String, ArrayList<SegmentBean>> aaaMap2000A,
			Map<String, ArrayList<SegmentBean>> aaaMap2000B, String traceNum,
			SegmentBean perBeanInfoSource) {
		LOG.debug("Entering in to BatchEligibility271Parser :: processLongDesc");
		Edi271longdesc edi271longdesc = new Edi271longdesc();
		if (traceNum != null && !traceNum.isEmpty()) {
			edi271longdesc.setEligibilitytracernumber(traceNum);
		}

		Insurancesummary insurancesummary = getInsuranceSummDB(
				nm1BeanInfoSource, perBeanInfoSource);
		Providersummary providersummary = getProviderSumm(nm1BeanInfoReceiver);

		ArrayList<Requestvalidation> requestvalidations = new ArrayList<Requestvalidation>();
		getReqValidationList(aaaMap2000A, requestvalidations);
		getReqValidationList(aaaMap2000B, requestvalidations);

		if (insurancesummary == null && providersummary == null
				&& requestvalidations.isEmpty()) {
			return null;
		}

		if (insurancesummary != null) {
			edi271longdesc.setInsurancesummary(insurancesummary);
		}

		if (providersummary != null) {
			edi271longdesc.setProvidersummary(providersummary);
		}

		if (!requestvalidations.isEmpty()) {
			if (!requestvalidations.isEmpty()) {
				for (Requestvalidation reqVal : requestvalidations) {
					edi271longdesc.addRequestvalidation(reqVal);
				}
			}
		}// end if
		longDescId = batchBaseDao.saveLongDecs(edi271longdesc, null,
				insurancesummary, providersummary, null);
		LOG.debug("Exiting from BatchEligibility271Parser :: processLongDesc");
		return edi271longdesc;
	}

	public FullDetailResponse getFullDetailResponseByTraceNum(String traceNum) {
		LOG.debug("Entering in to BatchEligibility271Parser :: getFullDetailResponseByTraceNum");
		if (traceNum == null || traceNum.isEmpty()) {
			return null;
		}
		Edi271longdesc edi271longdesc = batchBaseDao
				.getEdi271longdescByTraceNum(traceNum);
		LOG.debug("Exiting from BatchEligibility271Parser :: getFullDetailResponseByTraceNum");
		return getFullresponse(edi271longdesc, traceNum);
	}

	public Edi271shortdesc getshortDescriptionByTraceNum(String traceNum) {
		LOG.debug("Entering in to BatchEligibility271Parser :: getshortDescriptionByTraceNum");
		if (traceNum == null || traceNum.isEmpty()) {
			return null;
		}
		Edi271shortdesc edi271shortdesc = batchBaseDao
				.getShortDescByTraceNum(traceNum);
		LOG.debug("Exiting from BatchEligibility271Parser :: getshortDescriptionByTraceNum");
		return edi271shortdesc;
	}

	private void setMsgEB(Edi271shortdesc shortdesc, ArrayList<EbMSG> ebMSGs,
			String traceNum) {
		LOG.debug("Entering in to BatchEligibility271Parser :: setMsgEB");
		if (ebMSGs == null || ebMSGs.isEmpty()) {
			return;
		}
		// StringBuilder sbEb = new StringBuilder();
		EbMSG ebMSG = new EbMSG();
		EbMSG firstebMSGwitheb30 = null; // for first eb with eb03=30
		SegmentBean dtpBean = new SegmentBean();
		// StringBuilder sbMsg=new StringBuilder();
		String dtpCode01;
		String dtpCode03;
		String msg = "";
		String eb01 = null;
		int ebCode = 0;
		Boolean found = Boolean.FALSE;

		for (EbMSG eb : ebMSGs) {
			SegmentBean ebBean = eb.getEb();
			if (ebBean != null) {
				if (getFieldByRefDesg(RefDesgEnum.EB03, ebBean).equals(
						IEligibility271Constants.THIRTY)) {
					if (firstebMSGwitheb30 == null) {
						firstebMSGwitheb30 = new EbMSG();
						firstebMSGwitheb30 = eb; // storing the first eb with
													// eb03=30

					}
					eb01 = getFieldByRefDesg(RefDesgEnum.EB01, ebBean);
					try {
						if (eb01 != null) {
							ebCode = Integer.valueOf(eb01); // if eb01 is
															// between 1-8 then
															// select this eb

							if (ebCode >= 1 && ebCode <= 8) {
								ebMSG = eb;
								found = Boolean.TRUE;
								break;
							} else {
								continue;
							}
						}
					} catch (NumberFormatException exp) {
						continue;
					}
				}
			}
		}
		if (!found && firstebMSGwitheb30 != null) { // if eb01 is not between
													// 1-8 then first eb03=30
			ebMSG = firstebMSGwitheb30;
			found = Boolean.TRUE;
		}
		if (!found) { // if eb03=30 not found than first eb
			for (EbMSG eb : ebMSGs) {
				SegmentBean ebBean = eb.getEb();
				if (ebBean != null) {
					ebMSG = eb;
					break;
				}
			}
		}
		dtpBean = getDTPBean(ebMSG);

		if (dtpBean != null) {
			// dtp01 as on dtp03
			dtpCode01 = getFieldByRefDesg(RefDesgEnum.DTP01, dtpBean);
			dtpCode03 = getFieldByRefDesg(RefDesgEnum.DTP03, dtpBean);
			LOG.debug("dtpCode01:" + dtpCode01);
			LOG.debug("dtpCode03:" + dtpCode03);
			String defination = getDefination(dtpCode01);
			msg = defination + IEligibility271Constants.ASON + dtpCode03;
			shortdesc.setEligibilityoutcomecode(dtpCode01);
			shortdesc.setEligibilityoutcomemessage(msg);
		} else {
			// eb01 as on request date
			if (eb01 == null) {
				eb01 = getFieldByRefDesg(RefDesgEnum.EB01, ebMSG.getEb());
			}
			String status = batchBaseDao.getEbLookUp(eb01).getDefination();
			msg = status;
			if (ebCode >= 1 && ebCode <= 8) {
				Eligibility270withack eligibility270withack = batchBaseDao
						.getEligibility270withackByTraceNum(traceNum);
				String reqDate = "";
				if (eligibility270withack != null) {
					reqDate = new SimpleDateFormat("yyyyMMdd")
							.format(eligibility270withack.getRequestdate());
				} else {
					reqDate = new SimpleDateFormat("yyyyMMdd")
							.format(new Date());
				}
				msg = status + IEligibility271Constants.ASON + reqDate;
			}

			shortdesc.setEligibilityoutcomecode(eb01);
			shortdesc.setEligibilityoutcomemessage(msg);
		}
		LOG.debug("Exiting from BatchEligibility271Parser :: setMsgEB");
	}

	//
	private SegmentBean getDTPBean(EbMSG ebMSG) {
		LOG.debug("Entering in to BatchEligibility271Parser :: getDTPBean");
		if (ebMSG == null || ebMSG.getSegmentBeansDTPList().isEmpty()) {
			return null;
		}

		for (SegmentBean dtpBean : ebMSG.getSegmentBeansDTPList()) {
			if (dtpBean != null)
				return dtpBean;
		}
		LOG.debug("Exiting from BatchEligibility271Parser :: getDTPBean");
		return null;

	}

	@SuppressWarnings("unchecked")
	public void setDtpDef() {
		batchDtpLookUp.setDtpList(batchBaseDao.getDtpCodeList());
	}

	private String getDefination(String dtpCode) {
		LOG.debug("Entering in to BatchEligibility271Parser :: getDefination");
		String defination = "";
		List<DtpDefEntity> dtps = batchDtpLookUp.getDtpList();
		for (DtpDefEntity dtpDef : dtps) {
			if (dtpDef.getDtpcode().equals(dtpCode)) {
				defination = dtpDef.getDefination();
				break;
			}
		}
		LOG.debug("Exiting from BatchEligibility271Parser :: getDefination");
		return defination;
	}

	@SuppressWarnings("unchecked")
	private void processShortDesc(String traceNumber, String st02,
			String eligibility271, SegmentBean aaa) {
		LOG.debug("Entering in to BatchEligibility271Parser :: processShortDesc");
		Edi271shortdesc shortdesc = new Edi271shortdesc();
		shortdesc.setEligibilitytracernumber(traceNumber);
		try {
			shortdesc.setTransactionsetcontrolnumber(Integer.valueOf(st02));
		} catch (NumberFormatException ne) {
			LOG.error("Exception while casting String to int", ne);
		}
		// setMsgEB(shortdesc,dataBeanInfo.getEbMSGs(),traceNumber);
		shortdesc.setEdimessage(eligibility271);
		if (shortdesc.getEligibilityoutcomemessage() == null
				|| shortdesc.getEligibilityoutcomemessage().isEmpty()) {
			processAAA(shortdesc, aaa);
		}
		try {
			batchBaseDao.save(shortdesc);
		} catch (HibernateException he) {
			LOG.error("Exception while saving short description", he);
		}

		EligibilityBatchOutput output = new EligibilityBatchOutput();
		output.setEdimessage(eligibility271);
		output.setEligibilityoutcomecode(shortdesc.getEligibilityoutcomecode());
		output.setEligibilityoutcomemessage(shortdesc
				.getEligibilityoutcomemessage());
		output.setEligibilitytracenumber(traceNumber);
		output.setTransactionsetcontrolnumber(shortdesc
				.getTransactionsetcontrolnumber());

		processShortDescBatch(output);

		LOG.debug("Exiting from BatchEligibility271Parser :: processShortDesc");
	}

	private void processAAA(Edi271shortdesc shortdesc, SegmentBean aaa) {
		String aaa03 = getFieldByRefDesg(RefDesgEnum.AAA03, aaa);
		String aaa04 = getFieldByRefDesg(RefDesgEnum.AAA04, aaa);
		shortdesc.setEligibilityoutcomecode(Ack999Constants.ERROR);
		String msg = batchBaseDao.getAaaRejectReason(aaa03).getDefination();
		msg = msg + Ack999Constants.SEMICOLON_SEPRATOR
				+ batchBaseDao.getAaaFollowUpLookUp(aaa04).getDefination();
		shortdesc.setEligibilityoutcomemessage(msg);

	}

	public SegmentBean getPerBeanByLoopId(int startIndex,
			ArrayList<SegmentBean> segmentBeans) {
		LOG.debug("Eligibility271Parser", "getPerBeanByLoopId");
		if (segmentBeans == null || segmentBeans.isEmpty()) {
			return null;
		}

		for (int i = startIndex + 1; i < segmentBeans.size(); i++) {
			SegmentBean segmentBean = segmentBeans.get(i);
			if (segmentBean.getSegmentName().equals(EligibilityTagEnum.PER)) {
				return segmentBean;
			} else if (segmentBean.getSegmentName().equals(
					EligibilityTagEnum.HL)
					|| segmentBean.getSegmentName().equals(
							EligibilityTagEnum.SE)) {
				break;
			}

		}
		LOG.debug("Eligibility271Parser", "getPerBeanByLoopId");
		return null;

	}

	private void processShortDescBatch(EligibilityBatchOutput output) {
		output.setTransactionid(eligibility270Writer.getInput()
				.getTransactionid());
		output.setId(eligibility270Writer.getInput().getId());
		eligibility270Writer.getInput().setStatus(IConstants.IN_PROGRESS);
		try {
			batchBaseDao.save(output);
			batchBaseDao.update(eligibility270Writer.getInput());
		} catch (HibernateException e) {
			e.printStackTrace();
		}

	}

}
