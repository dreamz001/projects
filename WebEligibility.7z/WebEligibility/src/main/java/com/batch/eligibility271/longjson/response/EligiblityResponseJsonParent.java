package com.batch.eligibility271.longjson.response;

/**
 * @author Manish
 * @date MAR 20,2015
 */
public class EligiblityResponseJsonParent {
	private FullDetailResponse full_detail_response;

	public FullDetailResponse getFull_detail_response() {
		return full_detail_response;
	}

	public void setFull_detail_response(FullDetailResponse full_detail_response) {
		this.full_detail_response = full_detail_response;
	}

}
