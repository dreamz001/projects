package com.batch.eligibility271.beans;

/**
 * @author Manish
 * @date MAR 20,2015
 */
public class DataBeanLongDesc {

	private String traceNumber;
	private SegmentBean nm1Bean2100A;
	private SegmentBean nm1Bean2100B;
	private SegmentBean perBean2100A;
	private LoopLevelRequiredInfo loopLevelRequiredInfo;

	public String getTraceNumber() {
		return traceNumber;
	}

	public void setTraceNumber(String traceNumber) {
		this.traceNumber = traceNumber;
	}

	public SegmentBean getNm1Bean2100A() {
		return nm1Bean2100A;
	}

	public void setNm1Bean2100A(SegmentBean nm1Bean2100B) {
		this.nm1Bean2100A = nm1Bean2100B;
	}

	public SegmentBean getNm1Bean2100B() {
		return nm1Bean2100B;
	}

	public void setNm1Bean2100B(SegmentBean nm1Bean2200B) {
		this.nm1Bean2100B = nm1Bean2200B;
	}

	public LoopLevelRequiredInfo getLoopLevelRequiredInfo() {
		return loopLevelRequiredInfo;
	}

	public void setLoopLevelRequiredInfo(
			LoopLevelRequiredInfo loopLevelRequiredInfo) {
		this.loopLevelRequiredInfo = loopLevelRequiredInfo;
	}

	public SegmentBean getPerBean2100A() {
		return perBean2100A;
	}

	public void setPerBean2100A(SegmentBean perBean2100A) {
		this.perBean2100A = perBean2100A;
	}

}
