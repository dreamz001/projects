package com.batch.eligibility271.longjson.response;

/**
 * @author Manish
 * @date MAR 20,2015
 */
public class FullDetailResponse {
	private String eligibility_tracer_number;
	private GeneralEligibilityInformation general_eligibility_information;
	private BenifitsInformation benefits_information;

	public String getEligibility_tracer_number() {
		return eligibility_tracer_number;
	}

	public void setEligibility_tracer_number(String eligibility_tracer_number) {
		this.eligibility_tracer_number = eligibility_tracer_number;
	}

	public GeneralEligibilityInformation getGeneral_eligibility_information() {
		return general_eligibility_information;
	}

	public void setGeneral_eligibility_information(
			GeneralEligibilityInformation general_eligibility_information) {
		this.general_eligibility_information = general_eligibility_information;
	}

	public BenifitsInformation getBenefits_information() {
		return benefits_information;
	}

	public void setBenefits_information(BenifitsInformation benefits_information) {
		this.benefits_information = benefits_information;
	}

}
