package com.batch.eligibility.readwrite;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.Date;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.batch.eligibility.base.dao.BatchIBaseDao;
import com.batch.eligibility270.writer.DBSequenceType;
import com.batch.eligibility270.writer.IConstants;
import com.eligibility270.dbentities.EligibilityBatchFile;
import com.eligibility270.dbentities.EligibilityBatchInput;

public class ReadInput {
    
    private static final Logger LOG = LoggerFactory.getLogger(WriteOutputInFile.class);
    
    /*
     * this method is used to read the csv data from the file
     * and stores it to database input table.
     * */
    public void readFromFile(BatchIBaseDao baseDao, File inpuFile) throws Exception {
        LOG.debug("Entering in to  ReadInput :: readFromFile");
        String requestString = "";
        String fileName;
        EligibilityBatchFile batchfile = null;
        fileName = inpuFile.getName();
        BufferedReader br=null;
        Session session=null;

        try {
            br = new BufferedReader(new FileReader(inpuFile));
            String read;
            batchfile = new EligibilityBatchFile();
            while ((read = br.readLine()) != null) {
                System.out.println(read);
                requestString = requestString + read;
            }
        } catch (IOException e) {
            LOG.error("IOException while reading the csv data from input file", e);
        }
        if (batchfile != null && requestString.trim().length() > 0 && requestString.contains("~")) {
            Transaction tx = null;
            baseDao.openManualSession();
            session=baseDao.getCurrentSession();
            try {
                tx = baseDao.initializeTransaction();
                String reqStringList[] = requestString.split("~");
                BigInteger transactionId = baseDao.nextVal(DBSequenceType.ELIGIBILITY_BATCH_INPUT_TRANSACTION_ID);
                batchfile.setId(transactionId.intValue());
                batchfile.setInputfilename(fileName);
                batchfile.setCreatedon(new Timestamp(new Date().getTime()));
                baseDao.save(batchfile);
                for (String jsonString : reqStringList) {
                    // processEligibility(jsonString);
                    BigInteger id = baseDao.nextVal(DBSequenceType.ELIGIBILITY_BATCH_INPUT);
                    EligibilityBatchInput input = new EligibilityBatchInput();
                    input.setId(id.intValue());
                    input.setTransactionid(batchfile);
                    input.setStatus(IConstants.NEW);
                    input.setInputcsv(jsonString);
                    baseDao.save(input);
                }
                session.flush();
                baseDao.commitTransaction(tx);
                session.close();

            } catch (HibernateException e) {
                if (tx != null) {
                    baseDao.rollBackTransaction(tx);
                }
                LOG.error("HibernateException while saving the csv data to eligibility_batch_input table in database", e);
            }finally{
                br.close();
                if(session!=null && session.isOpen()){
                	session.close();
                }            
            }
            LOG.debug("Exiting from ReadInput :: readFromFile");
        }
    }
}
