package com.batch.eligibility.readwrite;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.batch.eligibility270.writer.BatchEligibility270Writer;
import com.batch.eligibility270.writer.DBSequenceType;
import com.batch.eligibility270.writer.IConstants;
import com.eligibility270.dbentities.EligibilityBatchFile;
import com.eligibility271.dbentities.EligibilityBatchOutput;
import com.webeligibility.actions.BatchProcessAction;

public class WriteOutputInFile {

    private static final Logger LOG = LoggerFactory.getLogger(WriteOutputInFile.class);

    private String renameOutputFile(StringBuilder inputFileName) {
        int ext = inputFileName.lastIndexOf(".");
        if (ext > 0) {
            return inputFileName.insert(ext, IConstants.OUTPUT_FILE).toString();
        } else {
            return inputFileName.toString() + IConstants.OUTPUT_FILE;
        }

    }

    /*
     * this method is used to write the short description in text file
     */
    public void writeInFile(BatchEligibility270Writer eligibility270Writer) {
        LOG.debug("Entering in to  WriteOutputInFile  ::  writeInFile");  
      String outboxPath=BatchProcessAction.getOutboxPath();
      
      eligibility270Writer.getBaseDao().openManualSession();
        Transaction tx = null;
        Session session=eligibility270Writer.getBaseDao().getCurrentSession();
        List<EligibilityBatchFile> processedFileList=null;
        try {
        	File file271=new File(outboxPath);
            tx = eligibility270Writer.getBaseDao().initializeTransaction();
            List<EligibilityBatchFile> fileIdList = eligibility270Writer.getBaseDao().getBatchFileList();
           
            if (fileIdList != null) {
            	 processedFileList = new ArrayList<EligibilityBatchFile>();
                for (EligibilityBatchFile fileid : fileIdList) {
                    if (fileid != null) {
                    	
                        try {
                        	
                        	
                        	if(session==null || !session.isOpen()){
                        		eligibility270Writer.getBaseDao().openManualSession();
                        		session=eligibility270Writer.getBaseDao().getCurrentSession();
                            	tx=eligibility270Writer.getBaseDao().initializeTransaction();
                        	}
                            if (!file271.exists()) {
                                if (file271.mkdir()) {
                                    LOG.info("RESPONSE 271 SHORT DESC DIRECTORY CREATED WITH AT : \'" + file271.getPath() + "\'");
                                } else {
                                    throw new FileNotFoundException("DIRECTORY PATH FOR OUTPUT 271 SHORT DESC N/A");
                                }
                            }
                            String fileOutputName=renameOutputFile(new StringBuilder(fileid.getInputfilename()));
                            File file = new File(file271.getPath() + File.separator + fileOutputName);

                            if (!file.exists()) {
                                file.createNewFile();
                            }
                            FileWriter fw = new FileWriter(file, true);
                            BufferedWriter bw = new BufferedWriter(fw);
                            List<EligibilityBatchOutput> outputList = eligibility270Writer.getBaseDao().getBatchOutputList(fileid);
                            
                            if (outputList.size() > 0) {
                                StringBuilder data = new StringBuilder(IConstants.TRACE_NUMBER + IConstants.PIPE_SEPARATOR);
                                data.append(IConstants.TRANSACTION_SET_CONTROL_NUMBER + IConstants.PIPE_SEPARATOR);
                                data.append(IConstants.OUTCOME_CODE + IConstants.PIPE_SEPARATOR);
                                data.append(IConstants.OUTCOME_MESSAGE + IConstants.PIPE_SEPARATOR);
                                data.append(IConstants.LAST_NAME + IConstants.PIPE_SEPARATOR);
                                data.append(IConstants.FIRST_NAME + IConstants.PIPE_SEPARATOR);
                                data.append(IConstants.MIDDLE_INITIAL + IConstants.PIPE_SEPARATOR);
                                data.append(IConstants.SSN + IConstants.PIPE_SEPARATOR);
                                data.append(IConstants.MEMBER_NUMBER + IConstants.PIPE_SEPARATOR);
                                data.append(IConstants.DATE_OF_BIRTH + IConstants.PIPE_SEPARATOR);
                                data.append(IConstants.GENDER + IConstants.PIPE_SEPARATOR);
                                data.append(IConstants.EDI_MESSAGE + IConstants.END_OF_LINE);
                                bw.write(data.toString());

                                for (EligibilityBatchOutput output : outputList) {
                                    data = new StringBuilder(output.getEligibilitytracenumber() + IConstants.PIPE_SEPARATOR);
                                    data.append(output.getTransactionsetcontrolnumber() + IConstants.PIPE_SEPARATOR);
                                    data.append(output.getEligibilityoutcomecode() + IConstants.PIPE_SEPARATOR);
                                    data.append(output.getEligibilityoutcomemessage() + IConstants.PIPE_SEPARATOR);
                                    data.append(output.getLastname() + IConstants.PIPE_SEPARATOR);
                                    data.append(output.getFirstname() + IConstants.PIPE_SEPARATOR);
                                    data.append(output.getMiddleinitial() + IConstants.PIPE_SEPARATOR);
                                    data.append(output.getSsn() + IConstants.PIPE_SEPARATOR);
                                    data.append(output.getMembernumber() + IConstants.PIPE_SEPARATOR);
                                    data.append((output.getDateofbirth()==null)?"":output.getDateofbirth() + IConstants.PIPE_SEPARATOR);
                                    data.append((output.getGender()==null)?"":output.getGender() + IConstants.PIPE_SEPARATOR);
                                    data.append(output.getEdimessage() + IConstants.END_OF_LINE);
                                    bw.write(data.toString());
                                }
                                bw.close();
                                fw.close();
                            }
                         // updating status in EligibilityBatchInput table
                            eligibility270Writer.getBaseDao().updateStausInBatchInput(fileid);
                            fileid.setUploadedon(new Timestamp(new Date().getTime()));
                            fileid.setOutputfilename(fileOutputName);
                            eligibility270Writer.getBaseDao().updateBatchFile(fileid);
                            
                           // session.flush();
                            eligibility270Writer.getBaseDao().commitTransaction(tx);
                            session.close();
                            fileid.setOutputfilename(file.getPath());
                            processedFileList.add(fileid);
                        } catch (IOException ioe) {
                            LOG.error("IOException while writing int the Short Description Output File", ioe);
                            if (tx != null) {
                            	eligibility270Writer.getBaseDao().rollBackTransaction(tx);
                            }
                            throw new HibernateException("Since IOException Occurred and all data not processed in file, Thrown HibernateException");
                        }finally{
                        	if(session.isOpen()){
                        		session.close();
                        	}
                        }
                    }
                }
                if(session==null || !session.isOpen()){
            		eligibility270Writer.getBaseDao().openManualSession();
            		session=eligibility270Writer.getBaseDao().getCurrentSession();
                	tx=eligibility270Writer.getBaseDao().initializeTransaction();
            	}
                // deleting the records and resetting sequence
                eligibility270Writer.getBaseDao().deleteBatchOutput();
                eligibility270Writer.getBaseDao().deleteBatchInput();
                // for transactional testing
                /*
                 * if(session.isOpen()) throw new
                 * HibernateException("Testing hibernate rollback");
                 */
                eligibility270Writer.getBaseDao().restartSeq(DBSequenceType.ELIGIBILITY_BATCH_INPUT);
                session.flush();
                eligibility270Writer.getBaseDao().commitTransaction(tx);

            }
        } catch (HibernateException he) {
            if (tx != null) {
                eligibility270Writer.getBaseDao().rollBackTransaction(tx);
            }
            LOG.error("Error while writing in the file", he);
        }
        if(processedFileList!=null && processedFileList.size()>0){
        	BatchProcessAction.processFilesInSession(processedFileList);
        }
        LOG.debug("Exiting from WriteOutputInFile :: writeInFile"); 
    }
}
