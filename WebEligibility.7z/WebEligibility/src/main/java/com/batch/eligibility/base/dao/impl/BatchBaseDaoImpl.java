package com.batch.eligibility.base.dao.impl;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.batch.eligibility.base.dao.BatchIBaseDao;
import com.batch.eligibility270.writer.DBSequenceType;
import com.batch.eligibility270.writer.IConstants;
import com.eligibility270.dbentities.Edi271longdesc;
import com.eligibility270.dbentities.Eligibility270withack;
import com.eligibility270.dbentities.EligibilityBatchFile;
import com.eligibility270.dbentities.EligibilityBatchInput;
import com.eligibility270.dbentities.Eligibilitysummary;
import com.eligibility270.dbentities.Insurancesummary;
import com.eligibility270.dbentities.Providersummary;
import com.eligibility270.dbentities.SFTPConfiguration;
import com.eligibility270.dbentities.Subscribersummary;
import com.eligibility270.header.entities.InterchangeControlHeader;
import com.eligibility270.mastertables.entities.Deliverymethod;
import com.eligibility270.mastertables.entities.ISAEntity;
import com.eligibility271.dbentities.AaaFollowUpLookUp;
import com.eligibility271.dbentities.AaaRejectReason;
import com.eligibility271.dbentities.Config;
import com.eligibility271.dbentities.DtpDefEntity;
import com.eligibility271.dbentities.EbLookUp;
import com.eligibility271.dbentities.Edi271shortdesc;
import com.eligibility271.dbentities.EligibilityBatchOutput;
import com.eligibility271.dbentities.Emdeonrequestresponse;
import com.eligibility271.dbentities.Patientsummary;

/**
 * Purpose : base DAO methods implementation for corresponding to 270 & 271
 * eligibility request and response.
 * 
 * @author Manish
 * @date MAR 20,2015
 */

@Component
@Repository("batchBaseDao")
public class BatchBaseDaoImpl<T, PK extends Serializable> implements
		BatchIBaseDao<T, PK> {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(BatchBaseDaoImpl.class);

	@Autowired
	private SessionFactory sessionFactory;

	private Session currentSession;

	/*
	 * @Override public void setCurrentSession(Session currentSession) {
	 * this.currentSession = currentSession; }
	 */
	@Override
	public void openManualSession() {
		this.currentSession = sessionFactory.openSession();
	}

	/**
	 * Save entity object related to edi schema
	 * 
	 * @param T
	 * @throws <code>HibernateException</code>
	 */
	@Override
	public Serializable save(T paramT) throws HibernateException {
		LOGGER.debug("SAVE OPERATION");
		Session currentSession = getCurrentSession();
		Serializable serializable = null;
		currentSession.persist(paramT);
		// currentSession.flush();
		LOGGER.debug("SAVE OPERATION COMPLETE");
		return serializable;

	}

	/**
	 * Execute sql query pass as an argument to database
	 * 
	 * @param sql
	 *            string
	 * @return Resultant <code>Object</code>
	 * @throws <code>Exception</code>
	 */
	public Object executSQL(String sql) throws Exception {
		LOGGER.debug("EXECUTE SQL");
		SQLQuery query = getCurrentSession().createSQLQuery(sql);
		Object result = query.uniqueResult();
		LOGGER.debug("EXECUTE SQL COMPLETE");
		return result;
	}

	/**
	 * It gets ISA entity.
	 * 
	 * @return <code>ISAEntity</code>
	 * @throws <code>HibernateException</code>
	 */
	public ISAEntity getISA() throws HibernateException {
		LOGGER.debug("GET ISA ENTITY TEMPLATE.");
		Criteria criteria = getCurrentSession().createCriteria(ISAEntity.class);
		return (ISAEntity) criteria.uniqueResult();
	}

	/**
	 * It returns delivery method refrence by deliviry method name like -
	 * EMDEON, AVAILITY.
	 * 
	 * @param name
	 * @return <code>Deliverymethod</code> reference
	 */
	@Override
	public Deliverymethod byDeliveryMethodName(String name) {
		LOGGER.debug("Get Delivery Method by delivery method name.");
		Session session = getCurrentSession();
		Criteria cr = session.createCriteria(Deliverymethod.class);
		cr.add(Restrictions.eq("deliverymethod", name));
		cr.add(Restrictions.like("deliverymethod", name.concat("%")));
		return (Deliverymethod) cr.uniqueResult();
	}

	/**
	 * This method return the next value of DB sequence.
	 * 
	 * @param sequenceType
	 * @return DB sequence value as <code>BigInteger</code>
	 * @throws <code>Exception</code>
	 */
	public BigInteger nextVal(DBSequenceType sequenceType) throws Exception {
		LOGGER.debug("HIT DB SEQUENCE " + sequenceType.value());
		String sql = "select nextVal('" + sequenceType.value() + "')";
		return (BigInteger) executSQL(sql);
	}

	/**
	 * It returns the current session.
	 * 
	 * @return hibernate current <code>Session</code>
	 */
	@Override
	public Session getCurrentSession() {
		if (currentSession == null || !currentSession.isOpen()) {
			currentSession = sessionFactory.getCurrentSession();
		}
		return currentSession;
	}

	/**
	 * It saves the <code>Eligibility270withack</code> reference into DB with
	 * ISA entity and all its dependent entity like GS, ST.
	 * 
	 * @param <code>InterchangeControlHeader</code>
	 * @param <code>Eligibility270withack</code>
	 * @throws <code>HibernateException</code>
	 */
	@Override
	public void saveWithAck(InterchangeControlHeader interchangeCOntrolHeader,
			Eligibility270withack eligibility270withack)
			throws HibernateException {
		LOGGER.debug("SAVE OPERATION");
		Session currentSession = getCurrentSession();
		currentSession.persist(interchangeCOntrolHeader);
		currentSession.persist(eligibility270withack);
		// currentSession.flush();
		LOGGER.debug("SAVE OPERATION COMPLETE");
	}

	/**
	 * It saves the short description with patient summary from 271 eligibility
	 * response EDI.
	 * 
	 * @param <code>Patientsummary</code>
	 * @param <code>Edi271shortdesc</code>
	 * @throws <code>HibernateException</code>
	 */
	@Override
	public void saveWithShortDesc(Patientsummary patientsummary,
			Edi271shortdesc shEdi271shortdesc) throws HibernateException {
		LOGGER.debug("SAVE OPERATION");
		Session currentSession = getCurrentSession();
		currentSession.persist(patientsummary);
		currentSession.persist(shEdi271shortdesc);
		// currentSession.flush();
		LOGGER.debug("SAVE OPERATION COMPLETE");
	}

	/**
	 * It returns the short description by trace number.
	 * 
	 * @param trace
	 *            number
	 * @return <code>Edi271shortdesc</code> reference.
	 */
	@Override
	public Edi271shortdesc getShortDescByTraceNum(String traceNum) {
		LOGGER.debug("GET SHORT DESCRIPTION BY TRACE NUMBER");
		Session currentSession = getCurrentSession();
		Criteria criteria = currentSession
				.createCriteria(Edi271shortdesc.class);
		criteria.add(Restrictions.eq("eligibilitytracernumber", traceNum));
		Object record = criteria.uniqueResult();
		if (record != null && record instanceof Edi271shortdesc) {
			LOGGER.debug("GET SHORT DESCRIPTION BY TRACE NUMBER COMPLETE");
			return (Edi271shortdesc) record;
		}
		LOGGER.debug("GET SHORT DESCRIPTION BY TRACE NUMBER COMPLETE");
		return null;
	}

	/**
	 * It updates the database entity.
	 * 
	 * @param T
	 * @throws <code>HibernateException</code>
	 */
	@Override
	public void update(T paramT) throws HibernateException {
		LOGGER.debug("SAVE OR UPDATE OPERATION");
		Session currentSession = getCurrentSession();
		currentSession.update(paramT);
		/* currentSession.flush(); */
		LOGGER.info("SAVE OR UPDATE OPERATION COMPLETE");
	}

	/**
	 * It saves the long description into DB with eligibility and insurance
	 * summary and all its dependent summary.
	 * 
	 * @param Edi271longdesc
	 * @param Eligibilitysummary
	 * @param Insurancesummary
	 * @throws <code>HibernateException</code>
	 */
	@Override
	public int saveLongDecs(Edi271longdesc longDesc,
			Eligibilitysummary eligibilitysummary,
			Insurancesummary insurancesummary, Providersummary providersummary,
			Subscribersummary subscribersummary) throws HibernateException {
		LOGGER.debug("START SAVE LONG DESCRIPTION OPERATION");
		Session currentSession = getCurrentSession();
		if (eligibilitysummary != null) {
			currentSession.persist(eligibilitysummary);
		}
		if (insurancesummary != null) {
			currentSession.persist(insurancesummary);
		}
		if (subscribersummary != null) {
			currentSession.persist(subscribersummary);
		}
		if (providersummary != null) {
			currentSession.persist(providersummary);
		}
		currentSession.persist(longDesc);
		// currentSession.flush();
		LOGGER.debug("SAVE LONG DESCRIPTION OPERATION COMPLETE");
		return longDesc.getId();
	}

	/**
	 * It returns the long description from Db on behalf of tracenumber.
	 * 
	 * @param traceNum
	 * @return <code>Edi271longdesc</code>
	 */
	@Override
	public Edi271longdesc getEdi271longdescByTraceNum(String traceNum) {
		LOGGER.debug("GET LONG DESCRIPTION BY TRACENUMBER");
		Session currentSession = getCurrentSession();
		Criteria criteria = currentSession.createCriteria(Edi271longdesc.class);
		criteria.add(Restrictions.eq("eligibilitytracernumber", traceNum));
		Object result = criteria.uniqueResult();
		if (result instanceof Edi271longdesc) {
			LOGGER.debug("GET LONG DESCRIPTION BY TRACENUMBER COMPLETE");
			return (Edi271longdesc) result;
		}
		LOGGER.debug("GET LONG DESCRIPTION BY TRACENUMBER COMPLETE");
		return null;
	}

	/**
	 * It returns the <code>Eligibility270withack</code> by trace number.
	 * 
	 * @param traceNum
	 * @return <code>Eligibility270withack</code>
	 * @throws <code>HibernateException</code>
	 */
	@Override
	public Eligibility270withack getEligibility270withackByTraceNum(
			String traceNum) throws HibernateException {
		LOGGER.debug("GET ELIGIBILITY ACK BY TRACE NUMBER");
		Session currentSession = getCurrentSession();
		Criteria criteria = currentSession
				.createCriteria(Eligibility270withack.class);
		criteria.add(Restrictions.eq("eligibilitytracenumber", traceNum));
		Object record = criteria.uniqueResult();
		if (record != null && record instanceof Eligibility270withack) {
			LOGGER.debug("GET ELIGIBILITY ACK BY TRACE NUMBER COMPLETE");
			return (Eligibility270withack) record;
		}
		LOGGER.debug("GET ELIGIBILITY ACK BY TRACE NUMBER COMPLETE");
		return null;
	}

	/**
	 * It return list of DTP codes from DB.
	 * 
	 * @return List of <code>List<DtpDefEntity></code>
	 * @throws <code>HibernateException</code>
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<DtpDefEntity> getDtpCodeList() throws HibernateException {
		LOGGER.debug("GET DTP CODE LIST");
		Session currentSession = getCurrentSession();
		Criteria criteria = currentSession.createCriteria(DtpDefEntity.class);
		List<DtpDefEntity> result = criteria.list();
		LOGGER.debug("GET DTP CODE LIST COMPLETE");
		return result;
	}

	@Override
	public void saveEmdeon(Emdeonrequestresponse emdeon)
			throws HibernateException {
		LOGGER.debug("SAVE OPERATION");
		Session currentSession = getCurrentSession();
		currentSession.persist(emdeon);
		// currentSession.flush();
		LOGGER.debug("SAVE OPERATION COMPLETE");
	}

	/**
	 * It return EBcode, defination from DB.
	 * 
	 * @param ebCode
	 * @return EbLookUp
	 * @throws <code>HibernateException</code>
	 */
	@Override
	public EbLookUp getEbLookUp(String ebCode) throws HibernateException {
		LOGGER.debug("GET EB CODE DEFINATION FROM LIST");
		Session currentSession = getCurrentSession();
		Criteria criteria = currentSession.createCriteria(EbLookUp.class);
		criteria.add(Restrictions.eq("ebcode", ebCode));
		Object record = criteria.uniqueResult();
		if (record != null && record instanceof EbLookUp)
			return (EbLookUp) record;
		LOGGER.debug("GET EB CODE DEFINATION FROM LIST COMPLETE");
		return null;
	}

	/**
	 * It return AaaRejectReason from DB.
	 * 
	 * @param aaaCode
	 * @return AaaRejectReason
	 * @throws <code>HibernateException</code>
	 */
	@Override
	public AaaRejectReason getAaaRejectReason(String aaaCode)
			throws HibernateException {
		LOGGER.debug("GET AAA CODE DEFINATION FROM LIST");
		Session currentSession = getCurrentSession();
		Criteria criteria = currentSession
				.createCriteria(AaaRejectReason.class);
		criteria.add(Restrictions.eq("aaacode", aaaCode));
		Object record = criteria.uniqueResult();
		if (record != null && record instanceof AaaRejectReason)
			return (AaaRejectReason) record;
		LOGGER.debug("GET AAA CODE DEFINATION FROM LIST COMPLETE");
		return null;
	}

	/**
	 * It return AaaRejectReason from DB.
	 * 
	 * @param aaaCode
	 * @return AaaRejectReason
	 * @throws <code>HibernateException</code>
	 */
	@Override
	public AaaFollowUpLookUp getAaaFollowUpLookUp(String aaaCode)
			throws HibernateException {
		LOGGER.debug("GET AAA FOLLOW UP CODE DEFINATION FROM LIST");
		Session currentSession = getCurrentSession();
		Criteria criteria = currentSession
				.createCriteria(AaaFollowUpLookUp.class);
		criteria.add(Restrictions.eq("aaacode", aaaCode));
		Object record = criteria.uniqueResult();
		if (record != null && record instanceof AaaFollowUpLookUp)
			return (AaaFollowUpLookUp) record;
		LOGGER.debug("GET AAA FOLLOW UP CODE DEFINATION FROM LIST COMPLETE");
		return null;
	}

	/**
	 * It return list of CONFIG codes from DB.
	 * 
	 * @return List of <code>List<DtpDefEntity></code>
	 * @throws <code>HibernateException</code>
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<Config> getConfigList() throws HibernateException {
		LOGGER.debug("GET CONFIG CODE LIST");
		Session currentSession = getCurrentSession();
		Transaction tx = currentSession.beginTransaction();
		Criteria criteria = currentSession.createCriteria(Config.class);
		List<Config> result = criteria.list();
		tx.commit();
		LOGGER.debug("GET CONFIG CODE LIST COMPLETE");
		return result;
	}

	/**
	 * It saves the EligibilityBatchInput data to DB.
	 * 
	 * @param EligibilityBatchInput
	 * @throws <code>HibernateException</code>
	 */
	@Override
	public void saveBatchInput(EligibilityBatchInput input)
			throws HibernateException {
		LOGGER.debug("SAVE EligibilityBatchInput OPERATION ");
		Session currentSession = getCurrentSession();
		currentSession.persist(input);
		// currentSession.flush();
		LOGGER.debug("SAVE EligibilityBatchInput OPERATION COMPLETE");
	}

	/**
	 * It return list of EligibilityBatchInput data from DB.
	 * 
	 * @return List of <code>List<EligibilityBatchInput></code>
	 * @throws <code>HibernateException</code>
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<EligibilityBatchInput> getBatchInputList()
			throws HibernateException {
		LOGGER.debug("GET EligibilityBatchInput LIST");
		Session currentSession = getCurrentSession();
		Criteria criteria = currentSession
				.createCriteria(EligibilityBatchInput.class);
		criteria.add(Restrictions.eq("status", IConstants.NEW));
		List<EligibilityBatchInput> result = criteria.list();
		LOGGER.debug("GET EligibilityBatchInput LIST COMPLETE");
		return result;
	}

	/**
	 * It return list of EligibilityBatchFile data from DB. distinct values from
	 * EligibilityBatchInput
	 * 
	 * @return List of <code>List<EligibilityBatchFile></code>
	 * @throws <code>HibernateException</code>
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<EligibilityBatchFile> getBatchFileList()
			throws HibernateException {
		LOGGER.debug("GET EligibilityBatchFile LIST");
		Session currentSession = getCurrentSession();
		Criteria criteria = currentSession
				.createCriteria(EligibilityBatchInput.class);
		criteria.add(Restrictions.eq("status", IConstants.IN_PROGRESS));
		criteria.setProjection(Projections.distinct(Projections
				.property("transactionid")));

		List<EligibilityBatchFile> result = criteria.list();
		LOGGER.debug("GET EligibilityBatchFile LIST COMPLETE");
		return result;
	}

	/**
	 * It return list of EligibilityBatchOutput data from DB according to
	 * transectionId.
	 * 
	 * @param transectionId
	 * @return List of <code>List<EligibilityBatchOutput></code>
	 * @throws <code>HibernateException</code>
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<EligibilityBatchOutput> getBatchOutputList(
			EligibilityBatchFile transectionId) throws HibernateException {
		LOGGER.debug("GET EligibilityBatchFile LIST");
		Session currentSession = getCurrentSession();
		Criteria criteria = currentSession
				.createCriteria(EligibilityBatchOutput.class);
		criteria.add(Restrictions.eq("transactionid", transectionId));
		List<EligibilityBatchOutput> result = criteria.list();
		LOGGER.debug("GET EligibilityBatchFile LIST COMPLETE");
		return result;
	}

	/**
	 * this method changes the status from In_Progress to Submitted in
	 * eligibility_batch_input table and return an int value as status for the
	 * command.
	 * 
	 * @param transactionid
	 * @return int
	 * @throws <code>HibernateException</code>
	 */
	@Override
	public int updateStausInBatchInput(EligibilityBatchFile transactionid)
			throws HibernateException {
		LOGGER.debug("Update status in EligibilityBatchInput");
		Session currentSession = getCurrentSession();
		Query query = currentSession
				.createQuery("UPDATE EligibilityBatchInput as i SET i.status=? WHERE i.transactionid=?");
		query.setParameter(0, IConstants.SUBMITTED);
		query.setParameter(1, transactionid);
		System.out.println(query.toString());
		int status = query.executeUpdate();
		LOGGER.debug("Update status in EligibilityBatchInput COMPLETE");
		return status;
	}

	/**
	 * this method delete all the temp data from eligibility_batch_input table
	 * and return an int value as status for the command.
	 * 
	 * @return int
	 * @throws <code>HibernateException</code>
	 */
	@Override
	public int deleteBatchInput() throws HibernateException {
		LOGGER.debug("Delete all records from EligibilityBatchInput");
		Session currentSession = getCurrentSession();
		Query query = currentSession
				.createQuery("DELETE FROM EligibilityBatchInput");
		int status = query.executeUpdate();
		LOGGER.debug("Delete all records from EligibilityBatchInput COMPLETE");
		return status;
	}

	/**
	 * this method delete all the temp data from EligibilityBatchOutput table
	 * and return an int value as status for the command.
	 * 
	 * @return int
	 * @throws <code>HibernateException</code>
	 */
	@Override
	public int deleteBatchOutput() throws HibernateException {
		LOGGER.debug("Delete all records from EligibilityBatchOutput");
		Session currentSession = getCurrentSession();
		Query query = currentSession
				.createQuery("DELETE FROM EligibilityBatchOutput");
		int status = query.executeUpdate();
		LOGGER.debug("Delete all records from EligibilityBatchOutput COMPLETE");
		return status;
	}

	/**
	 * this method reset(restart) the sequence eligibility_batch_input_id_seq
	 * and return an int value as status for the command.
	 * 
	 * @return int
	 * @throws <code>HibernateException</code>
	 */
	@Override
	public int restartSeq(DBSequenceType sequence) throws HibernateException {
		LOGGER.debug("RESTARTING THE SEQUENCE " + sequence.value());
		String sql = "ALTER SEQUENCE " + sequence.value() + " RESTART ";
		SQLQuery query = getCurrentSession().createSQLQuery(sql);
		int status = query.executeUpdate();
		LOGGER.debug("RESTARTING THE SEQUENCE COMPLETE");
		return status;
	}

	/*
	 * this method is used to get list of SFTPConfiguration
	 */
	@Override
	public List<SFTPConfiguration> getSftpConfigurations() {
		LOGGER.info("Get SFTPConfigurations from db");
		Session currentSession = getCurrentSession();
		Criteria criteria = currentSession
				.createCriteria(SFTPConfiguration.class);
		List<SFTPConfiguration> configurations = criteria.list();
		LOGGER.debug("Get SFTPConfigurations from db COMPLETE");
		return configurations;
	}

	@Override
	public Transaction initializeTransaction() {
		LOGGER.debug("BEGINING TRANSACTION [EligiblityBatch270]");
		Session session = getCurrentSession();
		Transaction tx = session.getTransaction();
		if (tx == null) {
			tx = session.beginTransaction();
		} else {
			if (!tx.isActive()) {
				tx = session.beginTransaction();
			}
		}
		return tx;
	}

	@Override
	public void commitTransaction(Transaction tx) {
		LOGGER.debug("COMMIT TRANSACTION [EligiblityBatch270]");
		if (tx != null && tx.isActive()) {
			tx.commit();
		}

	}

	@Override
	public void rollBackTransaction(Transaction tx) {
		LOGGER.debug("ROLLBACK TRANSACTION [EligiblityBatch270]");
		if (tx != null && tx.isActive()) {
			tx.rollback();
		}
	}

	/**
	 * this method update the output name and processed time in
	 * EligibilityBatchFile table command.
	 * 
	 * @param bathFile
	 * @return int
	 * @throws <code>HibernateException</code>
	 */
	@Override
	public int updateBatchFile(EligibilityBatchFile batchFile)
			throws HibernateException {
		LOGGER.debug("Update status in EligibilityBatchFile");
		Session currentSession = getCurrentSession();
		Query query = currentSession
				.createQuery("UPDATE EligibilityBatchFile bf SET bf.outputfilename=:filename , bf.uploadedon=:uploadedon WHERE bf.id=:id");
		query.setParameter("filename", batchFile.getOutputfilename());
		query.setParameter("uploadedon", batchFile.getUploadedon());
		query.setParameter("id", batchFile.getId());
		System.out.println(query.toString());
		int status = query.executeUpdate();
		LOGGER.debug("Update status in EligibilityBatchFile COMPLETE");
		return status;
	}
}
