package com.batch.eligibility.shared.constants;



/**
 * It contains all segment being specified in 270 specification.
 * 
 * @author manishm3
 * @DATE MARCH 5,2015 
 */
public enum EligibilityTagEnum {
	
	ISA("ISA"),
	GS("GS"),
	ST("ST"),
	BHT("BHT"),
	SE("SE"),
	NM1("NM1"),
	HL("HL"), //no
	REF("REF"),
	N3("N3"),
	N4("N4"),
	PRV("PRV"), 
	TRN("TRN"), //no
	DMG("DMG"),
	INS("INS"), //no
	HI("HI"), //no
	DTP("DTP"),
	EQ("EQ"), //no
	AMT("AMT"), 
	III("III"),//no
	
	/*271 specific segments*/
	AAA("AAA"),
	PER("PER"),
	MPI("MPI"),
	EB("EB"),
	HSD("HSD"),
	MSG("MSG"),
	LS("LS"),
	LE("LE"),
	
	/*999 specific segments*/
	AK1("AK1"),
    AK2("AK2"),
    IK3("IK3"),
    CTX("CTX"),
    IK4("IK4"),
    IK5("IK5"),
    AK9("AK9"),
	
	GE("GE"),
	IEA("IEA");
	
	private String tag;
	
	private EligibilityTagEnum(String tag){
		this.tag=tag;
	}

	public String value(){
		return tag;
	}
	
	public static EligibilityTagEnum getSegmentEnum(String tagName){
		EligibilityTagEnum[] enumList=EligibilityTagEnum.values();
		EligibilityTagEnum elSegment=null;
		for(EligibilityTagEnum ast:enumList){
			if(ast.equals(tagName)){
				elSegment=ast;
				break;
			}
		}
		return elSegment;
	}
	
	public boolean equals(EligibilityTagEnum otherTag){
		if(this.tag.equals(otherTag.toString())){
			return true;
		}
		return false;
	}
	
	public String toString(){
		return tag;
	}
	
	public boolean equals(String tagName){
		if(this.tag.equalsIgnoreCase(tagName)){
			return true;
		}
		return false;
	}
}
