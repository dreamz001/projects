package com.batch.eligibility.jsonschema270.beans;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * Parsed JSON contains JSON sub elements.
 * 
 * @author manishm3
 * @date March 11,2015
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "xs:schema" })
public class ParsedJson {

	@JsonProperty("xs:schema")
	private XsSchema xsSchema;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	/**
	 * 
	 * @return The xsSchema
	 */
	@JsonProperty("xs:schema")
	public XsSchema getXsSchema() {
		return xsSchema;
	}

	/**
	 * 
	 * @param xsSchema
	 *            The xs:schema
	 */
	@JsonProperty("xs:schema")
	public void setXsSchema(XsSchema xsSchema) {
		this.xsSchema = xsSchema;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

}
