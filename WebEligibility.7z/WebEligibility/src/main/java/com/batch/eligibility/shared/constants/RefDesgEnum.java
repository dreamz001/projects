package com.batch.eligibility.shared.constants;

/**
 * It contains reference designator which is necessary to 
 * generate or parse 271 and 270 eligibility inquiry and response.
 * 
 * @author manishm3
 */
public enum RefDesgEnum {
	
	ST02("ST02"),
	NM101("NM101"),
	NM102("NM102"),
	NM103("NM103"),
	NM104("NM104"),
	NM105("NM105"),
	NM106("NM106"),
	NM107("NM107"),
	NM108("NM108"),
	NM109("NM109"),
	REF01("REF01"),
	REF02("REF02"),
	REF03("REF03"),
	N301("NM01"),
	N302("NM02"),
	
	N401("N401"),
	N402("N402"),
	N403("N403"),
	N404("N404"),
	N405("N405"),
	N406("N406"),
	N407("N407"),
	
	TRN01("TRN01"),
	TRN02("TRN02"),
	TRN03("TRN03"),
	TRN04("TRN04"),
	INS01("INS01"),
	INS02("INS02"),
	INS17("INS17"),
	
	DTP01("DTP01"),
	DTP02("DTP02"),
	DTP03("DTP03"),
	AMT01("AMT01"),
	AMT02("AMT02"),
	III01("III01"),
	III02("III02"),
	
	PRV01("PRV01"),
	PRV02("PRV02"),
	PRV03("PRV03"),
	
	HL03("HL03"),
	
	DMG03("DMG03"),
	DMG02("DMG02"),
	
	EB01("EB01"),
	EB02("EB02"),
	EB03("EB03"),
	EB04("EB04"),
	EB05("EB05"),
	EB06("EB06"),
	EB07("EB07"),
	EB08("EB08"),
	EB09("EB09"),
	EB10("EB10"),
	EB11("EB11"),
	EB12("EB12"),
	EB13("EB13"),
	EB13_01("EB13:01"),
	EB13_02("EB13:02"),
	EB13_03("EB13:03"),
	EB13_04("EB13:04"),
	EB13_05("EB13:05"),
	EB13_06("EB13:06"),
	
	AAA01("AAA01"),
	AAA03("AAA03"),
	AAA04("AAA04"),
	
	
	
	MSG01("MSG01");
	
	
	private String val;
	
	private RefDesgEnum(String val){
		this.val=val;
	}
	
	public String value(){
		return val;
	}
 
}
