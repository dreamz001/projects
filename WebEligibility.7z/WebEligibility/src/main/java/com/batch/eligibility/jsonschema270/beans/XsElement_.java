package com.batch.eligibility.jsonschema270.beans;

import java.util.HashMap;
import java.util.Map;

import com.batch.eligibility270.exception.InvalidRequestDataException;
import com.batch.eligibility270.writer.IConstants;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * It contains all property os Xselement for received JSON.
 * 
 * @author manishm3
 * @date Mar 11,2015
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
		"system_error_code",
		"system_error_generic_description",
		"response_message",
		"delivery_method",
		"eligibility_tracer_code",
		"relationship_code",
		"eligibility_tracer_number",
		"source_entity_identifier_code",
		"source_entity_type_qualifier",
		"source_name_last",
		"source_name_first",
		"source_name_middle",
		"source_name_suffix",
		"source_identification_code_qualifier",
		"source_identification_code",
		"receiver_entity_identifier_code",
		"receiver_entity_type_qualifier",
		"receiver_last_name",
		"receiver_first_name",
		"receiver_middle_name",
		"receiver_suffix",
		"receiver_identifier_code_qualifier",
		"receiver_identifier_code",
		"receiver_address_line1",
		"receiver_address_line2",
		"receiver_address_city",
		"receiver_address_state",
		"receiver_address_zip_code",
		"receiver_address_country",
		"receiver_identification_qualifier",
		"receiver_identification",
		"receiver_description",
		"receiver_function_code",
		"receiver_name",
		"receiver_comm_no_qualifier1",
		"receiver_comm_no1",
		"receiver_comm_no_qualifier2",
		"receiver_comm_no2",
		"receiver_comm_no_qualifier3",
		"receiver_comm_no3",
		"receiver_provider_code",
		"receiver_provider_identification_qualifier",
		"receiver_provider_identification",
		"eligibility_entity_identifier",
		"eligibility_entity_additional_identifier",
		"primary_insured_entity_identifier_code",
		"primary_insured_entity_type_qualifier",
		"primary_insured_last_name",
		"primary_insured_first_name",
		"primary_insured_middle_initial",
		"primary_insured_suffix",
		"primary_insured_identifier_code_qualifier",
		"primary_insured_identifier_code",
		"primary_insured_address_line1",
		"primary_insured_address_line2",
		"primary_insured_address_city",
		"primary_insured_address_state",
		"primary_insured_address_zip_code",
		"primary_insured_address_country",
		"primary_insured_identification_qualifier",
		"primary_insured_identification",
		"primary_insured_provider_code",
		"primary_insured_provider_identification_qualifier",
		"primary_insured_provider_identification",
		"primary_insured_demographics_date_qualifier",
		"primary_insured_demographics_date_of_birth",
		"primary_insured_demographics_gender_code",
		"primary_insured_indicator",
		// "primary_insured_relationship_code",
		"primary_insured_birth_sequence_number",
		"primary_insured_date_qualifier",
		"primary_insured_date_format_qualifier", "primary_insured_date_period",
		"primary_insured_service_type_code",
		"primary_insured_service_identification_qualifier",
		"primary_insured_procedure_code",
		"primary_insured_procedure_mod1",
		"primary_insured_procedure_mod2",
		"primary_insured_procedure_mod3",
		"primary_insured_procedure_mod4",
		"primary_insured_description",
		"primary_insured_insurance_type",
		"primary_insured_coverage_level_code",
		"primary_insured_spend_amount_qualifier_code",
		"primary_insured_spend_monetary_amount",
		"primary_insured_list_qualifier_code",
		"primary_insured_industry_code",
		"primary_insured_information_identification_qualifier",
		"primary_insured_information_identification",
		"primary_insured_eligibility_date_qualifier",
		"primary_insured_eligibility_date_format_qualifier",
		"primary_insured_eligibility_date_period",
		"dependent_entity_identifier_code",
		"dependent_entity_type_qualifier",
		"dependent_last_name",
		"dependent_first_name",
		"dependent_middle_initial",
		"dependent_suffix",
		"dependent_address_line1",
		"dependent_address_line2",
		"dependent_address_city",
		"dependent_address_state",
		"dependent_address_zip_code",
		"dependent_address_country",
		"dependent_identification_qualifier",
		"dependent_identification",
		"dependent_provider_code",
		"dependent_provider_identification_qualifier",
		"dependent_provider_identification",
		"dependent_demographics_date_qualifier",
		"dependent_demographics_date_of_birth",
		"dependent_demographics_gender_code",
		"dependent_insured_indicator",
		// "dependent_individual_relationship_code",
		"dependent_birth_sequence_number", "dependent_date_qualifier",
		"dependent_date_format_qualifier", "dependent_date_period",
		"dependent_service_type_code",
		"dependent_service_identification_qualifier",
		"dependent_procedure_code", "dependent_procedure_mod1",
		"dependent_procedure_mod2", "dependent_procedure_mod3",
		"dependent_procedure_mod4", "dependent_description",
		"dependent_insurance_type", "dependent_coverage_level_code",
		"dependent_list_qualifier_code", "dependent_industry_code",
		"dependent_information_identification_qualifier",
		"dependent_information_identification",
		"dependent_eligibility_date_qualifier",
		"dependent_eligibility_date_format_qualifier",
		"dependent_eligibility_date_period" })
public class XsElement_ {

	@JsonProperty("system_error_code")
	private String systemErrorCode;
	@JsonProperty("system_error_generic_description")
	private String systemErrorGenericDescription;
	@JsonProperty("response_message")
	private String responseMessage;
	@JsonProperty("delivery_method")
	private String deliveryMethod;
	@JsonProperty("eligibility_tracer_code")
	private String eligibilityTracerCode;
	@JsonProperty("eligibility_tracer_number")
	private String eligibilityTracerNumber;
	@JsonProperty("source_entity_identifier_code")
	private String sourceEntityIdentifierCode;
	@JsonProperty("source_entity_type_qualifier")
	private String sourceEntityTypeQualifier;
	@JsonProperty("source_name_last")
	private String sourceNameLast;
	@JsonProperty("source_name_first")
	private String sourceNameFirst;
	@JsonProperty("source_name_middle")
	private String sourceNameMiddle;
	@JsonProperty("source_name_suffix")
	private String sourceNameSuffix;
	@JsonProperty("source_identification_code_qualifier")
	private String sourceIdentificationCodeQualifier;
	@JsonProperty("source_identification_code")
	private String sourceIdentificationCode;
	@JsonProperty("receiver_entity_identifier_code")
	private String receiverEntityIdentifierCode;
	@JsonProperty("receiver_entity_type_qualifier")
	private String receiverEntityTypeQualifier;
	@JsonProperty("receiver_last_name")
	private String receiverLastName;
	@JsonProperty("receiver_first_name")
	private String receiverFirstName;
	@JsonProperty("receiver_middle_name")
	private String receiverMiddleName;
	@JsonProperty("receiver_suffix")
	private String receiverSuffix;
	@JsonProperty("receiver_identifier_code_qualifier")
	private String receiverIdentifierCodeQualifier;
	@JsonProperty("receiver_identifier_code")
	private String receiverIdentifierCode;
	@JsonProperty("receiver_address_line1")
	private String receiverAddressLine1;
	@JsonProperty("receiver_address_line2")
	private String receiverAddressLine2;
	@JsonProperty("receiver_address_city")
	private String receiverAddressCity;
	@JsonProperty("receiver_address_state")
	private String receiverAddressState;
	@JsonProperty("receiver_address_zip_code")
	private String receiverAddressZipCode;
	@JsonProperty("receiver_address_country")
	private String receiverAddressCountry;
	@JsonProperty("receiver_identification_qualifier")
	private String receiverIdentificationQualifier;
	@JsonProperty("receiver_identification")
	private String receiverIdentification;
	@JsonProperty("receiver_description")
	private String receiverDescription;
	@JsonProperty("receiver_function_code")
	private String receiverFunctionCode;
	@JsonProperty("receiver_name")
	private String receiverName;
	@JsonProperty("receiver_comm_no_qualifier1")
	private String receiverCommNoQualifier1;
	@JsonProperty("receiver_comm_no1")
	private String receiverCommNo1;
	@JsonProperty("receiver_comm_no_qualifier2")
	private String receiverCommNoQualifier2;
	@JsonProperty("receiver_comm_no2")
	private String receiverCommNo2;
	@JsonProperty("receiver_comm_no_qualifier3")
	private String receiverCommNoQualifier3;
	@JsonProperty("receiver_comm_no3")
	private String receiverCommNo3;
	@JsonProperty("receiver_provider_code")
	private String receiverProviderCode;
	@JsonProperty("receiver_provider_identification_qualifier")
	private String receiverProviderIdentificationQualifier;
	@JsonProperty("receiver_provider_identification")
	private String receiverProviderIdentification;
	@JsonProperty("eligibility_entity_identifier")
	private String eligibilityEntityIdentifier;
	@JsonProperty("eligibility_entity_additional_identifier")
	private String eligibilityEntityAdditionalIdentifier;
	@JsonProperty("primary_insured_entity_identifier_code")
	private String primaryInsuredEntityIdentifierCode;
	@JsonProperty("primary_insured_entity_type_qualifier")
	private String primaryInsuredEntityTypeQualifier;
	@JsonProperty("primary_insured_last_name")
	private String primaryInsuredLastName;
	@JsonProperty("primary_insured_first_name")
	private String primaryInsuredFirstName;
	@JsonProperty("primary_insured_middle_initial")
	private String primaryInsuredMiddleInitial;
	@JsonProperty("primary_insured_suffix")
	private String primaryInsuredSuffix;
	@JsonProperty("primary_insured_identifier_code_qualifier")
	private String primaryInsuredIdentifierCodeQualifier;
	@JsonProperty("primary_insured_identifier_code")
	private String primaryInsuredIdentifierCode;
	@JsonProperty("primary_insured_address_line1")
	private String primaryInsuredAddressLine1;
	@JsonProperty("primary_insured_address_line2")
	private String primaryInsuredAddressLine2;
	@JsonProperty("primary_insured_address_city")
	private String primaryInsuredAddressCity;
	@JsonProperty("primary_insured_address_state")
	private String primaryInsuredAddressState;
	@JsonProperty("primary_insured_address_zip_code")
	private String primaryInsuredAddressZipCode;
	@JsonProperty("primary_insured_address_country")
	private String primaryInsuredAddressCountry;
	@JsonProperty("primary_insured_identification_qualifier")
	private String primaryInsuredIdentificationQualifier;
	@JsonProperty("primary_insured_identification")
	private String primaryInsuredIdentification;
	@JsonProperty("primary_insured_provider_code")
	private String primaryInsuredProviderCode;
	@JsonProperty("primary_insured_provider_identification_qualifier")
	private String primaryInsuredProviderIdentificationQualifier;
	@JsonProperty("primary_insured_provider_identification")
	private String primaryInsuredProviderIdentification;
	@JsonProperty("primary_insured_demographics_date_qualifier")
	private String primaryInsuredDemographicsDateQualifier;
	@JsonProperty("primary_insured_demographics_date_of_birth")
	private String primaryInsuredDemographicsDateOfBirth;
	@JsonProperty("primary_insured_demographics_gender_code")
	private String primaryInsuredDemographicsGenderCode;
	@JsonProperty("primary_insured_indicator")
	private String primaryInsuredIndicator;
	/*
	 * @JsonProperty("primary_insured_relationship_code") private String
	 * primaryInsuredRelationshipCode;
	 */
	@JsonProperty("primary_insured_birth_sequence_number")
	private String primaryInsuredBirthSequenceNumber;
	@JsonProperty("primary_insured_date_qualifier")
	private String primaryInsuredDateQualifier;
	@JsonProperty("primary_insured_date_format_qualifier")
	private String primaryInsuredDateFormatQualifier;
	@JsonProperty("primary_insured_date_period")
	private String primaryInsuredDatePeriod;
	@JsonProperty("primary_insured_service_type_code")
	private String primaryInsuredServiceTypeCode;
	@JsonProperty("primary_insured_service_identification_qualifier")
	private String primaryInsuredServiceIdentificationQualifier;
	@JsonProperty("primary_insured_procedure_code")
	private String primaryInsuredProcedureCode;
	@JsonProperty("primary_insured_procedure_mod1")
	private String primaryInsuredProcedureMod1;
	@JsonProperty("primary_insured_procedure_mod2")
	private String primaryInsuredProcedureMod2;
	@JsonProperty("primary_insured_procedure_mod3")
	private String primaryInsuredProcedureMod3;
	@JsonProperty("primary_insured_procedure_mod4")
	private String primaryInsuredProcedureMod4;
	@JsonProperty("primary_insured_description")
	private String primaryInsuredDescription;
	@JsonProperty("primary_insured_insurance_type")
	private String primaryInsuredInsuranceType;
	@JsonProperty("primary_insured_coverage_level_code")
	private String primaryInsuredCoverageLevelCode;
	@JsonProperty("primary_insured_spend_amount_qualifier_code")
	private String primaryInsuredSpendAmountQualifierCode;
	@JsonProperty("primary_insured_spend_monetary_amount")
	private String primaryInsuredSpendMonetaryAmount;
	@JsonProperty("primary_insured_list_qualifier_code")
	private String primaryInsuredListQualifierCode;
	@JsonProperty("primary_insured_industry_code")
	private String primaryInsuredIndustryCode;
	@JsonProperty("primary_insured_information_identification_qualifier")
	private String primaryInsuredInformationIdentificationQualifier;
	@JsonProperty("primary_insured_information_identification")
	private String primaryInsuredInformationIdentification;
	@JsonProperty("primary_insured_eligibility_date_qualifier")
	private String primaryInsuredEligibilityDateQualifier;
	@JsonProperty("primary_insured_eligibility_date_format_qualifier")
	private String primaryInsuredEligibilityDateFormatQualifier;
	@JsonProperty("primary_insured_eligibility_date_period")
	private String primaryInsuredEligibilityDatePeriod;
	@JsonProperty("dependent_entity_identifier_code")
	private String dependentEntityIdentifierCode;
	@JsonProperty("dependent_entity_type_qualifier")
	private String dependentEntityTypeQualifier;
	@JsonProperty("dependent_last_name")
	private String dependentLastName;
	@JsonProperty("dependent_first_name")
	private String dependentFirstName;
	@JsonProperty("dependent_middle_initial")
	private String dependentMiddleInitial;
	@JsonProperty("dependent_suffix")
	private String dependentSuffix;
	@JsonProperty("dependent_address_line1")
	private String dependentAddressLine1;
	@JsonProperty("dependent_address_line2")
	private String dependentAddressLine2;
	@JsonProperty("dependent_address_city")
	private String dependentAddressCity;
	@JsonProperty("dependent_address_state")
	private String dependentAddressState;
	@JsonProperty("dependent_address_zip_code")
	private String dependentAddressZipCode;
	@JsonProperty("dependent_address_country")
	private String dependentAddressCountry;
	@JsonProperty("dependent_identification_qualifier")
	private String dependentIdentificationQualifier;
	@JsonProperty("dependent_identification")
	private String dependentIdentification;
	@JsonProperty("dependent_provider_code")
	private String dependentProviderCode;
	@JsonProperty("dependent_provider_identification_qualifier")
	private String dependentProviderIdentificationQualifier;
	@JsonProperty("dependent_provider_identification")
	private String dependentProviderIdentification;
	@JsonProperty("dependent_demographics_date_qualifier")
	private String dependentDemographicsDateQualifier;
	@JsonProperty("dependent_demographics_date_of_birth")
	private String dependentDemographicsDateOfBirth;
	@JsonProperty("dependent_demographics_gender_code")
	private String dependentDemographicsGenderCode;
	@JsonProperty("dependent_insured_indicator")
	private String dependentInsuredIndicator;
	/*
	 * @JsonProperty("dependent_individual_relationship_code") private String
	 * dependentIndividualRelationshipCode;
	 */
	@JsonProperty("dependent_birth_sequence_number")
	private String dependentBirthSequenceNumber;
	@JsonProperty("dependent_date_qualifier")
	private String dependentDateQualifier;
	@JsonProperty("dependent_date_format_qualifier")
	private String dependentDateFormatQualifier;
	@JsonProperty("dependent_date_period")
	private String dependentDatePeriod;
	@JsonProperty("dependent_service_type_code")
	private String dependentServiceTypeCode;
	@JsonProperty("dependent_service_identification_qualifier")
	private String dependentServiceIdentificationQualifier;
	@JsonProperty("dependent_procedure_code")
	private String dependentProcedureCode;
	@JsonProperty("dependent_procedure_mod1")
	private String dependentProcedureMod1;
	@JsonProperty("dependent_procedure_mod2")
	private String dependentProcedureMod2;
	@JsonProperty("dependent_procedure_mod3")
	private String dependentProcedureMod3;
	@JsonProperty("dependent_procedure_mod4")
	private String dependentProcedureMod4;
	@JsonProperty("dependent_description")
	private String dependentDescription;
	@JsonProperty("dependent_insurance_type")
	private String dependentInsuranceType;
	@JsonProperty("dependent_coverage_level_code")
	private String dependentCoverageLevelCode;
	@JsonProperty("dependent_list_qualifier_code")
	private String dependentListQualifierCode;
	@JsonProperty("dependent_industry_code")
	private String dependentIndustryCode;
	@JsonProperty("dependent_information_identification_qualifier")
	private String dependentInformationIdentificationQualifier;
	@JsonProperty("dependent_information_identification")
	private String dependentInformationIdentification;
	@JsonProperty("dependent_eligibility_date_qualifier")
	private String dependentEligibilityDateQualifier;
	@JsonProperty("dependent_eligibility_date_format_qualifier")
	private String dependentEligibilityDateFormatQualifier;
	@JsonProperty("dependent_eligibility_date_period")
	private String dependentEligibilityDatePeriod;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("relationship_code")
	private String relationShipCode;

	/**
	 * 
	 * @return The systemErrorCode
	 */
	@JsonProperty("system_error_code")
	public String getSystemErrorCode() {
		return systemErrorCode;
	}

	/**
	 * 
	 * @param systemErrorCode
	 *            The system_error_code
	 */
	@JsonProperty("system_error_code")
	public void setSystemErrorCode(String systemErrorCode) {
		this.systemErrorCode = systemErrorCode;
	}

	/**
	 * 
	 * @return The systemErrorGenericDescription
	 */
	@JsonProperty("system_error_generic_description")
	public String getSystemErrorGenericDescription() {
		return systemErrorGenericDescription;
	}

	/**
	 * 
	 * @param systemErrorGenericDescription
	 *            The system_error_generic_description
	 */
	@JsonProperty("system_error_generic_description")
	public void setSystemErrorGenericDescription(
			String systemErrorGenericDescription) {
		this.systemErrorGenericDescription = systemErrorGenericDescription;
	}

	/**
	 * 
	 * @return The responseMessage
	 */
	@JsonProperty("response_message")
	public String getResponseMessage() {
		return responseMessage;
	}

	/**
	 * 
	 * @param responseMessage
	 *            The response_message
	 */
	@JsonProperty("response_message")
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}

	/**
	 * 
	 * @return The deliveryMethod
	 */
	@JsonProperty("delivery_method")
	public String getDeliveryMethod() {
		return deliveryMethod;
	}

	/**
	 * 
	 * @param deliveryMethod
	 *            The delivery_method
	 */
	@JsonProperty("delivery_method")
	public void setDeliveryMethod(String deliveryMethod) {
		this.deliveryMethod = deliveryMethod;
	}

	/**
	 * 
	 * @return The eligibilityTracerCode
	 */
	@JsonProperty("eligibility_tracer_code")
	public String getEligibilityTracerCode() {
		return eligibilityTracerCode;
	}

	/**
	 * 
	 * @param eligibilityTracerCode
	 *            The eligibility_tracer_code
	 */
	@JsonProperty("eligibility_tracer_code")
	public void setEligibilityTracerCode(String eligibilityTracerCode) {
		this.eligibilityTracerCode = eligibilityTracerCode;
	}

	/**
	 * 
	 * @return The eligibilityTracerNumber
	 */
	@JsonProperty("eligibility_tracer_number")
	public String getEligibilityTracerNumber() {
		return eligibilityTracerNumber;
	}

	/**
	 * 
	 * @param eligibilityTracerNumber
	 *            The eligibility_tracer_number
	 */
	@JsonProperty("eligibility_tracer_number")
	public void setEligibilityTracerNumber(String eligibilityTracerNumber) {
		this.eligibilityTracerNumber = eligibilityTracerNumber;
	}

	/**
	 * 
	 * @return The sourceEntityIdentifierCode
	 */
	@JsonProperty("source_entity_identifier_code")
	public String getSourceEntityIdentifierCode() {
		return sourceEntityIdentifierCode;
	}

	/**
	 * 
	 * @param sourceEntityIdentifierCode
	 *            The source_entity_identifier_code
	 */
	@JsonProperty("source_entity_identifier_code")
	public void setSourceEntityIdentifierCode(String sourceEntityIdentifierCode) {
		this.sourceEntityIdentifierCode = sourceEntityIdentifierCode;
	}

	/**
	 * 
	 * @return The sourceEntityTypeQualifier
	 */
	@JsonProperty("source_entity_type_qualifier")
	public String getSourceEntityTypeQualifier() {
		return sourceEntityTypeQualifier;
	}

	/**
	 * 
	 * @param sourceEntityTypeQualifier
	 *            The source_entity_type_qualifier
	 */
	@JsonProperty("source_entity_type_qualifier")
	public void setSourceEntityTypeQualifier(String sourceEntityTypeQualifier) {
		this.sourceEntityTypeQualifier = sourceEntityTypeQualifier;
	}

	/**
	 * 
	 * @return The sourceNameLast
	 */
	@JsonProperty("source_name_last")
	public String getSourceNameLast() {
		return sourceNameLast;
	}

	/**
	 * 
	 * @param sourceNameLast
	 *            The source_name_last
	 */
	@JsonProperty("source_name_last")
	public void setSourceNameLast(String sourceNameLast) {
		this.sourceNameLast = sourceNameLast;
	}

	/**
	 * 
	 * @return The sourceNameFirst
	 */
	@JsonProperty("source_name_first")
	public String getSourceNameFirst() {
		return sourceNameFirst;
	}

	/**
	 * 
	 * @param sourceNameFirst
	 *            The source_name_first
	 */
	@JsonProperty("source_name_first")
	public void setSourceNameFirst(String sourceNameFirst) {
		this.sourceNameFirst = sourceNameFirst;
	}

	/**
	 * 
	 * @return The sourceNameMiddle
	 */
	@JsonProperty("source_name_middle")
	public String getSourceNameMiddle() {
		return sourceNameMiddle;
	}

	/**
	 * 
	 * @param sourceNameMiddle
	 *            The source_name_middle
	 */
	@JsonProperty("source_name_middle")
	public void setSourceNameMiddle(String sourceNameMiddle) {
		this.sourceNameMiddle = sourceNameMiddle;
	}

	/**
	 * 
	 * @return The sourceNameSuffix
	 */
	@JsonProperty("source_name_suffix")
	public String getSourceNameSuffix() {
		return sourceNameSuffix;
	}

	/**
	 * 
	 * @param sourceNameSuffix
	 *            The source_name_suffix
	 */
	@JsonProperty("source_name_suffix")
	public void setSourceNameSuffix(String sourceNameSuffix) {
		this.sourceNameSuffix = sourceNameSuffix;
	}

	/**
	 * 
	 * @return The sourceIdentificationCodeQualifier
	 */
	@JsonProperty("source_identification_code_qualifier")
	public String getSourceIdentificationCodeQualifier() {
		return sourceIdentificationCodeQualifier;
	}

	/**
	 * 
	 * @param sourceIdentificationCodeQualifier
	 *            The source_identification_code_qualifier
	 */
	@JsonProperty("source_identification_code_qualifier")
	public void setSourceIdentificationCodeQualifier(
			String sourceIdentificationCodeQualifier) {
		this.sourceIdentificationCodeQualifier = sourceIdentificationCodeQualifier;
	}

	/**
	 * 
	 * @return The sourceIdentificationCode
	 */
	@JsonProperty("source_identification_code")
	public String getSourceIdentificationCode() {
		return sourceIdentificationCode;
	}

	/**
	 * 
	 * @param sourceIdentificationCode
	 *            The source_identification_code
	 */
	@JsonProperty("source_identification_code")
	public void setSourceIdentificationCode(String sourceIdentificationCode) {
		this.sourceIdentificationCode = sourceIdentificationCode;
	}

	/**
	 * 
	 * @return The receiverEntityIdentifierCode
	 */
	@JsonProperty("receiver_entity_identifier_code")
	public String getReceiverEntityIdentifierCode() {
		return receiverEntityIdentifierCode;
	}

	/**
	 * 
	 * @param receiverEntityIdentifierCode
	 *            The receiver_entity_identifier_code
	 */
	@JsonProperty("receiver_entity_identifier_code")
	public void setReceiverEntityIdentifierCode(
			String receiverEntityIdentifierCode) {
		this.receiverEntityIdentifierCode = receiverEntityIdentifierCode;
	}

	/**
	 * 
	 * @return The receiverEntityTypeQualifier
	 */
	@JsonProperty("receiver_entity_type_qualifier")
	public String getReceiverEntityTypeQualifier() {
		return receiverEntityTypeQualifier;
	}

	/**
	 * 
	 * @param receiverEntityTypeQualifier
	 *            The receiver_entity_type_qualifier
	 */
	@JsonProperty("receiver_entity_type_qualifier")
	public void setReceiverEntityTypeQualifier(
			String receiverEntityTypeQualifier) {
		this.receiverEntityTypeQualifier = receiverEntityTypeQualifier;
	}

	/**
	 * 
	 * @return The receiverLastName
	 */
	@JsonProperty("receiver_last_name")
	public String getReceiverLastName() {
		return receiverLastName;
	}

	/**
	 * 
	 * @param receiverLastName
	 *            The receiver_last_name
	 */
	@JsonProperty("receiver_last_name")
	public void setReceiverLastName(String receiverLastName) {
		this.receiverLastName = receiverLastName;
	}

	/**
	 * 
	 * @return The receiverFirstName
	 */
	@JsonProperty("receiver_first_name")
	public String getReceiverFirstName() {
		return receiverFirstName;
	}

	/**
	 * 
	 * @param receiverFirstName
	 *            The receiver_first_name
	 */
	@JsonProperty("receiver_first_name")
	public void setReceiverFirstName(String receiverFirstName) {
		this.receiverFirstName = receiverFirstName;
	}

	/**
	 * 
	 * @return The receiverMiddleName
	 */
	@JsonProperty("receiver_middle_name")
	public String getReceiverMiddleName() {
		return receiverMiddleName;
	}

	/**
	 * 
	 * @param receiverMiddleName
	 *            The receiver_middle_name
	 */
	@JsonProperty("receiver_middle_name")
	public void setReceiverMiddleName(String receiverMiddleName) {
		this.receiverMiddleName = receiverMiddleName;
	}

	/**
	 * 
	 * @return The receiverSuffix
	 */
	@JsonProperty("receiver_suffix")
	public String getReceiverSuffix() {
		return receiverSuffix;
	}

	/**
	 * 
	 * @param receiverSuffix
	 *            The receiver_suffix
	 */
	@JsonProperty("receiver_suffix")
	public void setReceiverSuffix(String receiverSuffix) {
		this.receiverSuffix = receiverSuffix;
	}

	/**
	 * 
	 * @return The receiverIdentifierCodeQualifier
	 */
	@JsonProperty("receiver_identifier_code_qualifier")
	public String getReceiverIdentifierCodeQualifier() {
		return receiverIdentifierCodeQualifier;
	}

	/**
	 * 
	 * @param receiverIdentifierCodeQualifier
	 *            The receiver_identifier_code_qualifier
	 */
	@JsonProperty("receiver_identifier_code_qualifier")
	public void setReceiverIdentifierCodeQualifier(
			String receiverIdentifierCodeQualifier) {
		this.receiverIdentifierCodeQualifier = receiverIdentifierCodeQualifier;
	}

	/**
	 * 
	 * @return The receiverIdentifierCode
	 */
	@JsonProperty("receiver_identifier_code")
	public String getReceiverIdentifierCode() {
		return receiverIdentifierCode;
	}

	/**
	 * 
	 * @param receiverIdentifierCode
	 *            The receiver_identifier_code
	 */
	@JsonProperty("receiver_identifier_code")
	public void setReceiverIdentifierCode(String receiverIdentifierCode) {
		this.receiverIdentifierCode = receiverIdentifierCode;
	}

	/**
	 * 
	 * @return The receiverAddressLine1
	 */
	@JsonProperty("receiver_address_line1")
	public String getReceiverAddressLine1() {
		return receiverAddressLine1;
	}

	/**
	 * 
	 * @param receiverAddressLine1
	 *            The receiver_address_line1
	 */
	@JsonProperty("receiver_address_line1")
	public void setReceiverAddressLine1(String receiverAddressLine1) {
		this.receiverAddressLine1 = receiverAddressLine1;
	}

	/**
	 * 
	 * @return The receiverAddressLine2
	 */
	@JsonProperty("receiver_address_line2")
	public String getReceiverAddressLine2() {
		return receiverAddressLine2;
	}

	/**
	 * 
	 * @param receiverAddressLine2
	 *            The receiver_address_line2
	 */
	@JsonProperty("receiver_address_line2")
	public void setReceiverAddressLine2(String receiverAddressLine2) {
		this.receiverAddressLine2 = receiverAddressLine2;
	}

	/**
	 * 
	 * @return The receiverAddressCity
	 */
	@JsonProperty("receiver_address_city")
	public String getReceiverAddressCity() {
		return receiverAddressCity;
	}

	/**
	 * 
	 * @param receiverAddressCity
	 *            The receiver_address_city
	 */
	@JsonProperty("receiver_address_city")
	public void setReceiverAddressCity(String receiverAddressCity) {
		this.receiverAddressCity = receiverAddressCity;
	}

	/**
	 * 
	 * @return The receiverAddressState
	 */
	@JsonProperty("receiver_address_state")
	public String getReceiverAddressState() {
		return receiverAddressState;
	}

	/**
	 * 
	 * @param receiverAddressState
	 *            The receiver_address_state
	 */
	@JsonProperty("receiver_address_state")
	public void setReceiverAddressState(String receiverAddressState) {
		this.receiverAddressState = receiverAddressState;
	}

	/**
	 * 
	 * @return The receiverAddressZipCode
	 */
	@JsonProperty("receiver_address_zip_code")
	public String getReceiverAddressZipCode() {
		return receiverAddressZipCode;
	}

	/**
	 * 
	 * @param receiverAddressZipCode
	 *            The receiver_address_zip_code
	 */
	@JsonProperty("receiver_address_zip_code")
	public void setReceiverAddressZipCode(String receiverAddressZipCode) {
		this.receiverAddressZipCode = receiverAddressZipCode;
	}

	/**
	 * 
	 * @return The receiverAddressCountry
	 */
	@JsonProperty("receiver_address_country")
	public String getReceiverAddressCountry() {
		return receiverAddressCountry;
	}

	/**
	 * 
	 * @param receiverAddressCountry
	 *            The receiver_address_country
	 */
	@JsonProperty("receiver_address_country")
	public void setReceiverAddressCountry(String receiverAddressCountry) {
		this.receiverAddressCountry = receiverAddressCountry;
	}

	/**
	 * 
	 * @return The receiverIdentificationQualifier
	 */
	@JsonProperty("receiver_identification_qualifier")
	public String getReceiverIdentificationQualifier() {
		return receiverIdentificationQualifier;
	}

	/**
	 * 
	 * @param receiverIdentificationQualifier
	 *            The receiver_identification_qualifier
	 */
	@JsonProperty("receiver_identification_qualifier")
	public void setReceiverIdentificationQualifier(
			String receiverIdentificationQualifier) {
		this.receiverIdentificationQualifier = receiverIdentificationQualifier;
	}

	/**
	 * 
	 * @return The receiverIdentification
	 */
	@JsonProperty("receiver_identification")
	public String getReceiverIdentification() {
		return receiverIdentification;
	}

	/**
	 * 
	 * @param receiverIdentification
	 *            The receiver_identification
	 */
	@JsonProperty("receiver_identification")
	public void setReceiverIdentification(String receiverIdentification) {
		this.receiverIdentification = receiverIdentification;
	}

	/**
	 * 
	 * @return The receiverDescription
	 */
	@JsonProperty("receiver_description")
	public String getReceiverDescription() {
		return receiverDescription;
	}

	/**
	 * 
	 * @param receiverDescription
	 *            The receiver_description
	 */
	@JsonProperty("receiver_description")
	public void setReceiverDescription(String receiverDescription) {
		this.receiverDescription = receiverDescription;
	}

	/**
	 * 
	 * @return The receiverFunctionCode
	 */
	@JsonProperty("receiver_function_code")
	public String getReceiverFunctionCode() {
		return receiverFunctionCode;
	}

	/**
	 * 
	 * @param receiverFunctionCode
	 *            The receiver_function_code
	 */
	@JsonProperty("receiver_function_code")
	public void setReceiverFunctionCode(String receiverFunctionCode) {
		this.receiverFunctionCode = receiverFunctionCode;
	}

	/**
	 * 
	 * @return The receiverName
	 */
	@JsonProperty("receiver_name")
	public String getReceiverName() {
		return receiverName;
	}

	/**
	 * 
	 * @param receiverName
	 *            The receiver_name
	 */
	@JsonProperty("receiver_name")
	public void setReceiverName(String receiverName) {
		this.receiverName = receiverName;
	}

	/**
	 * 
	 * @return The receiverCommNoQualifier1
	 */
	@JsonProperty("receiver_comm_no_qualifier1")
	public String getReceiverCommNoQualifier1() {
		return receiverCommNoQualifier1;
	}

	/**
	 * 
	 * @param receiverCommNoQualifier1
	 *            The receiver_comm_no_qualifier1
	 */
	@JsonProperty("receiver_comm_no_qualifier1")
	public void setReceiverCommNoQualifier1(String receiverCommNoQualifier1) {
		this.receiverCommNoQualifier1 = receiverCommNoQualifier1;
	}

	/**
	 * 
	 * @return The receiverCommNo1
	 */
	@JsonProperty("receiver_comm_no1")
	public String getReceiverCommNo1() {
		return receiverCommNo1;
	}

	/**
	 * 
	 * @param receiverCommNo1
	 *            The receiver_comm_no1
	 */
	@JsonProperty("receiver_comm_no1")
	public void setReceiverCommNo1(String receiverCommNo1) {
		this.receiverCommNo1 = receiverCommNo1;
	}

	/**
	 * 
	 * @return The receiverCommNoQualifier2
	 */
	@JsonProperty("receiver_comm_no_qualifier2")
	public String getReceiverCommNoQualifier2() {
		return receiverCommNoQualifier2;
	}

	/**
	 * 
	 * @param receiverCommNoQualifier2
	 *            The receiver_comm_no_qualifier2
	 */
	@JsonProperty("receiver_comm_no_qualifier2")
	public void setReceiverCommNoQualifier2(String receiverCommNoQualifier2) {
		this.receiverCommNoQualifier2 = receiverCommNoQualifier2;
	}

	/**
	 * 
	 * @return The receiverCommNo2
	 */
	@JsonProperty("receiver_comm_no2")
	public String getReceiverCommNo2() {
		return receiverCommNo2;
	}

	/**
	 * 
	 * @param receiverCommNo2
	 *            The receiver_comm_no2
	 */
	@JsonProperty("receiver_comm_no2")
	public void setReceiverCommNo2(String receiverCommNo2) {
		this.receiverCommNo2 = receiverCommNo2;
	}

	/**
	 * 
	 * @return The receiverCommNoQualifier3
	 */
	@JsonProperty("receiver_comm_no_qualifier3")
	public String getReceiverCommNoQualifier3() {
		return receiverCommNoQualifier3;
	}

	/**
	 * 
	 * @param receiverCommNoQualifier3
	 *            The receiver_comm_no_qualifier3
	 */
	@JsonProperty("receiver_comm_no_qualifier3")
	public void setReceiverCommNoQualifier3(String receiverCommNoQualifier3) {
		this.receiverCommNoQualifier3 = receiverCommNoQualifier3;
	}

	/**
	 * 
	 * @return The receiverCommNo3
	 */
	@JsonProperty("receiver_comm_no3")
	public String getReceiverCommNo3() {
		return receiverCommNo3;
	}

	/**
	 * 
	 * @param receiverCommNo3
	 *            The receiver_comm_no3
	 */
	@JsonProperty("receiver_comm_no3")
	public void setReceiverCommNo3(String receiverCommNo3) {
		this.receiverCommNo3 = receiverCommNo3;
	}

	/**
	 * 
	 * @return The receiverProviderCode
	 */
	@JsonProperty("receiver_provider_code")
	public String getReceiverProviderCode() {
		return receiverProviderCode;
	}

	/**
	 * 
	 * @param receiverProviderCode
	 *            The receiver_provider_code
	 */
	@JsonProperty("receiver_provider_code")
	public void setReceiverProviderCode(String receiverProviderCode) {
		this.receiverProviderCode = receiverProviderCode;
	}

	/**
	 * 
	 * @return The receiverProviderIdentificationQualifier
	 */
	@JsonProperty("receiver_provider_identification_qualifier")
	public String getReceiverProviderIdentificationQualifier() {
		return receiverProviderIdentificationQualifier;
	}

	/**
	 * 
	 * @param receiverProviderIdentificationQualifier
	 *            The receiver_provider_identification_qualifier
	 */
	@JsonProperty("receiver_provider_identification_qualifier")
	public void setReceiverProviderIdentificationQualifier(
			String receiverProviderIdentificationQualifier) {
		this.receiverProviderIdentificationQualifier = receiverProviderIdentificationQualifier;
	}

	/**
	 * 
	 * @return The receiverProviderIdentification
	 */
	@JsonProperty("receiver_provider_identification")
	public String getReceiverProviderIdentification() {
		return receiverProviderIdentification;
	}

	/**
	 * 
	 * @param receiverProviderIdentification
	 *            The receiver_provider_identification
	 */
	@JsonProperty("receiver_provider_identification")
	public void setReceiverProviderIdentification(
			String receiverProviderIdentification) {
		this.receiverProviderIdentification = receiverProviderIdentification;
	}

	/**
	 * 
	 * @return The eligibilityEntityIdentifier
	 */
	@JsonProperty("eligibility_entity_identifier")
	public String getEligibilityEntityIdentifier() {
		return eligibilityEntityIdentifier;
	}

	/**
	 * 
	 * @param eligibilityEntityIdentifier
	 *            The eligibility_entity_identifier
	 */
	@JsonProperty("eligibility_entity_identifier")
	public void setEligibilityEntityIdentifier(
			String eligibilityEntityIdentifier) {
		this.eligibilityEntityIdentifier = eligibilityEntityIdentifier;
	}

	/**
	 * 
	 * @return The eligibilityEntityAdditionalIdentifier
	 */
	@JsonProperty("eligibility_entity_additional_identifier")
	public String getEligibilityEntityAdditionalIdentifier() {
		return eligibilityEntityAdditionalIdentifier;
	}

	/**
	 * 
	 * @param eligibilityEntityAdditionalIdentifier
	 *            The eligibility_entity_additional_identifier
	 */
	@JsonProperty("eligibility_entity_additional_identifier")
	public void setEligibilityEntityAdditionalIdentifier(
			String eligibilityEntityAdditionalIdentifier) {
		this.eligibilityEntityAdditionalIdentifier = eligibilityEntityAdditionalIdentifier;
	}

	/**
	 * 
	 * @return The primaryInsuredEntityIdentifierCode
	 */
	@JsonProperty("primary_insured_entity_identifier_code")
	public String getPrimaryInsuredEntityIdentifierCode() {
		return primaryInsuredEntityIdentifierCode;
	}

	/**
	 * 
	 * @param primaryInsuredEntityIdentifierCode
	 *            The primary_insured_entity_identifier_code
	 */
	@JsonProperty("primary_insured_entity_identifier_code")
	public void setPrimaryInsuredEntityIdentifierCode(
			String primaryInsuredEntityIdentifierCode) {
		this.primaryInsuredEntityIdentifierCode = primaryInsuredEntityIdentifierCode;
	}

	/**
	 * 
	 * @return The primaryInsuredEntityTypeQualifier
	 */
	@JsonProperty("primary_insured_entity_type_qualifier")
	public String getPrimaryInsuredEntityTypeQualifier() {
		return primaryInsuredEntityTypeQualifier;
	}

	/**
	 * 
	 * @param primaryInsuredEntityTypeQualifier
	 *            The primary_insured_entity_type_qualifier
	 */
	@JsonProperty("primary_insured_entity_type_qualifier")
	public void setPrimaryInsuredEntityTypeQualifier(
			String primaryInsuredEntityTypeQualifier) {
		this.primaryInsuredEntityTypeQualifier = primaryInsuredEntityTypeQualifier;
	}

	/**
	 * 
	 * @return The primaryInsuredLastName
	 */
	@JsonProperty("primary_insured_last_name")
	public String getPrimaryInsuredLastName() {
		return primaryInsuredLastName;
	}

	/**
	 * 
	 * @param primaryInsuredLastName
	 *            The primary_insured_last_name
	 */
	@JsonProperty("primary_insured_last_name")
	public void setPrimaryInsuredLastName(String primaryInsuredLastName) {
		this.primaryInsuredLastName = primaryInsuredLastName;
	}

	/**
	 * 
	 * @return The primaryInsuredFirstName
	 */
	@JsonProperty("primary_insured_first_name")
	public String getPrimaryInsuredFirstName() {
		return primaryInsuredFirstName;
	}

	/**
	 * 
	 * @param primaryInsuredFirstName
	 *            The primary_insured_first_name
	 */
	@JsonProperty("primary_insured_first_name")
	public void setPrimaryInsuredFirstName(String primaryInsuredFirstName) {
		this.primaryInsuredFirstName = primaryInsuredFirstName;
	}

	/**
	 * 
	 * @return The primaryInsuredMiddleInitial
	 */
	@JsonProperty("primary_insured_middle_initial")
	public String getPrimaryInsuredMiddleInitial() {
		return primaryInsuredMiddleInitial;
	}

	/**
	 * 
	 * @param primaryInsuredMiddleInitial
	 *            The primary_insured_middle_initial
	 */
	@JsonProperty("primary_insured_middle_initial")
	public void setPrimaryInsuredMiddleInitial(
			String primaryInsuredMiddleInitial) {
		this.primaryInsuredMiddleInitial = primaryInsuredMiddleInitial;
	}

	/**
	 * 
	 * @return The primaryInsuredSuffix
	 */
	@JsonProperty("primary_insured_suffix")
	public String getPrimaryInsuredSuffix() {
		return primaryInsuredSuffix;
	}

	/**
	 * 
	 * @param primaryInsuredSuffix
	 *            The primary_insured_suffix
	 */
	@JsonProperty("primary_insured_suffix")
	public void setPrimaryInsuredSuffix(String primaryInsuredSuffix) {
		this.primaryInsuredSuffix = primaryInsuredSuffix;
	}

	/**
	 * 
	 * @return The primaryInsuredIdentifierCodeQualifier
	 */
	@JsonProperty("primary_insured_identifier_code_qualifier")
	public String getPrimaryInsuredIdentifierCodeQualifier() {
		return primaryInsuredIdentifierCodeQualifier;
	}

	/**
	 * 
	 * @param primaryInsuredIdentifierCodeQualifier
	 *            The primary_insured_identifier_code_qualifier
	 */
	@JsonProperty("primary_insured_identifier_code_qualifier")
	public void setPrimaryInsuredIdentifierCodeQualifier(
			String primaryInsuredIdentifierCodeQualifier) {
		this.primaryInsuredIdentifierCodeQualifier = primaryInsuredIdentifierCodeQualifier;
	}

	/**
	 * 
	 * @return The primaryInsuredIdentifierCode
	 */
	@JsonProperty("primary_insured_identifier_code")
	public String getPrimaryInsuredIdentifierCode() {
		return primaryInsuredIdentifierCode;
	}

	/**
	 * 
	 * @param primaryInsuredIdentifierCode
	 *            The primary_insured_identifier_code
	 */
	@JsonProperty("primary_insured_identifier_code")
	public void setPrimaryInsuredIdentifierCode(
			String primaryInsuredIdentifierCode) {
		this.primaryInsuredIdentifierCode = primaryInsuredIdentifierCode;
	}

	/**
	 * 
	 * @return The primaryInsuredAddressLine1
	 */
	@JsonProperty("primary_insured_address_line1")
	public String getPrimaryInsuredAddressLine1() {
		return primaryInsuredAddressLine1;
	}

	/**
	 * 
	 * @param primaryInsuredAddressLine1
	 *            The primary_insured_address_line1
	 */
	@JsonProperty("primary_insured_address_line1")
	public void setPrimaryInsuredAddressLine1(String primaryInsuredAddressLine1) {
		this.primaryInsuredAddressLine1 = primaryInsuredAddressLine1;
	}

	/**
	 * 
	 * @return The primaryInsuredAddressLine2
	 */
	@JsonProperty("primary_insured_address_line2")
	public String getPrimaryInsuredAddressLine2() {
		return primaryInsuredAddressLine2;
	}

	/**
	 * 
	 * @param primaryInsuredAddressLine2
	 *            The primary_insured_address_line2
	 */
	@JsonProperty("primary_insured_address_line2")
	public void setPrimaryInsuredAddressLine2(String primaryInsuredAddressLine2) {
		this.primaryInsuredAddressLine2 = primaryInsuredAddressLine2;
	}

	/**
	 * 
	 * @return The primaryInsuredAddressCity
	 */
	@JsonProperty("primary_insured_address_city")
	public String getPrimaryInsuredAddressCity() {
		return primaryInsuredAddressCity;
	}

	/**
	 * 
	 * @param primaryInsuredAddressCity
	 *            The primary_insured_address_city
	 */
	@JsonProperty("primary_insured_address_city")
	public void setPrimaryInsuredAddressCity(String primaryInsuredAddressCity) {
		this.primaryInsuredAddressCity = primaryInsuredAddressCity;
	}

	/**
	 * 
	 * @return The primaryInsuredAddressState
	 */
	@JsonProperty("primary_insured_address_state")
	public String getPrimaryInsuredAddressState() {
		return primaryInsuredAddressState;
	}

	/**
	 * 
	 * @param primaryInsuredAddressState
	 *            The primary_insured_address_state
	 */
	@JsonProperty("primary_insured_address_state")
	public void setPrimaryInsuredAddressState(String primaryInsuredAddressState) {
		this.primaryInsuredAddressState = primaryInsuredAddressState;
	}

	/**
	 * 
	 * @return The primaryInsuredAddressZipCode
	 */
	@JsonProperty("primary_insured_address_zip_code")
	public String getPrimaryInsuredAddressZipCode() {
		return primaryInsuredAddressZipCode;
	}

	/**
	 * 
	 * @param primaryInsuredAddressZipCode
	 *            The primary_insured_address_zip_code
	 */
	@JsonProperty("primary_insured_address_zip_code")
	public void setPrimaryInsuredAddressZipCode(
			String primaryInsuredAddressZipCode) {
		this.primaryInsuredAddressZipCode = primaryInsuredAddressZipCode;
	}

	/**
	 * 
	 * @return The primaryInsuredAddressCountry
	 */
	@JsonProperty("primary_insured_address_country")
	public String getPrimaryInsuredAddressCountry() {
		return primaryInsuredAddressCountry;
	}

	/**
	 * 
	 * @param primaryInsuredAddressCountry
	 *            The primary_insured_address_country
	 */
	@JsonProperty("primary_insured_address_country")
	public void setPrimaryInsuredAddressCountry(
			String primaryInsuredAddressCountry) {
		this.primaryInsuredAddressCountry = primaryInsuredAddressCountry;
	}

	/**
	 * 
	 * @return The primaryInsuredIdentificationQualifier
	 */
	@JsonProperty("primary_insured_identification_qualifier")
	public String getPrimaryInsuredIdentificationQualifier() {
		return primaryInsuredIdentificationQualifier;
	}

	/**
	 * 
	 * @param primaryInsuredIdentificationQualifier
	 *            The primary_insured_identification_qualifier
	 */
	@JsonProperty("primary_insured_identification_qualifier")
	public void setPrimaryInsuredIdentificationQualifier(
			String primaryInsuredIdentificationQualifier) {
		this.primaryInsuredIdentificationQualifier = primaryInsuredIdentificationQualifier;
	}

	/**
	 * 
	 * @return The primaryInsuredIdentification
	 */
	@JsonProperty("primary_insured_identification")
	public String getPrimaryInsuredIdentification() {
		return primaryInsuredIdentification;
	}

	/**
	 * 
	 * @param primaryInsuredIdentification
	 *            The primary_insured_identification
	 */
	@JsonProperty("primary_insured_identification")
	public void setPrimaryInsuredIdentification(
			String primaryInsuredIdentification) {
		this.primaryInsuredIdentification = primaryInsuredIdentification;
	}

	/**
	 * 
	 * @return The primaryInsuredProviderCode
	 */
	@JsonProperty("primary_insured_provider_code")
	public String getPrimaryInsuredProviderCode() {
		return primaryInsuredProviderCode;
	}

	/**
	 * 
	 * @param primaryInsuredProviderCode
	 *            The primary_insured_provider_code
	 */
	@JsonProperty("primary_insured_provider_code")
	public void setPrimaryInsuredProviderCode(String primaryInsuredProviderCode) {
		this.primaryInsuredProviderCode = primaryInsuredProviderCode;
	}

	/**
	 * 
	 * @return The primaryInsuredProviderIdentificationQualifier
	 */
	@JsonProperty("primary_insured_provider_identification_qualifier")
	public String getPrimaryInsuredProviderIdentificationQualifier() {
		return primaryInsuredProviderIdentificationQualifier;
	}

	/**
	 * 
	 * @param primaryInsuredProviderIdentificationQualifier
	 *            The primary_insured_provider_identification_qualifier
	 */
	@JsonProperty("primary_insured_provider_identification_qualifier")
	public void setPrimaryInsuredProviderIdentificationQualifier(
			String primaryInsuredProviderIdentificationQualifier) {
		this.primaryInsuredProviderIdentificationQualifier = primaryInsuredProviderIdentificationQualifier;
	}

	/**
	 * 
	 * @return The primaryInsuredProviderIdentification
	 */
	@JsonProperty("primary_insured_provider_identification")
	public String getPrimaryInsuredProviderIdentification() {
		return primaryInsuredProviderIdentification;
	}

	/**
	 * 
	 * @param primaryInsuredProviderIdentification
	 *            The primary_insured_provider_identification
	 */
	@JsonProperty("primary_insured_provider_identification")
	public void setPrimaryInsuredProviderIdentification(
			String primaryInsuredProviderIdentification) {
		this.primaryInsuredProviderIdentification = primaryInsuredProviderIdentification;
	}

	/**
	 * 
	 * @return The primaryInsuredDemographicsDateQualifier
	 */
	@JsonProperty("primary_insured_demographics_date_qualifier")
	public String getPrimaryInsuredDemographicsDateQualifier() {
		return primaryInsuredDemographicsDateQualifier;
	}

	/**
	 * 
	 * @param primaryInsuredDemographicsDateQualifier
	 *            The primary_insured_demographics_date_qualifier
	 */
	@JsonProperty("primary_insured_demographics_date_qualifier")
	public void setPrimaryInsuredDemographicsDateQualifier(
			String primaryInsuredDemographicsDateQualifier) {
		this.primaryInsuredDemographicsDateQualifier = primaryInsuredDemographicsDateQualifier;
	}

	/**
	 * 
	 * @return The primaryInsuredDemographicsDateOfBirth
	 */
	@JsonProperty("primary_insured_demographics_date_of_birth")
	public String getPrimaryInsuredDemographicsDateOfBirth() {
		return primaryInsuredDemographicsDateOfBirth;
	}

	/**
	 * 
	 * @param primaryInsuredDemographicsDateOfBirth
	 *            The primary_insured_demographics_date_of_birth
	 */
	@JsonProperty("primary_insured_demographics_date_of_birth")
	public void setPrimaryInsuredDemographicsDateOfBirth(
			String primaryInsuredDemographicsDateOfBirth) {
		this.primaryInsuredDemographicsDateOfBirth = primaryInsuredDemographicsDateOfBirth;
	}

	/**
	 * 
	 * @return The primaryInsuredDemographicsGenderCode
	 */
	@JsonProperty("primary_insured_demographics_gender_code")
	public String getPrimaryInsuredDemographicsGenderCode() {
		return primaryInsuredDemographicsGenderCode;
	}

	/**
	 * 
	 * @param primaryInsuredDemographicsGenderCode
	 *            The primary_insured_demographics_gender_code
	 */
	@JsonProperty("primary_insured_demographics_gender_code")
	public void setPrimaryInsuredDemographicsGenderCode(
			String primaryInsuredDemographicsGenderCode) {
		this.primaryInsuredDemographicsGenderCode = primaryInsuredDemographicsGenderCode;
	}

	/**
	 * 
	 * @return The primaryInsuredIndicator
	 */
	@JsonProperty("primary_insured_indicator")
	public String getPrimaryInsuredIndicator() {
		return primaryInsuredIndicator;
	}

	/**
	 * 
	 * @param primaryInsuredIndicator
	 *            The primary_insured_indicator
	 */
	@JsonProperty("primary_insured_indicator")
	public void setPrimaryInsuredIndicator(String primaryInsuredIndicator) {
		this.primaryInsuredIndicator = primaryInsuredIndicator;
	}

	/**
	 * 
	 * @return The primaryInsuredRelationshipCode
	 */
	/*
	 * @JsonProperty("primary_insured_relationship_code") public String
	 * getPrimaryInsuredRelationshipCode() { return
	 * primaryInsuredRelationshipCode; }
	 */

	/**
	 * 
	 * @param primaryInsuredRelationshipCode
	 *            The primary_insured_relationship_code
	 */
	/*
	 * @JsonProperty("primary_insured_relationship_code") public void
	 * setPrimaryInsuredRelationshipCode(String primaryInsuredRelationshipCode)
	 * { this.primaryInsuredRelationshipCode = primaryInsuredRelationshipCode; }
	 */

	/**
	 * 
	 * @return The primaryInsuredBirthSequenceNumber
	 */
	@JsonProperty("primary_insured_birth_sequence_number")
	public String getPrimaryInsuredBirthSequenceNumber() {
		return primaryInsuredBirthSequenceNumber;
	}

	/**
	 * 
	 * @param primaryInsuredBirthSequenceNumber
	 *            The primary_insured_birth_sequence_number
	 */
	@JsonProperty("primary_insured_birth_sequence_number")
	public void setPrimaryInsuredBirthSequenceNumber(
			String primaryInsuredBirthSequenceNumber) {
		this.primaryInsuredBirthSequenceNumber = primaryInsuredBirthSequenceNumber;
	}

	/**
	 * 
	 * @return The primaryInsuredDateQualifier
	 */
	@JsonProperty("primary_insured_date_qualifier")
	public String getPrimaryInsuredDateQualifier() {
		return primaryInsuredDateQualifier;
	}

	/**
	 * 
	 * @param primaryInsuredDateQualifier
	 *            The primary_insured_date_qualifier
	 */
	@JsonProperty("primary_insured_date_qualifier")
	public void setPrimaryInsuredDateQualifier(
			String primaryInsuredDateQualifier) {
		this.primaryInsuredDateQualifier = primaryInsuredDateQualifier;
	}

	/**
	 * 
	 * @return The primaryInsuredDateFormatQualifier
	 */
	@JsonProperty("primary_insured_date_format_qualifier")
	public String getPrimaryInsuredDateFormatQualifier() {
		return primaryInsuredDateFormatQualifier;
	}

	/**
	 * 
	 * @param primaryInsuredDateFormatQualifier
	 *            The primary_insured_date_format_qualifier
	 */
	@JsonProperty("primary_insured_date_format_qualifier")
	public void setPrimaryInsuredDateFormatQualifier(
			String primaryInsuredDateFormatQualifier) {
		this.primaryInsuredDateFormatQualifier = primaryInsuredDateFormatQualifier;
	}

	/**
	 * 
	 * @return The primaryInsuredDatePeriod
	 */
	@JsonProperty("primary_insured_date_period")
	public String getPrimaryInsuredDatePeriod() {
		return primaryInsuredDatePeriod;
	}

	/**
	 * 
	 * @param primaryInsuredDatePeriod
	 *            The primary_insured_date_period
	 */
	@JsonProperty("primary_insured_date_period")
	public void setPrimaryInsuredDatePeriod(String primaryInsuredDatePeriod) {
		this.primaryInsuredDatePeriod = primaryInsuredDatePeriod;
	}

	/**
	 * 
	 * @return The primaryInsuredServiceTypeCode
	 */
	@JsonProperty("primary_insured_service_type_code")
	public String getPrimaryInsuredServiceTypeCode() {
		return primaryInsuredServiceTypeCode;
	}

	/**
	 * 
	 * @param primaryInsuredServiceTypeCode
	 *            The primary_insured_service_type_code
	 */
	@JsonProperty("primary_insured_service_type_code")
	public void setPrimaryInsuredServiceTypeCode(
			String primaryInsuredServiceTypeCode) {
		this.primaryInsuredServiceTypeCode = primaryInsuredServiceTypeCode;
	}

	/**
	 * 
	 * @return The primaryInsuredServiceIdentificationQualifier
	 */
	@JsonProperty("primary_insured_service_identification_qualifier")
	public String getPrimaryInsuredServiceIdentificationQualifier() {
		return primaryInsuredServiceIdentificationQualifier;
	}

	/**
	 * 
	 * @param primaryInsuredServiceIdentificationQualifier
	 *            The primary_insured_service_identification_qualifier
	 */
	@JsonProperty("primary_insured_service_identification_qualifier")
	public void setPrimaryInsuredServiceIdentificationQualifier(
			String primaryInsuredServiceIdentificationQualifier) {
		this.primaryInsuredServiceIdentificationQualifier = primaryInsuredServiceIdentificationQualifier;
	}

	/**
	 * 
	 * @return The primaryInsuredProcedureCode
	 */
	@JsonProperty("primary_insured_procedure_code")
	public String getPrimaryInsuredProcedureCode() {
		return primaryInsuredProcedureCode;
	}

	/**
	 * 
	 * @param primaryInsuredProcedureCode
	 *            The primary_insured_procedure_code
	 */
	@JsonProperty("primary_insured_procedure_code")
	public void setPrimaryInsuredProcedureCode(
			String primaryInsuredProcedureCode) {
		this.primaryInsuredProcedureCode = primaryInsuredProcedureCode;
	}

	/**
	 * 
	 * @return The primaryInsuredProcedureMod1
	 */
	@JsonProperty("primary_insured_procedure_mod1")
	public String getPrimaryInsuredProcedureMod1() {
		return primaryInsuredProcedureMod1;
	}

	/**
	 * 
	 * @param primaryInsuredProcedureMod1
	 *            The primary_insured_procedure_mod1
	 */
	@JsonProperty("primary_insured_procedure_mod1")
	public void setPrimaryInsuredProcedureMod1(
			String primaryInsuredProcedureMod1) {
		this.primaryInsuredProcedureMod1 = primaryInsuredProcedureMod1;
	}

	/**
	 * 
	 * @return The primaryInsuredProcedureMod2
	 */
	@JsonProperty("primary_insured_procedure_mod2")
	public String getPrimaryInsuredProcedureMod2() {
		return primaryInsuredProcedureMod2;
	}

	/**
	 * 
	 * @param primaryInsuredProcedureMod2
	 *            The primary_insured_procedure_mod2
	 */
	@JsonProperty("primary_insured_procedure_mod2")
	public void setPrimaryInsuredProcedureMod2(
			String primaryInsuredProcedureMod2) {
		this.primaryInsuredProcedureMod2 = primaryInsuredProcedureMod2;
	}

	/**
	 * 
	 * @return The primaryInsuredProcedureMod3
	 */
	@JsonProperty("primary_insured_procedure_mod3")
	public String getPrimaryInsuredProcedureMod3() {
		return primaryInsuredProcedureMod3;
	}

	/**
	 * 
	 * @param primaryInsuredProcedureMod3
	 *            The primary_insured_procedure_mod3
	 */
	@JsonProperty("primary_insured_procedure_mod3")
	public void setPrimaryInsuredProcedureMod3(
			String primaryInsuredProcedureMod3) {
		this.primaryInsuredProcedureMod3 = primaryInsuredProcedureMod3;
	}

	/**
	 * 
	 * @return The primaryInsuredProcedureMod4
	 */
	@JsonProperty("primary_insured_procedure_mod4")
	public String getPrimaryInsuredProcedureMod4() {
		return primaryInsuredProcedureMod4;
	}

	/**
	 * 
	 * @param primaryInsuredProcedureMod4
	 *            The primary_insured_procedure_mod4
	 */
	@JsonProperty("primary_insured_procedure_mod4")
	public void setPrimaryInsuredProcedureMod4(
			String primaryInsuredProcedureMod4) {
		this.primaryInsuredProcedureMod4 = primaryInsuredProcedureMod4;
	}

	/**
	 * 
	 * @return The primaryInsuredDescription
	 */
	@JsonProperty("primary_insured_description")
	public String getPrimaryInsuredDescription() {
		return primaryInsuredDescription;
	}

	/**
	 * 
	 * @param primaryInsuredDescription
	 *            The primary_insured_description
	 */
	@JsonProperty("primary_insured_description")
	public void setPrimaryInsuredDescription(String primaryInsuredDescription) {
		this.primaryInsuredDescription = primaryInsuredDescription;
	}

	/**
	 * 
	 * @return The primaryInsuredInsuranceType
	 */
	@JsonProperty("primary_insured_insurance_type")
	public String getPrimaryInsuredInsuranceType() {
		return primaryInsuredInsuranceType;
	}

	/**
	 * 
	 * @param primaryInsuredInsuranceType
	 *            The primary_insured_insurance_type
	 */
	@JsonProperty("primary_insured_insurance_type")
	public void setPrimaryInsuredInsuranceType(
			String primaryInsuredInsuranceType) {
		this.primaryInsuredInsuranceType = primaryInsuredInsuranceType;
	}

	/**
	 * 
	 * @return The primaryInsuredCoverageLevelCode
	 */
	@JsonProperty("primary_insured_coverage_level_code")
	public String getPrimaryInsuredCoverageLevelCode() {
		return primaryInsuredCoverageLevelCode;
	}

	/**
	 * 
	 * @param primaryInsuredCoverageLevelCode
	 *            The primary_insured_coverage_level_code
	 */
	@JsonProperty("primary_insured_coverage_level_code")
	public void setPrimaryInsuredCoverageLevelCode(
			String primaryInsuredCoverageLevelCode) {
		this.primaryInsuredCoverageLevelCode = primaryInsuredCoverageLevelCode;
	}

	/**
	 * 
	 * @return The primaryInsuredSpendAmountQualifierCode
	 */
	@JsonProperty("primary_insured_spend_amount_qualifier_code")
	public String getPrimaryInsuredSpendAmountQualifierCode() {
		return primaryInsuredSpendAmountQualifierCode;
	}

	/**
	 * 
	 * @param primaryInsuredSpendAmountQualifierCode
	 *            The primary_insured_spend_amount_qualifier_code
	 */
	@JsonProperty("primary_insured_spend_amount_qualifier_code")
	public void setPrimaryInsuredSpendAmountQualifierCode(
			String primaryInsuredSpendAmountQualifierCode) {
		this.primaryInsuredSpendAmountQualifierCode = primaryInsuredSpendAmountQualifierCode;
	}

	/**
	 * 
	 * @return The primaryInsuredSpendMonetaryAmount
	 */
	@JsonProperty("primary_insured_spend_monetary_amount")
	public String getPrimaryInsuredSpendMonetaryAmount() {
		return primaryInsuredSpendMonetaryAmount;
	}

	/**
	 * 
	 * @param primaryInsuredSpendMonetaryAmount
	 *            The primary_insured_spend_monetary_amount
	 */
	@JsonProperty("primary_insured_spend_monetary_amount")
	public void setPrimaryInsuredSpendMonetaryAmount(
			String primaryInsuredSpendMonetaryAmount) {
		this.primaryInsuredSpendMonetaryAmount = primaryInsuredSpendMonetaryAmount;
	}

	/**
	 * 
	 * @return The primaryInsuredListQualifierCode
	 */
	@JsonProperty("primary_insured_list_qualifier_code")
	public String getPrimaryInsuredListQualifierCode() {
		return primaryInsuredListQualifierCode;
	}

	/**
	 * 
	 * @param primaryInsuredListQualifierCode
	 *            The primary_insured_list_qualifier_code
	 */
	@JsonProperty("primary_insured_list_qualifier_code")
	public void setPrimaryInsuredListQualifierCode(
			String primaryInsuredListQualifierCode) {
		this.primaryInsuredListQualifierCode = primaryInsuredListQualifierCode;
	}

	/**
	 * 
	 * @return The primaryInsuredIndustryCode
	 */
	@JsonProperty("primary_insured_industry_code")
	public String getPrimaryInsuredIndustryCode() {
		return primaryInsuredIndustryCode;
	}

	/**
	 * 
	 * @param primaryInsuredIndustryCode
	 *            The primary_insured_industry_code
	 */
	@JsonProperty("primary_insured_industry_code")
	public void setPrimaryInsuredIndustryCode(String primaryInsuredIndustryCode) {
		this.primaryInsuredIndustryCode = primaryInsuredIndustryCode;
	}

	/**
	 * 
	 * @return The primaryInsuredInformationIdentificationQualifier
	 */
	@JsonProperty("primary_insured_information_identification_qualifier")
	public String getPrimaryInsuredInformationIdentificationQualifier() {
		return primaryInsuredInformationIdentificationQualifier;
	}

	/**
	 * 
	 * @param primaryInsuredInformationIdentificationQualifier
	 *            The primary_insured_information_identification_qualifier
	 */
	@JsonProperty("primary_insured_information_identification_qualifier")
	public void setPrimaryInsuredInformationIdentificationQualifier(
			String primaryInsuredInformationIdentificationQualifier) {
		this.primaryInsuredInformationIdentificationQualifier = primaryInsuredInformationIdentificationQualifier;
	}

	/**
	 * 
	 * @return The primaryInsuredInformationIdentification
	 */
	@JsonProperty("primary_insured_information_identification")
	public String getPrimaryInsuredInformationIdentification() {
		return primaryInsuredInformationIdentification;
	}

	/**
	 * 
	 * @param primaryInsuredInformationIdentification
	 *            The primary_insured_information_identification
	 */
	@JsonProperty("primary_insured_information_identification")
	public void setPrimaryInsuredInformationIdentification(
			String primaryInsuredInformationIdentification) {
		this.primaryInsuredInformationIdentification = primaryInsuredInformationIdentification;
	}

	/**
	 * 
	 * @return The primaryInsuredEligibilityDateQualifier
	 */
	@JsonProperty("primary_insured_eligibility_date_qualifier")
	public String getPrimaryInsuredEligibilityDateQualifier() {
		return primaryInsuredEligibilityDateQualifier;
	}

	/**
	 * 
	 * @param primaryInsuredEligibilityDateQualifier
	 *            The primary_insured_eligibility_date_qualifier
	 */
	@JsonProperty("primary_insured_eligibility_date_qualifier")
	public void setPrimaryInsuredEligibilityDateQualifier(
			String primaryInsuredEligibilityDateQualifier) {
		this.primaryInsuredEligibilityDateQualifier = primaryInsuredEligibilityDateQualifier;
	}

	/**
	 * 
	 * @return The primaryInsuredEligibilityDateFormatQualifier
	 */
	@JsonProperty("primary_insured_eligibility_date_format_qualifier")
	public String getPrimaryInsuredEligibilityDateFormatQualifier() {
		return primaryInsuredEligibilityDateFormatQualifier;
	}

	/**
	 * 
	 * @param primaryInsuredEligibilityDateFormatQualifier
	 *            The primary_insured_eligibility_date_format_qualifier
	 */
	@JsonProperty("primary_insured_eligibility_date_format_qualifier")
	public void setPrimaryInsuredEligibilityDateFormatQualifier(
			String primaryInsuredEligibilityDateFormatQualifier) {
		this.primaryInsuredEligibilityDateFormatQualifier = primaryInsuredEligibilityDateFormatQualifier;
	}

	/**
	 * 
	 * @return The primaryInsuredEligibilityDatePeriod
	 */
	@JsonProperty("primary_insured_eligibility_date_period")
	public String getPrimaryInsuredEligibilityDatePeriod() {
		return primaryInsuredEligibilityDatePeriod;
	}

	/**
	 * 
	 * @param primaryInsuredEligibilityDatePeriod
	 *            The primary_insured_eligibility_date_period
	 */
	@JsonProperty("primary_insured_eligibility_date_period")
	public void setPrimaryInsuredEligibilityDatePeriod(
			String primaryInsuredEligibilityDatePeriod) {
		this.primaryInsuredEligibilityDatePeriod = primaryInsuredEligibilityDatePeriod;
	}

	/**
	 * 
	 * @return The dependentEntityIdentifierCode
	 */
	@JsonProperty("dependent_entity_identifier_code")
	public String getDependentEntityIdentifierCode() {
		return dependentEntityIdentifierCode;
	}

	/**
	 * 
	 * @param dependentEntityIdentifierCode
	 *            The dependent_entity_identifier_code
	 */
	@JsonProperty("dependent_entity_identifier_code")
	public void setDependentEntityIdentifierCode(
			String dependentEntityIdentifierCode) {
		this.dependentEntityIdentifierCode = dependentEntityIdentifierCode;
	}

	/**
	 * 
	 * @return The dependentEntityTypeQualifier
	 */
	@JsonProperty("dependent_entity_type_qualifier")
	public String getDependentEntityTypeQualifier() {
		return dependentEntityTypeQualifier;
	}

	/**
	 * 
	 * @param dependentEntityTypeQualifier
	 *            The dependent_entity_type_qualifier
	 */
	@JsonProperty("dependent_entity_type_qualifier")
	public void setDependentEntityTypeQualifier(
			String dependentEntityTypeQualifier) {
		this.dependentEntityTypeQualifier = dependentEntityTypeQualifier;
	}

	/**
	 * 
	 * @return The dependentLastName
	 */
	@JsonProperty("dependent_last_name")
	public String getDependentLastName() {
		return dependentLastName;
	}

	/**
	 * 
	 * @param dependentLastName
	 *            The dependent_last_name
	 */
	@JsonProperty("dependent_last_name")
	public void setDependentLastName(String dependentLastName) {
		this.dependentLastName = dependentLastName;
	}

	/**
	 * 
	 * @return The dependentFirstName
	 */
	@JsonProperty("dependent_first_name")
	public String getDependentFirstName() {
		return dependentFirstName;
	}

	/**
	 * 
	 * @param dependentFirstName
	 *            The dependent_first_name
	 */
	@JsonProperty("dependent_first_name")
	public void setDependentFirstName(String dependentFirstName) {
		this.dependentFirstName = dependentFirstName;
	}

	/**
	 * 
	 * @return The dependentMiddleInitial
	 */
	@JsonProperty("dependent_middle_initial")
	public String getDependentMiddleInitial() {
		return dependentMiddleInitial;
	}

	/**
	 * 
	 * @param dependentMiddleInitial
	 *            The dependent_middle_initial
	 */
	@JsonProperty("dependent_middle_initial")
	public void setDependentMiddleInitial(String dependentMiddleInitial) {
		this.dependentMiddleInitial = dependentMiddleInitial;
	}

	/**
	 * 
	 * @return The dependentSuffix
	 */
	@JsonProperty("dependent_suffix")
	public String getDependentSuffix() {
		return dependentSuffix;
	}

	/**
	 * 
	 * @param dependentSuffix
	 *            The dependent_suffix
	 */
	@JsonProperty("dependent_suffix")
	public void setDependentSuffix(String dependentSuffix) {
		this.dependentSuffix = dependentSuffix;
	}

	/**
	 * 
	 * @return The dependentAddressLine1
	 */
	@JsonProperty("dependent_address_line1")
	public String getDependentAddressLine1() {
		return dependentAddressLine1;
	}

	/**
	 * 
	 * @param dependentAddressLine1
	 *            The dependent_address_line1
	 */
	@JsonProperty("dependent_address_line1")
	public void setDependentAddressLine1(String dependentAddressLine1) {
		this.dependentAddressLine1 = dependentAddressLine1;
	}

	/**
	 * 
	 * @return The dependentAddressLine2
	 */
	@JsonProperty("dependent_address_line2")
	public String getDependentAddressLine2() {
		return dependentAddressLine2;
	}

	/**
	 * 
	 * @param dependentAddressLine2
	 *            The dependent_address_line2
	 */
	@JsonProperty("dependent_address_line2")
	public void setDependentAddressLine2(String dependentAddressLine2) {
		this.dependentAddressLine2 = dependentAddressLine2;
	}

	/**
	 * 
	 * @return The dependentAddressCity
	 */
	@JsonProperty("dependent_address_city")
	public String getDependentAddressCity() {
		return dependentAddressCity;
	}

	/**
	 * 
	 * @param dependentAddressCity
	 *            The dependent_address_city
	 */
	@JsonProperty("dependent_address_city")
	public void setDependentAddressCity(String dependentAddressCity) {
		this.dependentAddressCity = dependentAddressCity;
	}

	/**
	 * 
	 * @return The dependentAddressState
	 */
	@JsonProperty("dependent_address_state")
	public String getDependentAddressState() {
		return dependentAddressState;
	}

	/**
	 * 
	 * @param dependentAddressState
	 *            The dependent_address_state
	 */
	@JsonProperty("dependent_address_state")
	public void setDependentAddressState(String dependentAddressState) {
		this.dependentAddressState = dependentAddressState;
	}

	/**
	 * 
	 * @return The dependentAddressZipCode
	 */
	@JsonProperty("dependent_address_zip_code")
	public String getDependentAddressZipCode() {
		return dependentAddressZipCode;
	}

	/**
	 * 
	 * @param dependentAddressZipCode
	 *            The dependent_address_zip_code
	 */
	@JsonProperty("dependent_address_zip_code")
	public void setDependentAddressZipCode(String dependentAddressZipCode) {
		this.dependentAddressZipCode = dependentAddressZipCode;
	}

	/**
	 * 
	 * @return The dependentAddressCountry
	 */
	@JsonProperty("dependent_address_country")
	public String getDependentAddressCountry() {
		return dependentAddressCountry;
	}

	/**
	 * 
	 * @param dependentAddressCountry
	 *            The dependent_address_country
	 */
	@JsonProperty("dependent_address_country")
	public void setDependentAddressCountry(String dependentAddressCountry) {
		this.dependentAddressCountry = dependentAddressCountry;
	}

	/**
	 * 
	 * @return The dependentIdentificationQualifier
	 */
	@JsonProperty("dependent_identification_qualifier")
	public String getDependentIdentificationQualifier() {
		return dependentIdentificationQualifier;
	}

	/**
	 * 
	 * @param dependentIdentificationQualifier
	 *            The dependent_identification_qualifier
	 */
	@JsonProperty("dependent_identification_qualifier")
	public void setDependentIdentificationQualifier(
			String dependentIdentificationQualifier) {
		this.dependentIdentificationQualifier = dependentIdentificationQualifier;
	}

	/**
	 * 
	 * @return The dependentIdentification
	 */
	@JsonProperty("dependent_identification")
	public String getDependentIdentification() {
		return dependentIdentification;
	}

	/**
	 * 
	 * @param dependentIdentification
	 *            The dependent_identification
	 */
	@JsonProperty("dependent_identification")
	public void setDependentIdentification(String dependentIdentification) {
		this.dependentIdentification = dependentIdentification;
	}

	/**
	 * 
	 * @return The dependentProviderCode
	 */
	@JsonProperty("dependent_provider_code")
	public String getDependentProviderCode() {
		return dependentProviderCode;
	}

	/**
	 * 
	 * @param dependentProviderCode
	 *            The dependent_provider_code
	 */
	@JsonProperty("dependent_provider_code")
	public void setDependentProviderCode(String dependentProviderCode) {
		this.dependentProviderCode = dependentProviderCode;
	}

	/**
	 * 
	 * @return The dependentProviderIdentificationQualifier
	 */
	@JsonProperty("dependent_provider_identification_qualifier")
	public String getDependentProviderIdentificationQualifier() {
		return dependentProviderIdentificationQualifier;
	}

	/**
	 * 
	 * @param dependentProviderIdentificationQualifier
	 *            The dependent_provider_identification_qualifier
	 */
	@JsonProperty("dependent_provider_identification_qualifier")
	public void setDependentProviderIdentificationQualifier(
			String dependentProviderIdentificationQualifier) {
		this.dependentProviderIdentificationQualifier = dependentProviderIdentificationQualifier;
	}

	/**
	 * 
	 * @return The dependentProviderIdentification
	 */
	@JsonProperty("dependent_provider_identification")
	public String getDependentProviderIdentification() {
		return dependentProviderIdentification;
	}

	/**
	 * 
	 * @param dependentProviderIdentification
	 *            The dependent_provider_identification
	 */
	@JsonProperty("dependent_provider_identification")
	public void setDependentProviderIdentification(
			String dependentProviderIdentification) {
		this.dependentProviderIdentification = dependentProviderIdentification;
	}

	/**
	 * 
	 * @return The dependentDemographicsDateQualifier
	 */
	@JsonProperty("dependent_demographics_date_qualifier")
	public String getDependentDemographicsDateQualifier() {
		return dependentDemographicsDateQualifier;
	}

	/**
	 * 
	 * @param dependentDemographicsDateQualifier
	 *            The dependent_demographics_date_qualifier
	 */
	@JsonProperty("dependent_demographics_date_qualifier")
	public void setDependentDemographicsDateQualifier(
			String dependentDemographicsDateQualifier) {
		this.dependentDemographicsDateQualifier = dependentDemographicsDateQualifier;
	}

	/**
	 * 
	 * @return The dependentDemographicsDateOfBirth
	 */
	@JsonProperty("dependent_demographics_date_of_birth")
	public String getDependentDemographicsDateOfBirth() {
		return dependentDemographicsDateOfBirth;
	}

	/**
	 * 
	 * @param dependentDemographicsDateOfBirth
	 *            The dependent_demographics_date_of_birth
	 */
	@JsonProperty("dependent_demographics_date_of_birth")
	public void setDependentDemographicsDateOfBirth(
			String dependentDemographicsDateOfBirth) {
		this.dependentDemographicsDateOfBirth = dependentDemographicsDateOfBirth;
	}

	/**
	 * 
	 * @return The dependentDemographicsGenderCode
	 */
	@JsonProperty("dependent_demographics_gender_code")
	public String getDependentDemographicsGenderCode() {
		return dependentDemographicsGenderCode;
	}

	/**
	 * 
	 * @param dependentDemographicsGenderCode
	 *            The dependent_demographics_gender_code
	 */
	@JsonProperty("dependent_demographics_gender_code")
	public void setDependentDemographicsGenderCode(
			String dependentDemographicsGenderCode) {
		this.dependentDemographicsGenderCode = dependentDemographicsGenderCode;
	}

	/**
	 * 
	 * @return The dependentInsuredIndicator
	 */
	@JsonProperty("dependent_insured_indicator")
	public String getDependentInsuredIndicator() {
		return dependentInsuredIndicator;
	}

	/**
	 * 
	 * @param dependentInsuredIndicator
	 *            The dependent_insured_indicator
	 */
	@JsonProperty("dependent_insured_indicator")
	public void setDependentInsuredIndicator(String dependentInsuredIndicator) {
		this.dependentInsuredIndicator = dependentInsuredIndicator;
	}

	/**
	 * 
	 * @return The dependentIndividualRelationshipCode
	 */
	/*
	 * @JsonProperty("dependent_individual_relationship_code") public String
	 * getDependentIndividualRelationshipCode() { return
	 * dependentIndividualRelationshipCode; }
	 */

	/**
	 * 
	 * @param dependentIndividualRelationshipCode
	 *            The dependent_individual_relationship_code
	 */
	/*
	 * @JsonProperty("dependent_individual_relationship_code") public void
	 * setDependentIndividualRelationshipCode(String
	 * dependentIndividualRelationshipCode) {
	 * this.dependentIndividualRelationshipCode =
	 * dependentIndividualRelationshipCode; }
	 */

	/**
	 * 
	 * @return The dependentBirthSequenceNumber
	 */
	@JsonProperty("dependent_birth_sequence_number")
	public String getDependentBirthSequenceNumber() {
		return dependentBirthSequenceNumber;
	}

	/**
	 * 
	 * @param dependentBirthSequenceNumber
	 *            The dependent_birth_sequence_number
	 */
	@JsonProperty("dependent_birth_sequence_number")
	public void setDependentBirthSequenceNumber(
			String dependentBirthSequenceNumber) {
		this.dependentBirthSequenceNumber = dependentBirthSequenceNumber;
	}

	/**
	 * 
	 * @return The dependentDateQualifier
	 */
	@JsonProperty("dependent_date_qualifier")
	public String getDependentDateQualifier() {
		return dependentDateQualifier;
	}

	/**
	 * 
	 * @param dependentDateQualifier
	 *            The dependent_date_qualifier
	 */
	@JsonProperty("dependent_date_qualifier")
	public void setDependentDateQualifier(String dependentDateQualifier) {
		this.dependentDateQualifier = dependentDateQualifier;
	}

	/**
	 * 
	 * @return The dependentDateFormatQualifier
	 */
	@JsonProperty("dependent_date_format_qualifier")
	public String getDependentDateFormatQualifier() {
		return dependentDateFormatQualifier;
	}

	/**
	 * 
	 * @param dependentDateFormatQualifier
	 *            The dependent_date_format_qualifier
	 */
	@JsonProperty("dependent_date_format_qualifier")
	public void setDependentDateFormatQualifier(
			String dependentDateFormatQualifier) {
		this.dependentDateFormatQualifier = dependentDateFormatQualifier;
	}

	/**
	 * 
	 * @return The dependentDatePeriod
	 */
	@JsonProperty("dependent_date_period")
	public String getDependentDatePeriod() {
		return dependentDatePeriod;
	}

	/**
	 * 
	 * @param dependentDatePeriod
	 *            The dependent_date_period
	 */
	@JsonProperty("dependent_date_period")
	public void setDependentDatePeriod(String dependentDatePeriod) {
		this.dependentDatePeriod = dependentDatePeriod;
	}

	/**
	 * 
	 * @return The dependentServiceTypeCode
	 */
	@JsonProperty("dependent_service_type_code")
	public String getDependentServiceTypeCode() {
		return dependentServiceTypeCode;
	}

	/**
	 * 
	 * @param dependentServiceTypeCode
	 *            The dependent_service_type_code
	 */
	@JsonProperty("dependent_service_type_code")
	public void setDependentServiceTypeCode(String dependentServiceTypeCode) {
		this.dependentServiceTypeCode = dependentServiceTypeCode;
	}

	/**
	 * 
	 * @return The dependentServiceIdentificationQualifier
	 */
	@JsonProperty("dependent_service_identification_qualifier")
	public String getDependentServiceIdentificationQualifier() {
		return dependentServiceIdentificationQualifier;
	}

	/**
	 * 
	 * @param dependentServiceIdentificationQualifier
	 *            The dependent_service_identification_qualifier
	 */
	@JsonProperty("dependent_service_identification_qualifier")
	public void setDependentServiceIdentificationQualifier(
			String dependentServiceIdentificationQualifier) {
		this.dependentServiceIdentificationQualifier = dependentServiceIdentificationQualifier;
	}

	/**
	 * 
	 * @return The dependentProcedureCode
	 */
	@JsonProperty("dependent_procedure_code")
	public String getDependentProcedureCode() {
		return dependentProcedureCode;
	}

	/**
	 * 
	 * @param dependentProcedureCode
	 *            The dependent_procedure_code
	 */
	@JsonProperty("dependent_procedure_code")
	public void setDependentProcedureCode(String dependentProcedureCode) {
		this.dependentProcedureCode = dependentProcedureCode;
	}

	/**
	 * 
	 * @return The dependentProcedureMod1
	 */
	@JsonProperty("dependent_procedure_mod1")
	public String getDependentProcedureMod1() {
		return dependentProcedureMod1;
	}

	/**
	 * 
	 * @param dependentProcedureMod1
	 *            The dependent_procedure_mod1
	 */
	@JsonProperty("dependent_procedure_mod1")
	public void setDependentProcedureMod1(String dependentProcedureMod1) {
		this.dependentProcedureMod1 = dependentProcedureMod1;
	}

	/**
	 * 
	 * @return The dependentProcedureMod2
	 */
	@JsonProperty("dependent_procedure_mod2")
	public String getDependentProcedureMod2() {
		return dependentProcedureMod2;
	}

	/**
	 * 
	 * @param dependentProcedureMod2
	 *            The dependent_procedure_mod2
	 */
	@JsonProperty("dependent_procedure_mod2")
	public void setDependentProcedureMod2(String dependentProcedureMod2) {
		this.dependentProcedureMod2 = dependentProcedureMod2;
	}

	/**
	 * 
	 * @return The dependentProcedureMod3
	 */
	@JsonProperty("dependent_procedure_mod3")
	public String getDependentProcedureMod3() {
		return dependentProcedureMod3;
	}

	/**
	 * 
	 * @param dependentProcedureMod3
	 *            The dependent_procedure_mod3
	 */
	@JsonProperty("dependent_procedure_mod3")
	public void setDependentProcedureMod3(String dependentProcedureMod3) {
		this.dependentProcedureMod3 = dependentProcedureMod3;
	}

	/**
	 * 
	 * @return The dependentProcedureMod4
	 */
	@JsonProperty("dependent_procedure_mod4")
	public String getDependentProcedureMod4() {
		return dependentProcedureMod4;
	}

	/**
	 * 
	 * @param dependentProcedureMod4
	 *            The dependent_procedure_mod4
	 */
	@JsonProperty("dependent_procedure_mod4")
	public void setDependentProcedureMod4(String dependentProcedureMod4) {
		this.dependentProcedureMod4 = dependentProcedureMod4;
	}

	/**
	 * 
	 * @return The dependentDescription
	 */
	@JsonProperty("dependent_description")
	public String getDependentDescription() {
		return dependentDescription;
	}

	/**
	 * 
	 * @param dependentDescription
	 *            The dependent_description
	 */
	@JsonProperty("dependent_description")
	public void setDependentDescription(String dependentDescription) {
		this.dependentDescription = dependentDescription;
	}

	/**
	 * 
	 * @return The dependentInsuranceType
	 */
	@JsonProperty("dependent_insurance_type")
	public String getDependentInsuranceType() {
		return dependentInsuranceType;
	}

	/**
	 * 
	 * @param dependentInsuranceType
	 *            The dependent_insurance_type
	 */
	@JsonProperty("dependent_insurance_type")
	public void setDependentInsuranceType(String dependentInsuranceType) {
		this.dependentInsuranceType = dependentInsuranceType;
	}

	/**
	 * 
	 * @return The dependentCoverageLevelCode
	 */
	@JsonProperty("dependent_coverage_level_code")
	public String getDependentCoverageLevelCode() {
		return dependentCoverageLevelCode;
	}

	/**
	 * 
	 * @param dependentCoverageLevelCode
	 *            The dependent_coverage_level_code
	 */
	@JsonProperty("dependent_coverage_level_code")
	public void setDependentCoverageLevelCode(String dependentCoverageLevelCode) {
		this.dependentCoverageLevelCode = dependentCoverageLevelCode;
	}

	/**
	 * 
	 * @return The dependentListQualifierCode
	 */
	@JsonProperty("dependent_list_qualifier_code")
	public String getDependentListQualifierCode() {
		return dependentListQualifierCode;
	}

	/**
	 * 
	 * @param dependentListQualifierCode
	 *            The dependent_list_qualifier_code
	 */
	@JsonProperty("dependent_list_qualifier_code")
	public void setDependentListQualifierCode(String dependentListQualifierCode) {
		this.dependentListQualifierCode = dependentListQualifierCode;
	}

	/**
	 * 
	 * @return The dependentIndustryCode
	 */
	@JsonProperty("dependent_industry_code")
	public String getDependentIndustryCode() {
		return dependentIndustryCode;
	}

	/**
	 * 
	 * @param dependentIndustryCode
	 *            The dependent_industry_code
	 */
	@JsonProperty("dependent_industry_code")
	public void setDependentIndustryCode(String dependentIndustryCode) {
		this.dependentIndustryCode = dependentIndustryCode;
	}

	/**
	 * 
	 * @return The dependentInformationIdentificationQualifier
	 */
	@JsonProperty("dependent_information_identification_qualifier")
	public String getDependentInformationIdentificationQualifier() {
		return dependentInformationIdentificationQualifier;
	}

	/**
	 * 
	 * @param dependentInformationIdentificationQualifier
	 *            The dependent_information_identification_qualifier
	 */
	@JsonProperty("dependent_information_identification_qualifier")
	public void setDependentInformationIdentificationQualifier(
			String dependentInformationIdentificationQualifier) {
		this.dependentInformationIdentificationQualifier = dependentInformationIdentificationQualifier;
	}

	/**
	 * 
	 * @return The dependentInformationIdentification
	 */
	@JsonProperty("dependent_information_identification")
	public String getDependentInformationIdentification() {
		return dependentInformationIdentification;
	}

	/**
	 * 
	 * @param dependentInformationIdentification
	 *            The dependent_information_identification
	 */
	@JsonProperty("dependent_information_identification")
	public void setDependentInformationIdentification(
			String dependentInformationIdentification) {
		this.dependentInformationIdentification = dependentInformationIdentification;
	}

	/**
	 * 
	 * @return The dependentEligibilityDateQualifier
	 */
	@JsonProperty("dependent_eligibility_date_qualifier")
	public String getDependentEligibilityDateQualifier() {
		return dependentEligibilityDateQualifier;
	}

	/**
	 * 
	 * @param dependentEligibilityDateQualifier
	 *            The dependent_eligibility_date_qualifier
	 */
	@JsonProperty("dependent_eligibility_date_qualifier")
	public void setDependentEligibilityDateQualifier(
			String dependentEligibilityDateQualifier) {
		this.dependentEligibilityDateQualifier = dependentEligibilityDateQualifier;
	}

	/**
	 * 
	 * @return The dependentEligibilityDateFormatQualifier
	 */
	@JsonProperty("dependent_eligibility_date_format_qualifier")
	public String getDependentEligibilityDateFormatQualifier() {
		return dependentEligibilityDateFormatQualifier;
	}

	/**
	 * 
	 * @param dependentEligibilityDateFormatQualifier
	 *            The dependent_eligibility_date_format_qualifier
	 */
	@JsonProperty("dependent_eligibility_date_format_qualifier")
	public void setDependentEligibilityDateFormatQualifier(
			String dependentEligibilityDateFormatQualifier) {
		this.dependentEligibilityDateFormatQualifier = dependentEligibilityDateFormatQualifier;
	}

	/**
	 * 
	 * @return The dependentEligibilityDatePeriod
	 */
	@JsonProperty("dependent_eligibility_date_period")
	public String getDependentEligibilityDatePeriod() {
		return dependentEligibilityDatePeriod;
	}

	/**
	 * 
	 * @param dependentEligibilityDatePeriod
	 *            The dependent_eligibility_date_period
	 */
	@JsonProperty("dependent_eligibility_date_period")
	public void setDependentEligibilityDatePeriod(
			String dependentEligibilityDatePeriod) {
		this.dependentEligibilityDatePeriod = dependentEligibilityDatePeriod;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

	@JsonProperty("relationship_code")
	public String getRelationShipCode() {
		return relationShipCode;
	}

	@JsonProperty("relationship_code")
	public void setRelationShipCode(String relationShipCode) {
		this.relationShipCode = relationShipCode;
	}

	public XsElement_(String jsonString, String tracerNumber)
			throws InvalidRequestDataException {
		super();
		int i = 0;
		jsonString = jsonString + ";~";
		String request[] = jsonString.split(";");
		boolean dependentCase = false;
		int relationShip_Code = 0;
		// systemErrorCode = request[i++];
		// systemErrorGenericDescription = request[i++];
		// *responseMessage = request[i++];
		deliveryMethod = request[i++];
		if (deliveryMethod == null || deliveryMethod.trim().isEmpty()) {
			throw new InvalidRequestDataException(
					IConstants.DATA_MISSING.concat(IConstants.DELIVERY_METHOD));
		}
		eligibilityTracerCode = request[i++];
		if (eligibilityTracerCode == null
				|| eligibilityTracerCode.trim().isEmpty()) {
			throw new InvalidRequestDataException(
					IConstants.DATA_MISSING
							.concat(IConstants.ELIGIBILITY_TRACER_CODE));
		}
		relationShipCode = request[i++];
		if (relationShipCode == null || relationShipCode.trim().isEmpty()) {
			throw new InvalidRequestDataException(
					IConstants.DATA_MISSING
							.concat(IConstants.RELATIONSHIP_CODE));
		}
		try {
			relationShip_Code = Integer.valueOf(relationShipCode);
		} catch (NumberFormatException nfe) {
			throw new InvalidRequestDataException(
					IConstants.DATA_MISSING
							.concat(IConstants.RELATIONSHIP_CODE));
		}
		eligibilityTracerNumber = request[i++];
		if (tracerNumber != null) {
			eligibilityTracerNumber = tracerNumber;
		}
		if (eligibilityTracerNumber == null
				|| eligibilityTracerNumber.trim().isEmpty()) {
			throw new InvalidRequestDataException(
					IConstants.DATA_MISSING
							.concat(IConstants.ELIGIBILITY_TRACER_NUMBER));
		}
		sourceEntityIdentifierCode = request[i++];
		if (sourceEntityIdentifierCode == null
				|| sourceEntityIdentifierCode.trim().isEmpty()) {
			throw new InvalidRequestDataException(
					IConstants.DATA_MISSING
							.concat(IConstants.SOURCE_ENTITY_IDENTIFIER_CODE));
		}
		sourceEntityTypeQualifier = request[i++];
		if (sourceEntityTypeQualifier == null
				|| sourceEntityTypeQualifier.trim().isEmpty()) {
			throw new InvalidRequestDataException(
					IConstants.DATA_MISSING
							.concat(IConstants.SOURCE_ENTITY_TYPE_QUALIFIER));
		}
		sourceNameLast = request[i++];
		if (sourceNameLast == null || sourceNameLast.trim().isEmpty()) {
			throw new InvalidRequestDataException(
					IConstants.DATA_MISSING.concat(IConstants.SOURCE_NAME_LAST));
		}
		/*
		 * sourceNameFirst = request[i++]; sourceNameMiddle = request[i++];
		 * sourceNameSuffix = request[i++];
		 */
		sourceIdentificationCodeQualifier = request[i++];
		if (sourceIdentificationCodeQualifier == null
				|| sourceIdentificationCodeQualifier.trim().isEmpty()) {
			throw new InvalidRequestDataException(
					IConstants.DATA_MISSING
							.concat(IConstants.SOURCE_IDENTIFICATION_CODE_QUALIFIER));
		}
		sourceIdentificationCode = request[i++];
		if (sourceIdentificationCode == null
				|| sourceIdentificationCode.trim().isEmpty()) {
			throw new InvalidRequestDataException(
					IConstants.DATA_MISSING
							.concat(IConstants.SOURCE_IDENTIFICATION_CODE));
		}
		receiverEntityIdentifierCode = request[i++];
		if (receiverEntityIdentifierCode == null
				|| receiverEntityIdentifierCode.trim().isEmpty()) {
			throw new InvalidRequestDataException(
					IConstants.DATA_MISSING
							.concat(IConstants.RECEIVER_ENTITY_IDENTIFIER_CODE));
		}
		receiverEntityTypeQualifier = request[i++];
		if (receiverEntityTypeQualifier == null
				|| receiverEntityTypeQualifier.trim().isEmpty()) {
			throw new InvalidRequestDataException(
					IConstants.DATA_MISSING
							.concat(IConstants.RECEIVER_ENTITY_TYPE_QUALIFIER));
		}
		receiverLastName = request[i++];
		if (receiverLastName == null || receiverLastName.trim().isEmpty()) {
			throw new InvalidRequestDataException(
					IConstants.DATA_MISSING
							.concat(IConstants.RECEIVER_LAST_NAME));
		}
		receiverFirstName = request[i++];
		/*
		 * receiverMiddleName = request[i++]; receiverSuffix = request[i++];
		 */
		receiverIdentifierCodeQualifier = request[i++];
		if (receiverIdentifierCodeQualifier == null
				|| receiverIdentifierCodeQualifier.trim().isEmpty()) {
			throw new InvalidRequestDataException(
					IConstants.DATA_MISSING
							.concat(IConstants.RECEIVER_IDENTIFIER_CODE_QUALIFIER));
		}
		receiverIdentifierCode = request[i++];
		/*
		 * receiverAddressLine1 = request[i++]; receiverAddressLine2 =
		 * request[i++]; receiverAddressCity = request[i++];
		 * receiverAddressState = request[i++]; receiverAddressZipCode =
		 * request[i++]; receiverAddressCountry = request[i++];
		 * receiverIdentificationQualifier = request[i++];
		 * receiverIdentification = request[i++]; receiverDescription =
		 * request[i++]; receiverFunctionCode = request[i++]; receiverName =
		 * request[i++]; receiverCommNoQualifier1 = request[i++];
		 * receiverCommNo1 = request[i++]; receiverCommNoQualifier2 =
		 * request[i++]; receiverCommNo2 = request[i++];
		 * receiverCommNoQualifier3 = request[i++]; receiverCommNo3 =
		 * request[i++]; receiverProviderCode = request[i++];
		 * receiverProviderIdentificationQualifier = request[i++];
		 * receiverProviderIdentification = request[i++];
		 */
		eligibilityEntityIdentifier = request[i++];
		if (eligibilityEntityIdentifier == null
				|| eligibilityEntityIdentifier.trim().isEmpty()) {
			throw new InvalidRequestDataException(
					IConstants.DATA_MISSING
							.concat(IConstants.ELIGIBILITY_ENTITY_IDENTIFIER));
		}
		// *eligibilityEntityAdditionalIdentifier = request[i++];
		primaryInsuredEntityIdentifierCode = request[i++];
		if (primaryInsuredEntityIdentifierCode == null
				|| primaryInsuredEntityIdentifierCode.trim().isEmpty()) {
			throw new InvalidRequestDataException(
					IConstants.DATA_MISSING
							.concat(IConstants.PRIMARY_INSURED_ENTITY_IDENTIFIER_CODE));
		}
		primaryInsuredEntityTypeQualifier = request[i++];
		if (primaryInsuredEntityTypeQualifier == null
				|| primaryInsuredEntityTypeQualifier.trim().isEmpty()) {
			throw new InvalidRequestDataException(
					IConstants.DATA_MISSING
							.concat(IConstants.PRIMARY_INSURED_ENTITY_TYPE_QUALIFIER));
		}
		primaryInsuredLastName = request[i++];
		if (primaryInsuredLastName == null
				|| primaryInsuredLastName.trim().isEmpty()) {
			throw new InvalidRequestDataException(
					IConstants.DATA_MISSING
							.concat(IConstants.PRIMARY_INSURED_LAST_NAME));
		}
		primaryInsuredFirstName = request[i++];
		if (primaryInsuredFirstName == null
				|| primaryInsuredFirstName.trim().isEmpty()) {
			throw new InvalidRequestDataException(
					IConstants.DATA_MISSING
							.concat(IConstants.PRIMARY_INSURED_FIRST_NAME));
		}
		/*
		 * primaryInsuredMiddleInitial = request[i++]; primaryInsuredSuffix =
		 * request[i++];
		 */
		primaryInsuredIdentifierCodeQualifier = request[i++];
		if (primaryInsuredIdentifierCodeQualifier == null
				|| primaryInsuredIdentifierCodeQualifier.trim().isEmpty()) {
			throw new InvalidRequestDataException(
					IConstants.DATA_MISSING
							.concat(IConstants.PRIMARY_INSURED_IDENTIFIER_CODE_QUALIFIER));
		}
		primaryInsuredIdentifierCode = request[i++];
		if (primaryInsuredIdentifierCode == null
				|| primaryInsuredIdentifierCode.trim().isEmpty()) {
			throw new InvalidRequestDataException(
					IConstants.DATA_MISSING
							.concat(IConstants.PRIMARY_INSURED_IDENTIFIER_CODE));
		}
		/*
		 * primaryInsuredAddressLine1 = request[i++]; primaryInsuredAddressLine2
		 * = request[i++]; primaryInsuredAddressCity = request[i++];
		 * primaryInsuredAddressState = request[i++];
		 * primaryInsuredAddressZipCode = request[i++];
		 * primaryInsuredAddressCountry = request[i++];
		 * primaryInsuredIdentificationQualifier = request[i++];
		 * primaryInsuredIdentification = request[i++];
		 * primaryInsuredProviderCode = request[i++];
		 * primaryInsuredProviderIdentificationQualifier = request[i++];
		 * primaryInsuredProviderIdentification = request[i++];
		 */
		primaryInsuredDemographicsDateQualifier = request[i++];
		if (primaryInsuredDemographicsDateQualifier == null
				|| primaryInsuredDemographicsDateQualifier.trim().isEmpty()) {
			throw new InvalidRequestDataException(
					IConstants.DATA_MISSING
							.concat(IConstants.PRIMARY_INSURED_DEMOGRAPHICS_DATE_QUALIFIER));
		}
		primaryInsuredDemographicsDateOfBirth = request[i++];
		if (primaryInsuredDemographicsDateOfBirth == null
				|| primaryInsuredDemographicsDateOfBirth.trim().isEmpty()) {
			throw new InvalidRequestDataException(
					IConstants.DATA_MISSING
							.concat(IConstants.PRIMARY_INSURED_DEMOGRAPHICS_DATE_OF_BIRTH));
		}
		primaryInsuredDemographicsGenderCode = request[i++];
		// *primaryInsuredIndicator = request[i++];
		// primaryinsuredrelationshipcode = request[i++];
		// *primaryInsuredBirthSequenceNumber = request[i++];
		primaryInsuredDateQualifier = request[i++];
		if (primaryInsuredDateQualifier == null
				|| primaryInsuredDateQualifier.trim().isEmpty()) {
			throw new InvalidRequestDataException(
					IConstants.DATA_MISSING
							.concat(IConstants.PRIMARY_INSURED_DATE_QUALIFIER));
		}
		primaryInsuredDateFormatQualifier = request[i++];
		if (primaryInsuredDateFormatQualifier == null
				|| primaryInsuredDateFormatQualifier.trim().isEmpty()) {
			throw new InvalidRequestDataException(
					IConstants.DATA_MISSING
							.concat(IConstants.PRIMARY_INSURED_DATE_FORMAT_QUALIFIER));
		}
		primaryInsuredDatePeriod = request[i++];
		if (primaryInsuredDatePeriod == null
				|| primaryInsuredDatePeriod.trim().isEmpty()) {
			throw new InvalidRequestDataException(
					IConstants.DATA_MISSING
							.concat(IConstants.PRIMARY_INSURED_DATE_PERIOD));
		}
		primaryInsuredServiceTypeCode = request[i++];
		if (primaryInsuredServiceTypeCode == null
				|| primaryInsuredServiceTypeCode.trim().isEmpty()) {
			throw new InvalidRequestDataException(
					IConstants.DATA_MISSING
							.concat(IConstants.PRIMARY_INSURED_SERVICE_TYPE_CODE));
		}
		primaryInsuredServiceIdentificationQualifier = request[i++];
		primaryInsuredProcedureCode = request[i++];
		primaryInsuredProcedureMod1 = request[i++];
		primaryInsuredProcedureMod2 = request[i++];
		primaryInsuredProcedureMod3 = request[i++];
		primaryInsuredProcedureMod4 = request[i++];
		primaryInsuredDescription = request[i++];
		primaryInsuredInsuranceType = request[i++];
		primaryInsuredCoverageLevelCode = request[i++];
		primaryInsuredSpendAmountQualifierCode = request[i++];
		primaryInsuredSpendMonetaryAmount = request[i++];
		primaryInsuredListQualifierCode = request[i++];
		primaryInsuredIndustryCode = request[i++];
		primaryInsuredInformationIdentificationQualifier = request[i++];
		primaryInsuredInformationIdentification = request[i++];
		primaryInsuredEligibilityDateQualifier = request[i++];
		primaryInsuredEligibilityDateFormatQualifier = request[i++];
		primaryInsuredEligibilityDatePeriod = request[i++];

		// Dependent data
		if (relationShip_Code != IConstants.SELF) {
			dependentCase = true;
		}
		dependentEntityIdentifierCode = request[i++];
		if (dependentCase
				&& (dependentEntityIdentifierCode == null || dependentEntityIdentifierCode
						.trim().isEmpty())) {
			throw new InvalidRequestDataException(
					IConstants.DATA_MISSING
							.concat(IConstants.DEPENDENT_ENTITY_IDENTIFIER_CODE));
		}
		dependentEntityTypeQualifier = request[i++];
		if (dependentCase
				&& (dependentEntityTypeQualifier == null || dependentEntityTypeQualifier
						.trim().isEmpty())) {
			throw new InvalidRequestDataException(
					IConstants.DATA_MISSING
							.concat(IConstants.DEPENDENT_ENTITY_TYPE_QUALIFIER));
		}
		dependentLastName = request[i++];
		dependentFirstName = request[i++];
		dependentMiddleInitial = request[i++];
		dependentSuffix = request[i++];
		dependentAddressLine1 = request[i++];
		dependentAddressLine2 = request[i++];
		dependentAddressCity = request[i++];
		dependentAddressState = request[i++];
		dependentAddressZipCode = request[i++];
		dependentAddressCountry = request[i++];
		dependentIdentificationQualifier = request[i++];
		dependentIdentification = request[i++];
		dependentProviderCode = request[i++];
		dependentProviderIdentificationQualifier = request[i++];
		dependentProviderIdentification = request[i++];
		dependentDemographicsDateQualifier = request[i++];
		if (dependentCase
				&& (dependentDemographicsDateQualifier == null || dependentDemographicsDateQualifier
						.trim().isEmpty())) {
			throw new InvalidRequestDataException(
					IConstants.DATA_MISSING
							.concat(IConstants.DEPENDENT_DEMOGRAPHICS_DATE_QUALIFIER));
		}
		dependentDemographicsDateOfBirth = request[i++];
		if (dependentCase
				&& (dependentDemographicsDateOfBirth == null || dependentDemographicsDateOfBirth
						.trim().isEmpty())) {
			throw new InvalidRequestDataException(
					IConstants.DATA_MISSING
							.concat(IConstants.DEPENDENT_DEMOGRAPHICS_DATE_OF_BIRTH));
		}
		dependentDemographicsGenderCode = request[i++];
		dependentInsuredIndicator = request[i++];
		// dependentindividualrelationshipcode = request[i++];
		dependentBirthSequenceNumber = request[i++];
		dependentDateQualifier = request[i++];
		if (dependentCase
				&& (dependentDateQualifier == null || dependentDateQualifier
						.trim().isEmpty())) {
			throw new InvalidRequestDataException(
					IConstants.DATA_MISSING
							.concat(IConstants.DEPENDENT_DATE_QUALIFIER));
		}
		dependentDateFormatQualifier = request[i++];
		if (dependentCase
				&& (dependentDateFormatQualifier == null || dependentDateFormatQualifier
						.trim().isEmpty())) {
			throw new InvalidRequestDataException(
					IConstants.DATA_MISSING
							.concat(IConstants.DEPENDENT_DATE_FORMAT_QUALIFIER));
		}
		dependentDatePeriod = request[i++];
		if (dependentCase
				&& (dependentDatePeriod == null || dependentDatePeriod.trim()
						.isEmpty())) {
			throw new InvalidRequestDataException(
					IConstants.DATA_MISSING
							.concat(IConstants.DEPENDENT_DATE_PERIOD));
		}
		dependentServiceTypeCode = request[i++];
		if (dependentCase
				&& (dependentServiceTypeCode == null || dependentServiceTypeCode
						.trim().isEmpty())) {
			throw new InvalidRequestDataException(
					IConstants.DATA_MISSING
							.concat(IConstants.DEPENDENT_SERVICE_TYPE_CODE));
		}
		dependentServiceIdentificationQualifier = request[i++];
		dependentProcedureCode = request[i++];
		dependentProcedureMod1 = request[i++];
		dependentProcedureMod2 = request[i++];
		dependentProcedureMod3 = request[i++];
		dependentProcedureMod4 = request[i++];
		dependentDescription = request[i++];
		dependentInsuranceType = request[i++];
		dependentCoverageLevelCode = request[i++];
		dependentListQualifierCode = request[i++];
		dependentIndustryCode = request[i++];
		dependentInformationIdentificationQualifier = request[i++];
		dependentInformationIdentification = request[i++];
		dependentEligibilityDateQualifier = request[i++];
		dependentEligibilityDateFormatQualifier = request[i++];
		dependentEligibilityDatePeriod = request[i++];

	}

}
