package com.batch.eligibility.jsonschema270.beans;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * It contains <code>XsAll<code> and <code>XsElement<code>.
 * 
 * @author manishm3
 * @date Mar 11,2015
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "xs:all" })
public class XsComplexType {

	@JsonProperty("xs:all")
	private XsAll xsAll;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	/**
	 * 
	 * @return The xsAll
	 */
	@JsonProperty("xs:all")
	public XsAll getXsAll() {
		return xsAll;
	}

	/**
	 * 
	 * @param xsAll
	 *            The xs:all
	 */
	@JsonProperty("xs:all")
	public void setXsAll(XsAll xsAll) {
		this.xsAll = xsAll;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

}
