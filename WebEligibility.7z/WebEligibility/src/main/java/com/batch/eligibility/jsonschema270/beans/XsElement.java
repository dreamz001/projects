package com.batch.eligibility.jsonschema270.beans;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * It contains complextype and name etc property of received JSON.
 * 
 * @author manishm3
 * @date Mar 11,2015
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "-name", "xs:complexType" })
public class XsElement {

	@JsonProperty("-name")
	private String Name;
	@JsonProperty("xs:complexType")
	private XsComplexType xsComplexType;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	/**
	 * 
	 * @return The Name
	 */
	@JsonProperty("-name")
	public String getName() {
		return Name;
	}

	/**
	 * 
	 * @param Name
	 *            The -name
	 */
	@JsonProperty("-name")
	public void setName(String Name) {
		this.Name = Name;
	}

	/**
	 * 
	 * @return The xsComplexType
	 */
	@JsonProperty("xs:complexType")
	public XsComplexType getXsComplexType() {
		return xsComplexType;
	}

	/**
	 * 
	 * @param xsComplexType
	 *            The xs:complexType
	 */
	@JsonProperty("xs:complexType")
	public void setXsComplexType(XsComplexType xsComplexType) {
		this.xsComplexType = xsComplexType;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

}
