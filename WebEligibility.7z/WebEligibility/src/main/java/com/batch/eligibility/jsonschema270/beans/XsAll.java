package com.batch.eligibility.jsonschema270.beans;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * it contains all XsElement of received JSON.
 * 
 * @author manishm3
 * @date Mar 11,2015
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "xs:element" })
public class XsAll {

	@JsonProperty("xs:element")
	private List<XsElement_> xsElement = new ArrayList<XsElement_>();
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	/**
	 * 
	 * @return The xsElement
	 */
	@JsonProperty("xs:element")
	public List<XsElement_> getXsElement() {
		return xsElement;
	}

	/**
	 * 
	 * @param xsElement
	 *            The xs:element
	 */
	@JsonProperty("xs:element")
	public void setXsElement(List<XsElement_> xsElement) {
		this.xsElement = xsElement;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

}
