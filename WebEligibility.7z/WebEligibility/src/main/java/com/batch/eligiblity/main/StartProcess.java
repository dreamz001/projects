package com.batch.eligiblity.main;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.batch.eligibility.jsonschema270.beans.XsElement_;
import com.batch.eligibility.readwrite.ReadInput;
import com.batch.eligibility.readwrite.WriteOutputInFile;
import com.batch.eligibility270.parsing.error.Eligibility270ParserError;
import com.batch.eligibility270.writer.BatchEligibility270Writer;
import com.eligibility270.dbentities.EligibilityBatchInput;
import com.webeligibility.actions.BatchProcessAction;

@Component
public class StartProcess {

	static Integer hour;
	static Integer minutes;
	private static final Logger LOG = LoggerFactory
			.getLogger(StartProcess.class);

	@Autowired
	private BatchEligibility270Writer batchEligibility270Writer;

	public BatchEligibility270Writer getEligibility270Writer() {
		return batchEligibility270Writer;
	}

	public void setEligibility270Writer(
			BatchEligibility270Writer batchEligibility270Writer) {
		this.batchEligibility270Writer = batchEligibility270Writer;
	}

	public void startTask() {
		LOG.debug("Entering in to  StartProcess  ::  startTask");
		try {
			GregorianCalendar gc = new GregorianCalendar();
			String processStartInfo = "Start Clock Time: -> "
					+ gc.get(Calendar.HOUR) + ": " + gc.get(Calendar.MINUTE)
					+ " : " + gc.get(Calendar.SECOND) + " : "
					+ gc.get(Calendar.MILLISECOND);
			System.out.println(processStartInfo);
			LOG.info(processStartInfo);

			process();
			GregorianCalendar gc1 = new GregorianCalendar();
			String processEndInfo = "End Clock Time: -> "
					+ gc1.get(Calendar.HOUR) + ": " + gc1.get(Calendar.MINUTE)
					+ " : " + gc1.get(Calendar.SECOND) + " : "
					+ gc1.get(Calendar.MILLISECOND);
			System.out.println(processEndInfo);
			LOG.info(processEndInfo);
		} catch (FileNotFoundException fne) {
			LOG.error(fne.getMessage(), fne);
		}
		LOG.debug("Exiting from StartProcess :: startTask");
	}

	public void process() throws FileNotFoundException {
		LOG.debug("Entering in to  StartProcess  ::  process");

		try {
			File csv270InboxDir = new File(BatchProcessAction.getInboxPath());
			if (csv270InboxDir.isDirectory()) {
				File[] csvFiles = csv270InboxDir.listFiles();

				if (csvFiles != null && csvFiles.length > 0) {
					LinkedList<File> linkedListFiles = new LinkedList<File>(
							Arrays.asList(csvFiles));
					ListIterator<File> iterator = linkedListFiles
							.listIterator();
					while (iterator.hasNext()) {
						File csvFile = iterator.next();
						// readFromFile(csvFile);
						try {
							new ReadInput().readFromFile(
									batchEligibility270Writer.getBaseDao(),
									csvFile);
							Files.deleteIfExists(csvFile.toPath());
						} catch (IOException e) {
							LOG.error(
									"IOException occurred while reading and moving file to outbox",
									e);
							
							Files.deleteIfExists(csvFile.toPath());
						}
					}
				} else {
					System.out
							.println("INBOX DIRECTORY IS EMPTY FOR READING CSV 270 FILE");
				}
				// process batch system
				/* int count = 0; */
				Transaction tx = null;
				batchEligibility270Writer.getBaseDao().openManualSession();
				Session session = batchEligibility270Writer.getBaseDao()
						.getCurrentSession();
				try {
					tx = session.beginTransaction();
					List<EligibilityBatchInput> inputList = batchEligibility270Writer
							.getBaseDao().getBatchInputList();
					if (inputList != null) {

						for (EligibilityBatchInput input : inputList) {

							batchEligibility270Writer.getBaseDao().openManualSession();
							session = batchEligibility270Writer.getBaseDao().getCurrentSession();
							tx = batchEligibility270Writer.getBaseDao().initializeTransaction();

							batchEligibility270Writer.setInput(input);
							batchEligibility270Writer.setJson(input.getInputcsv());
							batchEligibility270Writer.processRequest(input.getInputcsv());
							// Testing for Transaction
							/*
							 * if (count++ > 0) { throw new
							 * Exception("My Exception::"); }
							 */
							clear();
							session.flush();
							batchEligibility270Writer.getBaseDao()
									.commitTransaction(tx);
							session.close();
						}
					}

				} catch (Exception exx) {
					if (tx != null) {
						batchEligibility270Writer.getBaseDao()
								.rollBackTransaction(tx);
					}
					LOG.error("Exception occurred while processing csvinput",
							exx);
				} finally {
					if (session != null && session.isOpen()) {
						session.close();
					}
				}

				new WriteOutputInFile().writeInFile(batchEligibility270Writer);
			}// End if
		} catch (Exception e) {
			LOG.error("Exception while reading and moving the csv files", e);
		}

		LOG.debug("Exiting from StartProcess :: process");
	}

	public void clear() {
		LOG.debug("Entering in to  StartProcess  ::  clear");
		batchEligibility270Writer.setJson("");
		batchEligibility270Writer.setTraceNumber("");
		List<XsElement_> elements = null;
		batchEligibility270Writer.setElements(elements);
		// batchEligibility270Writer.setJsonBytes((byte[]) null);
		BatchEligibility270Writer.parserErrors = new ArrayList<Eligibility270ParserError>();
		batchEligibility270Writer.setJsoninBytes(false);
		batchEligibility270Writer.setErrorInResponse(false);
		batchEligibility270Writer.setErrorDescription999("");
		batchEligibility270Writer.setErrorCode("");
		batchEligibility270Writer.setEmdeon(null);
		batchEligibility270Writer.setInput(null);
		LOG.debug("Exiting from StartProcess :: clear");
	}

}
