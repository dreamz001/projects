package com.batch.eligiblityshared.beans;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * @author shailendras4 Purpose : Bean corresponding to BHT segment
 * 
 */
public class BhtSegment implements Serializable {
	private static final long serialVersionUID = 1L;

	private Integer referenceidentification;
	private Timestamp bhtdate;
	private String hierarchicalstructurecode;
	private Timestamp bhttime;
	private String transactionsetpurposecode;
	private String transactiontypecode;
	private StSegment stSegment;

	public BhtSegment() {
	}

	public Integer getReferenceidentification() {
		return this.referenceidentification;
	}

	public void setReferenceidentification(Integer referenceidentification) {
		this.referenceidentification = referenceidentification;
	}

	public Timestamp getBhtdate() {
		return this.bhtdate;
	}

	public void setBhtdate(Timestamp bhtdate) {
		this.bhtdate = bhtdate;
	}

	public String getHierarchicalstructurecode() {
		return this.hierarchicalstructurecode;
	}

	public void setHierarchicalstructurecode(String hierarchicalstructurecode) {
		this.hierarchicalstructurecode = hierarchicalstructurecode;
	}

	public String getTransactionsetpurposecode() {
		return this.transactionsetpurposecode;
	}

	public void setTransactionsetpurposecode(String transactionsetpurposecode) {
		this.transactionsetpurposecode = transactionsetpurposecode;
	}

	public String getTransactiontypecode() {
		return this.transactiontypecode;
	}

	public void setTransactiontypecode(String transactiontypecode) {
		this.transactiontypecode = transactiontypecode;
	}

	public StSegment getStSegment() {
		return stSegment;
	}

	public void setStSegment(StSegment stSegment) {
		this.stSegment = stSegment;
	}

	public Timestamp getBhttime() {
		return bhttime;
	}

	public void setBhttime(Timestamp bhttime) {
		this.bhttime = bhttime;
	}
}