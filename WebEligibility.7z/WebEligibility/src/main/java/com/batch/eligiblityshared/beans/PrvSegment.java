package com.batch.eligiblityshared.beans;

import java.io.Serializable;

import com.batch.eligibility.common.utility.StringUtil;
import com.batch.eligibility.shared.constants.EligibilityTagEnum;
import com.batch.eligibility270.writer.IConstants;

/**
 * @author shailendras4 Purpose : Bean class corresponding to PRV Segment
 */
public class PrvSegment implements Serializable {

	private static final long serialVersionUID = 8348706501709025775L;

	private Integer prvid;

	private String providercode;

	private String providerorgcode;

	private String prviderspecialityinfo;

	private String refidentification;

	private String refidentificationqualifier;

	private String stateorprovincecode;

	public PrvSegment() {
	}

	public Integer getPrvid() {
		return this.prvid;
	}

	public void setPrvid(Integer prvid) {
		this.prvid = prvid;
	}

	public String getProvidercode() {
		return this.providercode;
	}

	public void setProvidercode(String providercode) {
		this.providercode = providercode;
	}

	public String getProviderorgcode() {
		return this.providerorgcode;
	}

	public void setProviderorgcode(String providerorgcode) {
		this.providerorgcode = providerorgcode;
	}

	public String getPrviderspecialityinfo() {
		return this.prviderspecialityinfo;
	}

	public void setPrviderspecialityinfo(String prviderspecialityinfo) {
		this.prviderspecialityinfo = prviderspecialityinfo;
	}

	public String getRefidentification() {
		return this.refidentification;
	}

	public void setRefidentification(String refidentification) {
		this.refidentification = refidentification;
	}

	public String getRefidentificationqualifier() {
		return this.refidentificationqualifier;
	}

	public void setRefidentificationqualifier(String refidentificationqualifier) {
		this.refidentificationqualifier = refidentificationqualifier;
	}

	public String getStateorprovincecode() {
		return this.stateorprovincecode;
	}

	public void setStateorprovincecode(String stateorprovincecode) {
		this.stateorprovincecode = stateorprovincecode;
	}

	/**
	 * It writes PRV segment as per the 270-Eligibility Specifications.
	 * 
	 * @author manishm3
	 * @date Mar 13,2015
	 * @return
	 */
	public String writer() {
		StringBuilder sb = new StringBuilder();
		sb.append(EligibilityTagEnum.PRV.value());
		sb.append(IConstants.SEPARATOR);

		/* PRV-01 */
		sb.append((providercode != null && !providercode.trim().isEmpty()) ? providercode
				+ IConstants.SEPARATOR
				: IConstants.SEPARATOR);
		/* PRV-02 */
		sb.append((refidentificationqualifier != null && !refidentificationqualifier
				.trim().isEmpty()) ? refidentificationqualifier
				+ IConstants.SEPARATOR : IConstants.SEPARATOR);
		/* PRV-03 */
		sb.append((refidentification != null && !refidentification.trim()
				.isEmpty()) ? refidentification + IConstants.SEPARATOR
				: IConstants.TERMINATOR);

		if (StringUtil.isSegmentContainsData(sb.toString(),
				EligibilityTagEnum.REF.value())) {
			return StringUtil.appendTerminatorIfNotFound(sb.toString());
		}
		return new String("");
	}
}