package com.batch.eligiblityshared.beans;

import java.io.Serializable;

import com.batch.eligibility.common.utility.StringUtil;
import com.batch.eligibility.shared.constants.EligibilityTagEnum;
import com.batch.eligibility270.writer.IConstants;

/**
 * @author shailendras4 Purpose : Bean corresponding to NM1 segment
 */
public class Nm1Segment implements Serializable {

	private static final long serialVersionUID = -7094711222394052791L;

	private Integer nm1id;

	private String entityidcode;

	private String entityidcode1;

	private String entityrelationshipcode;

	private String entitytypequalifier;

	private String firstname;

	private String idcode;

	private String idcodequalifier;

	private String middlename;

	private String namelastorgname;

	private String nameprefix;

	private String namesuffix;

	private String orgnameorlastname;

	public Nm1Segment() {
	}

	public Integer getNm1id() {
		return this.nm1id;
	}

	public void setNm1id(Integer nm1id) {
		this.nm1id = nm1id;
	}

	public String getEntityidcode() {
		return this.entityidcode;
	}

	public void setEntityidcode(String entityidcode) {
		this.entityidcode = entityidcode;
	}

	public String getEntityidcode1() {
		return this.entityidcode1;
	}

	public void setEntityidcode1(String entityidcode1) {
		this.entityidcode1 = entityidcode1;
	}

	public String getEntityrelationshipcode() {
		return this.entityrelationshipcode;
	}

	public void setEntityrelationshipcode(String entityrelationshipcode) {
		this.entityrelationshipcode = entityrelationshipcode;
	}

	public String getEntitytypequalifier() {
		return this.entitytypequalifier;
	}

	public void setEntitytypequalifier(String entitytypequalifier) {
		this.entitytypequalifier = entitytypequalifier;
	}

	public String getFirstname() {
		return this.firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getIdcode() {
		return this.idcode;
	}

	public void setIdcode(String idcode) {
		this.idcode = idcode;
	}

	public String getIdcodequalifier() {
		return this.idcodequalifier;
	}

	public void setIdcodequalifier(String idcodequalifier) {
		this.idcodequalifier = idcodequalifier;
	}

	public String getMiddlename() {
		return this.middlename;
	}

	public void setMiddlename(String middlename) {
		this.middlename = middlename;
	}

	public String getNamelastorgname() {
		return this.namelastorgname;
	}

	public void setNamelastorgname(String namelastorgname) {
		this.namelastorgname = namelastorgname;
	}

	public String getNameprefix() {
		return this.nameprefix;
	}

	public void setNameprefix(String nameprefix) {
		this.nameprefix = nameprefix;
	}

	public String getNamesuffix() {
		return this.namesuffix;
	}

	public void setNamesuffix(String namesuffix) {
		this.namesuffix = namesuffix;
	}

	public String getOrgnameorlastname() {
		return this.orgnameorlastname;
	}

	public void setOrgnameorlastname(String orgnameorlastname) {
		this.orgnameorlastname = orgnameorlastname;
	}

	/**
	 * It writes NM1 segment string as per 270 specifications.
	 * 
	 * @author manishm3
	 * @date Mar 12,2014
	 * @return
	 */
	public String writer() {
		StringBuilder sb = new StringBuilder();
		sb.append(EligibilityTagEnum.NM1.value());
		sb.append(IConstants.SEPARATOR);
		/* NM-101 */
		sb.append((entityidcode != null && !entityidcode.trim().isEmpty()) ? entityidcode
				.trim() + IConstants.SEPARATOR
				: IConstants.SEPARATOR);
		/* NM-102 */
		sb.append((entitytypequalifier != null && !entitytypequalifier.trim()
				.isEmpty()) ? entitytypequalifier.trim() + IConstants.SEPARATOR
				: IConstants.SEPARATOR);
		/* NM-103 */
		sb.append((namelastorgname != null && !namelastorgname.trim().isEmpty()) ? namelastorgname
				.trim() + IConstants.SEPARATOR
				: IConstants.SEPARATOR);
		/* NM-104 */
		sb.append((firstname != null && !firstname.trim().isEmpty()) ? firstname
				.trim() + IConstants.SEPARATOR
				: IConstants.SEPARATOR);
		/* NM-105 */
		sb.append((middlename != null && !middlename.trim().isEmpty()) ? middlename
				.trim() + IConstants.SEPARATOR
				: IConstants.SEPARATOR);
		/* NM-106 */
		sb.append((nameprefix != null && !nameprefix.trim().isEmpty()) ? nameprefix
				.trim() + IConstants.SEPARATOR
				: IConstants.SEPARATOR);
		/* NM-107 */
		sb.append((namesuffix != null && !namesuffix.trim().isEmpty()) ? namesuffix
				.trim() + IConstants.SEPARATOR
				: IConstants.SEPARATOR);
		/* NM-108 */
		sb.append((idcodequalifier != null && !idcodequalifier.trim().isEmpty()) ? idcodequalifier
				.trim() + IConstants.SEPARATOR
				: IConstants.SEPARATOR);
		/* NM-109 */
		sb.append((idcode != null && !idcode.trim().isEmpty()) ? idcode.trim()
				+ IConstants.TERMINATOR : IConstants.TERMINATOR);

		if (StringUtil.isSegmentContainsData(sb.toString(),
				EligibilityTagEnum.REF.value())) {
			return StringUtil.appendTerminatorIfNotFound(sb.toString());
		}
		return new String("");
	}
}