package com.batch.eligiblityshared.beans;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

/**
 * @author shailendras4 Purpose : Bean corresponding to ISA segment
 * 
 */
public class IsaSegment implements Serializable {
	private static final long serialVersionUID = 1L;

	private Integer interchangecontrolnumber;

	private String ackrequiredornot;

	private String authinfo;

	private String authinfoqualifier;

	private String compelementseprator;

	private String iccontrolversionnum;

	private String icreceiveridqualifier;

	private String interchangecontrolversionnum;

	private String interchangeidqualifier;

	private String interchangereceiverid;

	private String interchangesenderid;

	private Timestamp interchangetime;

	private String repetitionseprator;

	private String securityinfo;

	private String securityinfoqualifier;

	private String usageindicator;

	private List<GsSegment> gsSegments;

	public IsaSegment() {
	}

	public Integer getInterchangecontrolnumber() {
		return this.interchangecontrolnumber;
	}

	public void setInterchangecontrolnumber(Integer interchangecontrolnumber) {
		this.interchangecontrolnumber = interchangecontrolnumber;
	}

	public String getAckrequiredornot() {
		return this.ackrequiredornot;
	}

	public void setAckrequiredornot(String ackrequiredornot) {
		this.ackrequiredornot = ackrequiredornot;
	}

	public String getAuthinfo() {
		return this.authinfo;
	}

	public void setAuthinfo(String authinfo) {
		this.authinfo = authinfo;
	}

	public String getAuthinfoqualifier() {
		return this.authinfoqualifier;
	}

	public void setAuthinfoqualifier(String authinfoqualifier) {
		this.authinfoqualifier = authinfoqualifier;
	}

	public String getCompelementseprator() {
		return this.compelementseprator;
	}

	public void setCompelementseprator(String compelementseprator) {
		this.compelementseprator = compelementseprator;
	}

	public String getIccontrolversionnum() {
		return this.iccontrolversionnum;
	}

	public void setIccontrolversionnum(String iccontrolversionnum) {
		this.iccontrolversionnum = iccontrolversionnum;
	}

	public String getIcreceiveridqualifier() {
		return this.icreceiveridqualifier;
	}

	public void setIcreceiveridqualifier(String icreceiveridqualifier) {
		this.icreceiveridqualifier = icreceiveridqualifier;
	}

	public String getInterchangecontrolversionnum() {
		return this.interchangecontrolversionnum;
	}

	public void setInterchangecontrolversionnum(
			String interchangecontrolversionnum) {
		this.interchangecontrolversionnum = interchangecontrolversionnum;
	}

	public String getInterchangeidqualifier() {
		return this.interchangeidqualifier;
	}

	public void setInterchangeidqualifier(String interchangeidqualifier) {
		this.interchangeidqualifier = interchangeidqualifier;
	}

	public String getInterchangereceiverid() {
		return this.interchangereceiverid;
	}

	public void setInterchangereceiverid(String interchangereceiverid) {
		this.interchangereceiverid = interchangereceiverid;
	}

	public String getInterchangesenderid() {
		return this.interchangesenderid;
	}

	public void setInterchangesenderid(String interchangesenderid) {
		this.interchangesenderid = interchangesenderid;
	}

	public Timestamp getInterchangetime() {
		return this.interchangetime;
	}

	public void setInterchangetime(Timestamp interchangetime) {
		this.interchangetime = interchangetime;
	}

	public String getRepetitionseprator() {
		return this.repetitionseprator;
	}

	public void setRepetitionseprator(String repetitionseprator) {
		this.repetitionseprator = repetitionseprator;
	}

	public String getSecurityinfo() {
		return this.securityinfo;
	}

	public void setSecurityinfo(String securityinfo) {
		this.securityinfo = securityinfo;
	}

	public String getSecurityinfoqualifier() {
		return this.securityinfoqualifier;
	}

	public void setSecurityinfoqualifier(String securityinfoqualifier) {
		this.securityinfoqualifier = securityinfoqualifier;
	}

	public String getUsageindicator() {
		return this.usageindicator;
	}

	public void setUsageindicator(String usageindicator) {
		this.usageindicator = usageindicator;
	}

	public List<GsSegment> getGsSegments() {
		if (gsSegments == null) {
			gsSegments = new ArrayList<GsSegment>();
		}
		return gsSegments;
	}

	public void setGsSegments(List<GsSegment> gsSegments) {
		this.gsSegments = gsSegments;
	}

	public GsSegment addFunctionalgroupheader(GsSegment gsSegment) {
		getGsSegments().add(gsSegment);
		gsSegment.setIsaSegment(this);

		return gsSegment;
	}

	public GsSegment removeFunctionalgroupheader(GsSegment gsSegment) {
		getGsSegments().remove(gsSegment);
		gsSegment.setIsaSegment(null);

		return gsSegment;
	}

}