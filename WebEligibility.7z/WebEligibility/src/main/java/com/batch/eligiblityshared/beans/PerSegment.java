package com.batch.eligiblityshared.beans;

import java.io.Serializable;

/**
 * 
 * @author shailendras4 Purpose : Bean class corresponding to PER SEGMENT
 */
public class PerSegment implements Serializable {

	private static final long serialVersionUID = -7481987133188252454L;

	private Integer perid;

	private String commnumber1;

	private String commnumber2;

	private String commnumber3;

	private String commnumberqualifier1;

	private String commnumberqualifier2;

	private String commnumberqualifier3;

	private String contactfunctcode;

	private String contactinquieryreference;

	private String name;

	public PerSegment() {
	}

	public Integer getPerid() {
		return this.perid;
	}

	public void setPerid(Integer perid) {
		this.perid = perid;
	}

	public String getCommnumber1() {
		return this.commnumber1;
	}

	public void setCommnumber1(String commnumber1) {
		this.commnumber1 = commnumber1;
	}

	public String getCommnumber2() {
		return this.commnumber2;
	}

	public void setCommnumber2(String commnumber2) {
		this.commnumber2 = commnumber2;
	}

	public String getCommnumber3() {
		return this.commnumber3;
	}

	public void setCommnumber3(String commnumber3) {
		this.commnumber3 = commnumber3;
	}

	public String getCommnumberqualifier1() {
		return this.commnumberqualifier1;
	}

	public void setCommnumberqualifier1(String commnumberqualifier1) {
		this.commnumberqualifier1 = commnumberqualifier1;
	}

	public String getCommnumberqualifier2() {
		return this.commnumberqualifier2;
	}

	public void setCommnumberqualifier2(String commnumberqualifier2) {
		this.commnumberqualifier2 = commnumberqualifier2;
	}

	public String getCommnumberqualifier3() {
		return this.commnumberqualifier3;
	}

	public void setCommnumberqualifier3(String commnumberqualifier3) {
		this.commnumberqualifier3 = commnumberqualifier3;
	}

	public String getContactfunctcode() {
		return this.contactfunctcode;
	}

	public void setContactfunctcode(String contactfunctcode) {
		this.contactfunctcode = contactfunctcode;
	}

	public String getContactinquieryreference() {
		return this.contactinquieryreference;
	}

	public void setContactinquieryreference(String contactinquieryreference) {
		this.contactinquieryreference = contactinquieryreference;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

}