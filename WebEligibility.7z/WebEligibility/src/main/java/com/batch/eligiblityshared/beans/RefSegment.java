package com.batch.eligiblityshared.beans;

import java.io.Serializable;

import com.batch.eligibility.common.utility.StringUtil;
import com.batch.eligibility.shared.constants.EligibilityTagEnum;
import com.batch.eligibility270.writer.IConstants;

/**
 * 
 * @author shailendras4 Purpose : Bean class corresponding to REF segment
 */
public class RefSegment implements Serializable {
	private static final long serialVersionUID = 1L;

	private Integer refid;

	private String description;

	private String refidentification;

	private String refidentificationqualifier;

	private String refidentifier;

	public RefSegment() {
	}

	public Integer getRefid() {
		return this.refid;
	}

	public void setRefid(Integer refid) {
		this.refid = refid;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getRefidentification() {
		return this.refidentification;
	}

	public void setRefidentification(String refidentification) {
		this.refidentification = refidentification;
	}

	public String getRefidentificationqualifier() {
		return this.refidentificationqualifier;
	}

	public void setRefidentificationqualifier(String refidentificationqualifier) {
		this.refidentificationqualifier = refidentificationqualifier;
	}

	public String getRefidentifier() {
		return this.refidentifier;
	}

	public void setRefidentifier(String refidentifier) {
		this.refidentifier = refidentifier;
	}

	/**
	 * It writes REF segment as per the 270-Eligibility Specifications.
	 * 
	 * @author manishm3
	 * @date Mar 13,2015
	 * @return
	 */
	public String writer() {
		StringBuilder sb = new StringBuilder();
		sb.append(EligibilityTagEnum.REF.value());
		sb.append(IConstants.SEPARATOR);
		/* REF-01 */
		sb.append((refidentificationqualifier != null && !refidentificationqualifier
				.isEmpty()) ? refidentificationqualifier + IConstants.SEPARATOR
				: IConstants.SEPARATOR);
		/* REF-02 */
		sb.append((refidentification != null && !refidentification.isEmpty()) ? refidentification
				+ IConstants.SEPARATOR
				: IConstants.SEPARATOR);
		/* REF-03 */
		sb.append((description != null && !description.isEmpty()) ? description
				+ IConstants.TERMINATOR : IConstants.TERMINATOR);

		if (StringUtil.isSegmentContainsData(sb.toString(),
				EligibilityTagEnum.REF.value())) {
			return StringUtil.appendTerminatorIfNotFound(sb.toString());
		}
		return new String("");
	}
}