package com.batch.eligiblityshared.beans;

import java.io.Serializable;

import com.batch.eligibility.common.utility.StringUtil;
import com.batch.eligibility.shared.constants.EligibilityTagEnum;
import com.batch.eligibility270.writer.IConstants;

/**
 * 
 * @author shailendras4 Purpose : Bean class corresponding to DTP segment
 */

public class DtpSegment implements Serializable {

	private static final long serialVersionUID = 1759320449109241948L;

	private Integer dtpid;

	private String datetimeformatqualifier;

	private String datetimeperiod;

	private String datetimequalifier;

	public DtpSegment() {
	}

	public Integer getDtpid() {
		return this.dtpid;
	}

	public void setDtpid(Integer dtpid) {
		this.dtpid = dtpid;
	}

	public String getDatetimeformatqualifier() {
		return this.datetimeformatqualifier;
	}

	public void setDatetimeformatqualifier(String datetimeformatqualifier) {
		this.datetimeformatqualifier = datetimeformatqualifier;
	}

	public String getDatetimeperiod() {
		return this.datetimeperiod;
	}

	public void setDatetimeperiod(String datetimeperiod) {
		this.datetimeperiod = datetimeperiod;
	}

	public String getDatetimequalifier() {
		return this.datetimequalifier;
	}

	public void setDatetimequalifier(String datetimequalifier) {
		this.datetimequalifier = datetimequalifier;
	}

	public String writer() {
		StringBuilder sb = new StringBuilder();
		sb.append(EligibilityTagEnum.DTP.value());
		sb.append(IConstants.SEPARATOR);
		/* DTP-01 */
		sb.append((datetimequalifier != null && !datetimeformatqualifier.trim()
				.isEmpty()) ? datetimequalifier + IConstants.SEPARATOR
				: IConstants.SEPARATOR);
		/* DTP-02 */
		sb.append((datetimeformatqualifier != null && !datetimeformatqualifier
				.trim().isEmpty()) ? datetimeformatqualifier
				+ IConstants.SEPARATOR : IConstants.SEPARATOR);
		/* DTP-03 */
		sb.append((datetimeperiod != null && !datetimeperiod.trim().isEmpty()) ? datetimeperiod
				+ IConstants.SEPARATOR
				: IConstants.SEPARATOR);

		if (StringUtil.isSegmentContainsData(sb.toString(),
				EligibilityTagEnum.REF.value())) {
			return StringUtil.appendTerminatorIfNotFound(sb.toString());
		}
		return new String("");
	}

}