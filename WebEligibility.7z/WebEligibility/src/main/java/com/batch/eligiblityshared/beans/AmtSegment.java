package com.batch.eligiblityshared.beans;

import java.io.Serializable;

import com.batch.eligibility.common.utility.StringUtil;
import com.batch.eligibility.shared.constants.EligibilityTagEnum;
import com.batch.eligibility270.writer.IConstants;

/**
 * AMT- SUBSCRIBER SPEND DOWN AMOUNT/SUBSCRIBER SPEND DOWN TOTAL BILLED AMOUNT
 * 
 * @author manishm3
 * @date Mar 23,2015
 */

public class AmtSegment implements Serializable {
	private static final long serialVersionUID = 1L;

	private String amountqualifiercode;
	private String creditdebitflagcode;
	private String monetaryamount;

	public AmtSegment() {
	}

	public String getAmountqualifiercode() {
		return this.amountqualifiercode;
	}

	public void setAmountqualifiercode(String amountqualifiercode) {
		this.amountqualifiercode = amountqualifiercode;
	}

	public String getCreditdebitflagcode() {
		return this.creditdebitflagcode;
	}

	public void setCreditdebitflagcode(String creditdebitflagcode) {
		this.creditdebitflagcode = creditdebitflagcode;
	}

	public String getMonetaryamount() {
		return this.monetaryamount;
	}

	public void setMonetaryamount(String monetaryamount) {
		this.monetaryamount = monetaryamount;
	}

	public String writer() {

		StringBuilder sb = new StringBuilder();
		sb.append(EligibilityTagEnum.AMT.value());
		sb.append(IConstants.SEPARATOR);
		/* NM-101 */
		sb.append((amountqualifiercode != null && !amountqualifiercode.trim()
				.isEmpty()) ? amountqualifiercode.trim() + IConstants.SEPARATOR
				: IConstants.SEPARATOR);
		/* NM-102 */
		sb.append((monetaryamount != null && !monetaryamount.trim().isEmpty()) ? monetaryamount
				.trim() + IConstants.TERMINATOR
				: IConstants.TERMINATOR);

		if (StringUtil.isSegmentContainsData(sb.toString(),
				EligibilityTagEnum.AMT.value())) {
			return StringUtil.appendTerminatorIfNotFound(sb.toString());
		}
		return new String("");
	}

}