package com.batch.eligiblityshared.beans;

import java.io.Serializable;

import com.batch.eligibility.common.utility.StringUtil;
import com.batch.eligibility.shared.constants.EligibilityTagEnum;
import com.batch.eligibility270.writer.IConstants;

/**
 * 
 * @author shailendras4 Purpose : Bean class corresponding to N3 segment
 */

public class N3Segment implements Serializable {
	private static final long serialVersionUID = 1L;

	private Integer n3id;

	private String addressinfo1;

	private String addressinfo2;

	public N3Segment() {
	}

	public Integer getN3id() {
		return this.n3id;
	}

	public void setN3id(Integer n3id) {
		this.n3id = n3id;
	}

	public String getAddressinfo1() {
		return this.addressinfo1;
	}

	public void setAddressinfo1(String addressinfo1) {
		this.addressinfo1 = addressinfo1;
	}

	public String getAddressinfo2() {
		return this.addressinfo2;
	}

	public void setAddressinfo2(String addressinfo2) {
		this.addressinfo2 = addressinfo2;
	}

	/**
	 * It writes N3 segment as per the 270-Eligibility Specifications.
	 * 
	 * @author manishm3
	 * @date Mar 13,2015
	 * @return
	 */
	public String writer() {
		StringBuilder sb = new StringBuilder();
		sb.append(EligibilityTagEnum.N3.value());
		sb.append(IConstants.SEPARATOR);
		/* N3-01 */
		sb.append((addressinfo1 != null && !addressinfo1.trim().isEmpty()) ? addressinfo1
				+ IConstants.SEPARATOR
				: IConstants.SEPARATOR);
		/* N3-02 */
		sb.append((addressinfo2 != null && !addressinfo2.trim().isEmpty()) ? addressinfo2
				+ IConstants.SEPARATOR
				: IConstants.TERMINATOR);

		if (StringUtil.isSegmentContainsData(sb.toString(),
				EligibilityTagEnum.REF.value())) {
			return StringUtil.appendTerminatorIfNotFound(sb.toString());
		}
		return new String("");
	}

}