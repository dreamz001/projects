package com.batch.eligiblityshared.beans;

import java.io.Serializable;

import com.batch.eligibility.common.utility.StringUtil;
import com.batch.eligibility.shared.constants.EligibilityTagEnum;
import com.batch.eligibility270.writer.IConstants;

/**
 * @author shailendras4 Purpose : Bean class corresponding to DMG segment
 */
public class DmgSegment implements Serializable {

	private static final long serialVersionUID = -8331629172925102528L;

	private Integer dmgid;

	private String basisofverificationcode;

	private String citizenshipstatuscode;

	private String codelistqualifiercode;

	private String compositeraceorethnicityinfo;

	private String countrycode;

	private String datetimeformatqualifier;

	private String datetimeperiod;

	private String gendercode;

	private String industrycode;

	private String maritalstatuscode;

	private String quantity;

	public DmgSegment() {
	}

	public Integer getDmgid() {
		return this.dmgid;
	}

	public void setDmgid(Integer dmgid) {
		this.dmgid = dmgid;
	}

	public String getBasisofverificationcode() {
		return this.basisofverificationcode;
	}

	public void setBasisofverificationcode(String basisofverificationcode) {
		this.basisofverificationcode = basisofverificationcode;
	}

	public String getCitizenshipstatuscode() {
		return this.citizenshipstatuscode;
	}

	public void setCitizenshipstatuscode(String citizenshipstatuscode) {
		this.citizenshipstatuscode = citizenshipstatuscode;
	}

	public String getCodelistqualifiercode() {
		return this.codelistqualifiercode;
	}

	public void setCodelistqualifiercode(String codelistqualifiercode) {
		this.codelistqualifiercode = codelistqualifiercode;
	}

	public String getCompositeraceorethnicityinfo() {
		return this.compositeraceorethnicityinfo;
	}

	public void setCompositeraceorethnicityinfo(
			String compositeraceorethnicityinfo) {
		this.compositeraceorethnicityinfo = compositeraceorethnicityinfo;
	}

	public String getCountrycode() {
		return this.countrycode;
	}

	public void setCountrycode(String countrycode) {
		this.countrycode = countrycode;
	}

	public String getDatetimeformatqualifier() {
		return this.datetimeformatqualifier;
	}

	public void setDatetimeformatqualifier(String datetimeformatqualifier) {
		this.datetimeformatqualifier = datetimeformatqualifier;
	}

	public String getDatetimeperiod() {
		return this.datetimeperiod;
	}

	public void setDatetimeperiod(String datetimeperiod) {
		this.datetimeperiod = datetimeperiod;
	}

	public String getGendercode() {
		return this.gendercode;
	}

	public void setGendercode(String gendercode) {
		this.gendercode = gendercode;
	}

	public String getIndustrycode() {
		return this.industrycode;
	}

	public void setIndustrycode(String industrycode) {
		this.industrycode = industrycode;
	}

	public String getMaritalstatuscode() {
		return this.maritalstatuscode;
	}

	public void setMaritalstatuscode(String maritalstatuscode) {
		this.maritalstatuscode = maritalstatuscode;
	}

	public String getQuantity() {
		return this.quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	/**
	 * It writes DMG segment as per the 270-Eligibility Specifications.
	 * 
	 * @author manishm3
	 * @date Mar 13,2015
	 * @return
	 */
	public String writer() {
		StringBuilder sb = new StringBuilder();
		sb.append(EligibilityTagEnum.DMG.value());
		sb.append(IConstants.SEPARATOR);
		/* DMG-01 */
		sb.append((datetimeformatqualifier != null && !datetimeformatqualifier
				.trim().isEmpty()) ? datetimeformatqualifier
				+ IConstants.SEPARATOR : IConstants.SEPARATOR);
		/* DMG-02 */
		sb.append((datetimeperiod != null && !datetimeperiod.trim().isEmpty()) ? datetimeperiod
				+ IConstants.SEPARATOR
				: IConstants.SEPARATOR);
		/* DMG-03 */
		sb.append((gendercode != null && !gendercode.trim().isEmpty()) ? gendercode
				+ IConstants.TERMINATOR
				: IConstants.TERMINATOR);

		if (StringUtil.isSegmentContainsData(sb.toString(),
				EligibilityTagEnum.REF.value())) {
			return StringUtil.appendTerminatorIfNotFound(sb.toString());
		}
		return new String("");
	}
}