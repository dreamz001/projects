package com.batch.eligiblityshared.beans;

import java.io.Serializable;

import com.batch.eligibility.common.utility.StringUtil;
import com.batch.eligibility.shared.constants.EligibilityTagEnum;
import com.batch.eligibility270.writer.IConstants;

/**
 * 
 * @author shailendras4 Purpose : Bean class corresponding to N4 segment
 */

public class N4Segment implements Serializable {
	private static final long serialVersionUID = 1L;

	private Integer n4id;

	private String cityname;

	private String countrycode;

	private String countrysubcode;

	private String locationidentifier;

	private String locationqualifier;

	private String postalcode;

	private String stateorprovincecode;

	public N4Segment() {
	}

	public Integer getN4id() {
		return this.n4id;
	}

	public void setN4id(Integer n4id) {
		this.n4id = n4id;
	}

	public String getCityname() {
		return this.cityname;
	}

	public void setCityname(String cityname) {
		this.cityname = cityname;
	}

	public String getCountrycode() {
		return this.countrycode;
	}

	public void setCountrycode(String countrycode) {
		this.countrycode = countrycode;
	}

	public String getCountrysubcode() {
		return this.countrysubcode;
	}

	public void setCountrysubcode(String countrysubcode) {
		this.countrysubcode = countrysubcode;
	}

	public String getLocationidentifier() {
		return this.locationidentifier;
	}

	public void setLocationidentifier(String locationidentifier) {
		this.locationidentifier = locationidentifier;
	}

	public String getLocationqualifier() {
		return this.locationqualifier;
	}

	public void setLocationqualifier(String locationqualifier) {
		this.locationqualifier = locationqualifier;
	}

	public String getPostalcode() {
		return this.postalcode;
	}

	public void setPostalcode(String postalcode) {
		String postalZipCode = postalcode.replaceAll("[^0-9]", "");
		this.postalcode = postalZipCode;
	}

	public String getStateorprovincecode() {
		return this.stateorprovincecode;
	}

	public void setStateorprovincecode(String stateorprovincecode) {
		this.stateorprovincecode = stateorprovincecode;
	}

	/**
	 * It writes N4 segment as per the 270-Eligibility Specifications.
	 * 
	 * @author manishm3
	 * @date Mar 13,2015
	 * @return
	 */
	public String writer() {
		StringBuilder sb = new StringBuilder();
		sb.append(EligibilityTagEnum.N4.value());
		sb.append(IConstants.SEPARATOR);
		/* N4-01 */
		sb.append((cityname != null && !cityname.trim().isEmpty()) ? cityname
				+ IConstants.SEPARATOR : IConstants.SEPARATOR);
		/* N4-02 */
		sb.append((stateorprovincecode != null && !stateorprovincecode.trim()
				.isEmpty()) ? stateorprovincecode + IConstants.SEPARATOR
				: IConstants.SEPARATOR);
		/* N4-03 */
		sb.append((postalcode != null && !postalcode.trim().isEmpty()) ? postalcode
				+ IConstants.SEPARATOR
				: IConstants.SEPARATOR);
		/* N4-04 */
		sb.append((countrycode != null && !countrycode.trim().isEmpty()) ? countrycode
				+ IConstants.SEPARATOR
				: IConstants.SEPARATOR);
		/* N4-05 */
		sb.append((locationqualifier != null && !locationqualifier.trim()
				.isEmpty()) ? locationqualifier + IConstants.SEPARATOR
				: IConstants.SEPARATOR);
		/* N4-06 */
		sb.append((locationidentifier != null && !locationidentifier.trim()
				.isEmpty()) ? locationidentifier + IConstants.SEPARATOR
				: IConstants.SEPARATOR);
		/* N4-07 */
		sb.append((countrysubcode != null && !countrysubcode.trim().isEmpty()) ? countrysubcode
				+ IConstants.SEPARATOR
				: IConstants.TERMINATOR);

		if (StringUtil.isSegmentContainsData(sb.toString(),
				EligibilityTagEnum.REF.value())) {
			return StringUtil.appendTerminatorIfNotFound(sb.toString());
		}
		return new String("");
	}

}