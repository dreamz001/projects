package com.batch.eligibility270.beans;

import org.apache.log4j.Logger;

import com.batch.eligibility.common.utility.StringUtil;
import com.batch.eligibility.shared.constants.EligibilityTagEnum;
import com.batch.eligibility270.writer.IConstants;

/**
 * INS Segment Bean.
 * 
 * @author manishm3
 * @date March 4,2015
 */
public class InsSegment {
	private String yesNoCondRespCode;
	private String individualRelatCode;
	private Integer number;

	private final Logger LOGGER = Logger.getLogger(InsSegment.class);

	public String getYesNoCondRespCode() {
		return yesNoCondRespCode;
	}

	public void setYesNoCondRespCode(String yesNoCondRespCode) {
		this.yesNoCondRespCode = yesNoCondRespCode;
	}

	public String getIndividualRelatCode() {
		return individualRelatCode;
	}

	public void setIndividualRelatCode(String individualRelatCode) {
		this.individualRelatCode = individualRelatCode;
	}

	public Integer getNumber() {
		return number;
	}

	public void setNumber(Integer number) {
		this.number = number;
	}

	public String writer() {
		LOGGER.debug("INS SEGMENT WRITER");
		StringBuilder sb = new StringBuilder();
		sb.append(EligibilityTagEnum.INS.value());

		/* INS-01 */
		sb.append((yesNoCondRespCode != null && !yesNoCondRespCode.trim()
				.isEmpty()) ? yesNoCondRespCode + IConstants.SEPARATOR
				: IConstants.SEPARATOR);
		/* INS-02 */
		sb.append((individualRelatCode != null && !individualRelatCode.trim()
				.isEmpty()) ? individualRelatCode + IConstants.SEPARATOR
				: IConstants.SEPARATOR);

		if (number != null && number > 0) {
			/* INS-03 & INS-04 */
			sb.append(IConstants.SEPARATOR);
			sb.append(IConstants.SEPARATOR);
			/* INS-05 & INS-06 */
			sb.append(IConstants.SEPARATOR);
			sb.append(IConstants.SEPARATOR);
			/* INS-07 & INS-08 */
			sb.append(IConstants.SEPARATOR);
			sb.append(IConstants.SEPARATOR);
			/* INS-09 & INS-10 */
			sb.append(IConstants.SEPARATOR);
			sb.append(IConstants.SEPARATOR);
			/* INS-11 & INS-12 */
			sb.append(IConstants.SEPARATOR);
			sb.append(IConstants.SEPARATOR);
			/* INS-13 & INS-14 */
			sb.append(IConstants.SEPARATOR);
			sb.append(IConstants.SEPARATOR);
			/* INS-14 & INS-16 */
			sb.append(IConstants.SEPARATOR);
			sb.append(IConstants.SEPARATOR);
			/* INS-17 */
			sb.append(String.valueOf(number) + IConstants.TERMINATOR);
		}
		if (StringUtil.isSegmentContainsData(sb.toString(),
				EligibilityTagEnum.INS.value())) {
			LOGGER.debug("INS SEGMENT WRITER COMPLETE");
			return StringUtil.appendTerminatorIfNotFound(sb.toString());
		}
		LOGGER.debug("INS SEGMENT WRITER COMPLETE");
		return new String("");
	}
}
