package com.batch.eligibility270.writer;

import java.util.List;

import org.springframework.stereotype.Component;

import com.eligibility271.dbentities.Config;

@Component
public class ConfigLookUp {

	private List<Config> configList;

	public List<Config> getConfigList() {
		return configList;
	}

	public void setConfigList(List<Config> configList) {
		this.configList = configList;
	}

}
