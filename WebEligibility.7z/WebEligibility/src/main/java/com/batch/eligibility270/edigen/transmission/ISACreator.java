package com.batch.eligibility270.edigen.transmission;

import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.batch.eligibility.common.utility.StringUtil;
import com.batch.eligibility270.edigen.transmission.functionalgroup.transaction.ICreator;
import com.batch.eligibility270.writer.IConstants;
import com.eligibility270.edigen.transmission.IsaLength;
import com.eligibility270.header.entities.InterchangeControlHeader;

/**
 * ISA- Interchange Control Header The ISA is a fixed record length segment and
 * all positions within each of the data elements must be filled. The first
 * element separator(*) defines the element separator to be used through the
 * entire interchange. The segment terminator(~) used after the ISA defines the
 * segment terminator to be used throughout the entire interchange.
 * 
 * @author manishm3
 * @date NOV 28,2014
 */

public class ISACreator implements ICreator {


    private InterchangeControlHeader isaEntity;
    private BigInteger interchangeControlNumber;
    private Date date;

    private static final Logger LOG = LoggerFactory.getLogger(ISACreator.class);

    public ISACreator(InterchangeControlHeader isaEntity, BigInteger interchangeControlNumber, Date date) {
        this.isaEntity = isaEntity;
        this.interchangeControlNumber = interchangeControlNumber;
        this.date = date;
    }

    @Override
    public String creator() {
        LOG.debug("ISA CREATOR.");
        StringBuilder sbISA = new StringBuilder();
        /* ISA Interchange Control Header */
        sbISA.append("ISA");
        sbISA.append(IConstants.SEPARATOR);

        /* ISA-01 Authorization Information Qualifier */
        sbISA.append(isaEntity.getAuthinfoqualifier());
        sbISA.append(IConstants.SEPARATOR);

        /* ISA-02 Authorization Information */
        if (isaEntity.getAuthinfo() == null || "".equals(isaEntity.getAuthinfo().trim())) {
            sbISA.append(StringUtil.space(IsaLength.ISA02_MAX.value()));
            sbISA.append(IConstants.SEPARATOR);
        } else {
            sbISA.append(postfixWithSpaces(isaEntity.getAuthinfo(), IsaLength.ISA02_MAX.value()));                   
            sbISA.append(IConstants.SEPARATOR);
        }

        /* ISA-03 Security Information Qualifier */
        sbISA.append(isaEntity.getSecurityinfoqualifier());
        sbISA.append(IConstants.SEPARATOR);

        /* ISA-04 Security information */
        if (isaEntity.getSecurityinfo() == null || "".equals(isaEntity.getSecurityinfo().trim())) {
            sbISA.append(StringUtil.space(IsaLength.ISA04_MAX.value()));
            sbISA.append(IConstants.SEPARATOR);
        } else {
            sbISA.append(postfixWithSpaces(isaEntity.getSecurityinfo(), IsaLength.ISA04_MAX.value()));
            sbISA.append(IConstants.SEPARATOR);
        }

        /* ISA-05 Interchange ID Qualifier */
        sbISA.append(isaEntity.getInterchangeidqualifier());
        sbISA.append(IConstants.SEPARATOR);

        /* ISA-06 Interchange Sender Id */
        if (isaEntity.getInterchangesenderid() != null && isaEntity.getInterchangesenderid().trim().length() >= IsaLength.ISA06_MIN.value()
                && isaEntity.getInterchangesenderid().trim().length() <= IsaLength.ISA06_MAX.value()) {
            if (isaEntity.getInterchangesenderid().trim().length() == IsaLength.ISA06_MAX.value()) {
                sbISA.append(isaEntity.getInterchangesenderid());
            } else {
                sbISA.append(isaEntity.getInterchangesenderid() + StringUtil.space(IsaLength.ISA06_MAX.value() - isaEntity.getInterchangesenderid().length()));
            }
            sbISA.append(IConstants.SEPARATOR);
        }

        /* ISA-07 Interchange ID Qualifier */
        sbISA.append(isaEntity.getIcreceiveridqualifier());
        sbISA.append(IConstants.SEPARATOR);

        /* ISA-08 Interchange receiver ID */
        if (isaEntity.getInterchangereceiverid() != null && isaEntity.getInterchangereceiverid().trim().length() <= IsaLength.ISA08_MAX.value()) {
            if (isaEntity.getInterchangereceiverid().length() == IsaLength.ISA08_MAX.value()) {
                sbISA.append(isaEntity.getInterchangereceiverid());
            } else {
                sbISA.append(isaEntity.getInterchangereceiverid() + StringUtil.space(IsaLength.ISA08_MAX.value() - isaEntity.getInterchangereceiverid().length()));
            }
            sbISA.append(IConstants.SEPARATOR);
        }

        /* ISA-09 Interchange Date(DDMMYY) */
        SimpleDateFormat df = new SimpleDateFormat("yyMMdd");
        String isa09 = df.format(date);
        sbISA.append(isa09);
        sbISA.append(IConstants.SEPARATOR);

        /* ISA-10 Interchange Time (HHMM) */
        SimpleDateFormat it = new SimpleDateFormat("HHmm");
        sbISA.append(it.format(date));
        sbISA.append(IConstants.SEPARATOR);

        /* ISA-11 Repetition Separator */
        sbISA.append(isaEntity.getRepetitionseprator());
        sbISA.append(IConstants.SEPARATOR);

        /* ISA-12 Interchange Control Version Number */
        sbISA.append(isaEntity.getIccontrolversionnum());
        sbISA.append(IConstants.SEPARATOR);

        /* ISA-13 Interchange COntrol Number */
        if ((String.valueOf(interchangeControlNumber)).length() < IsaLength.ISA13_MAX.value()) {
            isaEntity.setInterchangecontrolnumber(interchangeControlNumber.intValue());
            sbISA.append(StringUtil.zeros(IsaLength.ISA13_MAX.value() - (String.valueOf(interchangeControlNumber)).length()) + String.valueOf(interchangeControlNumber));
            sbISA.append(IConstants.SEPARATOR);
        }

        /* ISA-14 Acknowledgement Required */
        sbISA.append(isaEntity.getAckrequiredornot());
        sbISA.append(IConstants.SEPARATOR);

        /* ISA-15 Usage Indicator */
        sbISA.append(isaEntity.getUsageindicator());
        sbISA.append(IConstants.SEPARATOR);

        /* ISA-16 Component Element Separator */
        sbISA.append(isaEntity.getCompelementseprator());
        sbISA.append(IConstants.TERMINATOR);
        LOG.info("ISA CREATOR COMPLETED.");
        return sbISA.toString();
    }
    
    private String postfixWithSpaces(String segment,int length){
        for(int i=segment.length();i<length;i++){
            segment=segment+" ";
        }
        return segment;
    }
}
