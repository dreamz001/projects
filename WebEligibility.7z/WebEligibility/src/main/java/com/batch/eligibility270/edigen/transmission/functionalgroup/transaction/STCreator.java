package com.batch.eligibility270.edigen.transmission.functionalgroup.transaction;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.batch.eligibility.common.utility.StringUtil;
import com.batch.eligibility270.writer.IConstants;

/**
 * ST- Transaction Set Header It creates ST segment.
 * 
 * @author manishm3
 * @date NOV 28,2014
 *
 */
public class STCreator implements ICreator {

    private String transactionControlNum;
    private String implementationCOnvRef;

    private final int MIN_LENGTH = 4;
    // private final int MAX_LENGTH=9;

    public static final String EDI_TYPE = "270";

    private static final Logger LOG = LoggerFactory.getLogger(STCreator.class);

    public STCreator(String transactionControlNum) {
        super();
        this.transactionControlNum = transactionControlNum;
        this.implementationCOnvRef = ICreator.VERSION_NO;
    }

    @Override
    public String creator() {
        LOG.debug("ST CREATOR.");
        StringBuilder sbST = new StringBuilder();

        /* ST-00 Transaction Set Header */
        sbST.append("ST");
        sbST.append(IConstants.SEPARATOR);

        /* ST-01 Transaction set Identifier */
        sbST.append(EDI_TYPE);
        sbST.append(IConstants.SEPARATOR);

        /* ST-02 Transaction set Control Number */
        if (transactionControlNum.length() < MIN_LENGTH) {
            sbST.append(StringUtil.zeros(MIN_LENGTH - transactionControlNum.length()) + String.valueOf(transactionControlNum));
        } else {
            sbST.append(transactionControlNum);
        }
        sbST.append(IConstants.SEPARATOR);

        /* ST-03 Implementation Convention Reference */
        sbST.append(implementationCOnvRef);
        sbST.append(IConstants.TERMINATOR);
        LOG.info("ST CREATOR SUCCESS.");
        return sbST.toString();
    }

}
