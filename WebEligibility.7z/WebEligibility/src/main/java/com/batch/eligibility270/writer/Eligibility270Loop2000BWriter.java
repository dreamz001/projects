package com.batch.eligibility270.writer;

import static com.batch.eligibility270.writer.IConstants.LICENCE_CODE;
import static com.batch.eligibility270.writer.IConstants.MAX_EIGHTY;
import static com.batch.eligibility270.writer.IConstants.MAX_FIFTY;
import static com.batch.eligibility270.writer.IConstants.MAX_FIFTY_FIVE;
import static com.batch.eligibility270.writer.IConstants.MAX_THIRTY;
import static com.batch.eligibility270.writer.IConstants.MAX_THREE;
import static com.batch.eligibility270.writer.IConstants.MIN_TWO;
import static com.batch.eligibility270.writer.IConstants.PERSON;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.batch.eligibility.common.utility.HLUtil;
import com.batch.eligibility.common.utility.StringUtil;
import com.batch.eligibility.jsonschema270.beans.XsElement_;
import com.batch.eligibility.shared.constants.EligibilityLoopEnum;
import com.batch.eligibility.shared.constants.EligibilityTagEnum;
import com.batch.eligibility.shared.constants.RefDesgEnum;
import com.batch.eligibility270.parsing.error.Eligibility270JSOnScema;
import com.batch.eligibility270.parsing.error.Eligibility270ParserError;
import com.batch.eligibility270.parsing.error.IErrorCodeEnum;
import com.batch.eligiblity271.beans.HlSegment;
import com.batch.eligiblityshared.beans.N3Segment;
import com.batch.eligiblityshared.beans.N4Segment;
import com.batch.eligiblityshared.beans.Nm1Segment;
import com.batch.eligiblityshared.beans.PrvSegment;
import com.batch.eligiblityshared.beans.RefSegment;

/**
 * It writes 2000B-INFORMATION LEVEL and 2100B-INFORMATION RECEIVER NAME loop.
 * 
 * @author manishm3
 * @date Mar 13,2015
 */
public class Eligibility270Loop2000BWriter {
	private XsElement_ element;

	private static final Logger LOG = LoggerFactory
			.getLogger(Eligibility270Loop2000BWriter.class);

	public Eligibility270Loop2000BWriter(XsElement_ element) {
		this.element = element;
	}

	private String loop2000BWriter() {
		HlSegment hL = new HlSegment();
		hL.setHierarchicalparentid(String.valueOf(HLUtil.HL_PARENT));
		HLUtil.HL_PARENT = HLUtil.VALUE;
		hL.setHierarchicalidno(String.valueOf(HLUtil.VALUE));
		HLUtil.nextVal();
		hL.setHierarchicallevelcode(String.valueOf(HLUtil.LEVEL_TWO));
		hL.setHierarchicalchildcode(String.valueOf(HLUtil.YES_CHILD));

		return hL.writer();
	}

	public String nm1MapperWriter() {
		Nm1Segment nm1 = new Nm1Segment();

		Eligibility270JSOnScema jsonScema = new Eligibility270JSOnScema();
		Eligibility270ParserError eligibility270ParserError;
		boolean isNM104SituationalFlag = false;
		boolean isNM104Sent = false;
		boolean isNM105Sent = false;

		/* NM-101 */
		String nm101 = element.getReceiverEntityIdentifierCode();
		eligibility270ParserError = new Eligibility270ParserError();
		eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2100B,
				EligibilityTagEnum.NM1, RefDesgEnum.NM101,
				jsonScema.getReceiverEntityIdentifierCode());
		if (StringUtil.isNullOrEmpty(nm101)) {
			eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL
					.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0001_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else if (StringUtil.isLengthExceeds(MIN_TWO, MAX_THREE, nm101)) {
			eligibility270ParserError
					.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0002_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else {
			nm1.setEntityidcode(nm101);
		}

		/* NM-102 */
		String nm102 = element.getReceiverEntityTypeQualifier();
		eligibility270ParserError = new Eligibility270ParserError();
		eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2100B,
				EligibilityTagEnum.NM1, RefDesgEnum.NM102,
				jsonScema.getReceiverEntityTypeQualifier());
		if (StringUtil.isNullOrEmpty(nm102)) {
			eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL
					.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0001_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else if (StringUtil.isLengthExceeds(IConstants.MIN_ONE,
				IConstants.MAX_ONE, nm102)) {
			eligibility270ParserError
					.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0002_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else {
			if (nm102.equals(PERSON)) {
				isNM104SituationalFlag = Boolean.TRUE;
			}
			nm1.setEntitytypequalifier(nm102);
		}

		/* NM-103 */
		String nm103 = element.getReceiverLastName();
		eligibility270ParserError = new Eligibility270ParserError();
		eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2100B,
				EligibilityTagEnum.NM1, RefDesgEnum.NM103,
				jsonScema.getReceiverLastName());
		if (StringUtil.isNullOrEmpty(nm103)) {
			eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL
					.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0001_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else if (StringUtil.isLengthExceeds(IConstants.MIN_ONE,
				IConstants.MAX_SIXTY, nm103)) {
			eligibility270ParserError
					.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0002_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else {
			nm1.setNamelastorgname(nm103);
		}

		/* NM-104 */
		String nm104 = element.getReceiverFirstName();
		if (!StringUtil.isNullOrEmpty(nm104) && isNM104SituationalFlag) {
			nm1.setFirstname(nm104);
			isNM104Sent = true;
		} else {
			LOG.debug("Loop ID->2100B Segment ID-: NM RefDesg->NM104 Situational Rule->Required when 2100B NM102 is 1.");
		}

		/* NM-105 */
		String nm105 = element.getReceiverMiddleName();
		/* NM-107 */
		String nm107 = element.getReceiverSuffix();

		if (!StringUtil.isNullOrEmpty(nm105) && isNM104Sent
				&& !StringUtil.isNullOrEmpty(nm107)) {
			nm1.setMiddlename(nm105);
			isNM105Sent = true;
		} else {
			LOG.debug("Loop ID->2100B Segment ID-: NM RefDesg->NM105 Situational Rule->Required when 2100B NM104 is present and Name Suffix in 2100B NM107 if sent, are not sufficient to identify the information receiver.");
		}

		if (isNM105Sent) {
			nm1.setNamesuffix(nm107);
		} else {
			LOG.debug("Loop ID->2100B Segment ID-: NM RefDesg->NM105 Situational Rule->Required when 2100B NM104 is present and Middle Name in 2100B NM105 if sent, are not sufficient to identify the information receiver.");
		}

		/* NM-108 */
		String nm108 = element.getReceiverIdentifierCodeQualifier();
		eligibility270ParserError = new Eligibility270ParserError();
		eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2100B,
				EligibilityTagEnum.NM1, RefDesgEnum.NM108,
				jsonScema.getReceiverLastName());
		if (StringUtil.isNullOrEmpty(nm108)) {
			eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL
					.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0001_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else if (StringUtil.isLengthExceeds(IConstants.MIN_ONE,
				IConstants.MAX_TWO, nm108)) {
			eligibility270ParserError
					.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0002_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else {
			nm1.setIdcodequalifier(nm108);
		}

		/* NM-109 */
		String nm109 = element.getReceiverIdentifierCode();
		eligibility270ParserError = new Eligibility270ParserError();
		eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2100B,
				EligibilityTagEnum.NM1, RefDesgEnum.NM109,
				jsonScema.getReceiverIdentifierCode());
		if (StringUtil.isNullOrEmpty(nm109)) {
			eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL
					.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0001_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else if (StringUtil.isLengthExceeds(IConstants.MIN_TWO, MAX_EIGHTY,
				nm109)) {
			eligibility270ParserError
					.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0002_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else {
			nm1.setIdcode(nm109);
		}
		return nm1.writer();
	}

	public String refMapperWrietr() {
		RefSegment ref = new RefSegment();

		Eligibility270JSOnScema jsonScema = new Eligibility270JSOnScema();
		Eligibility270ParserError eligibility270ParserError;

		boolean isStateLiccenceNum = false;

		String ref01 = element.getReceiverIdentificationQualifier();
		String ref02 = element.getReceiverIdentification();
		String ref03 = element.getReceiverDescription();

		if (StringUtil.isNullOrEmpty(ref01) && StringUtil.isNullOrEmpty(ref02)
				&& StringUtil.isNullOrEmpty(ref03)) {
			return new String("");
		}

		eligibility270ParserError = new Eligibility270ParserError();
		eligibility270ParserError.setSegmentSituational(true);
		eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2100B,
				EligibilityTagEnum.REF, RefDesgEnum.REF01,
				jsonScema.getReceiverIdentificationQualifier());
		if (StringUtil.isNullOrEmpty(ref01)) {
			eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL
					.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0001_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else if (StringUtil.isLengthExceeds(MIN_TWO, MAX_THREE, ref01)) {
			eligibility270ParserError
					.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0002_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else {
			if (ref01.equals(LICENCE_CODE)) {
				isStateLiccenceNum = true;
			}
			ref.setRefidentificationqualifier(ref01);
		}

		eligibility270ParserError = new Eligibility270ParserError();
		eligibility270ParserError.setSegmentSituational(true);
		eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2100B,
				EligibilityTagEnum.REF, RefDesgEnum.REF02,
				jsonScema.getReceiverIdentification());
		if (StringUtil.isNullOrEmpty(ref02)) {
			eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL
					.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0001_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else if (StringUtil.isLengthExceeds(MIN_TWO, MAX_FIFTY, ref02)) {
			eligibility270ParserError
					.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0002_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else {
			ref.setRefidentification(ref02);
			;
		}

		if (StringUtil.isNullOrEmpty(ref03) && isStateLiccenceNum) {
			ref.setDescription(ref03);
		} else {
			LOG.debug("Loop ID->2100B Segment ID-: REF RefDesg->REF03 Situational Rule->Required when the identifier supplied in REF02 is the State License Number.");
		}

		return ref.writer();
	}

	public String n3MapperWriter() {
		N3Segment n3 = new N3Segment();

		Eligibility270JSOnScema jsonScema = new Eligibility270JSOnScema();
		Eligibility270ParserError eligibility270ParserError;

		String n301 = element.getReceiverAddressLine1();
		String n302 = element.getReceiverAddressLine2();

		if (StringUtil.isNullOrEmpty(n301) && StringUtil.isNullOrEmpty(n302)) {
			return new String("");
		}

		eligibility270ParserError = new Eligibility270ParserError();
		eligibility270ParserError.setSegmentSituational(true);
		eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2100B,
				EligibilityTagEnum.N3, RefDesgEnum.N301,
				jsonScema.getReceiverAddressLine1());
		if (StringUtil.isNullOrEmpty(n301)) {
			eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL
					.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0001_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else if (StringUtil.isLengthExceeds(MIN_TWO, MAX_FIFTY_FIVE, n301)) {
			eligibility270ParserError
					.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0002_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else {
			n3.setAddressinfo1(n301);
		}

		if (!StringUtil.isNullOrEmpty(n302)) {
			n3.setAddressinfo2(n302);
		}
		return n3.writer();
	}

	public String n4MapperWriter() {
		N4Segment n4 = new N4Segment();

		Eligibility270JSOnScema jsonScema = new Eligibility270JSOnScema();
		Eligibility270ParserError eligibility270ParserError;

		String n401 = element.getReceiverAddressCity();
		String n402 = element.getReceiverAddressState();
		String n403 = element.getReceiverAddressZipCode();
		String n404 = element.getReceiverAddressCountry();

		if (StringUtil.isNullOrEmpty(n401) && StringUtil.isNullOrEmpty(n402)
				&& StringUtil.isNullOrEmpty(n403)
				&& StringUtil.isNullOrEmpty(n404)) {
			return new String("");
		}

		eligibility270ParserError = new Eligibility270ParserError();
		eligibility270ParserError.setSegmentSituational(true);
		eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2100B,
				EligibilityTagEnum.N4, RefDesgEnum.N401,
				jsonScema.getReceiverAddressCity());
		if (StringUtil.isNullOrEmpty(n401)) {
			eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL
					.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0001_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else if (StringUtil.isLengthExceeds(MIN_TWO, MAX_THIRTY, n401)) {
			eligibility270ParserError
					.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0002_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else {
			n4.setCityname(n401);
		}

		if (!StringUtil.isNullOrEmpty(n402)) {
			n4.setStateorprovincecode(n402);
		}

		if (!StringUtil.isNullOrEmpty(n403)) {
			n4.setPostalcode(n403);
		}

		if (!StringUtil.isNullOrEmpty(n404)) {
			n4.setCountrycode(n404);
		}
		return n4.writer();
	}

	public String prvWriterMapper() {
		PrvSegment prv = new PrvSegment();

		Eligibility270JSOnScema jsonScema = new Eligibility270JSOnScema();
		Eligibility270ParserError eligibility270ParserError;

		String prv01 = element.getReceiverProviderCode();
		String prv02 = element.getReceiverProviderIdentificationQualifier();
		String prv03 = element.getReceiverProviderIdentification();

		if (StringUtil.isNullOrEmpty(prv01) && StringUtil.isNullOrEmpty(prv02)
				&& StringUtil.isNullOrEmpty(prv03)) {
			return new String("");
		}

		eligibility270ParserError = new Eligibility270ParserError();
		eligibility270ParserError.setSegmentSituational(true);
		eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2100B,
				EligibilityTagEnum.N4, RefDesgEnum.N401,
				jsonScema.getReceiverProviderCode());
		if (StringUtil.isNullOrEmpty(prv01)) {
			eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL
					.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0001_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else if (StringUtil.isLengthExceeds(MIN_TWO, MAX_THIRTY, prv01)) {
			eligibility270ParserError
					.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0002_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else {
			prv.setProvidercode(prv01);
		}

		if (!StringUtil.isNullOrEmpty(prv02)) {
			prv.setRefidentificationqualifier(prv02);
		}

		if (!StringUtil.isNullOrEmpty(prv03)) {
			prv.setRefidentification(prv03);
		}

		return prv.writer();
	}

	public String loop2000BAnd2100B() {
		StringBuilder sb = new StringBuilder();
		sb.append(loop2000BWriter());
		sb.append(nm1MapperWriter());
		sb.append(refMapperWrietr());
		sb.append(n3MapperWriter());
		sb.append(n4MapperWriter());
		sb.append(prvWriterMapper());
		return sb.toString();
	}
}
