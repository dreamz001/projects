package com.batch.eligibility270.request.reponse.ack;

/**
 * It contains the eroor code for response ack json.
 * 
 * @author manishm3
 * @date MAR 26,2015
 */
public interface IResponseAckErrorCode {

    String DUPLICATE_TRACE_NUMBER_OR_DB_ERROR = "101";
    String IMPROPER_JSON_FORMAT = "102";
    String VALIDATION_ERROR = "103";
    String UNKNOWN = "105";
}
