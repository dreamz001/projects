package com.batch.eligibility270.edigeneration.transmission.functionalgroup;

import java.math.BigInteger;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.batch.eligibility270.edigen.transmission.IEACreator;
import com.batch.eligibility270.edigen.transmission.functionalgroup.transaction.ICreator;
import com.batch.eligibility270.writer.IConstants;

/**
 * It has methods to create GS segment closing of GS segment of 837p.
 * 
 * @author manishm3
 */
public class GECreator implements ICreator {

	private int numOFTransactionSetIncluded; // number of transaction set
												// included.
	private BigInteger groupControlNum;

	public GECreator(int numOFTransactionSetIncluded, BigInteger groupControlNum) {
		super();
		this.numOFTransactionSetIncluded = numOFTransactionSetIncluded;
		this.groupControlNum = groupControlNum;
	}

	private static final Logger LOG = LoggerFactory.getLogger(IEACreator.class);

	@Override
	public String creator() {
		LOG.debug("Create GE.");
		StringBuilder sbGE = new StringBuilder();

		/* GE-00 Functional Group Trailer */
		sbGE.append("GE");
		sbGE.append(IConstants.SEPARATOR);

		/* GE-01 Number of Transactions Sets Included */
		sbGE.append(numOFTransactionSetIncluded);
		sbGE.append(IConstants.SEPARATOR);

		/* GE-02 Group Control Number */
		sbGE.append(groupControlNum);
		sbGE.append(IConstants.TERMINATOR);
		LOG.debug("Create GE COMPLETED.");
		return sbGE.toString();
	}

}
