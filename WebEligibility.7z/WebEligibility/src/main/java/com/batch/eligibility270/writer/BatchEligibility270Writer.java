package com.batch.eligibility270.writer;

import java.math.BigInteger;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.hibernate.HibernateException;
import org.hibernate.exception.ConstraintViolationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.batch.eligibility.base.dao.BatchIBaseDao;
import com.batch.eligibility.common.utility.HLUtil;
import com.batch.eligibility.jsonschema270.beans.XsElement_;
import com.batch.eligibility.shared.constants.EligibilityTagEnum;
import com.batch.eligibility270.edigen.transmission.IEACreator;
import com.batch.eligibility270.edigen.transmission.ISACreator;
import com.batch.eligibility270.edigen.transmission.functionalgroup.transaction.BHTCreator;
import com.batch.eligibility270.edigen.transmission.functionalgroup.transaction.ICreator;
import com.batch.eligibility270.edigen.transmission.functionalgroup.transaction.SECreator;
import com.batch.eligibility270.edigen.transmission.functionalgroup.transaction.STCreator;
import com.batch.eligibility270.edigeneration.transmission.functionalgroup.GECreator;
import com.batch.eligibility270.edigeneration.transmission.functionalgroup.GSCreator;
import com.batch.eligibility270.exception.InvalidRequestDataException;
import com.batch.eligibility270.parsing.error.Eligibility270ParserError;
import com.batch.eligibility270.request.reponse.ack.IResponseAckErrorCode;
import com.batch.eligibility271.beans.Ack999Errors;
import com.batch.eligibility271.beans.FieldWithValueBean;
import com.batch.eligibility271.beans.SegmentBean;
import com.batch.eligibility271.common.utils.SegmentParseUtility;
import com.batch.eligibility271.constants.Ack999Constants;
import com.batch.eligibility271.constants.SegmentRefDesginatorConstants;
import com.batch.eligibility271.parser.BatchEligibility271Parser;
import com.batch.emdeon.client.CoreEmdeonRequestResponse;
import com.batch.emdeon.client.EmdeonClient;
import com.batch.emdeon.client.EmdeonConfiguration;
import com.eligibility270.dbentities.Eligibility270withack;
import com.eligibility270.dbentities.EligibilityBatchInput;
import com.eligibility270.header.entities.BeginingtransactionHeader;
import com.eligibility270.header.entities.FunctionalgroupHeader;
import com.eligibility270.header.entities.InterchangeControlHeader;
import com.eligibility270.header.entities.TransactionsetHeader;
import com.eligibility270.mastertables.entities.Deliverymethod;
import com.eligibility270.mastertables.entities.ISAEntity;
import com.eligibility271.dbentities.Config;
import com.eligibility271.dbentities.Edi271shortdesc;
import com.eligibility271.dbentities.EligibilityBatchOutput;
import com.eligibility271.dbentities.Emdeonrequestresponse;

/**
 * It writes the 270 eligibility EDI.
 * 
 * @author manishm3
 * @date Mar 20,2015
 */
@Component
@Entity
public class BatchEligibility270Writer {
	private static final Logger LOG = LoggerFactory
			.getLogger(BatchEligibility270Writer.class);

	@SuppressWarnings("rawtypes")
	@Autowired
	BatchIBaseDao batchBaseDao;

	@Autowired
	private BatchEligibility271Parser batchEligibility271Parser;

	@Autowired
	ConfigLookUp configLooUp;

	@Id
	private String json;
	private boolean isPath;
	private CoreEmdeonRequestResponse emdeon;
	private String traceNumber;
	private String errorCode = "";
	private boolean errorInResponse = false;
	private String errorDescription999 = null;
	List<XsElement_> elements = null;
	// byte jsonBytes[];

	private boolean isJsoninBytes;
	private EligibilityBatchInput input;

	public static List<Eligibility270ParserError> parserErrors = new ArrayList<Eligibility270ParserError>();

	public BatchEligibility270Writer() {
	}

	/*
	 * public Eligibility270Writer(String json, boolean isPath) throws
	 * IOException { if (isPath) { this.jsonBytes =
	 * Files.readAllBytes(Paths.get(json)); isJsoninBytes = true; } else {
	 * isJsoninBytes = true; this.jsonBytes = json.getBytes(); }
	 * 
	 * }
	 */

	public ConfigLookUp getConfigLooUp() {
		return configLooUp;
	}

	public BatchIBaseDao getBaseDao() {
		return batchBaseDao;
	}

	public EligibilityBatchInput getInput() {
		return input;
	}

	public void setInput(EligibilityBatchInput input) {
		this.input = input;
	}

	public String getTraceNumber() {
		return traceNumber;
	}

	public void setTraceNumber(String traceNumber) {
		this.traceNumber = traceNumber;
	}

	@SuppressWarnings("unchecked")
	public void setConfigLooUp() {
		configLooUp.setConfigList(batchBaseDao.getConfigList());
	}

	public String getConfigValue(String configKey) {
		LOG.debug("Entering in to  Eligibility270Writer  ::  getConfigValue");
		String configValue = null;
		if (configLooUp.getConfigList() == null) {
			setConfigLooUp();
		}
		List<Config> configs = configLooUp.getConfigList();
		for (Config config : configs) {
			if (config.getKey().trim().equals(configKey)) {
				configValue = config.getValue();
				break;
			}
		}
		LOG.debug("Exiting from Eligibility270Writer :: getConfigValue");
		return configValue;
	}

	/*
	 * public void getJsonIntoBytes() throws IOException { if (isPath()) {
	 * this.jsonBytes = Files.readAllBytes(Paths.get(getJson()));
	 * this.isJsoninBytes = true; } else { this.jsonBytes = json.getBytes();
	 * this.isJsoninBytes = true; } }
	 */

	/*
	 * public void parser() throws JsonParseException, JsonMappingException,
	 * IOException { LOG.debug("Going TO JSON Parser"); if (!this.isJsoninBytes)
	 * { getJsonIntoBytes(); } ObjectMapper objectMapper = new ObjectMapper();
	 * ParsedJson parsedJson = objectMapper.readValue(jsonBytes,
	 * ParsedJson.class); XsSchema xsSchema = parsedJson.getXsSchema();
	 * XsElement xsElement = xsSchema.getXsElement(); XsComplexType
	 * xsComplexType = xsElement.getXsComplexType(); XsAll xsAll =
	 * xsComplexType.getXsAll(); List<XsElement_> xsElement_s =
	 * xsAll.getXsElement(); if (xsElement_s != null && xsElement_s.size() > 0)
	 * { this.elements = xsElement_s; } }
	 */

	/*
	 * public void loopAwriter() throws Exception { for (XsElement_ element :
	 * elements) { writeAllLoop(element); } }
	 */

	public void writeAllLoop(XsElement_ element) throws Exception {
		traceNumber = element.getEligibilityTracerNumber();
		emdeon = new CoreEmdeonRequestResponse();
		Date date = new Date();
		String deliveryMethodNameStr = element.getDeliveryMethod();
		Deliverymethod deliverymethod = new Deliverymethod();
		if (deliveryMethodNameStr != null
				&& !deliveryMethodNameStr.trim().isEmpty()) {
			deliverymethod = batchBaseDao
					.byDeliveryMethodName(deliveryMethodNameStr);
			if (deliverymethod == null)
				return;
		}
		String senderId = deliverymethod.getSenderid().trim();
		String receiverID = deliverymethod.getReceiverid().trim();
		ISAEntity isa = batchBaseDao.getISA();
		if (isa == null) {
			LOG.error("ISA segment not found in DB");
			System.out.println("ISA segment not found in DB");
			return;
		}
		/* ISA */
		InterchangeControlHeader interchangeControlHeader = createInterchangeControlHeader(
				isa, deliverymethod);
		BigInteger interchangeControlNum = batchBaseDao
				.nextVal(DBSequenceType.ISA_INTERCHANGE_CONTRON_NUMBER);
		ISACreator isaCreator = new ISACreator(interchangeControlHeader,
				interchangeControlNum, date);

		/* GS */
		BigInteger groupControlNumber = batchBaseDao
				.nextVal(DBSequenceType.GS_GROUP_CONTROL_NUMBER);
		GSCreator gsCreator = new GSCreator(groupControlNumber, date, senderId,
				receiverID);
		FunctionalgroupHeader functionalgroupHeader = createFunctionalGroupHeader(
				groupControlNumber, date, senderId, receiverID);

		/* ST */
		BigInteger transactionSetControlNumber = batchBaseDao
				.nextVal(DBSequenceType.ST_TRANSACTION_CONTROL_NUMBER);
		STCreator stCreator = new STCreator(
				String.valueOf(transactionSetControlNumber));
		TransactionsetHeader transactionsetHeader = createTransactionSetHeader(transactionSetControlNumber);

		/* BHT -03 */
		// it must be saved into database for edi tracking purpose.
		BigInteger referenceIdentification = batchBaseDao
				.nextVal(DBSequenceType.BHT_REFERENCE_IDENTIFICATION);
		BHTCreator bhtCreator = new BHTCreator(date,
				String.valueOf(referenceIdentification));
		BeginingtransactionHeader beginingtransactionHeader = createBeginingtransactionHeader(
				date, referenceIdentification);

		// createGroupedFunctionalGroup(date, senderId,
		// receiverID,deliveryMethodNameStr);

		Eligibility270Loop2000AWriter eligibility270Loop2000AWriter = new Eligibility270Loop2000AWriter(
				element);
		Eligibility270Loop2000BWriter eligibility270Loop2000BWriter = new Eligibility270Loop2000BWriter(
				element);
		Eligibility270Loop2000CWriter eligibility270Loop2000CWriter = new Eligibility270Loop2000CWriter(
				element);
		Eligibility270Loop2000DWriter eligibility270Loop2000DWriter = new Eligibility270Loop2000DWriter(
				element);

		StringBuilder eligibility270 = new StringBuilder();
		eligibility270.append(isaCreator.creator());
		eligibility270.append(gsCreator.creator());
		eligibility270.append(stCreator.creator());
		eligibility270.append(bhtCreator.creator());
		eligibility270.append(eligibility270Loop2000AWriter
				.loopInformationSource());
		eligibility270
				.append(eligibility270Loop2000BWriter.loop2000BAnd2100B());
		eligibility270.append(eligibility270Loop2000CWriter
				.loop2000C_2100C_2110C());
		eligibility270.append(eligibility270Loop2000DWriter
				.loop2000D_2100D_2110D());

		/* SE */
		String[] lines = eligibility270.toString().split("~");
		int segmentCount = lines.length - 1;
		SECreator seCreator = new SECreator(interchangeControlNum, segmentCount);
		eligibility270.append(seCreator.creator());

		/* GE */
		GECreator geCreator = new GECreator(1, groupControlNumber);
		eligibility270.append(geCreator.creator());

		/* IEA */
		IEACreator ieaCreator = new IEACreator(interchangeControlNum, 1);
		eligibility270.append(ieaCreator.creator());

		HLUtil.resetValue();

		transactionsetHeader
				.addBeginingtransactionheader(beginingtransactionHeader);
		functionalgroupHeader.addTransactionsetheader(transactionsetHeader);
		interchangeControlHeader
				.addFunctionalgroupheader(functionalgroupHeader);

		Eligibility270withack eligibility270withack = null;
		if (element.getEligibilityTracerNumber() != null) {
			eligibility270withack = new Eligibility270withack();
			eligibility270withack.setEligibility270json(getJson());
			eligibility270withack.setEligibilitytracenumber(element
					.getEligibilityTracerNumber());
			eligibility270withack.setRequestdate(new Timestamp(
					new java.util.Date().getTime()));
			if (parserErrors != null && parserErrors.isEmpty()) {
				eligibility270withack
						.setEligibilitystatuscode(IConstants.ACCEPTED); // Accepted
				eligibility270withack.setEdi270gen(eligibility270.toString());
				eligibility270withack.setEmdeonsubmissionstatus(Boolean.TRUE);
				// System.out.println("<<<<<<<<<<<<<<<<<<<Going to save file>>>>>>>>>>>>>>>>>>>");
				// FileUtil.save(eligibility270.toString(), "EMDEON", "D:\\");
				// // uncomment code to save the file to INBOX directory

			} else {
				eligibility270withack
						.setEligibilitystatuscode(IConstants.REJECTED); // Rejected
				eligibility270withack.setEdi270gen(IConstants.NO_EDI);
				eligibility270withack.setEmdeonsubmissionstatus(Boolean.FALSE);
			}
			eligibility270withack.setError(parserErrors.toString());
			eligibility270withack.setErrorcode("");
			eligibility270withack
					.setInterchangeControlHeader(interchangeControlHeader);
			eligibility270withack.setTransactionid(input.getTransactionid()
					.getId());

			try {
				batchBaseDao.saveWithAck(interchangeControlHeader,
						eligibility270withack);
			} catch (ConstraintViolationException cvExp) {
				String errorCode = IResponseAckErrorCode.DUPLICATE_TRACE_NUMBER_OR_DB_ERROR;
				errorDescription999 = cvExp.getCause().toString();
				processShortDescIfException(eligibility270.toString(),
						errorDescription999, errorCode,
						transactionSetControlNumber);
			}
			if (eligibility270withack.getEligibilitystatuscode()
					.equalsIgnoreCase(IConstants.ACCEPTED)) {
				EmdeonConfiguration configuration = new EmdeonConfiguration();
				EmdeonClient emdeonClient = configuration
						.emdeonClient(configuration.marshaller());
				BigInteger emdeonRequestResponseId = batchBaseDao
						.nextVal(DBSequenceType.EMDEON_REQUEST_RESPONSE);
				Emdeonrequestresponse emdeonrequestresponse = new Emdeonrequestresponse();
				emdeonrequestresponse.setId(emdeonRequestResponseId);
				emdeonrequestresponse
						.setEligibility270withack(eligibility270withack);
				emdeon.setEmdeon(emdeonrequestresponse);
				emdeon = emdeonClient.coreEnvelopeRealTimeResponse(emdeon,
						eligibility270.toString(), deliverymethod);
				batchBaseDao.saveEmdeon(emdeon.getEmdeon());
				if (emdeon.isExceptionOccurred()) {
					errorDescription999 = emdeon.getDescription();
					processShortDescIfException(emdeon.getResponse()
							.getPayload(), errorDescription999,
							Ack999Constants.ERROR, transactionSetControlNumber);
				} else if (emdeon.getEmdeon().getResponsetype()
						.equals(Ack999Constants.ERROR)
						|| emdeon.getEmdeon().getResponsetype()
								.equals(Ack999Constants.UNAUTHORIZED)) {
					setErrorInResponse(true);
					errorDescription999 = emdeon.getResponse()
							.getErrorMessage();
					errorCode = emdeon.getResponse().getErrorCode();
					processShortDescIfException(emdeon.getResponse()
							.getPayload(), errorDescription999, errorCode,
							transactionSetControlNumber);
				} else {
					processEDI271(emdeon.getResponse().getPayload(),
							eligibility270withack, transactionSetControlNumber);
				}
			}
		}

		if (!parserErrors.isEmpty()) {
			for (Eligibility270ParserError errr : parserErrors) {
				System.out.println(errr.toString());
			}
		}

		// if check for not null for eligibility270withack object.
		// boolean isSend=sendEdi270Emdeon(eligibility270withack);
	}

	private InterchangeControlHeader createInterchangeControlHeader(
			ISAEntity isa, Deliverymethod deliverymethod) {
		LOG.debug("CREATE INTERCHANGE CONTROL HEADER.");
		InterchangeControlHeader interchangeControlHeader = new InterchangeControlHeader();

		interchangeControlHeader.setRepetitionseprator(isa
				.getRepetitionseprator());
		interchangeControlHeader.setAckrequiredornot(isa.getAckrequiredornot());
		interchangeControlHeader.setUsageindicator(isa.getUsageindicator());
		interchangeControlHeader.setCompelementseprator(isa
				.getCompelementseprator());
		interchangeControlHeader.setIccontrolversionnum(isa
				.getIccontrolversionnum());
		interchangeControlHeader.setInterchangeidqualifier(isa
				.getInterchangeIdQualifier());
		interchangeControlHeader.setIcreceiveridqualifier(isa
				.getIcReceiverIdQualifier());
		interchangeControlHeader.setInterchangereceiverid(deliverymethod
				.getReceiverid());
		interchangeControlHeader.setInterchangesenderid(deliverymethod
				.getSenderid());

		if ((deliverymethod.getUsername() != null && !deliverymethod
				.getUsername().trim().isEmpty())
				&& (deliverymethod.getPassword() != null && !deliverymethod
						.getPassword().trim().isEmpty())) {
			interchangeControlHeader
					.setAuthinfoqualifier(IConstants.AUTHRZATION_INFORMATION_QUALIFIER_YES);
			interchangeControlHeader
					.setSecurityinfoqualifier(IConstants.SECURITY_INFO_QUALIFIER_YES);
			interchangeControlHeader.setAuthinfo(deliverymethod.getUsername());
			interchangeControlHeader.setSecurityinfo(deliverymethod
					.getPassword());

		} else {
			interchangeControlHeader.setAuthinfoqualifier(isa
					.getAuthInfoQualifier());
			interchangeControlHeader.setSecurityinfoqualifier(isa
					.getSecurityInfoQualifier());
		}
		return interchangeControlHeader;
	}

	private FunctionalgroupHeader createFunctionalGroupHeader(
			BigInteger groupControlNum, Date date, String senderId,
			String receiverID) {
		LOG.debug("CREATE FUNCTION GROUP HEADER.");
		FunctionalgroupHeader functionalgroupHeader = new FunctionalgroupHeader();
		functionalgroupHeader
				.setFunctionalidentifiercode(GSCreator.FUNCTIONAL_IDENTIFIER_CODE);
		functionalgroupHeader.setApplicationsendercode(senderId);
		functionalgroupHeader.setApplicationReceiverCode(receiverID);
		Time gsDate = new Time(date.getTime());
		functionalgroupHeader.setGsdate(gsDate);
		functionalgroupHeader.setGstime(new Timestamp(date.getTime()));
		functionalgroupHeader.setGroupcontrolnumber(groupControlNum.intValue());
		functionalgroupHeader
				.setResponsibleagencycode(GSCreator.RESPONSIBLE_AGENCY_CODE);
		functionalgroupHeader.setVersionreleaseno(ICreator.VERSION_NO);
		return functionalgroupHeader;
	}

	private TransactionsetHeader createTransactionSetHeader(
			BigInteger interchangeControlNum) {
		LOG.debug("CREATE TRANSACTION SET HEADER.");
		TransactionsetHeader transactionsetHeader = new TransactionsetHeader();
		transactionsetHeader.setTransactionsetidentifier(STCreator.EDI_TYPE);
		transactionsetHeader
				.setTransactionsetcontrolnumber(interchangeControlNum
						.intValue());
		transactionsetHeader
				.setImplementationconventionreference(ICreator.VERSION_NO);
		LOG.info("CREATE TRANSACTION SET HEADER SUCCESS.");
		return transactionsetHeader;
	}

	private BeginingtransactionHeader createBeginingtransactionHeader(
			Date date, BigInteger referenceIdentification) {
		LOG.debug("CREATE BEGINING TRANSACTION SET HEADER.");
		BeginingtransactionHeader beginingtransactionHeader = new BeginingtransactionHeader();
		beginingtransactionHeader
				.setHierarchicalstructurecode(BHTCreator.HIERARCHICAL_STRUCTURE_CODE);
		beginingtransactionHeader
				.setTransactionsetpurposecode(BHTCreator.TRANSACTION_SET_PURPOSE_CODE_ORIGINAL);
		beginingtransactionHeader
				.setReferenceidentification(referenceIdentification.intValue());
		beginingtransactionHeader.setBhtdate(new Timestamp(date.getTime()));
		beginingtransactionHeader.setBhttime(new Timestamp(date.getTime()));
		beginingtransactionHeader
				.setTransactiontypecode(BHTCreator.TRANSACTION_TYPE_CODE);
		LOG.info("CREATE BEGINING TRANSACTIONSET HEADER SUCCESS.");
		return beginingtransactionHeader;
	}

	public String getJson() {
		return json;
	}

	public void setJson(String json) {
		this.json = json;
	}

	public boolean isPath() {
		return isPath;
	}

	public void setPath(boolean isPath) {
		this.isPath = isPath;
	}

	public List<XsElement_> getElements() {
		return elements;
	}

	public void setElements(List<XsElement_> elements) {
		this.elements = elements;
	}

	/*
	 * public byte[] getJsonBytes() { return jsonBytes; }
	 * 
	 * public void setJsonBytes(byte[] jsonBytes) { this.jsonBytes = jsonBytes;
	 * }
	 */

	public boolean isJsoninBytes() {
		return isJsoninBytes;
	}

	public void setJsoninBytes(boolean isJsoninBytes) {
		this.isJsoninBytes = isJsoninBytes;
	}

	public static List<Eligibility270ParserError> getParserErrors() {
		return parserErrors;
	}

	public static void setParserErrors(
			List<Eligibility270ParserError> parserErrors) {
		BatchEligibility270Writer.parserErrors = parserErrors;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public boolean isErrorInResponse() {
		return errorInResponse;
	}

	public void setErrorInResponse(boolean errorInResponse) {
		this.errorInResponse = errorInResponse;
	}

	public String getErrorDescription999() {
		return errorDescription999;
	}

	public void setErrorDescription999(String errorDescription999) {
		this.errorDescription999 = errorDescription999;
	}

	public CoreEmdeonRequestResponse getEmdeon() {
		return emdeon;
	}

	public void setEmdeon(CoreEmdeonRequestResponse emdeon) {
		this.emdeon = emdeon;
	}

	public BatchEligibility271Parser getEligibility271Parser() {
		return batchEligibility271Parser;
	}

	public void setEligibility271Parser(
			BatchEligibility271Parser batchEligibility271Parser) {
		this.batchEligibility271Parser = batchEligibility271Parser;
	}

	/*
	 * this method is used to parse the response EDI(999 OR 271)
	 */
	public void processEDI271(String eligibility271,
			Eligibility270withack eligibility270withack,
			BigInteger transactionSetControlNumber) {
		LOG.debug("Parse the Response.");
		// String
		// eligibility271="ISA*00* *00* *ZZ*CMS *ZZ*SUBMITTERID *140831*0758*^*00501*111111111*0*P*|~GS*HB*CMS*SUBMITTERID*20140831*07580000*1*X*005010X279A1~ST*271*4322*005010X279~BHT*0022*11*10001235*20060501*1319~HL*1**20*1~NM1*PR*2*ABC COMPANY*****PI*842610001~HL*2*1*21*1~NM1*1P*2*BONE AND JOINT CLINIC*****SV*2000035~HL*3*2*22*1~NM1*IL*1*SMITH*JOHN****MI*123456789~N3*15197 BROADWAY AVENUE*APT 215~N4*KANSAS CITY*MO*64108~DMG*D8*19630519*M~HL*4*3*23*1~TRN*2*000000120*9877281234~NM1*03*1*SMITH*MARY~N3*15197 BROADWAY AVENUE*APT 215~N4*KANSAS CITY*MO*64108~DMG*D8*19981014*F~INS*N*19~DTP*346*D8*20060101~EB*1**32**GOLD 123 PLAN~MSG*Free form text is discouraged~EB*L~LS*2120~NM1*P3*1*JONES*MARCUS****SV*0202034~LE*2120~DTP*346*D8*20060101~EB*1**1^33^35^47^86^88^98^AL^MH^UC~EB*B**1^33^35^47^86^88^98^AL^MH^UC*HM*GOLD 123 PLAN*27*10*****Y~EB*B**1^33^35^47^86^88^98^AL^MH^UC*HM*GOLD 123 PLAN*27*30*****N~SE*28*4322~GE*1*1~IEA*1*111111111~";
		batchEligibility271Parser.setDtpDef();
		System.out.println(eligibility271);
		ArrayList<SegmentBean> segmentBeansList = SegmentParseUtility
				.parseEligibility271String(eligibility271);
		SegmentBean segmentBeanST = getSegmentBeanFromListBySegmentTag(
				EligibilityTagEnum.ST, segmentBeansList);
		if (isContent(Ack999Constants.ACK999, segmentBeanST)) {
			// if 999 then add errors in json
			processAndUpdateAck999Info(eligibility271, segmentBeansList,
					transactionSetControlNumber);
		} else if (isContent(Ack999Constants.EDI271, segmentBeanST)) {
			batchEligibility271Parser.setEligibility270Writer(this);
			// if 271 then create shortDesc json
			SegmentBean segmentBeanAAA = getSegmentBeanFromListBySegmentTag(
					EligibilityTagEnum.AAA, segmentBeansList);
			batchEligibility271Parser.getShortDesc(segmentBeansList,
					eligibility271, eligibility270withack, segmentBeanAAA);
			if (segmentBeanAAA == null) {
				// if 271 then create LongDesc json
				batchEligibility271Parser.getLongDesc(segmentBeansList,
						eligibility271, eligibility270withack);
			}
		}
		// batchEligibility271Parser.restClient();
		// batchEligibility271Parser.restClient2();
		LOG.debug("Parse the Response Completed.");
	}

	/*
	 * this method is used to get a particular segment (elTag) from the list of
	 * segments
	 */
	public SegmentBean getSegmentBeanFromListBySegmentTag(
			EligibilityTagEnum elTag, ArrayList<SegmentBean> segmentBeanList) {
		SegmentBean segBean = null;
		for (SegmentBean segmentBean : segmentBeanList) {
			if (segmentBean.getSegmentName().equals(elTag)) {
				segBean = segmentBean;
				break;
			}
		}
		return segBean;
	}

	/*
	 * this method is used to get all particular segment list (elTag) from the
	 * list of segments
	 */
	public ArrayList<SegmentBean> getSegmentBeansFromListBySegmentTag(
			EligibilityTagEnum elTag, ArrayList<SegmentBean> segmentBeanList) {
		ArrayList<SegmentBean> segBeans = new ArrayList<SegmentBean>();
		for (SegmentBean segmentBean : segmentBeanList) {
			if (segmentBean.getSegmentName().equals(elTag)) {
				segBeans.add(segmentBean);
			}
		}
		return segBeans;
	}

	/*
	 * this method is to check the content type of ACK
	 */
	public boolean isContent(String ack999Constants, SegmentBean stSegmentBean) {
		LOG.info("Check ACK Content Type.");
		FieldWithValueBean st01Field = stSegmentBean
				.getFieldBeanByFieldName(SegmentRefDesginatorConstants.ST01);
		if (st01Field.getFieldValue().equals(ack999Constants)) {
			return true;
		} else
			return false;
	}

	/*
	 * This method shows 999 error if we receive 999 EDI in response
	 */
	private void processAndUpdateAck999Info(String ack999String,
			ArrayList<SegmentBean> segmentBeanList,
			BigInteger transactionSetControlNumber) {
		LOG.debug("Parse the Response(999 EDI) and add errors in json .");
		errorCode = Ack999Constants.ACK999;
		setErrorInResponse(true);
		if (segmentBeanList != null && !segmentBeanList.isEmpty()) {
			SegmentBean stSegmentBean = getSegmentBeanFromListBySegmentTag(
					EligibilityTagEnum.ST, segmentBeanList);
			FieldWithValueBean st01Field = stSegmentBean
					.getFieldBeanByFieldName(SegmentRefDesginatorConstants.ST01);
			if (st01Field.getFieldValue().equals(Ack999Constants.ACK999)) {
				SegmentBean ak1SegmentBean = getSegmentBeanFromListBySegmentTag(
						EligibilityTagEnum.AK1, segmentBeanList);
				SegmentBean ak2SegmentBean = getSegmentBeanFromListBySegmentTag(
						EligibilityTagEnum.AK2, segmentBeanList);
				ArrayList<SegmentBean> ik3SegmentBeans = getSegmentBeansFromListBySegmentTag(
						EligibilityTagEnum.IK3, segmentBeanList);
				ArrayList<SegmentBean> ik4SegmentBeans = getSegmentBeansFromListBySegmentTag(
						EligibilityTagEnum.IK4, segmentBeanList);
				SegmentBean ik5SegmentBean = getSegmentBeanFromListBySegmentTag(
						EligibilityTagEnum.IK5, segmentBeanList);
				if (ak1SegmentBean != null && ak2SegmentBean != null) {
					FieldWithValueBean edi270responseOrNot = ak2SegmentBean
							.getFieldBeanByFieldName(SegmentRefDesginatorConstants.AK201);
					if (edi270responseOrNot.getFieldValue().equals(
							Ack999Constants.EDI270)) {
						// FieldWithValueBean edi837stControlNum =
						// ak2SegmentBean.getFieldBeanByFieldName(SegmentRefDesginatorConstants.AK202);
						// FieldWithValueBean edi837gsControlNum =
						// ak1SegmentBean.getFieldBeanByFieldName(SegmentRefDesginatorConstants.AK102);

						FieldWithValueBean ediAcceptOrReject = null;
						if (ik5SegmentBean == null) {
							SegmentBean ak9SegmentBean = getSegmentBeanFromListBySegmentTag(
									EligibilityTagEnum.AK9, segmentBeanList);
							if (ak9SegmentBean != null) {
								ediAcceptOrReject = ak9SegmentBean
										.getFieldBeanByFieldName(SegmentRefDesginatorConstants.AK901);
							}
						} else {
							ediAcceptOrReject = ik5SegmentBean
									.getFieldBeanByFieldName(SegmentRefDesginatorConstants.IK501);
						}
						// String errorStr="";
						if (ediAcceptOrReject != null) {
							ArrayList<Ack999Errors> errors999 = new ArrayList<Ack999Errors>();
							for (int i = 0; i < ik3SegmentBeans.size(); i++) {
								Ack999Errors error999 = new Ack999Errors();
								FieldWithValueBean ik301 = ik3SegmentBeans.get(
										i).getFieldBeanByFieldName(
										SegmentRefDesginatorConstants.IK301);
								FieldWithValueBean ik303 = ik3SegmentBeans.get(
										i).getFieldBeanByFieldName(
										SegmentRefDesginatorConstants.IK303);
								FieldWithValueBean ik401 = ik4SegmentBeans.get(
										i).getFieldBeanByFieldName(
										SegmentRefDesginatorConstants.IK401);
								FieldWithValueBean ik404 = ik4SegmentBeans.get(
										i).getFieldBeanByFieldName(
										SegmentRefDesginatorConstants.IK404);
								error999.setData(ik404.getFieldValue());
								error999.setLoopid(ik303.getFieldValue());
								error999.setElementPosition(ik401
										.getFieldValue());
								error999.setSegmentName(ik301.getFieldValue());
								errors999.add(error999);
							}
							setErrorDescription999(errors999.toString());
							processShortDescIfException(ack999String,
									errors999.toString(),
									Ack999Constants.ACK999,
									transactionSetControlNumber);

						}

					}

				}

			}

		}
		LOG.debug("Parse the Response(999 EDI) Completed.");
	}

	public void processRequest(String request) {
		BigInteger tracerNumber = new BigInteger("0");
		try {
			tracerNumber = batchBaseDao
					.nextVal(DBSequenceType.ELIGIBILITY_BATCH_TRACER_NUMBER);
			String trcernum = String.valueOf(tracerNumber);
			while (trcernum.length() < 8) {
				trcernum = "0" + trcernum;
			}
			trcernum = "B" + trcernum;
			try {

				XsElement_ element = new XsElement_(request, trcernum);
				batchEligibility271Parser.setInsuranceId(element
						.getPrimaryInsuredIdentifierCode());
				writeAllLoop(element);
			} catch (InvalidRequestDataException irde) {
				LOG.error("Error while parsing the Input CSV as request.", irde);
				processShortDescIfException(request, irde.getMessage(),
						IConstants.INVALID_REQUEST, IConstants.MINUS_ONE);
			}

		} catch (Exception e) {
			LOG.error("Error while generating and processing 270 EDI.", e);
			processShortDescIfException(request,
					IConstants.INVALID_DESCRIPTION, IConstants.INVALID_REQUEST,
					IConstants.MINUS_ONE);
		}

	}

	public void processShortDescIfException(String ediMessage,
			String errorMessage, String error,
			BigInteger transactionSetControlNumber) {
		Edi271shortdesc shortDesc = new Edi271shortdesc();
		shortDesc.setEligibilityoutcomemessage(errorMessage);
		shortDesc.setEligibilityoutcomecode(error);
		shortDesc.setTransactionsetcontrolnumber(transactionSetControlNumber
				.intValue());
		shortDesc.setEdimessage(ediMessage);
		shortDesc.setEligibilitytracernumber(traceNumber);

		try {
			if (transactionSetControlNumber != IConstants.MINUS_ONE) {
				batchBaseDao.save(shortDesc); // saving the short description of
				// Error in db if error is not from
				// Input csv
			}
			/*
			 * EligibilityResponseNotification eligibilityResponseNotification =
			 * batchEligibility271Parser
			 * .getELiEligibilityResponseNotification(shortDesc); ObjectMapper
			 * objectMapper = new ObjectMapper(); String jsonShort=null; try {
			 * jsonShort=
			 * objectMapper.writeValueAsString(eligibilityResponseNotification);
			 * 
			 * } catch (JsonProcessingException e) { LOG.error(
			 * "Exception while parsing short description from response as JSON"
			 * , e); }
			 */
			// batchEligibility271Parser.addShortDescToList(jsonShort);
			EligibilityBatchOutput output = new EligibilityBatchOutput();
			input.setStatus(IConstants.IN_PROGRESS);
			output.setEdimessage(ediMessage);
			output.setEligibilitytracenumber(traceNumber);
			output.setTransactionid(input.getTransactionid());
			output.setId(input.getId());
			output.setEligibilityoutcomecode(error);
			output.setEligibilityoutcomemessage(errorMessage);
			output.setTransactionsetcontrolnumber(transactionSetControlNumber
					.intValue());

			batchBaseDao.save(output);
			batchBaseDao.update(input);
			// System.out.println(jsonShort);
		} catch (HibernateException he) {
			LOG.error("Exception while saving short description from response",
					he);
		}

	}

}
