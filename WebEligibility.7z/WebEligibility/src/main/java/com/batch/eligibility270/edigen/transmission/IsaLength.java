package com.batch.eligibility270.edigen.transmission;

/**
 * 
 * @author Manish Mishra Purpose : contain enums corresponding to ISA fields
 *         length
 *
 */

public enum IsaLength {
    ISA01_MIN(2), // Authorization InformationQualifier
    ISA01_MAX(2),

    ISA02_MIN(10), // AuthorizationInformation
    ISA02_MAX(10),

    ISA03_MIN(2), // Security InformationQualifier
    ISA03_MAX(2),

    ISA04_MIN(10), // security Information
    ISA04_MAX(10),

    ISA05_MIN(2), // Interchange ID qualifier
    ISA05_MAX(2),

    ISA06_MIN(2), // Interchange Sender ID
    ISA06_MAX(15),

    ISA07_MIN(2), // Interchange ID Qualifier
    ISA07_MAX(2),

    ISA08_MIN(15), // Interchange Receiver ID
    ISA08_MAX(15),

    ISA10_MIN(4), // Interchange Time(HHMM-current time)
    ISA10_MAX(4),

    ISA11_MIN(1), // Repetition separator
    ISA11_MAX(1),

    ISA12_MIN(5), // Interchange Control Version Number
    ISA12_MAX(5),

    ISA13_MIN(9), // Interchange Control Number
    ISA13_MAX(9),

    ISA15_MIN(1), // Usage Indicator
    ISA15_MAX(1),

    ISA16_MIN(1), // Component Element Separator.
    ISA16_MAX(1);

    private Integer val;

    private IsaLength(Integer val) {
        this.val = val;
    }

    public Integer value() {
        return val;
    }
}
