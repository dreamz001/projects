package com.batch.eligibility270.writer;

/**
 * 
 * @author Manish Mishra Purpose : Enum contains constants related to database
 *         sequence name used to hold primary id for related table
 *
 */

public enum DBSequenceType {
    ISA_INTERCHANGE_CONTRON_NUMBER("eligibility.eligibility_270_Interchange_Control_Num_seq"), // ISA
    GS_GROUP_CONTROL_NUMBER("eligibility.eligibility_270_Group_Control_Number_seq"), // GS
    ST_TRANSACTION_CONTROL_NUMBER("eligibility.eligibility_270_Transaction_Set_Control_Num_seq"), // ST
    BHT_REFERENCE_IDENTIFICATION("eligibility.eligibility_270_reference_identification_seq"), // BHT
    ELIGIBILITY_BATCH_INPUT("eligibility.eligibility_batch_input_id_seq"), //eligibility_batch_input_id_seq
    ELIGIBILITY_BATCH_INPUT_TRANSACTION_ID("eligibility.eligibility_batch_input_transaction_id_seq"), // eligibility.eligibility_batch_input_transaction_id_seq
    ELIGIBILITY_BATCH_TRACER_NUMBER("eligibility.eligibility_batch_tracernumber"), // eligibility.eligibility_batch_tracernumber
    EMDEON_REQUEST_RESPONSE("eligibility.emdeonrequestresponse_id_seq"); // emdeonrequestresponse_id_seq
    

    private String sequence;

    private DBSequenceType(String sequence) {
        this.sequence = sequence;
    }

    public String value() {
        return sequence;
    }
}
