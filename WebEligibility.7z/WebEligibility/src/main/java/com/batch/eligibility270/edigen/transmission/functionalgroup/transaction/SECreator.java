package com.batch.eligibility270.edigen.transmission.functionalgroup.transaction;

import java.math.BigInteger;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.batch.eligibility.common.utility.StringUtil;
import com.batch.eligibility270.writer.IConstants;

/**
 * It creates SE segment closing of ST segment in 837P.
 * 
 * @author manishm3
 * @date DEC 5,2014
 */

public class SECreator implements ICreator {

    private final int MIN = 4;
    private final int MAX = 9;

    private BigInteger transactionSetControlNum;
    private int numOfIncludeSegs; // Number of Included Segments

    public SECreator(BigInteger transactionSetControlNum, int numOfIncludeSegs) {
        super();
        this.transactionSetControlNum = transactionSetControlNum;
        this.numOfIncludeSegs = numOfIncludeSegs;
    }

    private static final Logger LOG = LoggerFactory.getLogger(SECreator.class);

    @Override
    public String creator() {
        LOG.debug("SE-Creator.");
        StringBuilder sbSe = new StringBuilder();

        /* SE-00 Transaction Set Trailer */
        sbSe.append("SE");
        sbSe.append(IConstants.SEPARATOR);

        /* SE-01 Number of Included Segments */
        sbSe.append(numOfIncludeSegs);
        sbSe.append(IConstants.SEPARATOR);

        /* SE-02 Transaction Set Control Number */
        if ((String.valueOf(transactionSetControlNum)).length() >= MIN && (String.valueOf(transactionSetControlNum)).length() <= MAX) {
            sbSe.append(transactionSetControlNum);
        } else if ((String.valueOf(transactionSetControlNum)).length() < MIN) {
            sbSe.append(StringUtil.zeros(MIN - (String.valueOf(transactionSetControlNum)).length()) + transactionSetControlNum);
        } else if ((String.valueOf(transactionSetControlNum)).length() < MAX) {
            sbSe.append(StringUtil.zeros(MAX - (String.valueOf(transactionSetControlNum)).length()) + transactionSetControlNum);
        }
        sbSe.append(IConstants.TERMINATOR);
        LOG.debug("SE-Creator COMPLETED.");
        return sbSe.toString();
    }

}
