package com.batch.eligibility270.parsing.error;

/**
 * It contains all error codes for 271 eligibility inquiry parsing.
 * 
 * @author manishm3
 *
 */
public enum IErrorCodeEnum {
	C0001_MISSING_VAL("0001"),
	C0002_INVALID_LENGTH("0002"),
	C0003_INVALID_DATA_TYPE("0003"),
	C0004_MISMATCH_FIELD("0004"),
	C0005_JSONMPAPPING("0005"),
	C0006_MULTIPLE_TYPE_OF_ERROR("0006"),
	
	C0001_VAL("MISSING FIELD VALUE"),                     
	C0002_VAL("INVALID LENGTH OF FIELD"),                 
	C0003_VAL("INVALID DATA TYPE OF FIELD"),              
	C0004_VAL("MISMATCH FIELDS"),                         
	C0005_VAL("JSON SCHEMA COLUMN MAPPING MISSING"),    
	C0006_VAL("MULTIPLE TYPE OF ERROR");

    private String val;

    private IErrorCodeEnum(String val) {
        this.val = val;
    }

    public String value() {
        return val;
    }
}
