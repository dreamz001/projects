package com.batch.eligibility270.edigen.transmission.functionalgroup.transaction;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.batch.eligibility270.writer.IConstants;

/**
 * BHT - Beginning of Hierarchical Transaction It creates teh BHT segment.
 * 
 * @author manishm3
 * @date DEC 05,2014
 */
public class BHTCreator implements ICreator {

    public static final String HIERARCHICAL_STRUCTURE_CODE = "0022";
    public static final String TRANSACTION_SET_PURPOSE_CODE_ORIGINAL = "13";
    public static final int TRANSACTION_SET_PURPOSE_CODE_REISSUE = 18;

    private Date date;

    /*
     * Just for tracking purpose, Software should generate unique EDI File Batch
     * Number. length- 1/50 Required value
     */
    private String rferenceIdentification;

    /* ************************************************************************************************************
     * 31 Subrogation Demand
     * 
     * CH Chargeable – Use this code when the transaction contains only fee for
     * service claims or claims with at least one chargeable line item. if it is
     * not clear whether a transaction contains claims or encounters, or if the
     * transaction contains a mix of claims and encounters.
     * 
     * RP Reporting – Use RP When the entire ST-SE envelope contains encounters.
     * Use RP When the transaction is being sent to an entity.
     * ******************
     * ********************************************************
     * ********************************
     */
    public static final String TRANSACTION_TYPE_CODE = "CH";

    private static final Logger LOG = LoggerFactory.getLogger(BHTCreator.class);

    public BHTCreator(Date date, String rferenceIdentification) {
        super();
        this.date = date;
        this.rferenceIdentification = rferenceIdentification;
    }

    @Override
    public String creator() {

        LOG.debug("BHT CREATOR.");
        StringBuilder sbBHT = new StringBuilder();
        /* BHT-00 Beginning of Hierarchical Segment */
        sbBHT.append("BHT");
        sbBHT.append(IConstants.SEPARATOR);

        /* BHT-01 Hierarchical Structure Code */
        sbBHT.append(HIERARCHICAL_STRUCTURE_CODE);
        sbBHT.append(IConstants.SEPARATOR);

        /* BHT-02 Transaction set purpose Code */
        sbBHT.append(TRANSACTION_SET_PURPOSE_CODE_ORIGINAL);
        sbBHT.append(IConstants.SEPARATOR);

        /* BHT-03 Reference Identification */
        // just for tracking purpose, Software should generate unique EDI File
        // Batch Number.
        sbBHT.append(rferenceIdentification);
        sbBHT.append(IConstants.SEPARATOR);

        /* BHT-04 Date (Current date in YYYYMMDD Format) */
        SimpleDateFormat df = new SimpleDateFormat("yyyyMMdd");
        sbBHT.append(df.format(date));
        sbBHT.append(IConstants.SEPARATOR);

        /* BHT-05 Interchange ID Qualifier (Current time in HHMMSS Format) */
        SimpleDateFormat itQualifier = new SimpleDateFormat("HHmmss");
        sbBHT.append(itQualifier.format(date));
        sbBHT.append(IConstants.TERMINATOR);

        /* BHT-06 Transaction Type Code */
        /*
         * sbBHT.append(TRANSACTION_TYPE_CODE);
         * sbBHT.append(IConstants.TERMINATOR);
         */

        LOG.info("BHT CREATOR COMPLETED.");
        return sbBHT.toString();
    }

}
