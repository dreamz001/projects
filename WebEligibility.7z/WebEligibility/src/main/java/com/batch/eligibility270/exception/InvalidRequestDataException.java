package com.batch.eligibility270.exception;

public class InvalidRequestDataException extends Exception {

	private static final long serialVersionUID = 1L;

	public InvalidRequestDataException(String message) {
		super(message);
	}

}
