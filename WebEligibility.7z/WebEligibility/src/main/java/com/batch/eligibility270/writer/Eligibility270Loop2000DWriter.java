package com.batch.eligibility270.writer;

import static com.batch.eligibility270.writer.IConstants.MAX_FIFTY;
import static com.batch.eligibility270.writer.IConstants.MAX_ONE;
import static com.batch.eligibility270.writer.IConstants.MAX_TEN;
import static com.batch.eligibility270.writer.IConstants.MAX_THIRTY;
import static com.batch.eligibility270.writer.IConstants.MAX_THREE;
import static com.batch.eligibility270.writer.IConstants.MAX_TWO;
import static com.batch.eligibility270.writer.IConstants.MIN_ONE;
import static com.batch.eligibility270.writer.IConstants.MIN_TEN;
import static com.batch.eligibility270.writer.IConstants.MIN_THREE;
import static com.batch.eligibility270.writer.IConstants.MIN_TWO;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.batch.eligibility.common.utility.HLUtil;
import com.batch.eligibility.common.utility.StringUtil;
import com.batch.eligibility.jsonschema270.beans.XsElement_;
import com.batch.eligibility.shared.constants.EligibilityLoopEnum;
import com.batch.eligibility.shared.constants.EligibilityTagEnum;
import com.batch.eligibility.shared.constants.RefDesgEnum;
import com.batch.eligibility270.beans.EqSegment;
import com.batch.eligibility270.beans.InsSegment;
import com.batch.eligibility270.parsing.error.Eligibility270JSOnScema;
import com.batch.eligibility270.parsing.error.Eligibility270ParserError;
import com.batch.eligibility270.parsing.error.IErrorCodeEnum;
import com.batch.eligiblity271.beans.HlSegment;
import com.batch.eligiblityshared.beans.Compositemedicalprocedure;
import com.batch.eligiblityshared.beans.DmgSegment;
import com.batch.eligiblityshared.beans.DtpSegment;
import com.batch.eligiblityshared.beans.IiiSegment;
import com.batch.eligiblityshared.beans.N3Segment;
import com.batch.eligiblityshared.beans.N4Segment;
import com.batch.eligiblityshared.beans.Nm1Segment;
import com.batch.eligiblityshared.beans.PrvSegment;
import com.batch.eligiblityshared.beans.RefSegment;
import com.batch.eligiblityshared.beans.TrnSegment;

/**
 * @author Manish
 * @date MAR 20,2015
 */
public class Eligibility270Loop2000DWriter {
	private XsElement_ element;

	private static final Logger LOG = LoggerFactory
			.getLogger(Eligibility270Loop2000DWriter.class);

	public Eligibility270Loop2000DWriter(XsElement_ element) {
		this.element = element;
	}

	private String loop2000DWriter() {
		LOG.debug("Entering in to  Eligibility270Loop2000DWriter  ::  loop2000DWriter");
		HlSegment hL = new HlSegment();
		hL.setHierarchicalparentid(String.valueOf(HLUtil.HL_PARENT));
		HLUtil.HL_PARENT = HLUtil.VALUE;
		hL.setHierarchicalidno(String.valueOf(HLUtil.VALUE));
		HLUtil.nextVal();
		hL.setHierarchicallevelcode(String.valueOf(HLUtil.LEVEL_FOUR));
		hL.setHierarchicalchildcode(String.valueOf(HLUtil.NO_CHILD));
		LOG.debug("Exiting from Eligibility270Loop2000DWriter :: loop2000DWriter");
		return hL.writer();
	}

	// trn

	public String nm1MapperWriter() {
		LOG.debug("Entering in to  Eligibility270Loop2000DWriter  ::  nm1MapperWriter");
		Nm1Segment nm1 = new Nm1Segment();

		Eligibility270JSOnScema jsonScema = new Eligibility270JSOnScema();
		Eligibility270ParserError eligibility270ParserError;

		/* NM-101 */
		String nm101 = element.getDependentEntityIdentifierCode();
		eligibility270ParserError = new Eligibility270ParserError();
		eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2100D,
				EligibilityTagEnum.NM1, RefDesgEnum.NM101,
				jsonScema.getDependentEntityIdentifierCode());
		if (StringUtil.isNullOrEmpty(nm101)) {
			eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL
					.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0001_VAL.value());
			if (!HLUtil.isSelf) {
				BatchEligibility270Writer.parserErrors
						.add(eligibility270ParserError);
			}
		} else if (StringUtil.isLengthExceeds(MIN_TWO, MAX_THREE, nm101)) {
			eligibility270ParserError
					.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0002_VAL.value());
			if (!HLUtil.isSelf) {
				BatchEligibility270Writer.parserErrors
						.add(eligibility270ParserError);
			}
		} else {
			nm1.setEntityidcode(nm101);
		}

		/* NM-102 */
		String nm102 = element.getDependentEntityTypeQualifier();
		eligibility270ParserError = new Eligibility270ParserError();
		eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2100D,
				EligibilityTagEnum.NM1, RefDesgEnum.NM102,
				jsonScema.getDependentEntityTypeQualifier());
		if (StringUtil.isNullOrEmpty(nm102)) {
			eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL
					.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0001_VAL.value());
			if (!HLUtil.isSelf) {
				BatchEligibility270Writer.parserErrors
						.add(eligibility270ParserError);
			}
		} else if (StringUtil.isLengthExceeds(IConstants.MIN_ONE,
				IConstants.MAX_ONE, nm102)) {
			eligibility270ParserError
					.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0002_VAL.value());
			if (!HLUtil.isSelf) {
				BatchEligibility270Writer.parserErrors
						.add(eligibility270ParserError);
			}
		} else {
			nm1.setEntitytypequalifier(nm102);
		}

		/* NM-103 */
		String nm103 = element.getDependentLastName();
		if (!StringUtil.isNullOrEmpty(nm103)) {
			nm1.setNamelastorgname(nm103);
		}
		/* NM-104 */
		String nm104 = element.getDependentFirstName();
		if (!StringUtil.isNullOrEmpty(nm104)) {
			nm1.setFirstname(nm104);
		}
		/* NM-105 */
		String nm105 = element.getDependentMiddleInitial();
		if (!StringUtil.isNullOrEmpty(nm105)) {
			nm1.setMiddlename(nm105);
		}
		/* NM-107 */
		String nm107 = element.getDependentSuffix();
		if (!StringUtil.isNullOrEmpty(nm107)) {
			nm1.setNamesuffix(nm107);
		}
		LOG.debug("Exiting from Eligibility270Loop2000DWriter :: nm1MapperWriter");
		return nm1.writer();
	}

	public String refMapperWrietr() {
		LOG.debug("Entering in to  Eligibility270Loop2000DWriter  ::  refMapperWrietr");
		RefSegment ref = new RefSegment();

		Eligibility270JSOnScema jsonScema = new Eligibility270JSOnScema();
		Eligibility270ParserError eligibility270ParserError;

		String ref01 = element.getDependentIdentificationQualifier();
		String ref02 = element.getDependentIdentification();
		if (StringUtil.isNullOrEmpty(ref01) && StringUtil.isNullOrEmpty(ref02)) {
			return new String("");
		}

		eligibility270ParserError = new Eligibility270ParserError();
		eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2100D,
				EligibilityTagEnum.REF, RefDesgEnum.REF01,
				jsonScema.getDependentIdentificationQualifier());
		if (StringUtil.isNullOrEmpty(ref01)) {
			eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL
					.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0001_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else if (StringUtil.isLengthExceeds(IConstants.MIN_TWO,
				IConstants.MAX_THREE, ref01)) {
			eligibility270ParserError
					.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0002_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else {
			ref.setRefidentificationqualifier(ref01);
		}

		eligibility270ParserError = new Eligibility270ParserError();
		eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2100D,
				EligibilityTagEnum.REF, RefDesgEnum.REF02,
				jsonScema.getDependentIdentification());
		if (StringUtil.isNullOrEmpty(ref02)) {
			eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL
					.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0001_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else if (StringUtil.isLengthExceeds(IConstants.MIN_TWO,
				IConstants.MAX_FIFTY, ref02)) {
			eligibility270ParserError
					.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0002_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else {
			ref.setRefidentification(ref02);
		}
		LOG.debug("Exiting from Eligibility270Loop2000DWriter :: refMapperWrietr");
		return ref.writer();
	}

	public String n3MapperWriter() {
		LOG.debug("Entering in to  Eligibility270Loop2000DWriter  ::  n3MapperWriter");
		N3Segment n3 = new N3Segment();

		Eligibility270JSOnScema jsonScema = new Eligibility270JSOnScema();
		Eligibility270ParserError eligibility270ParserError;

		String n301 = element.getDependentAddressLine1();
		String n302 = element.getDependentAddressLine2();
		if (StringUtil.isNullOrEmpty(n301) && StringUtil.isNullOrEmpty(n302)) {
			return new String("");
		}

		eligibility270ParserError = new Eligibility270ParserError();
		eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2100D,
				EligibilityTagEnum.N3, RefDesgEnum.N301,
				jsonScema.getDependentAddressLine1());
		if (StringUtil.isNullOrEmpty(n301)) {
			eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL
					.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0001_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else if (StringUtil.isLengthExceeds(IConstants.MIN_ONE,
				IConstants.MAX_FIFTY_FIVE, n301)) {
			eligibility270ParserError
					.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0002_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else {
			n3.setAddressinfo1(n301);
		}

		if (!StringUtil.isNullOrEmpty(n302)) {
			n3.setAddressinfo2(n302);
		}
		LOG.debug("Exiting from Eligibility270Loop2000DWriter :: n3MapperWriter");
		return n3.writer();
	}

	public String n4MapperWriter() {
		LOG.debug("Entering in to  Eligibility270Loop2000DWriter  ::  n4MapperWriter");
		N4Segment n4 = new N4Segment();

		Eligibility270JSOnScema jsonScema = new Eligibility270JSOnScema();
		Eligibility270ParserError eligibility270ParserError;

		String n401 = element.getDependentAddressCity();
		String n402 = element.getDependentAddressState();
		String n403 = element.getDependentAddressZipCode();
		String n404 = element.getDependentAddressCountry();

		if (StringUtil.isNullOrEmpty(n401) && StringUtil.isNullOrEmpty(n402)
				&& StringUtil.isNullOrEmpty(n403)
				&& StringUtil.isNullOrEmpty(n404)) {
			return new String("");
		}

		eligibility270ParserError = new Eligibility270ParserError();
		eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2100C,
				EligibilityTagEnum.N4, RefDesgEnum.N401,
				jsonScema.getDependentAddressCity());
		if (StringUtil.isNullOrEmpty(n401)) {
			eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL
					.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0001_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else if (StringUtil.isLengthExceeds(MIN_TWO, MAX_THIRTY, n401)) {
			eligibility270ParserError
					.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0002_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else {
			n4.setCityname(n401);
		}

		if (!StringUtil.isNullOrEmpty(n402)) {
			n4.setStateorprovincecode(n402);
		}

		if (!StringUtil.isNullOrEmpty(n403)) {
			n4.setPostalcode(n403);
		}

		if (!StringUtil.isNullOrEmpty(n404)) {
			n4.setCountrycode(n404);
		}
		LOG.debug("Exiting from Eligibility270Loop2000DWriter :: n4MapperWriter");
		return n4.writer();
	}

	public String prvWriterMapper() {
		LOG.debug("Entering in to  Eligibility270Loop2000DWriter  ::  prvWriterMapper");
		PrvSegment prv = new PrvSegment();

		Eligibility270JSOnScema jsonScema = new Eligibility270JSOnScema();
		Eligibility270ParserError eligibility270ParserError;

		String prv01 = element.getDependentProviderCode();
		String prv02 = element.getDependentProviderIdentificationQualifier();
		String prv03 = element.getDependentProviderIdentification();

		if (StringUtil.isNullOrEmpty(prv01) && StringUtil.isNullOrEmpty(prv02)
				&& StringUtil.isNullOrEmpty(prv03)) {
			return new String("");
		}

		eligibility270ParserError = new Eligibility270ParserError();
		eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2100D,
				EligibilityTagEnum.PRV, RefDesgEnum.PRV01,
				jsonScema.getDependentProviderCode());
		if (StringUtil.isNullOrEmpty(prv01)) {
			eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL
					.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0001_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else if (StringUtil.isLengthExceeds(MIN_ONE, MAX_THREE, prv01)) {
			eligibility270ParserError
					.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0002_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else {
			prv.setProvidercode(prv01);
		}

		boolean isPrv02 = false;

		if (!StringUtil.isNullOrEmpty(prv02)) {
			prv.setRefidentificationqualifier(prv02);
			isPrv02 = true;
		}

		if (!StringUtil.isNullOrEmpty(prv03) && isPrv02) {
			prv.setRefidentification(prv03);
		} else {
			LOG.debug("Loop ID->2100D Segment ID-: PRV RefDesg->PRV03 Situational Rule->Required when PRV02 is used.");
		}
		LOG.debug("Exiting from Eligibility270Loop2000DWriter :: prvWriterMapper");
		return prv.writer();
	}

	public String dmgWriterMapper() {
		LOG.debug("Entering in to  Eligibility270Loop2000DWriter  ::  dmgWriterMapper");
		DmgSegment dmg = new DmgSegment();
		String dmg01 = element.getDependentDemographicsDateQualifier();
		if (dmg01 != null && !dmg01.trim().isEmpty()) {
			dmg.setDatetimeformatqualifier(dmg01);
		}
		String dmg02 = element.getDependentDemographicsDateOfBirth();
		if (dmg02 != null && !dmg02.trim().isEmpty()) {
			dmg.setDatetimeperiod(dmg02);
		}
		String dmg03 = element.getDependentDemographicsGenderCode();
		if (dmg03 != null && !dmg03.trim().isEmpty()) {
			dmg.setGendercode(dmg03);
		}
		LOG.debug("Exiting from Eligibility270Loop2000DWriter :: dmgWriterMapper");
		return dmg.writer();
	}

	public String insWriterMapper() throws NumberFormatException {
		LOG.debug("Entering in to  Eligibility270Loop2000DWriter  ::  insWriterMapper");
		InsSegment ins = new InsSegment();

		Eligibility270JSOnScema jsonScema = new Eligibility270JSOnScema();
		Eligibility270ParserError eligibility270ParserError;

		String ins01 = element.getDependentInsuredIndicator();
		String ins02 = element.getRelationShipCode();
		String ins17 = element.getDependentBirthSequenceNumber();

		if (StringUtil.isNullOrEmpty(ins01) && StringUtil.isNullOrEmpty(ins17)) {
			return new String("");
		}

		eligibility270ParserError = new Eligibility270ParserError();
		eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2100D,
				EligibilityTagEnum.INS, RefDesgEnum.INS01,
				jsonScema.getDependentInsuredIndicator());
		if (StringUtil.isNullOrEmpty(ins01)) {
			eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL
					.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0001_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else if (StringUtil.isLengthExceeds(MIN_ONE, MAX_ONE, ins01)) {
			eligibility270ParserError
					.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0002_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else {
			ins.setYesNoCondRespCode(ins01);
		}

		eligibility270ParserError = new Eligibility270ParserError();
		eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2100C,
				EligibilityTagEnum.INS, RefDesgEnum.INS02,
				jsonScema.getDependentIndividualRelationshipCode());
		if (StringUtil.isNullOrEmpty(ins02)) {
			eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL
					.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0001_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else if (StringUtil.isLengthExceeds(MIN_TWO, MAX_TWO, ins02)) {
			eligibility270ParserError
					.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0002_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else {
			ins.setIndividualRelatCode(ins02);
		}

		if (!StringUtil.isNullOrEmpty(ins17)) {
			ins.setNumber(Integer.valueOf(ins17));
		}
		LOG.debug("Exiting from Eligibility270Loop2000DWriter :: insWriterMapper");
		return ins.writer();
	}

	public String dtpWriterMapper() {
		LOG.debug("Entering in to  Eligibility270Loop2000DWriter  ::  dtpWriterMapper");
		DtpSegment dtp = new DtpSegment();

		Eligibility270JSOnScema jsonScema = new Eligibility270JSOnScema();
		Eligibility270ParserError eligibility270ParserError;

		String dtp01 = element.getDependentDateQualifier();
		String dtp02 = element.getDependentDateFormatQualifier();
		String dtp03 = element.getDependentDatePeriod();

		if (StringUtil.isNullOrEmpty(dtp01) && StringUtil.isNullOrEmpty(dtp02)
				&& StringUtil.isNullOrEmpty(dtp03)) {
			return new String("");
		}

		eligibility270ParserError = new Eligibility270ParserError();
		eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2100D,
				EligibilityTagEnum.DTP, RefDesgEnum.DTP01,
				jsonScema.getDependentDateQualifier());
		if (StringUtil.isNullOrEmpty(dtp01)) {
			eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL
					.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0001_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else if (StringUtil.isLengthExceeds(MIN_THREE, MAX_THREE, dtp01)) {
			eligibility270ParserError
					.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0002_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else {
			dtp.setDatetimequalifier(dtp01);
		}

		eligibility270ParserError = new Eligibility270ParserError();
		eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2100D,
				EligibilityTagEnum.DTP, RefDesgEnum.DTP02,
				jsonScema.getDependentDateFormatQualifier());
		if (StringUtil.isNullOrEmpty(dtp02)) {
			eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL
					.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0001_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else if (StringUtil.isLengthExceeds(MIN_TWO, MAX_THREE, dtp02)) {
			eligibility270ParserError
					.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0002_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else {
			dtp.setDatetimeformatqualifier(dtp02);
		}

		eligibility270ParserError = new Eligibility270ParserError();
		eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2100D,
				EligibilityTagEnum.DTP, RefDesgEnum.DTP03,
				jsonScema.getDependentDatePeriod());
		if (StringUtil.isNullOrEmpty(dtp03)) {
			eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL
					.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0001_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else if (StringUtil.isLengthExceeds(MIN_ONE,
				IConstants.MAX_THIRTY_FIVE, dtp03)) {
			eligibility270ParserError
					.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0002_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else {
			dtp.setDatetimeperiod(dtp03);
		}
		LOG.debug("Exiting from Eligibility270Loop2000DWriter :: dtpWriterMapper");
		return dtp.writer();
	}

	/*-------------Loop-2100D Begins--------------------------*/
	public String eqWriterMapperLoop2110D() {
		LOG.debug("Entering in to  Eligibility270Loop2000DWriter  ::  eqWriterMapperLoop2110D");
		EqSegment eq = new EqSegment();

		String eq01 = element.getDependentServiceTypeCode();
		if (eq01 != null && !eq01.trim().isEmpty()) {
			eq.setServiceTypeCode(eq01);
		}

		int flag = IConstants.NOT_CREATABLE;
		Compositemedicalprocedure compositemedicalprocedure = new Compositemedicalprocedure();
		String eq0201 = element.getDependentServiceIdentificationQualifier();
		if (eq0201 != null && !eq0201.trim().isEmpty()) {
			compositemedicalprocedure.setProductserviceidqualifier(eq0201);
			flag = IConstants.CREATABLE;
		}
		String eq0202 = element.getDependentProcedureCode();
		if (eq0202 != null && !eq0202.trim().isEmpty()) {
			compositemedicalprocedure.setProductserviceid1(eq0202);
			flag = IConstants.CREATABLE;
		}

		String eq0203 = element.getDependentProcedureMod1();
		if (eq0203 != null && !eq0203.trim().isEmpty()) {
			compositemedicalprocedure.setProceduremodifier1(eq0203);
			flag = IConstants.CREATABLE;
		}
		String eq0204 = element.getDependentProcedureMod2();
		if (eq0204 != null && !eq0204.trim().isEmpty()) {
			compositemedicalprocedure.setProceduremodifier2(eq0204);
			flag = IConstants.CREATABLE;
		}

		String eq0205 = element.getDependentProcedureMod3();
		if (eq0205 != null && !eq0205.trim().isEmpty()) {
			compositemedicalprocedure.setProceduremodifier3(eq0205);
			flag = IConstants.CREATABLE;
		}

		String eq0206 = element.getDependentProcedureMod4();
		if (eq0206 != null && !eq0206.trim().isEmpty()) {
			compositemedicalprocedure.setProceduremodifier4(eq0206);
			flag = IConstants.CREATABLE;
		}
		String eq0207 = element.getDependentDescription();
		if (eq0207 != null && !eq0207.trim().isEmpty()) {
			compositemedicalprocedure.setDescription(eq0207);
			flag = IConstants.CREATABLE;
		}
		if (flag == IConstants.CREATABLE) {
			eq.setCompMedProcId(compositemedicalprocedure);
		}

		String eq03 = element.getDependentInsuranceType();
		if (eq03 != null && !eq03.trim().isEmpty()) {
			eq.setCoverageLevelCode(eq03);
		}

		String eq04 = element.getDependentCoverageLevelCode();
		if (eq04 != null && !eq04.trim().isEmpty()) {
			eq.setInsuranceTypeCode(eq04);
		}
		LOG.debug("Exiting from Eligibility270Loop2000DWriter :: eqWriterMapperLoop2110D");
		return eq.writer();
	}

	public String iiiWriterMapperLoop2110D() {
		LOG.debug("Entering in to  Eligibility270Loop2000DWriter  ::  iiiWriterMapperLoop2110D");
		IiiSegment iii = new IiiSegment();

		Eligibility270JSOnScema jsonScema = new Eligibility270JSOnScema();
		Eligibility270ParserError eligibility270ParserError;

		String iii01 = element.getDependentListQualifierCode();
		String iii02 = element.getDependentIndustryCode();

		if (StringUtil.isNullOrEmpty(iii01) && StringUtil.isNullOrEmpty(iii01)) {
			return new String("");
		}

		eligibility270ParserError = new Eligibility270ParserError();
		eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2110D,
				EligibilityTagEnum.III, RefDesgEnum.III01,
				jsonScema.getDependentListQualifierCode());
		if (StringUtil.isNullOrEmpty(iii01)) {
			eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL
					.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0001_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else if (StringUtil.isLengthExceeds(MIN_ONE, MAX_THREE, iii01)) {
			eligibility270ParserError
					.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0002_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else {
			iii.setCodeListQualCode(iii01);
		}

		eligibility270ParserError = new Eligibility270ParserError();
		eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2110D,
				EligibilityTagEnum.III, RefDesgEnum.III02,
				jsonScema.getDependentIndustryCode());
		if (StringUtil.isNullOrEmpty(iii02)) {
			eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL
					.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0001_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else if (StringUtil.isLengthExceeds(MIN_ONE, MAX_THIRTY, iii02)) {
			eligibility270ParserError
					.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0002_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else {
			iii.setIndustryCode(iii02);
		}
		LOG.debug("Exiting from Eligibility270Loop2000DWriter :: iiiWriterMapperLoop2110D");
		return iii.writer();
	}

	public String refMapperWrietrLoop2110D() {
		LOG.debug("Entering in to  Eligibility270Loop2000DWriter  ::  refMapperWrietrLoop2110D");
		RefSegment ref = new RefSegment();

		Eligibility270JSOnScema jsonScema = new Eligibility270JSOnScema();
		Eligibility270ParserError eligibility270ParserError;

		String ref01 = element.getDependentInformationIdentificationQualifier();
		String ref02 = element.getDependentInformationIdentification();

		if (StringUtil.isNullOrEmpty(ref01) && StringUtil.isNullOrEmpty(ref02)) {
			return new String("");
		}

		eligibility270ParserError = new Eligibility270ParserError();
		eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2110D,
				EligibilityTagEnum.REF, RefDesgEnum.REF01,
				jsonScema.getDependentInformationIdentificationQualifier());
		if (StringUtil.isNullOrEmpty(ref01)) {
			eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL
					.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0001_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else if (StringUtil.isLengthExceeds(MIN_TWO, MAX_THREE, ref01)) {
			eligibility270ParserError
					.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0002_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else {
			ref.setRefidentificationqualifier(ref01);
		}

		eligibility270ParserError = new Eligibility270ParserError();
		eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2110D,
				EligibilityTagEnum.REF, RefDesgEnum.REF02,
				jsonScema.getDependentInformationIdentification());
		if (StringUtil.isNullOrEmpty(ref02)) {
			eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL
					.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0001_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else if (StringUtil.isLengthExceeds(MIN_TWO, MAX_FIFTY, ref02)) {
			eligibility270ParserError
					.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0002_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else {
			ref.setRefidentification(ref02);
			;
		}
		LOG.debug("Exiting from Eligibility270Loop2000DWriter :: refMapperWrietrLoop2110D");
		return ref.writer();
	}

	public String dtpWriterMapperLoop2110D() {
		LOG.debug("Entering in to  Eligibility270Loop2000DWriter  ::  dtpWriterMapperLoop2110D");
		DtpSegment dtp = new DtpSegment();

		Eligibility270JSOnScema jsonScema = new Eligibility270JSOnScema();
		Eligibility270ParserError eligibility270ParserError;

		String dtp01 = element.getDependentEligibilityDateQualifier();
		String dtp02 = element.getDependentEligibilityDateFormatQualifier();
		String dtp03 = element.getDependentEligibilityDatePeriod();

		if (StringUtil.isNullOrEmpty(dtp01) && StringUtil.isNullOrEmpty(dtp02)
				&& StringUtil.isNullOrEmpty(dtp03)) {
			return new String("");
		}

		eligibility270ParserError = new Eligibility270ParserError();
		eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2100D,
				EligibilityTagEnum.DTP, RefDesgEnum.DTP01,
				jsonScema.getDependentEligibilityDateQualifier());
		if (StringUtil.isNullOrEmpty(dtp01)) {
			eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL
					.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0001_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else if (StringUtil.isLengthExceeds(MIN_THREE, MAX_THREE, dtp01)) {
			eligibility270ParserError
					.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0002_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else {
			dtp.setDatetimequalifier(dtp01);
		}

		eligibility270ParserError = new Eligibility270ParserError();
		eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2110C,
				EligibilityTagEnum.DTP, RefDesgEnum.DTP02,
				jsonScema.getDependentEligibilityDateFormatQualifier());
		if (StringUtil.isNullOrEmpty(dtp02)) {
			eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL
					.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0001_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else if (StringUtil.isLengthExceeds(MIN_TWO, MAX_THREE, dtp02)) {
			eligibility270ParserError
					.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0002_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else {
			dtp.setDatetimeformatqualifier(dtp02);
		}

		eligibility270ParserError = new Eligibility270ParserError();
		eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2110D,
				EligibilityTagEnum.DTP, RefDesgEnum.DTP03,
				jsonScema.getDependentEligibilityDatePeriod());
		if (StringUtil.isNullOrEmpty(dtp03)) {
			eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL
					.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0001_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else if (StringUtil.isLengthExceeds(MIN_ONE,
				IConstants.MAX_THIRTY_FIVE, dtp03)) {
			eligibility270ParserError
					.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
			eligibility270ParserError
					.setError(IErrorCodeEnum.C0002_VAL.value());
			BatchEligibility270Writer.parserErrors
					.add(eligibility270ParserError);
		} else {
			dtp.setDatetimeperiod(dtp03);
		}
		LOG.debug("Exiting from Eligibility270Loop2000DWriter :: dtpWriterMapperLoop2110D");
		return dtp.writer();
	}

	private String trnMapperWriter() {
		LOG.debug("Entering in to  Eligibility270Loop2000DWriter  ::  trnMapperWriter");
		if (!HLUtil.isSelf) {
			HLUtil.isSelf = Boolean.FALSE;

			Eligibility270JSOnScema jsonScema = new Eligibility270JSOnScema();
			Eligibility270ParserError eligibility270ParserError;

			TrnSegment trn = new TrnSegment();

			String trn01 = element.getEligibilityTracerCode();
			String trn02 = element.getEligibilityTracerNumber();
			String trn03 = element.getEligibilityEntityIdentifier();
			String trn04 = element.getEligibilityEntityAdditionalIdentifier();
			if (StringUtil.isNullOrEmpty(trn01)
					&& StringUtil.isNullOrEmpty(trn02)
					&& StringUtil.isNullOrEmpty(trn03)
					&& StringUtil.isNullOrEmpty(trn04)) {
				return new String("");
			}

			eligibility270ParserError = new Eligibility270ParserError();
			eligibility270ParserError.setErrorDesc(
					EligibilityLoopEnum.LOOP2100C, EligibilityTagEnum.TRN,
					RefDesgEnum.TRN01, jsonScema.getEligibilityTracerCode());
			if (StringUtil.isNullOrEmpty(trn01)) {
				eligibility270ParserError
						.setCode(IErrorCodeEnum.C0001_MISSING_VAL.value());
				eligibility270ParserError.setError(IErrorCodeEnum.C0001_VAL
						.value());
				BatchEligibility270Writer.parserErrors
						.add(eligibility270ParserError);
			} else if (StringUtil.isLengthExceeds(MIN_ONE, MAX_TWO, trn01)) {
				eligibility270ParserError
						.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
				eligibility270ParserError.setError(IErrorCodeEnum.C0002_VAL
						.value());
				BatchEligibility270Writer.parserErrors
						.add(eligibility270ParserError);
			} else {
				trn.setTraceIdCode(trn01);
			}

			eligibility270ParserError = new Eligibility270ParserError();
			eligibility270ParserError.setErrorDesc(
					EligibilityLoopEnum.LOOP2100C, EligibilityTagEnum.TRN,
					RefDesgEnum.TRN02, jsonScema.getEligibilityTracerNumber());
			if (StringUtil.isNullOrEmpty(trn02)) {
				eligibility270ParserError
						.setCode(IErrorCodeEnum.C0001_MISSING_VAL.value());
				eligibility270ParserError.setError(IErrorCodeEnum.C0001_VAL
						.value());
				BatchEligibility270Writer.parserErrors
						.add(eligibility270ParserError);
			} else if (StringUtil.isLengthExceeds(MIN_ONE, MAX_FIFTY, trn02)) {
				eligibility270ParserError
						.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
				eligibility270ParserError.setError(IErrorCodeEnum.C0002_VAL
						.value());
				BatchEligibility270Writer.parserErrors
						.add(eligibility270ParserError);
			} else {
				trn.setReferenceIden1(trn02);
			}

			eligibility270ParserError = new Eligibility270ParserError();
			eligibility270ParserError.setErrorDesc(
					EligibilityLoopEnum.LOOP2100C, EligibilityTagEnum.TRN,
					RefDesgEnum.TRN03,
					jsonScema.getEligibilityEntityIdentifier());
			if (StringUtil.isNullOrEmpty(trn03)) {
				eligibility270ParserError
						.setCode(IErrorCodeEnum.C0001_MISSING_VAL.value());
				eligibility270ParserError.setError(IErrorCodeEnum.C0001_VAL
						.value());
				BatchEligibility270Writer.parserErrors
						.add(eligibility270ParserError);
			} else if (StringUtil.isLengthExceeds(MIN_TEN, MAX_TEN, trn03)) {
				eligibility270ParserError
						.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
				eligibility270ParserError.setError(IErrorCodeEnum.C0002_VAL
						.value());
				BatchEligibility270Writer.parserErrors
						.add(eligibility270ParserError);
			} else {
				trn.setOriginatingCompId(trn03);
			}

			if (!StringUtil.isNullOrEmpty(trn04)) {
				trn.setReferenceIden2(trn04);
			}

			return trn.writer();
		}
		LOG.debug("Exiting from Eligibility270Loop2000DWriter :: trnMapperWriter");
		return new String();
	}

	public String loop2000D_2100D_2110D() {
		LOG.debug("Entering in to  Eligibility270Loop2000DWriter  ::  loop2000D_2100D_2110D");
		StringBuilder sb = new StringBuilder();

		if (HLUtil.isSelf) {
			return "";
		}
		String nm1seg = nm1MapperWriter();
		if (!StringUtil.isNullOrEmpty(nm1seg)) {
			sb.append(loop2000DWriter());
		}

		sb.append(trnMapperWriter());

		/* Loop 2100C */
		sb.append(nm1seg);
		sb.append(refMapperWrietr());
		sb.append(n3MapperWriter());
		sb.append(n4MapperWriter());
		sb.append(prvWriterMapper());
		sb.append(dmgWriterMapper());
		sb.append(insWriterMapper());
		sb.append(dtpWriterMapper());

		/* Loop 2110C */
		sb.append(eqWriterMapperLoop2110D());
		sb.append(iiiWriterMapperLoop2110D());
		sb.append(refMapperWrietrLoop2110D());
		sb.append(dtpWriterMapperLoop2110D());
		LOG.debug("Exiting from Eligibility270Loop2000DWriter :: loop2000D_2100D_2110D");
		return sb.toString();
	}

}
