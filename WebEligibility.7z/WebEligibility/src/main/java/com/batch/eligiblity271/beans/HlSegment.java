package com.batch.eligiblity271.beans;

import java.io.Serializable;

import com.batch.eligibility.shared.constants.EligibilityTagEnum;
import com.batch.eligibility270.writer.IConstants;

/**
 * 
 * @author shailendras4 Purpose : Bean corresponding to HL segment
 */

public class HlSegment implements Serializable {
	private static final long serialVersionUID = 1L;

	private Integer hlid;

	private String hierarchicalchildcode;

	private String hierarchicalidno;

	private String hierarchicallevelcode;

	private String hierarchicalparentid;

	public HlSegment() {
	}

	public Integer getHlid() {
		return this.hlid;
	}

	public void setHlid(Integer hlid) {
		this.hlid = hlid;
	}

	public String getHierarchicalchildcode() {
		return this.hierarchicalchildcode;
	}

	public void setHierarchicalchildcode(String hierarchicalchildcode) {
		this.hierarchicalchildcode = hierarchicalchildcode;
	}

	public String getHierarchicalidno() {
		return this.hierarchicalidno;
	}

	public void setHierarchicalidno(String hierarchicalidno) {
		this.hierarchicalidno = hierarchicalidno;
	}

	public String getHierarchicallevelcode() {
		return this.hierarchicallevelcode;
	}

	public void setHierarchicallevelcode(String hierarchicallevelcode) {
		this.hierarchicallevelcode = hierarchicallevelcode;
	}

	public String getHierarchicalparentid() {
		return this.hierarchicalparentid;
	}

	public void setHierarchicalparentid(String hierarchicalparentid) {
		this.hierarchicalparentid = hierarchicalparentid;
	}

	public String writer() {
		StringBuilder sb = new StringBuilder();
		sb.append(EligibilityTagEnum.HL.value());
		sb.append(IConstants.SEPARATOR);

		/* HL-01 */
		sb.append((hierarchicalidno != null && !hierarchicalidno.isEmpty()) ? hierarchicalidno
				+ IConstants.SEPARATOR
				: IConstants.SEPARATOR);
		/* HL-02 */
		sb.append((hierarchicalparentid != null && !hierarchicalparentid
				.isEmpty()) ? hierarchicalparentid + IConstants.SEPARATOR
				: IConstants.SEPARATOR);
		/* HL-03 */
		sb.append((hierarchicallevelcode != null && !hierarchicallevelcode
				.isEmpty()) ? hierarchicallevelcode + IConstants.SEPARATOR
				: IConstants.SEPARATOR);
		/* HL-04 */
		sb.append((hierarchicalchildcode != null && !hierarchicalchildcode
				.isEmpty()) ? hierarchicalchildcode + IConstants.TERMINATOR
				: IConstants.TERMINATOR);

		return sb.toString();
	}

}