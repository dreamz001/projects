package com.batch.eligiblity271.beans;

import java.io.Serializable;

/**
 * 
 * @author shailendras4 Purpose : Bean corresponding to AAA Segment
 */
public class AaaSegment implements Serializable {

	private static final long serialVersionUID = -1254622450263767297L;

	private String responseCode;
	private String agencyQualifierCode;
	private String rejectReasonCode;
	private String followUpActionCode;

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	public String getAgencyQualifierCode() {
		return agencyQualifierCode;
	}

	public void setAgencyQualifierCode(String agencyQualifierCode) {
		this.agencyQualifierCode = agencyQualifierCode;
	}

	public String getRejectReasonCode() {
		return rejectReasonCode;
	}

	public void setRejectReasonCode(String rejectReasonCode) {
		this.rejectReasonCode = rejectReasonCode;
	}

	public String getFollowUpActionCode() {
		return followUpActionCode;
	}

	public void setFollowUpActionCode(String followUpActionCode) {
		this.followUpActionCode = followUpActionCode;
	}

}
