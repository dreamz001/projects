package com.batch.eligiblity271.beans;

import java.io.Serializable;

/**
 * 
 * @author shailendras4 Purpose : Bean class corresponding to LE segment
 */

public class LeSegment implements Serializable {

	private static final long serialVersionUID = -6673319954899453092L;

	private String loopIdentifierCode;

	public String getLoopIdentifierCode() {
		return loopIdentifierCode;
	}

	public void setLoopIdentifierCode(String loopIdentifierCode) {
		this.loopIdentifierCode = loopIdentifierCode;
	}

}
