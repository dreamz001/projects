package com.batch.eligiblity271.beans;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @author shailendras4 Purpose : Bean class corresponding HSD segment
 */
public class HsdSegment implements Serializable {

	private static final long serialVersionUID = -992460114343827384L;

	private String quantityQualifier;

	private BigDecimal quantity;

	private String unitOrBasisMeasureCode;

	private BigDecimal sampleSelectionModulus;

	private String timePeriodQualifier;

	private Integer numberOfPeriods;

	private String shipDelOrCalPatternCode;

	private String shipDelOrCalTimeCode;

	public String getQuantityQualifier() {
		return quantityQualifier;
	}

	public void setQuantityQualifier(String quantityQualifier) {
		this.quantityQualifier = quantityQualifier;
	}

	public BigDecimal getQuantity() {
		return quantity;
	}

	public void setQuantity(BigDecimal quantity) {
		this.quantity = quantity;
	}

	public String getUnitOrBasisMeasureCode() {
		return unitOrBasisMeasureCode;
	}

	public void setUnitOrBasisMeasureCode(String unitOrBasisMeasureCode) {
		this.unitOrBasisMeasureCode = unitOrBasisMeasureCode;
	}

	public BigDecimal getSampleSelectionModulus() {
		return sampleSelectionModulus;
	}

	public void setSampleSelectionModulus(BigDecimal sampleSelectionModulus) {
		this.sampleSelectionModulus = sampleSelectionModulus;
	}

	public String getTimePeriodQualifier() {
		return timePeriodQualifier;
	}

	public void setTimePeriodQualifier(String timePeriodQualifier) {
		this.timePeriodQualifier = timePeriodQualifier;
	}

	public Integer getNumberOfPeriods() {
		return numberOfPeriods;
	}

	public void setNumberOfPeriods(Integer numberOfPeriods) {
		this.numberOfPeriods = numberOfPeriods;
	}

	public String getShipDelOrCalPatternCode() {
		return shipDelOrCalPatternCode;
	}

	public void setShipDelOrCalPatternCode(String shipDelOrCalPatternCode) {
		this.shipDelOrCalPatternCode = shipDelOrCalPatternCode;
	}

	public String getShipDelOrCalTimeCode() {
		return shipDelOrCalTimeCode;
	}

	public void setShipDelOrCalTimeCode(String shipDelOrCalTimeCode) {
		this.shipDelOrCalTimeCode = shipDelOrCalTimeCode;
	}

}
