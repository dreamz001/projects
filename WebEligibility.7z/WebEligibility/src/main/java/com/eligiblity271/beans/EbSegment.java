package com.eligiblity271.beans;

import java.io.Serializable;
import java.math.BigDecimal;

import com.eligiblityshared.beans.Compositemedicalprocedure;
import com.eligiblityshared.beans.Diagnosiscodepointer;

/**
 * @author Manish
 * @date MAR 20,2015
 */
public class EbSegment implements Serializable {

    private static final long serialVersionUID = -6366221562266755274L;

    private String eligiblityOrBenfitInfoCode;

    private String coverageLevelCode;

    private String serviceTypeCode;

    private String insuranceTypecode;

    private String planCoverageDescription;

    private String timePeriodQualifier;

    private BigDecimal monetaryAmount;

    private BigDecimal percent;

    private String quantityQualifier;

    private BigDecimal quanity;

    private String responseCode1; // EB11

    private String reponseCode2; // EB12

    private Compositemedicalprocedure compositeMedicalProcId;

    private Diagnosiscodepointer dianosisCodePointer;

    public String getEligiblityOrBenfitInfoCode() {
        return eligiblityOrBenfitInfoCode;
    }

    public void setEligiblityOrBenfitInfoCode(String eligiblityOrBenfitInfoCode) {
        this.eligiblityOrBenfitInfoCode = eligiblityOrBenfitInfoCode;
    }

    public String getCoverageLevelCode() {
        return coverageLevelCode;
    }

    public void setCoverageLevelCode(String coverageLevelCode) {
        this.coverageLevelCode = coverageLevelCode;
    }

    public String getServiceTypeCode() {
        return serviceTypeCode;
    }

    public void setServiceTypeCode(String serviceTypeCode) {
        this.serviceTypeCode = serviceTypeCode;
    }

    public String getInsuranceTypecode() {
        return insuranceTypecode;
    }

    public void setInsuranceTypecode(String insuranceTypecode) {
        this.insuranceTypecode = insuranceTypecode;
    }

    public String getPlanCoverageDescription() {
        return planCoverageDescription;
    }

    public void setPlanCoverageDescription(String planCoverageDescription) {
        this.planCoverageDescription = planCoverageDescription;
    }

    public String getTimePeriodQualifier() {
        return timePeriodQualifier;
    }

    public void setTimePeriodQualifier(String timePeriodQualifier) {
        this.timePeriodQualifier = timePeriodQualifier;
    }

    public BigDecimal getMonetaryAmount() {
        return monetaryAmount;
    }

    public void setMonetaryAmount(BigDecimal monetaryAmount) {
        this.monetaryAmount = monetaryAmount;
    }

    public BigDecimal getPercent() {
        return percent;
    }

    public void setPercent(BigDecimal percent) {
        this.percent = percent;
    }

    public String getQuantityQualifier() {
        return quantityQualifier;
    }

    public void setQuantityQualifier(String quantityQualifier) {
        this.quantityQualifier = quantityQualifier;
    }

    public BigDecimal getQuanity() {
        return quanity;
    }

    public void setQuanity(BigDecimal quanity) {
        this.quanity = quanity;
    }

    public String getResponseCode1() {
        return responseCode1;
    }

    public void setResponseCode1(String responseCode1) {
        this.responseCode1 = responseCode1;
    }

    public String getReponseCode2() {
        return reponseCode2;
    }

    public void setReponseCode2(String reponseCode2) {
        this.reponseCode2 = reponseCode2;
    }

    public Compositemedicalprocedure getCompositeMedicalProcId() {
        return compositeMedicalProcId;
    }

    public void setCompositeMedicalProcId(Compositemedicalprocedure compositeMedicalProcId) {
        this.compositeMedicalProcId = compositeMedicalProcId;
    }

    public Diagnosiscodepointer getDianosisCodePointer() {
        return dianosisCodePointer;
    }

    public void setDianosisCodePointer(Diagnosiscodepointer dianosisCodePointer) {
        this.dianosisCodePointer = dianosisCodePointer;
    }

}
