package com.eligiblity271.beans;

import java.io.Serializable;

/**
 * 
 * @author shailendras4 Purpose : Bean class corresponding MSG segment
 */

public class MsgSegment implements Serializable {

    private static final long serialVersionUID = -3336894236735616501L;

    private String freeFormText;

    public String getFreeFormText() {
        return freeFormText;
    }

    public void setFreeFormText(String freeFormText) {
        this.freeFormText = freeFormText;
    }
}
