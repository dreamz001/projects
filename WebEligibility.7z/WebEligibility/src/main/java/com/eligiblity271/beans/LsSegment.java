package com.eligiblity271.beans;

import java.io.Serializable;

/**
 * 
 * @author shailendras4 Purpose : Bean class corresponding to LS segment
 */
public class LsSegment implements Serializable {

    private static final long serialVersionUID = -1907452039943338870L;

    private String loopIdentifierCode;

    public String getLoopIdentifierCode() {
        return loopIdentifierCode;
    }

    public void setLoopIdentifierCode(String loopIdentifierCode) {
        this.loopIdentifierCode = loopIdentifierCode;
    }

}
