package com.eligiblity271.beans;

import java.io.Serializable;

/**
 * 
 * @author shailendras4 Purpose : Bean class corresponding to MPI segment
 */
public class MpiSegment implements Serializable {

    private static final long serialVersionUID = 7962199011356304550L;

    private String informationStatusCode;

    private String employementStatusCode;

    private String govtServiceAffiliationCode;

    private String description;

    private String militaryServiceRankCode;

    private String dateTimeFormatQualifier;

    private String dateTimePeriod;

    public String getInformationStatusCode() {
        return informationStatusCode;
    }

    public void setInformationStatusCode(String informationStatusCode) {
        this.informationStatusCode = informationStatusCode;
    }

    public String getEmployementStatusCode() {
        return employementStatusCode;
    }

    public void setEmployementStatusCode(String employementStatusCode) {
        this.employementStatusCode = employementStatusCode;
    }

    public String getGovtServiceAffiliationCode() {
        return govtServiceAffiliationCode;
    }

    public void setGovtServiceAffiliationCode(String govtServiceAffiliationCode) {
        this.govtServiceAffiliationCode = govtServiceAffiliationCode;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getMilitaryServiceRankCode() {
        return militaryServiceRankCode;
    }

    public void setMilitaryServiceRankCode(String militaryServiceRankCode) {
        this.militaryServiceRankCode = militaryServiceRankCode;
    }

    public String getDateTimeFormatQualifier() {
        return dateTimeFormatQualifier;
    }

    public void setDateTimeFormatQualifier(String dateTimeFormatQualifier) {
        this.dateTimeFormatQualifier = dateTimeFormatQualifier;
    }

    public String getDateTimePeriod() {
        return dateTimePeriod;
    }

    public void setDateTimePeriod(String dateTimePeriod) {
        this.dateTimePeriod = dateTimePeriod;
    }

}
