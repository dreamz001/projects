package com.eligiblityshared.beans;

import java.io.Serializable;

/**
 * @author shailendras4 Purpose : Bean class corresponding Composite medical
 *         procedure field
 */

public class Compositemedicalprocedure implements Serializable {

    private static final long serialVersionUID = -328439463349834314L;

    private Integer medicalprocedureid;
    private String description;
    private String proceduremodifier1;
    private String proceduremodifier2;
    private String proceduremodifier3;
    private String proceduremodifier4;
    private String productserviceid1;
    private String productserviceid2;
    private String productserviceidqualifier;

    public Compositemedicalprocedure() {
    }

    public Integer getMedicalprocedureid() {
        return this.medicalprocedureid;
    }

    public void setMedicalprocedureid(Integer medicalprocedureid) {
        this.medicalprocedureid = medicalprocedureid;
    }

    public String getDescription() {
        return this.description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getProceduremodifier1() {
        return this.proceduremodifier1;
    }

    public void setProceduremodifier1(String proceduremodifier1) {
        this.proceduremodifier1 = proceduremodifier1;
    }

    public String getProceduremodifier2() {
        return this.proceduremodifier2;
    }

    public void setProceduremodifier2(String proceduremodifier2) {
        this.proceduremodifier2 = proceduremodifier2;
    }

    public String getProceduremodifier3() {
        return this.proceduremodifier3;
    }

    public void setProceduremodifier3(String proceduremodifier3) {
        this.proceduremodifier3 = proceduremodifier3;
    }

    public String getProceduremodifier4() {
        return this.proceduremodifier4;
    }

    public void setProceduremodifier4(String proceduremodifier4) {
        this.proceduremodifier4 = proceduremodifier4;
    }

    public String getProductserviceid1() {
        return this.productserviceid1;
    }

    public void setProductserviceid1(String productserviceid1) {
        this.productserviceid1 = productserviceid1;
    }

    public String getProductserviceid2() {
        return this.productserviceid2;
    }

    public void setProductserviceid2(String productserviceid2) {
        this.productserviceid2 = productserviceid2;
    }

    public String getProductserviceidqualifier() {
        return this.productserviceidqualifier;
    }

    public void setProductserviceidqualifier(String productserviceidqualifier) {
        this.productserviceidqualifier = productserviceidqualifier;
    }

}