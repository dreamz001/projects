package com.eligiblityshared.beans;

import java.io.Serializable;

import com.eligibility.common.utility.StringUtil;
import com.eligibility.shared.constants.EligibilityTagEnum;
import com.eligibility270.writer.IConstants;

/**
 * III Segment Bean.
 * 
 * @author manishm3
 * @Date March 4,2015
 */
public class IiiSegment implements Serializable {
    private static final long serialVersionUID = 6242956040940814787L;

    private String codeListQualCode;
    private String industryCode;
    private String codeCateogry;
    private String freeFormMsgtext;

    public String getCodeListQualCode() {
        return codeListQualCode;
    }

    public void setCodeListQualCode(String codeListQualCode) {
        this.codeListQualCode = codeListQualCode;
    }

    public String getIndustryCode() {
        return industryCode;
    }

    public void setIndustryCode(String industryCode) {
        this.industryCode = industryCode;
    }

    public String getCodeCateogry() {
        return codeCateogry;
    }

    public void setCodeCateogry(String codeCateogry) {
        this.codeCateogry = codeCateogry;
    }

    public String getFreeFormMsgtext() {
        return freeFormMsgtext;
    }

    public void setFreeFormMsgtext(String freeFormMsgtext) {
        this.freeFormMsgtext = freeFormMsgtext;
    }

    /**
     * It writes III segment as per the 270-Eligibility Specifications.
     * 
     * @author manishm3
     * @date Mar 13,2015
     * @return
     */
    public String writer() {
        StringBuilder sb = new StringBuilder();
        sb.append(EligibilityTagEnum.III.value());
        sb.append(IConstants.SEPARATOR);

        /* III-01 */
        sb.append((codeListQualCode != null && !codeListQualCode.trim().isEmpty()) ? codeListQualCode.concat(IConstants.SEPARATOR) : IConstants.SEPARATOR);
        /* III-02 */
        sb.append((industryCode != null && !industryCode.trim().isEmpty()) ? industryCode.concat(IConstants.TERMINATOR) : IConstants.TERMINATOR);

        if (StringUtil.isSegmentContainsData(sb.toString(), EligibilityTagEnum.REF.value())) {
            return StringUtil.appendTerminatorIfNotFound(sb.toString());
        }
        return new String("");
    }
}
