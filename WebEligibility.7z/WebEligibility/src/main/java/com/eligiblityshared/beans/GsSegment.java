package com.eligiblityshared.beans;

import java.io.Serializable;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

/**
 * @author shailendras4 Purpose : Bean corresponding GS segment
 * 
 */
public class GsSegment implements Serializable {
    private static final long serialVersionUID = 1L;

    private Integer groupcontrolnumber;

    private String applicationReceiverCode;

    private String applicationsendercode;

    private Time gsdate;

    private String functionalidentifiercode;

    private Timestamp gstime;

    private String responsibleagencycode;

    private String versionreleaseno;

    private IsaSegment isaSegment;

    private List<StSegment> transactionsetheaders;

    public GsSegment() {
    }

    public Integer getGroupcontrolnumber() {
        return this.groupcontrolnumber;
    }

    public void setGroupcontrolnumber(Integer groupcontrolnumber) {
        this.groupcontrolnumber = groupcontrolnumber;
    }

    public String getApplicationReceiverCode() {
        return this.applicationReceiverCode;
    }

    public void setApplicationReceiverCode(String applicationReceiverCode) {
        this.applicationReceiverCode = applicationReceiverCode;
    }

    public String getApplicationsendercode() {
        return this.applicationsendercode;
    }

    public void setApplicationsendercode(String applicationsendercode) {
        this.applicationsendercode = applicationsendercode;
    }

    public Time getGsdate() {
        return this.gsdate;
    }

    public void setGsdate(Time date) {
        this.gsdate = date;
    }

    public String getFunctionalidentifiercode() {
        return this.functionalidentifiercode;
    }

    public void setFunctionalidentifiercode(String functionalidentifiercode) {
        this.functionalidentifiercode = functionalidentifiercode;
    }

    public Timestamp getGstime() {
        return this.gstime;
    }

    public void setGstime(Timestamp gstime) {
        this.gstime = gstime;
    }

    public String getResponsibleagencycode() {
        return this.responsibleagencycode;
    }

    public void setResponsibleagencycode(String responsibleagencycode) {
        this.responsibleagencycode = responsibleagencycode;
    }

    public String getVersionreleaseno() {
        return this.versionreleaseno;
    }

    public void setVersionreleaseno(String versionreleaseno) {
        this.versionreleaseno = versionreleaseno;
    }

    public IsaSegment getIsaSegment() {
        return isaSegment;
    }

    public void setIsaSegment(IsaSegment isaSegment) {
        this.isaSegment = isaSegment;
    }

    public List<StSegment> getTransactionsetheaders() {
        if (this.transactionsetheaders == null) {
            this.transactionsetheaders = new ArrayList<StSegment>();
        }
        return this.transactionsetheaders;
    }

    public void setTransactionsetheaders(List<StSegment> transactionsetheaders) {
        this.transactionsetheaders = transactionsetheaders;
    }

    public StSegment addTransactionsetheader(StSegment stSegment) {
        getTransactionsetheaders().add(stSegment);
        stSegment.setGsSegment(this);

        return stSegment;
    }

    public StSegment removeTransactionsetheader(StSegment stSegment) {
        getTransactionsetheaders().remove(stSegment);
        stSegment.setGsSegment(null);
        return stSegment;
    }

}