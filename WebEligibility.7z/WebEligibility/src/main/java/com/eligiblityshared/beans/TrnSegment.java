package com.eligiblityshared.beans;

import com.eligibility.common.utility.StringUtil;
import com.eligibility.shared.constants.EligibilityTagEnum;
import com.eligibility270.writer.IConstants;

/**
 * TRN segment beans.
 * 
 * @author manishm3
 * @date MAR 03 2015
 */
public class TrnSegment {
    private String traceIdCode;
    private String referenceIden1;
    private String originatingCompId;
    private String referenceIden2;

    public String getTraceIdCode() {
        return traceIdCode;
    }

    public void setTraceIdCode(String traceIdCode) {
        this.traceIdCode = traceIdCode;
    }

    public String getReferenceIden1() {
        return referenceIden1;
    }

    public void setReferenceIden1(String referenceIden1) {
        this.referenceIden1 = referenceIden1;
    }

    public String getOriginatingCompId() {
        return originatingCompId;
    }

    public void setOriginatingCompId(String originatingCompId) {
        this.originatingCompId = originatingCompId;
    }

    public String getReferenceIden2() {
        return referenceIden2;
    }

    public void setReferenceIden2(String referenceIden2) {
        this.referenceIden2 = referenceIden2;
    }

    public String writer() {

        StringBuilder sb = new StringBuilder();
        sb.append(EligibilityTagEnum.TRN.value());
        sb.append(IConstants.SEPARATOR);

        /* NM-101 */
        sb.append((traceIdCode != null && !traceIdCode.trim().isEmpty()) ? traceIdCode.trim().concat(IConstants.SEPARATOR) : IConstants.SEPARATOR);
        /* NM-102 */
        sb.append((referenceIden1 != null && !referenceIden1.trim().isEmpty()) ? referenceIden1.trim().concat(IConstants.SEPARATOR) : IConstants.SEPARATOR);
        /* NM-103 */
        sb.append((originatingCompId != null && !originatingCompId.trim().isEmpty()) ? originatingCompId.trim().concat(IConstants.SEPARATOR) : IConstants.SEPARATOR);
        /* NM-104 */
        sb.append((referenceIden2 != null && !referenceIden2.trim().isEmpty()) ? referenceIden2.trim().concat(IConstants.TERMINATOR) : IConstants.TERMINATOR);

        if (StringUtil.isSegmentContainsData(sb.toString(), EligibilityTagEnum.TRN.value())) {
            return StringUtil.appendTerminatorIfNotFound(sb.toString());
        }
        return new String("");
    }

}
