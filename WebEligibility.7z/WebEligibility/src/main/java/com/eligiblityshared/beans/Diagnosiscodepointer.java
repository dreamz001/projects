package com.eligiblityshared.beans;

import java.io.Serializable;

/**
 * 
 * @author shailendras4 Purpose : Bean class corresponding to Dianosis code
 *         pointer
 */
public class Diagnosiscodepointer implements Serializable {

    private static final long serialVersionUID = 3117201885964746785L;

    private Integer diagnosiscodepointerid;

    private Integer diagnosiscodepointer1;

    private Integer diagnosiscodepointer2;

    private Integer diagnosiscodepointer3;

    private Integer diagnosiscodepointer4;

    public Diagnosiscodepointer() {
    }

    public Integer getDiagnosiscodepointerid() {
        return diagnosiscodepointerid;
    }

    public void setDiagnosiscodepointerid(Integer diagnosiscodepointerid) {
        this.diagnosiscodepointerid = diagnosiscodepointerid;
    }

    public Integer getDiagnosiscodepointer1() {
        return this.diagnosiscodepointer1;
    }

    public void setDiagnosiscodepointer1(Integer diagnosiscodepointer1) {
        this.diagnosiscodepointer1 = diagnosiscodepointer1;
    }

    public Integer getDiagnosiscodepointer2() {
        return this.diagnosiscodepointer2;
    }

    public void setDiagnosiscodepointer2(Integer diagnosiscodepointer2) {
        this.diagnosiscodepointer2 = diagnosiscodepointer2;
    }

    public Integer getDiagnosiscodepointer3() {
        return this.diagnosiscodepointer3;
    }

    public void setDiagnosiscodepointer3(Integer diagnosiscodepointer3) {
        this.diagnosiscodepointer3 = diagnosiscodepointer3;
    }

    public Integer getDiagnosiscodepointer4() {
        return this.diagnosiscodepointer4;
    }

    public void setDiagnosiscodepointer4(Integer diagnosiscodepointer4) {
        this.diagnosiscodepointer4 = diagnosiscodepointer4;
    }

}