package com.eligiblityshared.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * @author shailendras4 Pupose : Bean corresponding to ST segment
 * 
 */

public class StSegment implements Serializable {
    private static final long serialVersionUID = 1L;

    private Integer transactionsetcontrolnumber;

    private String implementationconventionreference;

    private String transactionsetidentifier;

    private List<BhtSegment> bhtSegments;

    private GsSegment gsSegment;

    public StSegment() {
    }

    public Integer getTransactionsetcontrolnumber() {
        return this.transactionsetcontrolnumber;
    }

    public void setTransactionsetcontrolnumber(Integer transactionsetcontrolnumber) {
        this.transactionsetcontrolnumber = transactionsetcontrolnumber;
    }

    public String getImplementationconventionreference() {
        return this.implementationconventionreference;
    }

    public void setImplementationconventionreference(String implementationconventionreference) {
        this.implementationconventionreference = implementationconventionreference;
    }

    public String getTransactionsetidentifier() {
        return this.transactionsetidentifier;
    }

    public void setTransactionsetidentifier(String transactionsetidentifier) {
        this.transactionsetidentifier = transactionsetidentifier;
    }

    public List<BhtSegment> getBhtSegments() {
        if (bhtSegments == null) {
            bhtSegments = new ArrayList<BhtSegment>();
        }
        return bhtSegments;
    }

    public void setBhtSegments(List<BhtSegment> bhtSegments) {
        this.bhtSegments = bhtSegments;
    }

    public BhtSegment addBhtSegment(BhtSegment bhtSegment) {
        getBhtSegments().add(bhtSegment);
        bhtSegment.setStSegment(this);

        return bhtSegment;
    }

    public BhtSegment removeBhtSegment(BhtSegment bhtSegment) {
        getBhtSegments().remove(bhtSegment);
        bhtSegment.setStSegment(null);

        return bhtSegment;
    }

    public GsSegment getGsSegment() {
        return gsSegment;
    }

    public void setGsSegment(GsSegment gsSegment) {
        this.gsSegment = gsSegment;
    }

}