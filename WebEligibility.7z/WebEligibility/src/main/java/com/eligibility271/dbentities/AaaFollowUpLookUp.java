package com.eligibility271.dbentities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * The persistent class for the aaafollowuplookuptable database table.
 * 
 * @author Manish
 * @date MAR 20,2015
 */
@Entity
@Table(name="eligibility.aaafollowuplookuptable")
public class AaaFollowUpLookUp implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    private String aaacode;

    private String defination="";
    
    public AaaFollowUpLookUp() {
        super();
    }
    
    public String getAaacode() {
        return aaacode;
    }

    public void setAaacode(String aaacode) {
        this.aaacode = aaacode;
    }

    public String getDefination() {
        return this.defination;
    }

    public void setDefination(String defination) {
        this.defination = defination;
    }

}