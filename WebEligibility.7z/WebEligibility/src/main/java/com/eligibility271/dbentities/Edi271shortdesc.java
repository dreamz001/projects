package com.eligibility271.dbentities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * The persistent class for the edi271shortdesc database table.
 * @author Manish
 * @date MAR 20,2015
 */
@Entity
@Table(name="eligibility.edi271shortdesc")
@NamedQuery(name = "Edi271shortdesc.findAll", query = "SELECT e FROM Edi271shortdesc e")
public class Edi271shortdesc implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @JsonIgnore
    private Integer id;

    private String eligibilitytracernumber;

    private String edimessage;

    private String eligibilityoutcomecode;

    private String eligibilityoutcomemessage;
    
    @JsonIgnore
    private Boolean isack;

    @JsonIgnore
    private String ackjson="";

    @Column(name = "msp_type")
    @JsonIgnore
    private String mspType;

    private Integer transactionsetcontrolnumber;

    // bi-directional many-to-one association to Emdeonrequestresponse
    @ManyToOne
    @JoinColumn(name = "emdeonrequestresponseid")
    @JsonIgnore
    private Emdeonrequestresponse emdeonrequestresponse;

    // bi-directional many-to-one association to Patientsummary
    @ManyToOne
    @JoinColumn(name = "patientsummaryid")
    private Patientsummary patientsummary;

    public Edi271shortdesc() {
    }

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getEdimessage() {
        return this.edimessage;
    }

    public void setEdimessage(String edimessage) {
        this.edimessage = edimessage;
    }

    public String getEligibilityoutcomecode() {
        return this.eligibilityoutcomecode;
    }

    public void setEligibilityoutcomecode(String eligibilityoutcomecode) {
        this.eligibilityoutcomecode = eligibilityoutcomecode;
    }

    public String getEligibilityoutcomemessage() {
    	if(eligibilityoutcomemessage==null){
    		return eligibilityoutcomemessage;
    	}
        return this.eligibilityoutcomemessage.trim();
    }

    public void setEligibilityoutcomemessage(String eligibilityoutcomemessage) {
        this.eligibilityoutcomemessage = eligibilityoutcomemessage;
    }

    public String getEligibilitytracernumber() {
        return this.eligibilitytracernumber;
    }

    public void setEligibilitytracernumber(String eligibilitytracernumber) {
        this.eligibilitytracernumber = eligibilitytracernumber;
    }

    public String getMspType() {
        return this.mspType;
    }

    public void setMspType(String mspType) {
        this.mspType = mspType;
    }

    public Integer getTransactionsetcontrolnumber() {
        return this.transactionsetcontrolnumber;
    }

    public void setTransactionsetcontrolnumber(Integer transactionsetcontrolnumber) {
        this.transactionsetcontrolnumber = transactionsetcontrolnumber;
    }

    public Emdeonrequestresponse getEmdeonrequestresponse() {
        return this.emdeonrequestresponse;
    }

    public void setEmdeonrequestresponse(Emdeonrequestresponse emdeonrequestresponse) {
        this.emdeonrequestresponse = emdeonrequestresponse;
    }

    public Patientsummary getPatientsummary() {
        return this.patientsummary;
    }

    public void setPatientsummary(Patientsummary patientsummary) {
        this.patientsummary = patientsummary;
    }

    public Boolean getIsack() {
        return isack;
    }

    public void setIsack(Boolean isack) {
        this.isack = isack;
    }

    public String getAckjson() {
        return ackjson;
    }

    public void setAckjson(String ackjson) {
        this.ackjson = ackjson;
    }

}