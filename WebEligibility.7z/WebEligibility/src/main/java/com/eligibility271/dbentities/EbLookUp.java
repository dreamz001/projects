package com.eligibility271.dbentities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * The persistent class for the eblookuptable database table.
 * 
 * @author Manish
 * @date MAR 20,2015
 */
@Entity
@Table(name="eligibility.eblookuptable")
public class EbLookUp implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    private String ebcode;

    private String defination;

    
    public EbLookUp() {
        super();
    }

    public String getEbcode() {
        return ebcode;
    }

    public void setEbcode(String ebcode) {
        this.ebcode = ebcode;
    }

    public String getDefination() {
        return this.defination;
    }

    public void setDefination(String defination) {
        this.defination = defination;
    }

}