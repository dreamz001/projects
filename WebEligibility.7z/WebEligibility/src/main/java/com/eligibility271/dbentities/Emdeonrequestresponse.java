package com.eligibility271.dbentities;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.eligibility270.dbentities.Eligibility270withack;

/**
 * The persistent class for the emdeonrequestresponse database table.
 * @author Manish
 * @date MAR 20,2015
 */
@Entity
@Table(name="eligibility.emdeonrequestresponse")
@NamedQuery(name = "Emdeonrequestresponse.findAll", query = "SELECT e FROM Emdeonrequestresponse e")
public class Emdeonrequestresponse implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    private BigInteger id;

    private String emdeonresponseedi271 = "";
    private String soaprequest = "";
    private String responsetype = "";
    private String responsepayload = "";

    // bi-directional many-to-one association to Edi271shortdesc
    @OneToMany(mappedBy = "emdeonrequestresponse")
    private List<Edi271shortdesc> edi271shortdescs;

    // bi-directional many-to-one association to Eligibility270withack
    @ManyToOne
    @JoinColumn(name = "requestid")
    private Eligibility270withack eligibility270withack;

    public Emdeonrequestresponse() {
    }

    public BigInteger getId() {
        return this.id;
    }

    public void setId(BigInteger id) {
        this.id = id;
    }

    public String getEmdeonresponseedi271() {
        return this.emdeonresponseedi271;
    }

    public void setEmdeonresponseedi271(String emdeonresponseedi271) {
        this.emdeonresponseedi271 = emdeonresponseedi271;
    }

    public List<Edi271shortdesc> getEdi271shortdescs() {
        return this.edi271shortdescs;
    }

    public void setEdi271shortdescs(List<Edi271shortdesc> edi271shortdescs) {
        this.edi271shortdescs = edi271shortdescs;
    }

    public Edi271shortdesc addEdi271shortdesc(Edi271shortdesc edi271shortdesc) {
        getEdi271shortdescs().add(edi271shortdesc);
        edi271shortdesc.setEmdeonrequestresponse(this);

        return edi271shortdesc;
    }

    public Edi271shortdesc removeEdi271shortdesc(Edi271shortdesc edi271shortdesc) {
        getEdi271shortdescs().remove(edi271shortdesc);
        edi271shortdesc.setEmdeonrequestresponse(null);

        return edi271shortdesc;
    }

    public Eligibility270withack getEligibility270withack() {
        return this.eligibility270withack;
    }

    public void setEligibility270withack(Eligibility270withack eligibility270withack) {
        this.eligibility270withack = eligibility270withack;
    }

    public String getSoaprequest() {
        return soaprequest;
    }

    public void setSoaprequest(String soaprequest) {
        this.soaprequest = soaprequest;
    }

    public String getResponsetype() {
        return responsetype;
    }

    public void setResponsetype(String responsetype) {
        this.responsetype = responsetype;
    }

    public String getResponsepayload() {
        return responsepayload;
    }

    public void setResponsepayload(String responsepayload) {
        this.responsepayload = responsepayload;
    }

}