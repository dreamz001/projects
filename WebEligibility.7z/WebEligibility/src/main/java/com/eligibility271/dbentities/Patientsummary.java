package com.eligibility271.dbentities;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.webeligibility.actions.LoginAction;

/**
 * The persistent class for the patientsummary database table.
 * 
 * @author Manish
 * @date MAR 20,2015
 */
@Entity
@Table(name="eligibility.patientsummary")
@NamedQuery(name = "Patientsummary.findAll", query = "SELECT p FROM Patientsummary p")
public class Patientsummary implements Serializable {
    private static final long serialVersionUID = 1L;
    private static final Logger LOG = LoggerFactory.getLogger(Patientsummary.class);
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @JsonIgnore
    private Integer id;

    private String dateofbirth;

    private String firstname;

    private String gender;

    private String lastname;

    private String membernumber="";

    private String middleinitial="";

    private String ssn="";
    
    @Transient
    private String dateFormate;
    
    // bi-directional many-to-one association to Edi271shortdesc
    @OneToMany(mappedBy = "patientsummary")
    @JsonIgnore
    private List<Edi271shortdesc> edi271shortdescs;

    public Patientsummary() {
    }

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDateofbirth() {
        return this.dateofbirth;
    }

    public void setDateofbirth(String dateofbirth) {
        this.dateofbirth = dateofbirth;
    }

    public String getFirstname() {
        return this.firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getGender() {
        return this.gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getLastname() {
        return this.lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getMembernumber() {
        return this.membernumber;
    }

    public void setMembernumber(String membernumber) {
        this.membernumber = membernumber;
    }

    public String getMiddleinitial() {
        return this.middleinitial;
    }

    public void setMiddleinitial(String middleinitial) {
        this.middleinitial = middleinitial;
    }

    public String getSsn() {
        return this.ssn;
    }

    public void setSsn(String ssn) {
        this.ssn = ssn;
    }

    public List<Edi271shortdesc> getEdi271shortdescs() {
        return this.edi271shortdescs;
    }

    public void setEdi271shortdescs(List<Edi271shortdesc> edi271shortdescs) {
        this.edi271shortdescs = edi271shortdescs;
    }

    public Edi271shortdesc addEdi271shortdesc(Edi271shortdesc edi271shortdesc) {
        getEdi271shortdescs().add(edi271shortdesc);
        edi271shortdesc.setPatientsummary(this);

        return edi271shortdesc;
    }

    public Edi271shortdesc removeEdi271shortdesc(Edi271shortdesc edi271shortdesc) {
        getEdi271shortdescs().remove(edi271shortdesc);
        edi271shortdesc.setPatientsummary(null);

        return edi271shortdesc;
    }

    public String getDateFormate() {
        LOG.debug("Start getDateFormate method");
        SimpleDateFormat sm=new SimpleDateFormat("MM/dd/yyyy");
        Date dob=new Date();
        try {
            dob=new SimpleDateFormat("yyyyMMdd").parse(dateofbirth);
        } catch (ParseException e) {
            LOG.error("Exception in date format" ,e);
        }
        LOG.debug("End getDateFormate method");
        return sm.format(dob);
    }
}