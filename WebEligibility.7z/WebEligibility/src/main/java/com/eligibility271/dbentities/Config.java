package com.eligibility271.dbentities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The persistent class for the config database table.
 * 
 */
@Entity
@Table(name = "eligibility.config")
public class Config implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(unique = true, nullable = false)
    private Integer id;

    @Column(length = 100)
    private String description;

    @Column(length = 30)
    private String key;

    @Column(length = 50)
    private String value;

    public Config() {
    }

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDescription() {
        return this.description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

}