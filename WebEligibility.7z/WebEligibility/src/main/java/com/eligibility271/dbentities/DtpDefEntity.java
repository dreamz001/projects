package com.eligibility271.dbentities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The persistent class for the dtplookuptable database table.
 * 
 * @author Manish
 * @date MAR 20,2015
 */
@Entity
@Table(name = "eligibility.dtplookuptable")
public class DtpDefEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    private String dtpcode;

    private String defination;

    public DtpDefEntity() {
    }

    public String getDtpcode() {
        return this.dtpcode;
    }

    public void setDtpcode(String dtpcode) {
        this.dtpcode = dtpcode;
    }

    public String getDefination() {
        return this.defination;
    }

    public void setDefination(String defination) {
        this.defination = defination;
    }

}