package com.eligibility271.longjson.response;
/**
 * @author Manish
 * @date MAR 20,2015
 */
public class SubscriberSummary {
    private String subscriber_name;
    private String new_member_id;
    private String member_id;
    private String group_number;
    private String policy_number;
    private String ssn;
    private String group_name;
    private String subscriber_address;
    private String susbcriber_city;
    private String subscriber_state_code;
    private String subscriber_postal_code;
    private String date_of_birth;
    private String gender;
    private String relationship_to_patient;
    private String subscriber_date_qualifier;
    private String subscriber_datetime_qualifier;
    private String subscriber_date;

    public String getSubscriber_name() {
        return subscriber_name;
    }

    public void setSubscriber_name(String subscriber_name) {
        this.subscriber_name = subscriber_name;
    }

    public String getNew_member_id() {
        return new_member_id;
    }

    public void setNew_member_id(String new_member_id) {
        this.new_member_id = new_member_id;
    }

    public String getMember_id() {
        return member_id;
    }

    public void setMember_id(String member_id) {
        this.member_id = member_id;
    }

    public String getGroup_number() {
        return group_number;
    }

    public void setGroup_number(String group_number) {
        this.group_number = group_number;
    }

    public String getPolicy_number() {
        return policy_number;
    }

    public void setPolicy_number(String policy_number) {
        this.policy_number = policy_number;
    }

    public String getSsn() {
        return ssn;
    }

    public void setSsn(String ssn) {
        this.ssn = ssn;
    }

    public String getGroup_name() {
        return group_name;
    }

    public void setGroup_name(String group_name) {
        this.group_name = group_name;
    }

    public String getSubscriber_address() {
        return subscriber_address;
    }

    public void setSubscriber_address(String subscriber_address) {
        this.subscriber_address = subscriber_address;
    }

    public String getSusbcriber_city() {
        return susbcriber_city;
    }

    public void setSusbcriber_city(String susbcriber_city) {
        this.susbcriber_city = susbcriber_city;
    }

    public String getSubscriber_state_code() {
        return subscriber_state_code;
    }

    public void setSubscriber_state_code(String subscriber_state_code) {
        this.subscriber_state_code = subscriber_state_code;
    }

    public String getSubscriber_postal_code() {
        return subscriber_postal_code;
    }

    public void setSubscriber_postal_code(String subscriber_postal_code) {
        this.subscriber_postal_code = subscriber_postal_code;
    }

    public String getDate_of_birth() {
        return date_of_birth;
    }

    public void setDate_of_birth(String date_of_birth) {
        this.date_of_birth = date_of_birth;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getRelationship_to_patient() {
        return relationship_to_patient;
    }

    public void setRelationship_to_patient(String relationship_to_patient) {
        this.relationship_to_patient = relationship_to_patient;
    }

    public String getSubscriber_date_qualifier() {
        return subscriber_date_qualifier;
    }

    public void setSubscriber_date_qualifier(String subscriber_date_qualifier) {
        this.subscriber_date_qualifier = subscriber_date_qualifier;
    }

    public String getSubscriber_datetime_qualifier() {
        return subscriber_datetime_qualifier;
    }

    public void setSubscriber_datetime_qualifier(String subscriber_datetime_qualifier) {
        this.subscriber_datetime_qualifier = subscriber_datetime_qualifier;
    }

    public String getSubscriber_date() {
        return subscriber_date;
    }

    public void setSubscriber_date(String subscriber_date) {
        this.subscriber_date = subscriber_date;
    }

}
