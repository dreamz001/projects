package com.eligibility271.longjson.response;

import java.util.ArrayList;
import java.util.List;
/**
 * @author Manish
 * @date MAR 20,2015
 */
public class BenifitsInformation {
    private List<RowItem> row_items;
    private int row_item_Count;
    private List<RequestValidation> request_validations;
    private int request_validations_count;

    public List<RowItem> getRow_items() {
        if (row_items == null) {
            row_items = new ArrayList<RowItem>();
        }
        return row_items;
    }

    public void setRow_items(List<RowItem> row_items) {
        this.row_items = row_items;
    }

    public void addRowItem(RowItem rowItem) {
        getRow_items().add(rowItem);
        setRow_item_Count(getRow_items().size());
    }

    public void removeRowItem(RowItem rowItem) {
        getRow_items().remove(rowItem);
        setRow_item_Count(getRow_items().size());
    }

    public int getRow_item_Count() {
        return row_item_Count;
    }

    public void setRow_item_Count(int row_item_Count) {
        this.row_item_Count = row_item_Count;
    }

    public List<RequestValidation> getRequest_validations() {
        if (request_validations == null) {
            request_validations = new ArrayList<RequestValidation>();
        }
        return request_validations;
    }

    public void setRequest_validations(List<RequestValidation> request_validations) {
        this.request_validations = request_validations;
    }

    public int getRequest_validations_count() {
        return request_validations_count;
    }

    public void setRequest_validations_count(int request_validations_count) {
        this.request_validations_count = request_validations_count;
    }

    public void addRequestValidatation(RequestValidation rv) {
        getRequest_validations().add(rv);
        setRequest_validations_count(getRequest_validations().size());
    }

    public void removeRequestValidation(RequestValidation rv) {
        getRequest_validations().remove(rv);
    }

}
