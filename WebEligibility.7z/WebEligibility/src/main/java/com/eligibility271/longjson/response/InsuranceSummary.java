package com.eligibility271.longjson.response;

/**
 * @author Manish
 * @date MAR 20,2015
 */
public class InsuranceSummary {

    private String payer_name;
    private String payer_identification_qualifier;
    private String payer_identification_code;
    private String payer_address;
    private String telephone;
    private String url;

    public String getPayer_name() {
        return payer_name;
    }

    public void setPayer_name(String payer_name) {
        this.payer_name = payer_name;
    }

    public String getPayer_identification_qualifier() {
        return payer_identification_qualifier;
    }

    public void setPayer_identification_qualifier(String payer_identification_qualifier) {
        this.payer_identification_qualifier = payer_identification_qualifier;
    }

    public String getPayer_identification_code() {
        return payer_identification_code;
    }

    public void setPayer_identification_code(String payer_identification_code) {
        this.payer_identification_code = payer_identification_code;
    }

    public String getPayer_address() {
        return payer_address;
    }

    public void setPayer_address(String payer_address) {
        this.payer_address = payer_address;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

}
