package com.eligibility271.longjson.response;
/**
 * @author Manish
 * @date MAR 20,2015
 */
public class PatientSummary {
    private String patient_name;
    private String new_member_number;
    private String member_number;
    private String policy_number;
    private String ssn;
    private String group_number;
    private String group_name;
    private String patient_address;
    private String patient_city;
    private String patient_state_code;
    private String patient_postal_code;
    private String date_of_birth;
    private String gender;
    private String relationship_to_patient;
    private String patient_date_qualifier;
    private String patient_datetime_qualifier;
    private String patient_date;

    public String getPatient_name() {
        return patient_name;
    }

    public void setPatient_name(String patient_name) {
        this.patient_name = patient_name;
    }

    public String getNew_member_number() {
        return new_member_number;
    }

    public void setNew_member_number(String new_member_number) {
        this.new_member_number = new_member_number;
    }

    public String getMember_number() {
        return member_number;
    }

    public void setMember_number(String member_number) {
        this.member_number = member_number;
    }

    public String getPolicy_number() {
        return policy_number;
    }

    public void setPolicy_number(String policy_number) {
        this.policy_number = policy_number;
    }

    public String getSsn() {
        return ssn;
    }

    public void setSsn(String ssn) {
        this.ssn = ssn;
    }

    public String getGroup_number() {
        return group_number;
    }

    public void setGroup_number(String group_number) {
        this.group_number = group_number;
    }

    public String getGroup_name() {
        return group_name;
    }

    public void setGroup_name(String group_name) {
        this.group_name = group_name;
    }

    public String getPatient_address() {
        return patient_address;
    }

    public void setPatient_address(String patient_address) {
        this.patient_address = patient_address;
    }

    public String getPatient_city() {
        return patient_city;
    }

    public void setPatient_city(String patient_city) {
        this.patient_city = patient_city;
    }

    public String getPatient_state_code() {
        return patient_state_code;
    }

    public void setPatient_state_code(String patient_state_code) {
        this.patient_state_code = patient_state_code;
    }

    public String getPatient_postal_code() {
        return patient_postal_code;
    }

    public void setPatient_postal_code(String patient_postal_code) {
        this.patient_postal_code = patient_postal_code;
    }

    public String getDate_of_birth() {
        return date_of_birth;
    }

    public void setDate_of_birth(String date_of_birth) {
        this.date_of_birth = date_of_birth;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getRelationship_to_patient() {
        return relationship_to_patient;
    }

    public void setRelationship_to_patient(String relationship_to_patient) {
        this.relationship_to_patient = relationship_to_patient;
    }

    public String getPatient_date_qualifier() {
        return patient_date_qualifier;
    }

    public void setPatient_date_qualifier(String patient_date_qualifier) {
        this.patient_date_qualifier = patient_date_qualifier;
    }

    public String getPatient_datetime_qualifier() {
        return patient_datetime_qualifier;
    }

    public void setPatient_datetime_qualifier(String patient_datetime_qualifier) {
        this.patient_datetime_qualifier = patient_datetime_qualifier;
    }

    public String getPatient_date() {
        return patient_date;
    }

    public void setPatient_date(String patient_date) {
        this.patient_date = patient_date;
    }

}
