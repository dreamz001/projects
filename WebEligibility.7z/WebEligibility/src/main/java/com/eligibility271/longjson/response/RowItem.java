package com.eligibility271.longjson.response;
/**
 * @author Manish
 * @date MAR 20,2015
 */
public class RowItem {
    private String eligibility_status_info;
    private String coverage_code;
    private String service_type_code_list;
    private String plan;
    private String monetary_amount;
    private String percentage;
    private String quantity_and_qualifier;
    private String authorization_indicator;
    private String network_indicator;
    private String industry_code;
    private String procedure_code;
    private String modifier1;
    private String modifier2;
    private String modifier3;
    private String modifier4;
    private String timeperiodqualifier_monetaryamount_percentageasdecimal; // added
                                                                           // by
                                                                           // manish

    public String getCoverage_code() {
        return coverage_code;
    }

    public void setCoverage_code(String coverage_code) {
        this.coverage_code = coverage_code;
    }

    public String getService_type_code_list() {
        return service_type_code_list;
    }

    public void setService_type_code_list(String service_type_code_list) {
        this.service_type_code_list = service_type_code_list;
    }

    public String getPlan() {
        return plan;
    }

    public void setPlan(String plan) {
        this.plan = plan;
    }

    public String getMonetary_amount() {
        return monetary_amount;
    }

    public void setMonetary_amount(String monetary_amount) {
        this.monetary_amount = monetary_amount;
    }

    public String getPercentage() {
        return percentage;
    }

    public void setPercentage(String percentage) {
        this.percentage = percentage;
    }

    public String getQuantity_and_qualifier() {
        return quantity_and_qualifier;
    }

    public void setQuantity_and_qualifier(String quantity_and_qualifier) {
        this.quantity_and_qualifier = quantity_and_qualifier;
    }

    public String getAuthorization_indicator() {
        return authorization_indicator;
    }

    public void setAuthorization_indicator(String authorization_indicator) {
        this.authorization_indicator = authorization_indicator;
    }

    public String getNetwork_indicator() {
        return network_indicator;
    }

    public void setNetwork_indicator(String network_indicator) {
        this.network_indicator = network_indicator;
    }

    public String getIndustry_code() {
        return industry_code;
    }

    public void setIndustry_code(String industry_code) {
        this.industry_code = industry_code;
    }

    public String getProcedure_code() {
        return procedure_code;
    }

    public void setProcedure_code(String procedure_code) {
        this.procedure_code = procedure_code;
    }

    public String getModifier1() {
        return modifier1;
    }

    public void setModifier1(String modifier1) {
        this.modifier1 = modifier1;
    }

    public String getModifier2() {
        return modifier2;
    }

    public void setModifier2(String modifier2) {
        this.modifier2 = modifier2;
    }

    public String getModifier3() {
        return modifier3;
    }

    public void setModifier3(String modifier3) {
        this.modifier3 = modifier3;
    }

    public String getModifier4() {
        return modifier4;
    }

    public void setModifier4(String modifier4) {
        this.modifier4 = modifier4;
    }

    public String getEligibility_status_info() {
        return eligibility_status_info;
    }

    public void setEligibility_status_info(String eligibility_status_info) {
        this.eligibility_status_info = eligibility_status_info;
    }

    public String getTimeperiodqualifier_monetaryamount_percentageasdecimal() {
        return timeperiodqualifier_monetaryamount_percentageasdecimal;
    }

    public void setTimeperiodqualifier_monetaryamount_percentageasdecimal(String timeperiodqualifier_monetaryamount_percentageasdecimal) {
        this.timeperiodqualifier_monetaryamount_percentageasdecimal = timeperiodqualifier_monetaryamount_percentageasdecimal;
    }

}
