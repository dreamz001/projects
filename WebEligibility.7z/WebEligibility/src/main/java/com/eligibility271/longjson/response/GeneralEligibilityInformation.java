package com.eligibility271.longjson.response;
/**
 * @author Manish
 * @date MAR 20,2015
 */
public class GeneralEligibilityInformation {
    private EligibilitySummary eligibility_summary;
    private InsuranceSummary insurance_summary;
    private ProviderSummary provider_summary;
    private PatientSummary patient_summary;
    private SubscriberSummary subscriber_summary;

    public EligibilitySummary getEligibility_summary() {
        return eligibility_summary;
    }

    public void setEligibility_summary(EligibilitySummary eligibility_summary) {
        this.eligibility_summary = eligibility_summary;
    }

    public InsuranceSummary getInsurance_summary() {
        return insurance_summary;
    }

    public void setInsurance_summary(InsuranceSummary insurance_summary) {
        this.insurance_summary = insurance_summary;
    }

    public ProviderSummary getProvider_summary() {
        return provider_summary;
    }

    public void setProvider_summary(ProviderSummary provider_summary) {
        this.provider_summary = provider_summary;
    }

    public PatientSummary getPatient_summary() {
        return patient_summary;
    }

    public void setPatient_summary(PatientSummary patient_summary) {
        this.patient_summary = patient_summary;
    }

    public SubscriberSummary getSubscriber_summary() {
        return subscriber_summary;
    }

    public void setSubscriber_summary(SubscriberSummary subscriber_summary) {
        this.subscriber_summary = subscriber_summary;
    }

}
