package com.eligibility271.longjson.response;
/**
 * @author Manish
 * @date MAR 20,2015
 */
public class RequestValidation {

    private String response_code;
    private String reject_reason_code;
    private String follow_up_code;
    private String validation_level;

    public String getResponse_code() {
        return response_code;
    }

    public void setResponse_code(String response_code) {
        this.response_code = response_code;
    }

    public String getReject_reason_code() {
        return reject_reason_code;
    }

    public void setReject_reason_code(String reject_reason_code) {
        this.reject_reason_code = reject_reason_code;
    }

    public String getFollow_up_code() {
        return follow_up_code;
    }

    public void setFollow_up_code(String follow_up_code) {
        this.follow_up_code = follow_up_code;
    }

    public String getValidation_level() {
        return validation_level;
    }

    public void setValidation_level(String validation_level) {
        this.validation_level = validation_level;
    }

}
