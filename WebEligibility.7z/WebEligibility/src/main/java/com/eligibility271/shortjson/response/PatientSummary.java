package com.eligibility271.shortjson.response;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
/**
 * @author Manish
 * @date MAR 20,2015
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "last_name", "first_name", "middle_initial", "ssn", "member_number", "date_of_birth", "gender" })
public class PatientSummary {

    @JsonProperty("last_name")
    private String lastName;
    @JsonProperty("first_name")
    private String firstName;
    @JsonProperty("middle_initial")
    private String middleInitial;
    @JsonProperty("ssn")
    private String ssn;
    @JsonProperty("member_number")
    private String memberNumber;
    @JsonProperty("date_of_birth")
    private String dateOfBirth;
    @JsonProperty("gender")
    private String gender;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * 
     * @return The lastName
     */
    @JsonProperty("last_name")
    public String getLastName() {
        return lastName;
    }

    /**
     * 
     * @param lastName
     *            The last_name
     */
    @JsonProperty("last_name")
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * 
     * @return The firstName
     */
    @JsonProperty("first_name")
    public String getFirstName() {
        return firstName;
    }

    /**
     * 
     * @param firstName
     *            The first_name
     */
    @JsonProperty("first_name")
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * 
     * @return The middleInitial
     */
    @JsonProperty("middle_initial")
    public String getMiddleInitial() {
        return middleInitial;
    }

    /**
     * 
     * @param middleInitial
     *            The middle_initial
     */
    @JsonProperty("middle_initial")
    public void setMiddleInitial(String middleInitial) {
        this.middleInitial = middleInitial;
    }

    /**
     * 
     * @return The ssn
     */
    @JsonProperty("ssn")
    public String getSsn() {
        return ssn;
    }

    /**
     * 
     * @param ssn
     *            The ssn
     */
    @JsonProperty("ssn")
    public void setSsn(String ssn) {
        this.ssn = ssn;
    }

    /**
     * 
     * @return The memberNumber
     */
    @JsonProperty("member_number")
    public String getMemberNumber() {
        return memberNumber;
    }

    /**
     * 
     * @param memberNumber
     *            The member_number
     */
    @JsonProperty("member_number")
    public void setMemberNumber(String memberNumber) {
        this.memberNumber = memberNumber;
    }

    /**
     * 
     * @return The dateOfBirth
     */
    @JsonProperty("date_of_birth")
    public String getDateOfBirth() {
        return dateOfBirth;
    }

    /**
     * 
     * @param dateOfBirth
     *            The date_of_birth
     */
    @JsonProperty("date_of_birth")
    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    /**
     * 
     * @return The gender
     */
    @JsonProperty("gender")
    public String getGender() {
        return gender;
    }

    /**
     * 
     * @param gender
     *            The gender
     */
    @JsonProperty("gender")
    public void setGender(String gender) {
        this.gender = gender;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
