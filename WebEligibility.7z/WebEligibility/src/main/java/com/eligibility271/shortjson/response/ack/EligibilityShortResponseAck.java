package com.eligibility271.shortjson.response.ack;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
/**
 * @author Manish
 * @date MAR 20,2015
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "eligibility_tracer_number", "eligibility_status_code", "errors", "response_size" })
public class EligibilityShortResponseAck {
    
    private static final Logger LOG = LoggerFactory.getLogger(EligibilityShortResponseAck.class);
    
    @JsonProperty("eligibility_tracer_number")
    private String eligibilityTracerNumber;
    @JsonProperty("eligibility_status_code")
    private String eligibilityStatusCode;
    @JsonProperty("errors")
    private List<Error> errors = new ArrayList<Error>();
    @JsonProperty("response_size")
    private String responseSize;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * 
     * @return The eligibilityTracerNumber
     */
    @JsonProperty("eligibility_tracer_number")
    public String getEligibilityTracerNumber() {
        return eligibilityTracerNumber;
    }

    /**
     * 
     * @param eligibilityTracerNumber
     *            The eligibility_tracer_number
     */
    @JsonProperty("eligibility_tracer_number")
    public void setEligibilityTracerNumber(String eligibilityTracerNumber) {
        this.eligibilityTracerNumber = eligibilityTracerNumber;
    }

    /**
     * 
     * @return The eligibilityStatusCode
     */
    @JsonProperty("eligibility_status_code")
    public String getEligibilityStatusCode() {
        return eligibilityStatusCode;
    }

    /**
     * 
     * @param eligibilityStatusCode
     *            The eligibility_status_code
     */
    @JsonProperty("eligibility_status_code")
    public void setEligibilityStatusCode(String eligibilityStatusCode) {
        this.eligibilityStatusCode = eligibilityStatusCode;
    }

    /**
     * 
     * @return The errors
     */
    @JsonProperty("errors")
    public List<Error> getErrors() {
        return errors;
    }

    /**
     * 
     * @param errors
     *            The errors
     */
    @JsonProperty("errors")
    public void setErrors(List<Error> errors) {
        this.errors = errors;
    }

    /**
     * 
     * @return The responseSize
     */
    @JsonProperty("response_size")
    public String getResponseSize() {
        return responseSize;
    }

    /**
     * 
     * @param responseSize
     *            The response_size
     */
    @JsonProperty("response_size")
    public void setResponseSize(String responseSize) {
        this.responseSize = responseSize;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            return objectMapper.writeValueAsString(this);
        } catch (JsonProcessingException e) {
            LOG.error("Exception while parsing JSON", e);
        }
        return "EligibilityShortResponseAck [eligibilityTracerNumber=" + eligibilityTracerNumber + ", eligibilityStatusCode=" + eligibilityStatusCode + ", errors=" + errors
                + ", responseSize=" + responseSize + ", additionalProperties=" + additionalProperties + "]";
    }

}
