package com.eligibility271.shortjson.response;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
/**
 * @author Manish
 * @date MAR 20,2015
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "eligibility_tracer_number", "eligibility_outcome_code", "eligibility_outcome_message", "edi_message", "transaction_set_control_number", "msp_type",
        "patient_summary" })
public class EligibilityResponseNotification {

    @JsonProperty("eligibility_tracer_number")
    private String eligibilityTracerNumber;
    @JsonProperty("eligibility_outcome_code")
    private String eligibilityOutcomeCode;
    @JsonProperty("eligibility_outcome_message")
    private String eligibilityOutcomeMessage;
    @JsonProperty("edi_message")
    private String ediMessage;
    @JsonProperty("transaction_set_control_number")
    private String transactionSetControlNumber;
    @JsonProperty("msp_type")
    private String mspType;
    @JsonProperty("patient_summary")
    private List<PatientSummary> patientSummary = new ArrayList<PatientSummary>();
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * 
     * @return The eligibilityTracerNumber
     */
    @JsonProperty("eligibility_tracer_number")
    public String getEligibilityTracerNumber() {
        return eligibilityTracerNumber;
    }

    /**
     * 
     * @param eligibilityTracerNumber
     *            The eligibility_tracer_number
     */
    @JsonProperty("eligibility_tracer_number")
    public void setEligibilityTracerNumber(String eligibilityTracerNumber) {
        this.eligibilityTracerNumber = eligibilityTracerNumber;
    }

    /**
     * 
     * @return The eligibilityOutcomeCode
     */
    @JsonProperty("eligibility_outcome_code")
    public String getEligibilityOutcomeCode() {
        return eligibilityOutcomeCode;
    }

    /**
     * 
     * @param eligibilityOutcomeCode
     *            The eligibility_outcome_code
     */
    @JsonProperty("eligibility_outcome_code")
    public void setEligibilityOutcomeCode(String eligibilityOutcomeCode) {
        this.eligibilityOutcomeCode = eligibilityOutcomeCode;
    }

    /**
     * 
     * @return The eligibilityOutcomeMessage
     */
    @JsonProperty("eligibility_outcome_message")
    public String getEligibilityOutcomeMessage() {
        return eligibilityOutcomeMessage;
    }

    /**
     * 
     * @param eligibilityOutcomeMessage
     *            The eligibility_outcome_message
     */
    @JsonProperty("eligibility_outcome_message")
    public void setEligibilityOutcomeMessage(String eligibilityOutcomeMessage) {
        this.eligibilityOutcomeMessage = eligibilityOutcomeMessage;
    }

    /**
     * 
     * @return The ediMessage
     */
    @JsonProperty("edi_message")
    public String getEdiMessage() {
        return ediMessage;
    }

    /**
     * 
     * @param ediMessage
     *            The edi_message
     */
    @JsonProperty("edi_message")
    public void setEdiMessage(String ediMessage) {
        this.ediMessage = ediMessage;
    }

    /**
     * 
     * @return The transactionSetControlNumber
     */
    @JsonProperty("transaction_set_control_number")
    public String getTransactionSetControlNumber() {
        return transactionSetControlNumber;
    }

    /**
     * 
     * @param transactionSetControlNumber
     *            The transaction_set_control_number
     */
    @JsonProperty("transaction_set_control_number")
    public void setTransactionSetControlNumber(String transactionSetControlNumber) {
        this.transactionSetControlNumber = transactionSetControlNumber;
    }

    /**
     * 
     * @return The mspType
     */
    @JsonProperty("msp_type")
    public String getMspType() {
        return mspType;
    }

    /**
     * 
     * @param mspType
     *            The msp_type
     */
    @JsonProperty("msp_type")
    public void setMspType(String mspType) {
        this.mspType = mspType;
    }

    /**
     * 
     * @return The patientSummary
     */
    @JsonProperty("patient_summary")
    public List<PatientSummary> getPatientSummary() {
        return patientSummary;
    }

    /**
     * 
     * @param patientSummary
     *            The patient_summary
     */
    @JsonProperty("patient_summary")
    public void setPatientSummary(List<PatientSummary> patientSummary) {
        this.patientSummary = patientSummary;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
