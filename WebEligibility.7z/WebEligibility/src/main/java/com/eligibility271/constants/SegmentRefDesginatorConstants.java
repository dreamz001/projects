package com.eligibility271.constants;
/**
 * @author Manish
 * @date MAR 20,2015
 */
public class SegmentRefDesginatorConstants {
    public static final String ST01 = "ST01";
    public static final String ST02 = "ST02";
    public static final String ST03 = "ST03";
    public static final String AK101 = "AK101";
    public static final String AK102 = "AK102";
    public static final String AK103 = "AK103";
    public static final String AK201 = "AK201";
    public static final String AK202 = "AK202";
    public static final String AK203 = "AK203";
    public static final String IK301 = "IK301";
    public static final String IK302 = "IK302";
    public static final String IK303 = "IK303";
    public static final String IK304 = "IK304";
    public static final String IK401 = "IK401";
    public static final String IK402 = "IK402";
    public static final String IK403 = "IK403";
    public static final String IK404 = "IK404";
    public static final String IK501 = "IK501";
    public static final String IK502 = "IK502";
    public static final String IK503 = "IK503";
    public static final String IK504 = "IK504";
    public static final String IK505 = "IK505";
    public static final String IK506 = "IK506";
    public static final String AK901 = "AK901";
    public static final String AK902 = "AK902";
    public static final String AK903 = "AK903";
    public static final String AK904 = "AK904";
    public static final String AK905 = "AK905";
    public static final String AK906 = "AK906";
    public static final String AK907 = "AK907";
    public static final String AK908 = "AK908";
    public static final String AK909 = "AK909";

    public static final String NM101 = "NM101";
    public static final String NM102 = "NM102";

    public static final String TRN02 = "TRN02";

    public static final String HL03 = "HL03";

    public static final String STC03 = "STC03";
    public static final String STC01 = "STC01";
    public static final String STC10 = "STC10";
    public static final String SVC02 = "SVC02";
    public static final String SVC01 = "SVC01";

}
