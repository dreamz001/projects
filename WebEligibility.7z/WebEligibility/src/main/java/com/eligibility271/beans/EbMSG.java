package com.eligibility271.beans;

import java.util.ArrayList;
/**
 * @author Manish
 * @date MAR 20,2015
 */
public class EbMSG {
    SegmentBean eb;

    ArrayList<SegmentBean> segmentBeansMSGList;
    ArrayList<SegmentBean> segmentBeansDTPList;

    public SegmentBean getEb() {
        return eb;
    }

    public ArrayList<SegmentBean> getSegmentBeansDTPList() {
        if (segmentBeansDTPList == null) {
            segmentBeansDTPList = new ArrayList<SegmentBean>();
        }
        return segmentBeansDTPList;
    }

    public void setSegmentBeansDTPList(ArrayList<SegmentBean> segmentBeansDTPList) {
        this.segmentBeansDTPList = segmentBeansDTPList;
    }

    public void setEb(SegmentBean eb) {
        this.eb = eb;
    }

    public ArrayList<SegmentBean> getSegmentBeansMSGList() {
        if (segmentBeansMSGList == null) {
            segmentBeansMSGList = new ArrayList<SegmentBean>();
        }
        return segmentBeansMSGList;
    }

    public void setSegmentBeansMSGList(ArrayList<SegmentBean> segmentBeansMSG) {
        this.segmentBeansMSGList = segmentBeansMSG;
    }

}
