package com.eligibility271.beans;

import java.util.ArrayList;
import java.util.Map;

/**
 * @author Rajinders
 * @date Apr 3,2015
 */

public class LoopLevelRequiredInfo {

    private SegmentBean nm1Bean;
    private ArrayList<SegmentBean> refBean;
    private SegmentBean n3Bean;
    private SegmentBean n4Bean;
    private SegmentBean dmgBean;
    private SegmentBean isnBean;
    private ArrayList<SegmentBean> dtpBean;
    private ArrayList<EbMSG> ebMSGs;
    private Map<String, ArrayList<SegmentBean>> aaaSegments;

    private ArrayList<EbREF> ebRefBean;

    public ArrayList<EbREF> getEbRefBean() {
        return ebRefBean;
    }

    public void setEbRefBean(ArrayList<EbREF> ebRefBean) {
        this.ebRefBean = ebRefBean;
    }

    public SegmentBean getNm1Bean() {
        return nm1Bean;
    }

    public void setNm1Bean(SegmentBean nm1Bean) {
        this.nm1Bean = nm1Bean;
    }

    public SegmentBean getN3Bean() {
        return n3Bean;
    }

    public void setN3Bean(SegmentBean n3Bean) {
        this.n3Bean = n3Bean;
    }

    public SegmentBean getN4Bean() {
        return n4Bean;
    }

    public void setN4Bean(SegmentBean n4Bean) {
        this.n4Bean = n4Bean;
    }

    public ArrayList<SegmentBean> getRefBean() {
        if (refBean == null) {
            refBean= new ArrayList<SegmentBean>();
        }
        return refBean;
    }

    public void setRefBean(ArrayList<SegmentBean> refBean) {
        this.refBean = refBean;
    }

    public SegmentBean getDmgBean() {
        return dmgBean;
    }

    public void setDmgBean(SegmentBean dmgBean) {
        this.dmgBean = dmgBean;
    }

    public SegmentBean getIsnBean() {
        return isnBean;
    }

    public void setIsnBean(SegmentBean isnBean) {
        this.isnBean = isnBean;
    }

    public ArrayList<SegmentBean> getDtpBean() {
        return dtpBean;
    }

    public void setDtpBean(ArrayList<SegmentBean> dtpBean) {
        this.dtpBean = dtpBean;
    }

    public ArrayList<EbMSG> getEbMSGs() {
        return ebMSGs;
    }

    public void setEbMSGs(ArrayList<EbMSG> ebMSGs) {
        this.ebMSGs = ebMSGs;
    }

    public Map<String, ArrayList<SegmentBean>> getAaaSegments() {
        return aaaSegments;
    }

    public void setAaaSegments(Map<String, ArrayList<SegmentBean>> aaaSegments) {
        this.aaaSegments = aaaSegments;
    }

    @Override
    public String toString() {
        return "LoopLevelRequiredInfo [nm1Bean=" + nm1Bean + ", refBean=" + refBean + ", n3Bean=" + n3Bean + ", n4Bean=" + n4Bean + ", dmgBean=" + dmgBean + ", isnBean=" + isnBean
                + ", dtpBean=" + dtpBean + ", ebMSGs=" + ebMSGs + ", ebRefBean=" + ebRefBean + "]";
    }

}
