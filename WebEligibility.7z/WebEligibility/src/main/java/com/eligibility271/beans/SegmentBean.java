package com.eligibility271.beans;

import java.util.ArrayList;

import com.eligibility.shared.constants.EligibilityTagEnum;

/***
 * @author shailendras4 Class to hold a segment information in memory after
 *         reading from file.
 *
 */
public class SegmentBean {
    private EligibilityTagEnum segmentName;
    private ArrayList<FieldWithValueBean> segmentFieldList;

    public EligibilityTagEnum getSegmentName() {
        return segmentName;
    }

    public void setSegmentName(EligibilityTagEnum segmentName) {
        this.segmentName = segmentName;
    }

    public ArrayList<FieldWithValueBean> getSegmentFieldList() {
        return segmentFieldList;
    }

    public void setSegmentFieldList(ArrayList<FieldWithValueBean> segmentFieldList) {
        this.segmentFieldList = segmentFieldList;
    }

    public String toString() {
        return "[" + segmentName.toString() + " : " + segmentFieldList.toString() + "]";
    }

    public FieldWithValueBean getFieldBeanByFieldName(String refDesigField) {
        FieldWithValueBean field = null;
        if (getSegmentFieldList() != null && getSegmentFieldList().size() > 0) {
            for (FieldWithValueBean fieldBean : getSegmentFieldList()) {
                if (fieldBean.getFieldDesginator().trim().equalsIgnoreCase(refDesigField)) {
                    field = fieldBean;
                    break;
                }
            }
        }
        return field;
    }

}
