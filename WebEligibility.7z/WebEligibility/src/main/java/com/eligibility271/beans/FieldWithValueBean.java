package com.eligibility271.beans;

/**
 * @author shailendras4 Bean to hold single reference designator of Segment and
 *         corresponding fieldValue
 */
public class FieldWithValueBean {
    private String fieldDesginator;
    private String fieldValue;

    public String getFieldDesginator() {
        return fieldDesginator;
    }

    public void setFieldDesginator(String fieldDesginator) {
        this.fieldDesginator = fieldDesginator;
    }

    public String getFieldValue() {
        return fieldValue;
    }

    public void setFieldValue(String fieldValue) {
        this.fieldValue = fieldValue;
    }

}
