package com.eligibility271.beans;

import com.eligibility.shared.constants.EligibilityTagEnum;

/**
 * This class is used to manage indexing where the segment beans
 * collection(271-segment beans) traversal is done.
 * 
 * @author manishm3
 * @Date Mar 30,2015
 */
public class BeanIndex {
    private int index;
    private SegmentBean segmentBean;
    private String loopId;

    public BeanIndex(int index, SegmentBean segmentBean, String loopId) {
        super();
        this.index = index;
        this.segmentBean = segmentBean;
        this.loopId = loopId;
    }

    EligibilityTagEnum segmentTagEnum;

    public BeanIndex(int index, SegmentBean segmentBean, String loopId, EligibilityTagEnum segmentTagEnum) {
        super();
        this.index = index;
        this.segmentBean = segmentBean;
        this.loopId = loopId;
        this.segmentTagEnum = segmentTagEnum;
    }

    public BeanIndex(int index, SegmentBean segmentBean, EligibilityTagEnum segmentTagEnum) {
        super();
        this.index = index;
        this.segmentBean = segmentBean;
        this.segmentTagEnum = segmentTagEnum;
    }

    public BeanIndex(int index, String loopId, String errString, EligibilityTagEnum ackSegmentTagEnum) {
        super();
        this.index = index;
        this.loopId = loopId;
        this.segmentTagEnum = ackSegmentTagEnum;
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public SegmentBean getSegmentBean() {
        return segmentBean;
    }

    public void setSegmentBean(SegmentBean segmentBean) {
        this.segmentBean = segmentBean;
    }

    public String getLoopId() {
        return loopId;
    }

    public void setLoopId(String loopId) {
        this.loopId = loopId;
    }

    public EligibilityTagEnum getSegmentTagEnum() {
        return segmentTagEnum;
    }

    public void setSegmentTagEnum(EligibilityTagEnum ackSegmentTagEnum) {
        this.segmentTagEnum = ackSegmentTagEnum;
    }

}
