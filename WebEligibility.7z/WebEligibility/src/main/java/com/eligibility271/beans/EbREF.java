package com.eligibility271.beans;

import java.util.ArrayList;

/**
 * @author Rajinders
 * @date Apr 3,2015
 */
public class EbREF {

    private SegmentBean eb;
    private ArrayList<SegmentBean> ref;

    public SegmentBean getEb() {
        return eb;
    }

    public void setEb(SegmentBean eb) {
        this.eb = eb;
    }

    public ArrayList<SegmentBean> getRef() {
        return ref;
    }

    public void setRef(ArrayList<SegmentBean> ref) {
        this.ref = ref;
    }

}
