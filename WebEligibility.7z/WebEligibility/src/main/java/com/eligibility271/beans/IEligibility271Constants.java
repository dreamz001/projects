package com.eligibility271.beans;

public interface IEligibility271Constants {

    String IL = "IL";
    String SY = "SY";
    String ONE_W = "1W";

    String ZERO_3 = "03";

    String COMMA = ",";
    String CARET = "^";

    String THIRTY = "30";
    String ACTIVE = "Active";
    String INACTIVE = "Inactive";
    String ASON = " as on ";
}
