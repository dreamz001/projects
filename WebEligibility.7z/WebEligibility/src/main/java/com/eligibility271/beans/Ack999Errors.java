package com.eligibility271.beans;
/**
 * @author Manish
 * @date MAR 20,2015
 */
public class Ack999Errors {

    private String loopid;
    private String segmentName;
    private String data;
    private String elementPosition;
    public String getLoopid() {
        return loopid;
    }
    public void setLoopid(String loopid) {
        this.loopid = loopid;
    }
    public String getSegmentName() {
        return segmentName;
    }
    public void setSegmentName(String segmentName) {
        this.segmentName = segmentName;
    }
    public String getData() {
        return data;
    }
    public void setData(String data) {
        this.data = data;
    }
    public String getElementPosition() {
        return elementPosition;
    }
    public void setElementPosition(String elementPosition) {
        this.elementPosition = elementPosition;
    }
    @Override
    public String toString() {
        return " [" + loopid + "->" + segmentName + "->" + elementPosition + "->" + data + "]";
    }
    
    
}
