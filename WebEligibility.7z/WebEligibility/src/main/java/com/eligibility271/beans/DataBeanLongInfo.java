package com.eligibility271.beans;

import java.util.ArrayList;

/**
 * @author Rajinders
 * @date Apr 3,2015
 */

public class DataBeanLongInfo {

    private ArrayList<SegmentBean> nm12100ABean;
    private ArrayList<SegmentBean> nm12100BBean;
    private ArrayList<LoopLevelRequiredInfo> sl2100c;
    private ArrayList<LoopLevelRequiredInfo> sl2100d;

    public ArrayList<SegmentBean> getNm12100ABean() {
        return nm12100ABean;
    }

    public void setNm12100ABean(ArrayList<SegmentBean> nm12100aBean) {
        nm12100ABean = nm12100aBean;
    }

    public ArrayList<SegmentBean> getNm12100BBean() {
        return nm12100BBean;
    }

    public void setNm12100BBean(ArrayList<SegmentBean> nm12100bBean) {
        nm12100BBean = nm12100bBean;
    }

    public ArrayList<LoopLevelRequiredInfo> getSl2100c() {
        return sl2100c;
    }

    public void setSl2100c(ArrayList<LoopLevelRequiredInfo> sl2100c) {
        this.sl2100c = sl2100c;
    }

    public ArrayList<LoopLevelRequiredInfo> getSl2100d() {
        return sl2100d;
    }

    public void setSl2100d(ArrayList<LoopLevelRequiredInfo> sl2100d) {
        this.sl2100d = sl2100d;
    }

}
