/*package com.eligibility271.webservices;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.eligibility271.dbentities.Edi271shortdesc;
import com.eligibility271.longjson.response.FullDetailResponse;
import com.eligibility271.parser.Eligibility271Parser;
import com.eligibility271.shortjson.response.EligibilityResponseNotification;
import com.eligibility271.shortjson.response.ack.EligibilityShortResponseAck;
import com.eligibility271.shortjson.response.ack.Error;
import com.eligibility271.shortjson.response.ack.Error_;
*//**
 * @author Manish
 * @date MAR 20,2015
 *//*
@Component
@RestController
@RequestMapping("/eligibility271")
public class Eligibility271RestService {

    @Autowired
    Eligibility271Parser eligibility271Parser;

    @RequestMapping("/traceNum")
    public String traceNum() {
        String traceNum = "93175-012547";
        return traceNum;
    }

    @RequestMapping(value = "/shortdescack", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody EligibilityShortResponseAck shortDesc(@RequestBody EligibilityResponseNotification responseNotification) {

        EligibilityShortResponseAck responseAck = new EligibilityShortResponseAck();
        responseAck.setEligibilityStatusCode("A");
        responseAck.setEligibilityTracerNumber("93175-012547");
        responseAck.setErrors(getErrorAck());
        responseAck.setResponseSize("");

        return responseAck;
    }

    public ArrayList<Error> getErrorAck() {
        ArrayList<Error> errors = new ArrayList<Error>();
        Error_ errorAck = new Error_();
        errorAck.setCode("100");
        errorAck.setDescription("Accepted Successfully");

        Error err = new Error();
        err.setError(errorAck);
        errors.add(err);
        return errors;
    }

    @RequestMapping("/shortdesc")
    public Edi271shortdesc getShortDesc(
            @RequestParam(value = "traceNum", defaultValue = "Request URL must be like http://localhost:8080/eligibility271/shortdesc?traceNum=TRACE NUMBER") String traceNum) {
        return eligibility271Parser.getshortDescriptionByTraceNum(traceNum);
    }

    @RequestMapping("/longdescription")
    public FullDetailResponse getLongDesc(
            @RequestParam(value = "traceNum", defaultValue = "Request URL must be like http://localhost:8080/eligibility271/longdescription?traceNum=TRACE NUMBER") String traceNum) {
        return eligibility271Parser.getFullDetailResponseByTraceNum(traceNum);
    }
}
*/