package com.webeligibility.dao;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.Collections;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.eligibility270.dbentities.FullDescription;
import com.eligibility270.dbentities.PayerDetails;
import com.eligibility270.dbentities.ProviderDetails;
import com.eligibility270.dbentities.ServiceTypeCodeLookUp;
import com.eligibility270.mastertables.entities.Deliverymethod;
import com.eligibility270.writer.DBSequenceType;
import com.eligibility271.dbentities.Edi271shortdesc;
import com.webeligibility.comparator.UserScreenMapComparator;
import com.webeligibility.model.User;

@SuppressWarnings("rawtypes")
@Repository("userDao")
public class UserDaoImpl implements UserDao {
    private static final Logger LOG = LoggerFactory.getLogger(UserDaoImpl.class);
    @Autowired
    private SessionFactory sessionFactory;

    public SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    @SuppressWarnings("unchecked")
    @Override
    public User getUserByEmailId(String emailId) throws HibernateException {
        LOG.debug("Start getUserByEmailId method");
        Session currentSession = sessionFactory.getCurrentSession();
        Transaction tx = currentSession.beginTransaction();
        Criteria criteria = currentSession.createCriteria(User.class);
        criteria.add(Restrictions.eq("email", emailId));
        criteria.add(Restrictions.eq("isdeleted", false));
        List<User> userList = criteria.list();
        User user = null;
        if (userList.size() > 0) {
            user = userList.get(0);
            user.getUserScreenmasterMap().size();
        }
        tx.commit();
        if (user != null && user instanceof User) {
            Collections.sort(user.getUserScreenmasterMap(), new UserScreenMapComparator());
            LOG.debug("End getUserByEmailId method");
            return (User) user;
        }
        return null;
    }

    @Override
    public int updatePassword(String email, String password) throws HibernateException {
        LOG.debug("Start updatePassword method");
        int result = 0;
        Session currentSession = sessionFactory.getCurrentSession();
        Transaction tx = currentSession.beginTransaction();
        Query query = currentSession.createQuery("UPDATE User SET password=:password where email=:email");
        query.setParameter("password", password);
        query.setParameter("email", email);
        result = query.executeUpdate();
        tx.commit();
        LOG.debug("End updatePassword method");
        return result;
    }

    @Override
    public int updateLastLoggedIn(String email, Timestamp lastloggedin) throws HibernateException {
        LOG.debug("Start updateLastLoggedIn method");
        int result = 0;
        Session currentSession = sessionFactory.getCurrentSession();
        Transaction tx = currentSession.beginTransaction();
        Query query = currentSession.createQuery("UPDATE User SET lastloggedin=:lastlogin where email=:email");
        query.setParameter("lastlogin", lastloggedin);
        query.setParameter("email", email);
        result = query.executeUpdate();
        tx.commit();
        LOG.debug("End updateLastLoggedIn method");
        return result;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<PayerDetails> getPayerInfo() throws HibernateException {
        LOG.debug("Start getPayerInfo method");
        Session currentSession = sessionFactory.getCurrentSession();
        Transaction tx = currentSession.beginTransaction();
        Criteria criteria = currentSession.createCriteria(PayerDetails.class);
        List<PayerDetails> payerList = criteria.list();
        tx.commit();
        LOG.debug("End getPayerInfo method");
        return payerList;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<ProviderDetails> getProviderInfo() throws HibernateException {
        LOG.debug("Start getProviderInfo method");
        Session currentSession = sessionFactory.getCurrentSession();
        Transaction tx = currentSession.beginTransaction();
        Criteria criteria = currentSession.createCriteria(ProviderDetails.class);
        List<ProviderDetails> providerList = criteria.list();
        tx.commit();
        LOG.debug("End getProviderInfo method");
        return providerList;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<ServiceTypeCodeLookUp> getServiceTypeCodes() throws HibernateException {
        LOG.debug("Start getServiceTypeCodes method");
        Session currentSession = sessionFactory.getCurrentSession();
        Transaction tx = currentSession.beginTransaction();
        Criteria criteria = currentSession.createCriteria(ServiceTypeCodeLookUp.class);
        List<ServiceTypeCodeLookUp> serviceCodeList = criteria.list();
        tx.commit();
        LOG.debug("End getServiceTypeCodes method");
        return serviceCodeList;
    }

    @Override
    public PayerDetails getPayerDetails(String payerId) throws HibernateException {
        LOG.debug("Start getPayerDetails method");
        Session currentSession = sessionFactory.getCurrentSession();
        Transaction tx = currentSession.beginTransaction();
        Criteria criteria = currentSession.createCriteria(PayerDetails.class);
        criteria.add(Restrictions.eq("sourceidentificationcode", payerId));
        Object payer = criteria.uniqueResult();
        tx.commit();
        if (payer != null && payer instanceof PayerDetails) {
            LOG.debug("End getPayerDetails method");
            return (PayerDetails) payer;
        }

        return null;
    }

    @Override
    public void saveOrUpdate(Object params) throws HibernateException {
        LOG.debug("Start saveOrUpdate method");
        Session currentSession = sessionFactory.getCurrentSession();
        Transaction tx = currentSession.beginTransaction();
        currentSession.saveOrUpdate(params);
        currentSession.flush();
        tx.commit();
        LOG.debug("End saveOrUpdate method");
    }

    /**
     * This method return the next value of DB sequence.
     * 
     * @param sequenceType
     * @return DB sequence value as <code>BigInteger</code>
     * @throws <code>Exception</code>
     */
    public BigInteger nextVal(DBSequenceType sequenceType) throws HibernateException {
        // LOGGER.debug("HIT DB SEQUENCE " + sequenceType.value());
        String sql = "select nextVal('" + sequenceType.value() + "')";
        return (BigInteger) executSQL(sql);
    }

    /**
     * Execute sql query pass as an argument to database
     * 
     * @param sql
     *            string
     * @return Resultant <code>Object</code>
     * @throws <code>Exception</code>
     */
    public Object executSQL(String sql) throws HibernateException {
        LOG.debug("Start executSQL method");
        Session currentSession = sessionFactory.getCurrentSession();
        Transaction tx = currentSession.beginTransaction();
        SQLQuery query = currentSession.createSQLQuery(sql);
        Object result = query.uniqueResult();
        tx.commit();
        LOG.debug("End executSQL method");
        return result;
    }

    @Override
    public ProviderDetails getProviderDetails(String providerId) throws HibernateException {
        LOG.debug("Start getProviderDetails method");
        Session currentSession = sessionFactory.getCurrentSession();
        Transaction tx = currentSession.beginTransaction();
        Criteria criteria = currentSession.createCriteria(ProviderDetails.class);
        criteria.add(Restrictions.eq("receiveridentifiercode", providerId));
        Object provider = criteria.uniqueResult();
        tx.commit();
        if (provider != null && provider instanceof ProviderDetails) {
            LOG.debug("End getProviderDetails method");
            return (ProviderDetails) provider;
        }
        return null;
    }

    @Override
    public void addUserDetail(User user) throws HibernateException {
        LOG.debug("Start addUserDetail method");
        Session currentSession = sessionFactory.getCurrentSession();
        Transaction tx = currentSession.beginTransaction();
        currentSession.save(user);
        currentSession.flush();
        tx.commit();
        LOG.debug("End addUserDetail method");
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<User> getUserList() throws HibernateException {
        LOG.debug("Start getUserList method");
        Session currentSession = sessionFactory.getCurrentSession();
        Transaction tx = currentSession.beginTransaction();
        Criteria criteria = currentSession.createCriteria(User.class);
        criteria.add(Restrictions.ge("userid", 0));
        criteria.add(Restrictions.eq("isdeleted", false));
        // criteria.setProjection(Projections.property("email"));
        List<User> userEmailList = criteria.list();
        tx.commit();
        LOG.debug("End getUserList method");
        return userEmailList;
    }

    @Override
    public boolean isEmailExist(String email) throws HibernateException {
        LOG.debug("Start isEmailExist method");
        Session currentSession = sessionFactory.getCurrentSession();
        Transaction tx = currentSession.beginTransaction();
        Criteria criteria = currentSession.createCriteria(User.class);
        criteria.add(Restrictions.eq("email", email));
        criteria.add(Restrictions.eq("isdeleted", false));

        Object user = criteria.uniqueResult();
        tx.commit();
        if (user != null && user instanceof User) {
            LOG.debug("End isEmailExist method");
            return true;
        }
        return false;
    }

    @Override
    public boolean isEmailExist(String email, int userid) throws HibernateException {
        LOG.debug("Start isEmailExist(String email, int userid) method");
        Session currentSession = sessionFactory.getCurrentSession();
        Transaction tx = currentSession.beginTransaction();
        Criteria criteria = currentSession.createCriteria(User.class);
        criteria.add(Restrictions.eq("email", email));
        criteria.add(Restrictions.eq("isdeleted", false));
        criteria.add(Restrictions.ne("userid", userid));
        Object user = criteria.uniqueResult();
        tx.commit();
        if (user != null && user instanceof User) {
            LOG.debug("End isEmailExist(String email, int userid) method");
            return true;
        }
        return false;
    }

    @SuppressWarnings("unchecked")
    @Override
    public User getUserByUserId(int userid) throws HibernateException {
        LOG.debug("Start getUserByUserId method");
        Session currentSession = sessionFactory.getCurrentSession();
        Transaction tx = currentSession.beginTransaction();
        Criteria criteria = currentSession.createCriteria(User.class);
        criteria.add(Restrictions.eq("userid", userid));
        List<User> userList = criteria.list();
        User user = userList.get(0);
        user.getUserScreenmasterMap().size();
        tx.commit();
        if (user != null && user instanceof User) {
            LOG.debug("End getUserByUserId method");
            return (User) user;
        }
        return null;
    }

    @Override
    public int deleteUser(int userid) throws HibernateException {
        LOG.debug("Start deleteUser method");
        String hql = "UPDATE User SET isdeleted=:delete WHERE userid=:userid";
        Session currentSession = sessionFactory.getCurrentSession();
        Transaction tx = currentSession.beginTransaction();
        Query query = currentSession.createQuery(hql);
        query.setParameter("delete", true);
        query.setParameter("userid", userid);
        int status = query.executeUpdate();
        tx.commit();
        LOG.debug("End deleteUser method");
        return status;
    }

    @Override
    public List<FullDescription> getFullDescription(int longdescr) throws HibernateException {
        Session currentSession = sessionFactory.getCurrentSession();
        Transaction tx = currentSession.beginTransaction();
        String sql = "select BI.id ,EBL.defination as eligibilitystatusinfo, BI.coveragecode,  TPL.defination as  plan, BI.monetaryamount, BI.networkindicator from eligibility.benefitsinformation as BI, eligibility.timeperiodqualifierlookuptable AS TPL , eligibility.eblookuptable EBL where trim(both ' ' from BI.plan) = trim(both ' ' from  TPL.CODE) AND  trim(both ' ' from BI.eligibilitystatusinfo) = trim(both ' ' from EBL.ebcode)    AND  BI.longdescid=:longdescid and BI.monetaryamount IS NOT NULL and BI.eligibilitystatusinfo IS NOT NULL and BI.coveragecode IS NOT NULL and BI.plan IS NOT NULL and BI.networkindicator IS NOT NULL  order by BI.eligibilitystatusinfo,  BI.coveragecode DESC, TPL.CODE, BI.networkindicator DESC";
        // String sql1 =
        // "select stud.firstname,stud.roll,sub.subjectname,cls.classname,exam.exam_name,exam.from_time,exam.to_time,exam.exam_date from Student stud,Subject sub,Classs cls,Exam exam where exam.classs=cls.id and exam.subject=sub.id and sub.classs=cls.id and stud.classs=cls.id and stud.roll= :roll";
        SQLQuery query = currentSession.createSQLQuery(sql);
        query.setInteger("longdescid", longdescr);
        query.addEntity(FullDescription.class);
        List<FullDescription> benefitsinformations = query.list();
        tx.commit();
        return benefitsinformations;
    }

    @Override
    public Deliverymethod getDeliveryMethod(int id) throws HibernateException {
        LOG.debug("Start getDeliveryMethod method");
        Session currentSession = sessionFactory.getCurrentSession();
        Transaction tx = currentSession.beginTransaction();
        Criteria criteria = currentSession.createCriteria(Deliverymethod.class);
        criteria.add(Restrictions.eq("id", id));
        Object deliveryMethod = criteria.uniqueResult();
        tx.commit();
        if (deliveryMethod != null && deliveryMethod instanceof Deliverymethod) {
            LOG.debug("End getDeliveryMethod method");
            return (Deliverymethod) deliveryMethod;
        }
        LOG.debug("End getDeliveryMethod method");
        return null;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Edi271shortdesc> getShortReport() throws HibernateException {
        LOG.debug("Start getShortReport method");
        List<Edi271shortdesc> shortReport = null;
        Session currentSession = sessionFactory.getCurrentSession();
        Transaction tx = currentSession.beginTransaction();
        Criteria criteria = currentSession.createCriteria(Edi271shortdesc.class);
        criteria.addOrder(Order.asc("id"));
        shortReport = criteria.list();
        currentSession.flush();
        tx.commit();
        if (shortReport != null) {
            LOG.debug("End getDeliveryMethod method");
            return shortReport;
        }
        LOG.debug("End getDeliveryMethod method");
        return null;
    }
}
