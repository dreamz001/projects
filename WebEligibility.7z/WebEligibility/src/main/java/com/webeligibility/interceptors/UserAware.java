package com.webeligibility.interceptors;

import com.webeligibility.model.User;

public interface UserAware {

    public void setUser(User user);
}
