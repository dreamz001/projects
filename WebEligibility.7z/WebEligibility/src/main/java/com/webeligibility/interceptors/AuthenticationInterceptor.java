package com.webeligibility.interceptors;

import java.util.List;
import java.util.Map;

import org.apache.struts2.ServletActionContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.Interceptor;
import com.webeligibility.constants.WebUtilityConstants;
import com.webeligibility.model.User;
import com.webeligibility.model.UserScreenmasterMap;

public class AuthenticationInterceptor implements Interceptor {
	private static final Logger LOG = LoggerFactory
			.getLogger(AuthenticationInterceptor.class);
	private static final long serialVersionUID = -5011962009065225959L;

	@Override
	public void destroy() {

	}

	@Override
	public void init() {

	}

	@Override
	public String intercept(ActionInvocation actionInvocation) throws Exception {
		LOG.debug("Start intercept method");
		Map<String, Object> sessionAttributes = actionInvocation
				.getInvocationContext().getSession();
		String isLogin = ServletActionContext.getRequest()
				.getParameter("login");
		String actionName = ActionContext.getContext().getName();
		actionName = actionName.toLowerCase();
		User user = (User) sessionAttributes.get("USER");
		sessionAttributes.remove("tab");// remove tab value
		sessionAttributes.remove("page");// remove tab value
		sessionAttributes.remove("payersuccess");
		sessionAttributes.remove("providersuccess");
		sessionAttributes.remove("userupdatesuccess");
		sessionAttributes.remove("useraddsuccess");
		sessionAttributes.remove("accountsettingsuccess");
		sessionAttributes.remove("userdeletesuccess");
		sessionAttributes.remove("uploadbatchfile");
		sessionAttributes.remove("BATCHOUTPUTFILELIST");
		if (isLogin == null) {
			isLogin = "false";
		}
		if (user == null && !isLogin.equals("true")) {
			return Action.LOGIN;
		} else if (actionName.contains("user") || actionName.contains("payer") || actionName.contains("provider") || actionName.contains("updateaccount")
				|| actionName.contains("batchfiles") || actionName.contains("report")) {
			if (isLogin.equals("false")) {
				if (actionName.contains("shortreport")) {
					sessionAttributes.remove("ELIGIBILITYOUTPUT");
					// sessionAttributes.remove("FULLDISCRIPTION");
				}
				List<UserScreenmasterMap> permissionList = user
						.getUserScreenmasterMap();
				boolean manageuser = false;
				boolean managepayer = false;
				boolean manageprovider = false;
				boolean accountsettings = false;
				boolean history = false;
				boolean batchprocess = false;
				for (UserScreenmasterMap screenMap : permissionList) {
					if (screenMap.getScreenid().getScreenname().trim()
							.equals(WebUtilityConstants.MANAGE_USER)) {
						manageuser = screenMap.isIspermission();
					}
					if (screenMap.getScreenid().getScreenname().trim()
							.equals(WebUtilityConstants.MANAGE_PAYER)) {
						managepayer = screenMap.isIspermission();
					}
					if (screenMap.getScreenid().getScreenname().trim()
							.equals(WebUtilityConstants.MANAGE_PROVIDER)) {
						manageprovider = screenMap.isIspermission();
					}
					if (screenMap.getScreenid().getScreenname().trim()
							.equals(WebUtilityConstants.ACCOUNT_SETTINGS)) {
						accountsettings = screenMap.isIspermission();
					}
					if (screenMap.getScreenid().getScreenname().trim()
							.equals(WebUtilityConstants.HISTORY)) {
						history = screenMap.isIspermission();
					}
					if (screenMap.getScreenid().getScreenname().trim()
							.equals(WebUtilityConstants.BATCH_PROCESS)) {
						batchprocess = screenMap.isIspermission();
					}
				}

				if (actionName.contains("user") && manageuser) {
					LOG.debug("End intercept method");
					return actionInvocation.invoke();
				}
				if (actionName.contains("payer") && managepayer) {
					LOG.debug("End intercept method");
					return actionInvocation.invoke();
				}
				if (actionName.contains("provider") && manageprovider) {
					LOG.debug("End intercept method");
					return actionInvocation.invoke();
				}
				if (actionName.contains("updateaccount") && accountsettings) {
					LOG.debug("End intercept method");
					return actionInvocation.invoke();
				}
				if (actionName.contains("report") && history) {
					LOG.debug("End intercept method");
					return actionInvocation.invoke();
				}
				if (actionName.contains("batchfiles") && batchprocess) {
					LOG.debug("End intercept method");
					return actionInvocation.invoke();
				}
			}

			LOG.debug("End intercept method");
			return "permissionhome";
		} else {
			Action action = (Action) actionInvocation.getAction();
			if (action instanceof UserAware) {
				((UserAware) action).setUser(user);

			}
			LOG.debug("End intercept method");
			return actionInvocation.invoke();

		}
	}

}
