package com.webeligibility.actions;

import java.io.IOException;
import java.math.BigInteger;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.SessionAware;
import org.hibernate.HibernateException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.eligibility270.dbentities.ProviderDetails;
import com.eligibility270.writer.DBSequenceType;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
import com.webeligibility.constants.WebUtilityConstants;
import com.webeligibility.service.UserService;
import com.webeligibility.utils.GetPayersProvidersListUtil;

public class UpdateProviderAction extends ActionSupport implements ModelDriven<ProviderDetails>,SessionAware {
    private static final Logger LOG = LoggerFactory.getLogger(UpdateProviderAction.class);
    private static final long serialVersionUID = 2368885976885601344L;

    private ProviderDetails provider;
    private Map<String, Object> sessionAttributes = null;
    @SuppressWarnings("rawtypes")
    @Autowired
    private UserService userService;

    @Override
    public ProviderDetails getModel() {
        if (this.provider == null) {
            provider = new ProviderDetails();
        }
        return provider;
    }

    public String getproviderdetails() {
        LOG.debug("Start getproviderdetails method");
        JSONObject obj = new JSONObject();
        HttpServletResponse response = ServletActionContext.getResponse();
        try {
            String providerId = ServletActionContext.getRequest().getParameter("providercode");
            if (providerId != null) {
                provider = userService.getProviderDetails(providerId);
                if (provider != null) {
                    Map<String, String> providerDetails = new HashMap<String, String>();
                    providerDetails.put("PROVIDERID", provider.getId().toString());
                    providerDetails.put("PROVIDERCODE", provider.getReceiveridentifiercode().trim());
                    providerDetails.put("PROVIDERNAME", provider.getReceivername().trim());
                    providerDetails.put("PROVIDERIDCODEQUALIFIER", provider.getReceiveridentifiercodequalifier().trim());
                    providerDetails.put("PROVIDERIDENTIFIERCODE", provider.getReceiverentityidentifiercode().trim());
                    providerDetails.put("PROVIDERTYPEQUALIFIER", provider.getReceiverentitytypequalifier().trim());
                    obj.put("PROVIDERDETAILS", providerDetails);

                }
            }
        } catch (HibernateException e) {
            LOG.error("Exception in HibernateException", e);
            sessionAttributes.put(WebUtilityConstants.ERROR_KEY, WebUtilityConstants.ERROR_MESSAGE);
            return ERROR;
        }
        try {
            response.getWriter().write(obj.toString());
        } catch (IOException e) {
            LOG.error("Exception in IOException", e);
            sessionAttributes.put(WebUtilityConstants.ERROR_KEY, WebUtilityConstants.ERROR_MESSAGE);
            return ERROR;
        }
        LOG.debug("End getproviderdetails method");
        return NONE;
    }

    @SuppressWarnings("unchecked")
    @Override
    public String execute() throws Exception {
        LOG.debug("Start execute method");
        provider.setReceiveridentifiercode(provider.getNewproviderid());
        try {
            if (provider.getId() == null) {
                BigInteger providerId = userService.nextVal(DBSequenceType.PROVIDERDETAILS_ID);
                provider.setId(providerId.intValue());
            }
            userService.saveOrUpdate(provider);
            GetPayersProvidersListUtil.getProviderList(userService,true);
            this.provider = new ProviderDetails();
            ActionContext.getContext().getValueStack().push(provider);
            sessionAttributes.put("tab", "3");//default
            sessionAttributes.put("providersuccess", "Data Saved Successfully.");
        } catch (HibernateException e) {
            if (provider.getId() == null) {
                sessionAttributes.put("tab", "8");//Add
            }else{
                sessionAttributes.put("tab", "7");//edit
            }
            LOG.error("Exception in HibernateException", e);
            sessionAttributes.put(WebUtilityConstants.ERROR_KEY, WebUtilityConstants.ERROR_MESSAGE);
            return ERROR;
        }
        LOG.debug("End execute method");
        return SUCCESS;
    }

    @Override
    public void setSession(Map<String, Object> sessionAttributes) {
        this.sessionAttributes = sessionAttributes;

    }
}
