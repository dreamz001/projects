package com.webeligibility.actions;

import java.math.BigInteger;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.SessionAware;
import org.hibernate.HibernateException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.batch.eligiblity.main.StartProcess;
import com.eligibility.jsonschema270.beans.XsElement_;
import com.eligibility270.dbentities.FullDescription;
import com.eligibility270.dbentities.PayerDetails;
import com.eligibility270.dbentities.ProviderDetails;
import com.eligibility270.writer.DBSequenceType;
import com.eligibility270.writer.Eligibility270Writer;
import com.eligibility271.constants.Ack999Constants;
import com.eligibility271.dbentities.Edi271shortdesc;
import com.eligibility271.longjson.response.FullDetailResponse;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
import com.webeligibility.constants.WebUtilityConstants;
import com.webeligibility.model.EligibilityOutput;
import com.webeligibility.service.UserService;
import com.webeligibility.utils.ApplicationContextUtility;
import com.webeligibility.utils.GetPayersProvidersListUtil;

@Component
public class EligibilityProcessAction extends ActionSupport implements ModelDriven<XsElement_>, SessionAware {
    private static final Logger LOG = LoggerFactory.getLogger(EligibilityProcessAction.class);
    private static final long serialVersionUID = -6030624950082799482L;
    private Map<String, Object> sessionAttributes = null;
    private BigInteger tracerNumber = new BigInteger("0");
    private XsElement_ element;
    private static String errorCode = "";
    @Autowired
    Eligibility270Writer eligibility270Writer;

    @SuppressWarnings("rawtypes")
    @Autowired
    private UserService userService;

    @Autowired
    private StartProcess startProcess;
    @Override
    public XsElement_ getModel() {
        if (element == null) {
            element = new XsElement_();
        }
        return element;
    }

    // private void setProvider

    @Override
    public String execute() throws Exception {
        LOG.debug("Start execute method");
        boolean productionStatus = GetPayersProvidersListUtil.getProductionStatus();
        sessionAttributes.put("page", "success");// default
        sessionAttributes.put("tab", "1");

        if (productionStatus) {
            setFixedValues(element);
            fillPayerInfo(element);
            fillProviderInfo(element);
            try {
                if (eligibility270Writer == null) {
                    eligibility270Writer = ApplicationContextUtility.getApplicationContext().getBean(Eligibility270Writer.class);
                }
                errorCode = "";
                eligibility270Writer.processRequest(element);
                if (errorCode.equals(Ack999Constants.UNAUTHORIZED)) {
                    sessionAttributes.put(WebUtilityConstants.ERROR_KEY, Ack999Constants.UNAUTHORIZED);
                    return ERROR;
                }
                GetPayersProvidersListUtil.getShortReport(userService);
                LOG.debug("End execute method");
                return SUCCESS;
            } catch (HibernateException e) {
                LOG.error("Exception in execute", e);
                sessionAttributes.put(WebUtilityConstants.ERROR_KEY, WebUtilityConstants.ERROR_MESSAGE);
                return ERROR;
            }
        } else {
            getTestEligibility(element);
            return SUCCESS;
        }
    }

    private void setFixedValues(XsElement_ element) {
        LOG.debug("Start setFixedValues method");
        // element.setRelationShipCode("01");

        try {
            tracerNumber = eligibility270Writer.getBaseDao().nextVal(DBSequenceType.TRACERNUMBER);
        } catch (Exception e) {
            LOG.error("Exception in execute", e);
        }
        String trcernum = String.valueOf(tracerNumber);
        while (trcernum.length() < 9) {
            trcernum = "0" + trcernum;
        }
        element.setEligibilityTracerNumber(trcernum);
        element.setDeliveryMethod("EMDEON_P_5010");
        element.setEligibilityTracerCode("1");
        element.setEligibilityEntityIdentifier("EZDERM9999");
        element.setPrimaryInsuredEntityIdentifierCode("IL");
        element.setPrimaryInsuredEntityTypeQualifier("1");
        element.setPrimaryInsuredIdentifierCodeQualifier("MI");

        // if patient is a dependent
        if (!(element.getRelationShipCode().trim().equals("18"))) {
            // ui fields
            element.setDependentLastName(element.getPrimaryInsuredLastName());
            element.setDependentFirstName(element.getPrimaryInsuredFirstName());
            element.setDependentDemographicsDateOfBirth(element.getPrimaryInsuredDemographicsDateOfBirth());
            element.setDependentDemographicsGenderCode(element.getPrimaryInsuredDemographicsGenderCode());
            element.setDependentServiceTypeCode(element.getPrimaryInsuredServiceTypeCode());

            // background values
            element.setDependentEntityIdentifierCode("03");
            element.setDependentEntityTypeQualifier("1");
            element.setDependentDateQualifier("291");
            element.setDependentDateFormatQualifier("RD8");
            element.setDependentDatePeriod(convertDateFormatServicePeriod(element.getServicePeriod()));
            element.setDependentDemographicsDateQualifier("D8");
            element.setDependentDemographicsDateOfBirth(convertDateFormat(element.getPrimaryInsuredDemographicsDateOfBirth()));

            // removing primary values
            element.setPrimaryInsuredLastName("");
            element.setPrimaryInsuredFirstName("");
            element.setPrimaryInsuredDemographicsDateOfBirth("");
            element.setPrimaryInsuredDemographicsGenderCode("");
            element.setPrimaryInsuredServiceTypeCode("");
        } else {
            // background values
            element.setPrimaryInsuredDateQualifier("291");
            element.setPrimaryInsuredDateFormatQualifier("RD8");
            element.setPrimaryInsuredDatePeriod(convertDateFormatServicePeriod(element.getServicePeriod()));
            element.setPrimaryInsuredDemographicsDateQualifier("D8");
            element.setPrimaryInsuredDemographicsDateOfBirth(convertDateFormat(element.getPrimaryInsuredDemographicsDateOfBirth()));
        }
        LOG.debug("End setFixedValues method");
    }

    public static void setEligibilityOutput(EligibilityOutput output) {
        LOG.debug("Start setEligibilityOutput method");
        List<String> errorsList = GetPayersProvidersListUtil.getErrorsListFromContext();
        String error = "No Errors";
        if (output.getEligibilityoutcomecode().equals(Ack999Constants.UNAUTHORIZED)) {
            error = Ack999Constants.UNAUTHORIZED;
        } else if (errorsList.contains(output.getEligibilityoutcomecode())) {
            error = output.getEligibilityoutcomecode();
        }
        ServletActionContext.getRequest().getSession().setAttribute("ELIGIBILITYERROR", error);
        ServletActionContext.getRequest().getSession().setAttribute("ELIGIBILITYOUTPUT", output);
        errorCode = error;
        LOG.debug("End setEligibilityOutput method");
    }

    @SuppressWarnings("unchecked")
    private void fillPayerInfo(XsElement_ element) {
        LOG.debug("Start fillPayerInfo method");
        Set<PayerDetails> payerSet = (Set<PayerDetails>) ServletActionContext.getServletContext().getAttribute("PAYERINFOSET");
        element.setSourceIdentificationCode(element.getSourceIdentificationCode().trim());
        if (payerSet != null) {
            for (PayerDetails payer : payerSet) {
                if (payer.getSourceidentificationcode().trim().equals(element.getSourceIdentificationCode())) {
                    element.setSourceNameLast(payer.getSourcename().trim());
                    element.setSourceIdentificationCodeQualifier(payer.getSourceidentificationcodequalifier().trim());
                    element.setSourceEntityIdentifierCode(payer.getSourceentityidentifiercode().trim());
                    element.setSourceEntityTypeQualifier(payer.getSourceentitytypequalifier().trim());
                    break;
                }
            }
        }
        LOG.debug("End fillPayerInfo method");
    }

    @SuppressWarnings("unchecked")
    private void fillProviderInfo(XsElement_ element) {
        LOG.debug("Start fillProviderInfo method");
        Set<ProviderDetails> providerSet = (Set<ProviderDetails>) ServletActionContext.getServletContext().getAttribute("PROVIDERINFOSET");
        element.setReceiverIdentifierCode(element.getReceiverIdentifierCode().trim());
        if (providerSet != null) {
            for (ProviderDetails provider : providerSet) {
                if (provider.getReceiveridentifiercode().trim().equals(element.getReceiverIdentifierCode())) {
                    element.setReceiverLastName(provider.getReceivername().trim());
                    element.setReceiverIdentifierCodeQualifier(provider.getReceiveridentifiercodequalifier().trim());
                    element.setReceiverEntityIdentifierCode(provider.getReceiverentityidentifiercode().trim());
                    element.setReceiverEntityTypeQualifier(provider.getReceiverentitytypequalifier().trim());
                    break;
                }
            }
        }
        LOG.debug("End fillProviderInfo method");
    }

    public static void setEligibilityFullDetails(FullDetailResponse details) {
        ServletActionContext.getRequest().getSession().setAttribute("FULLDISCRIPTION", details);
    }

    private String convertDateFormatServicePeriod(String date) {
        LOG.debug("Start convertDateFormat method");
        if (date != null && !date.isEmpty()) {
            StringBuffer sb = new StringBuffer();
            int count = 0;
            String dateArrayByUnder[] = date.split("-");
            for (int i = 0; i < dateArrayByUnder.length; i++) {
                date = dateArrayByUnder[i].trim();
                String dateArray[] = date.split("/");
                if (dateArray.length == 3) {
                    sb.append(dateArray[2] + dateArray[0] + dateArray[1]);
                    if (count == 0) {
                        sb.append("-");
                    }
                    count++;
                }

            }
            LOG.debug("End convertDateFormat method");
            return sb.toString();
        }
        return "";
    }

    private String convertDateFormat(String date) {
        LOG.debug("Start convertDateFormat method");
        String converted = "";
        if (date != null && !date.isEmpty()) {
            String dateArray[] = date.split("/");
            if (dateArray.length == 3) {
                // convert days and month to double character
                if(dateArray[0].length()==1){
                    dateArray[0]="0"+dateArray[0];
                }
                if(dateArray[1].length()==1){
                    dateArray[1]="0"+dateArray[1];
                }
                converted = dateArray[2] + dateArray[0] + dateArray[1];
            }
            LOG.debug("End convertDateFormat method");
            return converted;
        }
        return "";
    }

    @SuppressWarnings("unchecked")
    public String getFullDescription() throws Exception {
        LOG.debug("Start getFullDescription method");
        String longdescrId = ServletActionContext.getRequest().getParameter("longdescr");
        try {
            if (longdescrId != null && !longdescrId.isEmpty()) {
                int longdescr = Integer.parseInt(longdescrId);
                Map<String, Map<String, List<FullDescription>>> fullDescriptions = userService.getFullDescription(longdescr);
                if (fullDescriptions != null) {
                    ServletActionContext.getRequest().getSession().setAttribute("FULLDESCRIPTIONMAP", fullDescriptions);
                    Map<String, Object> map = ActionContext.getContext().getSession();
                    String page = (String) map.get("page");
                    if (page == null || !page.equals("fullreport")) {
                        map.put("page", "fulldescription");// default
                    }
                    LOG.debug("End getFullDescription method");
                    return SUCCESS;
                }
            } else {
                LOG.error("Long Description Id is : " + longdescrId);
                return INPUT;
            }
        } catch (HibernateException e) {
            sessionAttributes.put(WebUtilityConstants.ERROR_KEY, WebUtilityConstants.ERROR_MESSAGE);
            LOG.error("Exception in HibernateException", e);
            return ERROR;
        }
        return INPUT;

    }

    private void getTestEligibility(XsElement_ element) {
        LOG.debug("Start getTestEligibility method");
        if (element != null && element.getRelationShipCode().trim().equals("18")) {
            eligibility270Writer.getEligibility271Parser().getFullDetailResponseByTraceNum("000000001");
            LOG.debug("End getTestEligibility method");
        } else {
            eligibility270Writer.getEligibility271Parser().getFullDetailResponseByTraceNum("000000002");
            LOG.debug("End getTestEligibility method");
        }
    }

    @Override
    public void setSession(Map<String, Object> sessionAttributes) {
        this.sessionAttributes = sessionAttributes;

    }

    public String getShortReport() throws Exception {
        LOG.debug("Start getShortReport method");
        String tracerNumber = ServletActionContext.getRequest().getParameter("eligibilitytracernumber");
        errorCode = "";
        try {
            if (tracerNumber != null && !tracerNumber.isEmpty()) {
                FullDetailResponse details = eligibility270Writer.getEligibility271Parser().getFullDetailResponseByTraceNum(tracerNumber);
                if (details == null) {
                    EligibilityOutput output = new EligibilityOutput();
                    Edi271shortdesc shortdetails = eligibility270Writer.getEligibility271Parser().getshortDescriptionByTraceNum(tracerNumber);
                    if (shortdetails != null) {
                        output.setEdimessage(shortdetails.getEdimessage());
                        output.setEligibilityoutcomecode(shortdetails.getEligibilityoutcomecode());
                        output.setEligibilityoutcomemessage(shortdetails.getEligibilityoutcomemessage());
                        output.setEligibilitytracenumber(shortdetails.getEligibilitytracernumber());
                        if (shortdetails.getPatientsummary() != null) {
                            output.setDateofbirth(shortdetails.getPatientsummary().getDateofbirth());
                            output.setMembernumber(shortdetails.getPatientsummary().getMembernumber());
                            output.setFirstname(shortdetails.getPatientsummary().getFirstname());
                            output.setLastname(shortdetails.getPatientsummary().getLastname());
                            output.setGender(shortdetails.getPatientsummary().getGender());
                        }
                        ServletActionContext.getRequest().getSession().setAttribute("ELIGIBILITYERROR", output.getEligibilityoutcomecode());
                        ServletActionContext.getRequest().getSession().setAttribute("ELIGIBILITYOUTPUT", output);
                    }

                }
                
                sessionAttributes.put("tab", "11");
                LOG.debug("End getShortReport method");
                return SUCCESS;
            }

        } catch (HibernateException e) {
            sessionAttributes.put("tab", "12");
            sessionAttributes.put(WebUtilityConstants.ERROR_KEY, WebUtilityConstants.ERROR_MESSAGE);
            LOG.error("Exception in HibernateException", e);
            return ERROR;
        }
        return INPUT;
    }

    public String getFullReport() throws Exception {
        errorCode = "";
        sessionAttributes.put("tab", "11");
        sessionAttributes.put("page", "fullreport");
        LOG.debug("End getFullReport method");
        return getFullDescription();

    }

    public String batchProcess(){
        try{
            startProcess.startTask();
        }catch(Exception e){
            e.printStackTrace();
            return ERROR;
        }
        return SUCCESS;
    }
}
