package com.webeligibility.actions;

import java.io.IOException;
import java.math.BigInteger;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.SessionAware;
import org.hibernate.HibernateException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.eligibility270.dbentities.PayerDetails;
import com.eligibility270.writer.DBSequenceType;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
import com.webeligibility.constants.WebUtilityConstants;
import com.webeligibility.service.UserService;
import com.webeligibility.utils.GetPayersProvidersListUtil;

public class UpdatePayerAction extends ActionSupport implements ModelDriven<PayerDetails>,SessionAware {
    private static final Logger LOG = LoggerFactory.getLogger(UpdatePayerAction.class);
    private static final long serialVersionUID = 2368885976885601344L;

    private PayerDetails payer;
    private Map<String, Object> sessionAttributes = null;
    @SuppressWarnings("rawtypes")
    @Autowired
    private UserService userService;

    @Override
    public PayerDetails getModel() {
        if (this.payer == null) {
            payer = new PayerDetails();
        }
        return payer;
    }

    public String getpayerdetails() {
        LOG.debug("Start getpayerdetails method");
        JSONObject obj = new JSONObject();
        HttpServletResponse response = ServletActionContext.getResponse();
        try {
            String payerId = ServletActionContext.getRequest().getParameter("payercode");
            if (payerId != null) {
                payer = userService.getPayerDetails(payerId);
                if (payer != null) {
                    Map<String, String> payerDetails = new HashMap<String, String>();
                    payerDetails.put("PAYERID", payer.getId().toString());
                    payerDetails.put("PAYERCODE", payer.getSourceidentificationcode().trim());
                    payerDetails.put("PAYERNAME", payer.getSourcename().trim());
                    payerDetails.put("PAYERIDCODEQUALIFIER", payer.getSourceidentificationcodequalifier().trim());
                    payerDetails.put("PAYERIDENTIFIERCODE", payer.getSourceentityidentifiercode().trim());
                    payerDetails.put("PAYERTYPEQUALIFIER", payer.getSourceentitytypequalifier().trim());
                    obj.put("PAYERDETAILS", payerDetails);

                }
            }
        } catch (HibernateException e) {
            LOG.error("Exception in HibernateException", e);
            sessionAttributes.put(WebUtilityConstants.ERROR_KEY, WebUtilityConstants.ERROR_MESSAGE);
            return ERROR;
        }
        try {
            response.getWriter().write(obj.toString());
        } catch (IOException e) {
            LOG.error("Exception in getpayerdetails", e);
            sessionAttributes.put(WebUtilityConstants.ERROR_KEY, WebUtilityConstants.ERROR_MESSAGE);
            return ERROR;
        }
        LOG.debug("End getpayerdetails method");
        return NONE;
    }

    @SuppressWarnings("unchecked")
    @Override
    public String execute() throws Exception {
        LOG.debug("Start getpayerdetails method");
        payer.setSourceidentificationcode(payer.getNewpayerid());
        try {
            if (payer.getId() == null) {
                BigInteger payerId = userService.nextVal(DBSequenceType.PAYERDETAILS_ID);
                payer.setId(payerId.intValue());
            }
            userService.saveOrUpdate(payer);
            GetPayersProvidersListUtil.getPayerList(userService, true);
            this.payer = new PayerDetails();
            ActionContext.getContext().getValueStack().push(payer);
            sessionAttributes.put("tab", "2");
            sessionAttributes.put("payersuccess", "Data Saved Successfully.");
        } catch (HibernateException e) {
            if (payer.getId() == null) {
                sessionAttributes.put("tab", "6");
            }else{
                sessionAttributes.put("tab", "5");
            }
            LOG.error("Exception in HibernateException", e);
            sessionAttributes.put(WebUtilityConstants.ERROR_KEY, WebUtilityConstants.ERROR_MESSAGE);
            return ERROR;
        }
        LOG.debug("End getpayerdetails method");
        return SUCCESS;
    }

    @Override
    public void setSession(Map<String, Object> sessionAttributes) {
        this.sessionAttributes = sessionAttributes;

    }
}
