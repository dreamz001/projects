package com.webeligibility.actions;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.opensymphony.xwork2.ActionSupport;

public class DownloadFileAction extends ActionSupport implements
		ServletRequestAware {

	private static final long serialVersionUID = -1631489178191247577L;
	private static final Logger LOG = LoggerFactory.getLogger(DownloadFileAction.class);
	private InputStream fileInputStream;

	private HttpServletResponse response;
	private HttpServletRequest request;
	private String fileName;

	public InputStream getFileInputStream() {
		return fileInputStream;
	}

	@Override
	public void setServletRequest(HttpServletRequest request) {
		this.request = request;
	}

	
	@Override
	public String execute() throws Exception {
		LOG.debug("Start execute method");
		String filePath = request.getParameter("downloadFile");
		File fileToDownload=new File(filePath);
		fileName=fileToDownload.getName();
		fileInputStream = new FileInputStream(fileToDownload);
		LOG.debug("End execute method");
		return SUCCESS;

	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	
	
}
