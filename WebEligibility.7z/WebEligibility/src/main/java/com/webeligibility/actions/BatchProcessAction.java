package com.webeligibility.actions;

import java.io.File;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.FileUtils;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.SessionAware;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.batch.eligiblity.main.StartProcess;
import com.eligibility270.dbentities.EligibilityBatchFile;
import com.opensymphony.xwork2.ActionSupport;
import com.webeligibility.constants.WebUtilityConstants;
import com.webeligibility.service.UserService;
import com.webeligibility.utils.GetPayersProvidersListUtil;

@Component
public class BatchProcessAction extends ActionSupport implements ServletRequestAware,SessionAware{

	private static final long serialVersionUID = 4557057830127750486L;
	private static final Logger LOG = LoggerFactory.getLogger(BatchProcessAction.class);
	private List<File> batchFile;
    private List<String> batchFileFileName;
    private List<String> batchFileContentType;
    private HttpServletRequest request;
    private Map<String, Object> sessionAttributes = null;
    
    @Autowired
    private UserService userService;
    
    private static String inboxPath;
    private static String outboxPath;
    
    @Autowired
    private StartProcess startProcess;
    
    public static String getInboxPath() {
		return inboxPath;
	}

	public static String getOutboxPath() {
		return outboxPath;
	}

	public List<File> getBatchFile() {
    	if(this.batchFile==null){
    		this.batchFile=new ArrayList<File>();
    	}
		return batchFile;
	}

	public void setBatchFile(List<File> batchFile) {
		this.batchFile = batchFile;
	}

	public List<String> getBatchFileFileName() {
		if(this.batchFileFileName==null){
			batchFileFileName=new ArrayList<String>();
		}
		return batchFileFileName;
	}

	public void setBatchFileFileName(List<String> batchFileFileName) {
		this.batchFileFileName = batchFileFileName;
	}

	public List<String> getBatchFileContentType() {
		if(this.batchFileContentType==null){
			this.batchFileContentType=new ArrayList<String>();
		}
		return batchFileContentType;
	}

	public void setBatchFileContentType(List<String> batchFileContentType) {
		this.batchFileContentType = batchFileContentType;
	}

	@Override
    public void setServletRequest(HttpServletRequest request) {
        this.request=request;        
    }
    
    @Override
    public String execute() throws Exception {
    	LOG.debug("Start execute method");
    	sessionAttributes.put("tab", "13");
    	if(batchFile==null || batchFile.size()==0){
    		sessionAttributes.put("uploadbatchfile","Please select some files to upload");
    		return INPUT;
    	}
    	if(uploadFile().equals(SUCCESS)){
    		LOG.debug("End execute method");
    		return batchProcess();
    	}
    	else {
    		LOG.debug("End execute method");
			return ERROR;
		}
    	
    }
    
    private String uploadFile(){
    	LOG.debug("Start uploadFile method");
      //  System.out.println("Working Directory::"+System.getProperty("user.dir"));
        inboxPath=request.getSession().getServletContext().getRealPath("").concat("edibatchfiles"+File.separator+"Inbox");
        outboxPath=request.getSession().getServletContext().getRealPath("").concat("edibatchfiles"+File.separator+"Outbox");
        
        //filePath="D:\\";
        try {
        for(int i=0;i<batchFile.size();i++){
        	File file=batchFile.get(i);
        File uploadedFile=new File(inboxPath, batchFileFileName.get(i));
        
            FileUtils.copyFile(file, uploadedFile);
        }
        } catch (IOException e) {
        	sessionAttributes.put("tab", "14");
        	sessionAttributes.put(WebUtilityConstants.ERROR_KEY, WebUtilityConstants.ERROR_MESSAGE);
            LOG.error("Exception in HibernateException", e);
            return ERROR;
        }
        LOG.debug("End uploadFile method");
       return SUCCESS; 
    }
    
    public String batchProcess(){
    	LOG.debug("Start batchProcess method");
    	boolean productionStatus = GetPayersProvidersListUtil.getProductionStatus();
    	if(productionStatus){
        try{
            startProcess.startTask();
        }catch(Exception e){
        	sessionAttributes.put("tab", "14");
        	sessionAttributes.put(WebUtilityConstants.ERROR_KEY, WebUtilityConstants.ERROR_MESSAGE);
            LOG.error("Exception in HibernateException", e);
            return ERROR;
        }
        GetPayersProvidersListUtil.getShortReport(userService);
        LOG.debug("End batchProcess method");
    	}else{
    		List<EligibilityBatchFile> processedFileList=new ArrayList<EligibilityBatchFile>();
    		EligibilityBatchFile batchFile= new EligibilityBatchFile();
    		batchFile.setId(1);
    		batchFile.setInputfilename("DefaultFile.txt");
    		batchFile.setCreatedon(new Timestamp(new Date().getTime()));
    		batchFile.setOutputfilename(outboxPath+File.separator+"DefaultFile_OUTPUT.txt");
    		processedFileList.add(batchFile);
    		processFilesInSession(processedFileList);
    		sessionAttributes.put("uploadbatchfile","Production Mode:'TEST'. So this is the default file, please change the production settings or Contact Admin");
    	}
        return SUCCESS;
    }
    
    public static void processFilesInSession(List<EligibilityBatchFile> processedFileList){
    	ServletActionContext.getRequest().getSession().setAttribute("BATCHOUTPUTFILELIST", processedFileList);
    }

	@Override
	public void setSession(Map<String, Object> sessionAttributes) {
		this.sessionAttributes=sessionAttributes;		
	}
}
