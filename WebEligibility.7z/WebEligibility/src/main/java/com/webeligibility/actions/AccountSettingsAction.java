package com.webeligibility.actions;

import java.util.Map;

import org.hibernate.HibernateException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.eligibility270.mastertables.entities.Deliverymethod;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
import com.webeligibility.constants.WebUtilityConstants;
import com.webeligibility.service.UserService;
import com.webeligibility.utils.GetPayersProvidersListUtil;

public class AccountSettingsAction extends ActionSupport implements ModelDriven<Deliverymethod> {
    
    private static final Logger LOG = LoggerFactory.getLogger(AccountSettingsAction.class);
    private static final long serialVersionUID = -6193881422570137284L;
    private Deliverymethod deliverymethod;
    @SuppressWarnings("rawtypes")
    @Autowired
    private UserService userService;

    @Override
    public Deliverymethod getModel() {
        if (this.deliverymethod == null) {
            this.deliverymethod = new Deliverymethod();
        }
        return deliverymethod;
    }

    @SuppressWarnings("unchecked")
    @Override
    public String execute() throws Exception {
        LOG.debug("Start execute method");
        Map<String, Object> map = ActionContext.getContext().getSession();
        try {
            Deliverymethod oldMethod = userService.getDeliveryMethod(deliverymethod.getId());
            if (oldMethod != null) {
                oldMethod.setUsername(deliverymethod.getUsername().trim());
                oldMethod.setPassword(deliverymethod.getPassword().trim());
                oldMethod.setSenderid(deliverymethod.getUsername().trim());
                oldMethod.setIsonproduction(deliverymethod.getIsonproduction());
                userService.saveOrUpdate(oldMethod);
                map.put("accountsettingsuccess", "Data saved successfully");
                GetPayersProvidersListUtil.getAccountSettings(userService, true);
            }
            map.put("tab", "9");
            LOG.debug("End execute method");
            return SUCCESS;
        } catch (HibernateException e) {
            map.put("tab", "10");
            map.put(WebUtilityConstants.ERROR_KEY, WebUtilityConstants.ERROR_MESSAGE);
            LOG.error("Exception in HibernateException", e);
            return ERROR;
        }
    }
}
