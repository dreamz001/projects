package com.webeligibility.actions;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.SessionAware;
import org.hibernate.HibernateException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
import com.opensymphony.xwork2.util.ValueStack;
import com.webeligibility.constants.WebUtilityConstants;
import com.webeligibility.model.User;
import com.webeligibility.service.UserService;
import com.webeligibility.utils.EmailUtility;
import com.webeligibility.utils.GetPayersProvidersListUtil;

public class LoginAction extends ActionSupport implements ModelDriven<User>, SessionAware {
    private static final Logger LOG = LoggerFactory.getLogger(LoginAction.class);
    private static final long serialVersionUID = 1L;
    @Autowired
    private User user;
    private Map<String, Object> sessionAttributes = null;
    @SuppressWarnings("rawtypes")
    @Autowired
    private UserService userService;

    @Override
    public User getModel() {
        if (this.user == null) {
            this.user = new User();
        }
        return user;
    }

    @Override
    public String execute() throws Exception {
        LOG.debug("Start execute method");
        String pass = user.getPassword().trim();
        try {
            if (user.getEmail() != null && !user.getEmail().isEmpty()) {
                user = userService.getUserByEmailId(user.getEmail());
                if (user != null) {
                    if (user.getPassword().trim().equals(pass)) {
                        sessionAttributes.put("USER", user);
                        // setting user list in session for managing users
                        getUsersList();
                        // fetch patient report and set in session for managing
                        // report
                        getShortReport();
                        // removing the action object from value stack
                        user = new User();
                        ValueStack stack = ActionContext.getContext().getValueStack();
                        stack.push(user);
                        GetPayersProvidersListUtil.getPayerList(userService, false);
                        GetPayersProvidersListUtil.getProviderList(userService, false);
                        GetPayersProvidersListUtil.getServiceTypeCodes(userService);
                        GetPayersProvidersListUtil.getAccountSettings(userService, false);
                        LOG.debug("End execute method");
                        return SUCCESS;
                    } else {
                        addActionError("Email id or Password is Invalid");
                        return INPUT;
                    }
                } else {
                    addActionError("Email id or Password is Invalid");
                    return INPUT;
                }
            } else {
                addActionError("Email id or Password is Invalid");
                return INPUT;
            }
        } catch (HibernateException e) {
            sessionAttributes.put(WebUtilityConstants.ERROR_KEY, WebUtilityConstants.ERROR_MESSAGE);
            LOG.error("Exception in HibernateException", e);
            return ERROR;
        }

    }

    public String generateTempPassword() throws Exception {
        LOG.debug("Start generateTempPassword method");
        try {
            user = userService.getUserByEmailId(user.getEmail());
            if (user != null) {
                String tempPass = RandomStringUtils.randomAlphanumeric(8);
                int result = userService.updatePassword(user.getEmail(), tempPass);
                if (result > 0) {
                    try {
                        EmailUtility.sendEmail(user.getEmail(), tempPass, false);
                    } catch (Exception e) {
                        LOG.debug("Exception in send mail", e);
                        sessionAttributes.put("errorsendmail", WebUtilityConstants.ERROR_MESSAGE);
                        return ERROR;
                    }
                    LOG.debug("End generateTempPassword method");
                    return SUCCESS;
                } else {
                    addActionError("Email id NOT found");
                    return INPUT;
                }
            }
            addActionError("Email id NOT found");
            return INPUT;
        } catch (HibernateException e) {
            sessionAttributes.put(WebUtilityConstants.ERROR_KEY, WebUtilityConstants.ERROR_MESSAGE);
            LOG.error("Exception in HibernateException", e);
            return ERROR;
        }
    }

    public String changePassword() throws Exception {
        LOG.debug("Start changePassword method");
        HttpSession session = ServletActionContext.getRequest().getSession(false);
        user = (User) session.getAttribute("USER");
        if (user == null) {
            return INPUT;
        }
        HttpServletRequest request = ServletActionContext.getRequest();
        String oldPassword = request.getParameter("password");
        try {
            if (user.getPassword().trim().equals(oldPassword.trim())) {
                if (request.getParameter("newpassword").trim().equals(request.getParameter("conformpassword").trim())) {
                    userService.updatePassword(user.getEmail(), request.getParameter("newpassword").trim());
                    LOG.debug("End changePassword method");
                    return SUCCESS;
                } else
                    addActionError("Password NOT Matched");
                return INPUT;

            } else
                addActionError("Invalid Old Password");
            return INPUT;
        } catch (HibernateException e) {
            sessionAttributes.put(WebUtilityConstants.ERROR_KEY, WebUtilityConstants.ERROR_MESSAGE);
            LOG.error("Exception in HibernateException", e);
            return ERROR;
        }
    }

    public String logout() throws Exception {
        LOG.debug("Start logout method");
        HttpSession session = ServletActionContext.getRequest().getSession(false);
        session.invalidate();
        LOG.debug("End logout method");
        return SUCCESS;
    }

    @Override
    public void setSession(Map<String, Object> sessionAttributes) {
        this.sessionAttributes = sessionAttributes;

    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    @SuppressWarnings("unchecked")
    public String getUsersList() {
        LOG.debug("Start getUsersList method");
        try {

            List<User> userList = userService.getUserList();
            ServletActionContext.getRequest().getSession().setAttribute("USERS", userList);
        } catch (HibernateException e) {
            sessionAttributes.put(WebUtilityConstants.ERROR_KEY, WebUtilityConstants.ERROR_MESSAGE);
            LOG.error("Exception in HibernateException", e);
            return ERROR;
        }
        LOG.debug("End getUsersList method");
        return SUCCESS;
    }

    public void getShortReport() {
        LOG.debug("Start getShortReport method");
        try {
            GetPayersProvidersListUtil.getShortReport(userService);
        } catch (HibernateException e) {
            sessionAttributes.put(WebUtilityConstants.ERROR_KEY, WebUtilityConstants.ERROR_MESSAGE);
            LOG.error("Exception in HibernateException", e);
        }
        LOG.debug("End getShortReport method");
    }

}
