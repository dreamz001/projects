package com.webeligibility.actions;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.SessionAware;
import org.hibernate.HibernateException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.eligibility270.writer.DBSequenceType;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
import com.webeligibility.constants.WebUtilityConstants;
import com.webeligibility.model.ScreenMaster;
import com.webeligibility.model.User;
import com.webeligibility.model.UserScreenmasterMap;
import com.webeligibility.service.UserService;
import com.webeligibility.utils.EmailUtility;

public class ManageUserAction extends ActionSupport implements
		ModelDriven<User>, SessionAware {
	private static final Logger LOG = LoggerFactory
			.getLogger(ManageUserAction.class);
	private static final long serialVersionUID = 1L;
	@Autowired
	private User user;
	private Map<String, Object> sessionAttributes = null;
	@SuppressWarnings("rawtypes")
	@Autowired
	private UserService userService;

	@Override
	public User getModel() {
		if (this.user == null) {
			this.user = new User();
		}
		return user;
	}

	public String addUserDetail() throws Exception {
		LOG.debug("Start addUserDetail method");
		try {
			boolean status = userService.isEmailExist(user.getEmail());
			if (status) {
				addFieldError("email", "Email Id already exist.");
				return INPUT;
			}
			user.setUserid(userService.nextVal(DBSequenceType.USER_ID)
					.intValue());

			List<UserScreenmasterMap> userScreenmasterMaps = new ArrayList<UserScreenmasterMap>();
			for (int i = 1; i <= 7; i++) {
				if (i == 5) {
					continue;// skip the account settings permission
				}
				UserScreenmasterMap screenmasterMap = new UserScreenmasterMap();
				ScreenMaster master = new ScreenMaster();
				master.setScreenid(i);
				screenmasterMap.setId(userService.nextVal(DBSequenceType.USER_SCREENMASTER_MAP_ID).intValue());
				screenmasterMap.setScreenid(master);
				setPermissions(i, screenmasterMap);
				screenmasterMap.setUserid(user);
				userScreenmasterMaps.add(screenmasterMap);
			}
			user.setUserScreenmasterMap(userScreenmasterMaps);
			user.setTelephone(Long.parseLong(user.getConvertTelephone()));
			String tempPass = RandomStringUtils.randomAlphanumeric(8);
			user.setPassword(tempPass);
			userService.addUserDetail(user);
			try {
				EmailUtility.sendEmail(user.getEmail(), tempPass, true);
			} catch (Exception e) {
				LOG.debug("Exception in send mail", e);
				sessionAttributes.put(WebUtilityConstants.ERROR_KEY,
						WebUtilityConstants.ERROR_MESSAGE);
				return ERROR;
			}
			getUsersList();
			sessionAttributes
					.put("useraddsuccess", "User created successfully");
			sessionAttributes.put("CURRENTPAGE", "manageuser");
			LOG.debug("End addUserDetail method");
			return SUCCESS;
		} catch (HibernateException e) {
			LOG.error("Exception in HibernateException", e);
			sessionAttributes.put(WebUtilityConstants.ERROR_KEY,
					WebUtilityConstants.ERROR_MESSAGE);
			return ERROR;
		}

	}

	@SuppressWarnings("unchecked")
	public String updateUser() throws Exception {
		LOG.debug("Start updateUser method");
		try {
			Enumeration<String> value = ServletActionContext.getRequest()
					.getParameterNames();
			int i = 0;
			while (value.hasMoreElements()) {
				String nm = value.nextElement();
			}
			boolean status = userService.isEmailExist(user.getEmail(),
					user.getUserid());
			if (status) {
				addFieldError("email", "Email Id already exist.");
				return INPUT;
			}
			user.setTelephone(Long.parseLong(user.getConvertTelephone()));
			User olduser = (User) ServletActionContext.getRequest()
					.getSession().getAttribute("UPDATEUSER");

			List<UserScreenmasterMap> userScreenmasterMaps = olduser
					.getUserScreenmasterMap();
			List<UserScreenmasterMap> newuserScreenmasterMaps = new ArrayList<UserScreenmasterMap>();
			for (UserScreenmasterMap screenList : userScreenmasterMaps) {
				setPermissions(screenList.getScreenid().getScreenid(),
						screenList);
				newuserScreenmasterMaps.add(screenList);
			}
			user.setUserScreenmasterMap(newuserScreenmasterMaps);
			userService.saveOrUpdate(user);
			getUsersList();
			sessionAttributes.put("userupdatesuccess",
					"User updated successfully");
			sessionAttributes.put("CURRENTPAGE", "manageuser");
			LOG.debug("End updateUser method");
			return SUCCESS;
		} catch (HibernateException e) {
			LOG.error("Exception in HibernateException", e);
			sessionAttributes.put(WebUtilityConstants.ERROR_KEY,
					WebUtilityConstants.ERROR_MESSAGE);
			return ERROR;
		}
	}

	@Override
	public void setSession(Map<String, Object> sessionAttributes) {
		this.sessionAttributes = sessionAttributes;

	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	private void setPermissions(int i, UserScreenmasterMap screenmasterMap) {
		LOG.debug("Start setPermissions method");
		if (i == 1) {
			screenmasterMap.setIspermission(true);
		} else if (i == 2) {
			screenmasterMap.setIspermission(user.isManagepayer());
		} else if (i == 3) {
			screenmasterMap.setIspermission(user.isManageprovider());
		} else if (i == 4) {
			screenmasterMap.setIspermission(user.isManageuser());
		} else if (i == 6) {
			screenmasterMap.setIspermission(user.isHistory());
		} else if (i == 7) {
			screenmasterMap.setIspermission(user.isBatchprocess());
		}
		LOG.debug("End setPermissions method");
	}

	@SuppressWarnings("unchecked")
	public String getUsersList() {
		LOG.debug("Start getUsersList method");
		try {

			List<User> userList = userService.getUserList();
			ServletActionContext.getRequest().getSession()
					.setAttribute("USERS", userList);
		} catch (HibernateException e) {
			LOG.error("Exception in HibernateException", e);
			sessionAttributes.put(WebUtilityConstants.ERROR_KEY,
					WebUtilityConstants.ERROR_MESSAGE);
			return ERROR;
		}
		LOG.debug("End getUsersList method");
		return SUCCESS;
	}

	public String updateUserDetails() {
		LOG.debug("Start updateUserDetails method");
		try {
			String uid = ServletActionContext.getRequest().getParameter(
					"userid");
			user = userService.getUserByUserId(Integer.parseInt(uid));
			for (UserScreenmasterMap screen : user.getUserScreenmasterMap()) {
				if (screen.getScreenid().getScreenid() == 1
						&& screen.isIspermission()) {
					user.setDashboard(true);
				}
				if (screen.getScreenid().getScreenid() == 2
						&& screen.isIspermission()) {
					user.setManagepayer(true);
				}
				if (screen.getScreenid().getScreenid() == 3
						&& screen.isIspermission()) {
					user.setManageprovider(true);
				}
				if (screen.getScreenid().getScreenid() == 4
						&& screen.isIspermission()) {
					user.setManageuser(true);
				}
				if (screen.getScreenid().getScreenid() == 6
						&& screen.isIspermission()) {
					user.setHistory(true);
				}
				if (screen.getScreenid().getScreenid() == 7
						&& screen.isIspermission()) {
					user.setBatchprocess(true);
				}

			}
			ServletActionContext.getRequest().getSession()
					.setAttribute("UPDATEUSER", user);

		} catch (HibernateException e) {
			LOG.error("Exception in HibernateException", e);
			sessionAttributes.put(WebUtilityConstants.ERROR_KEY,
					WebUtilityConstants.ERROR_MESSAGE);
			return ERROR;
		}
		LOG.debug("End updateUserDetails method");
		return SUCCESS;
	}

	public String deleteUser() {
		LOG.debug("Start deleteUser method");
		try {
			String uid = ServletActionContext.getRequest().getParameter(
					"userid");
			HttpSession session = ServletActionContext.getRequest()
					.getSession();
			User currentUser = (User) session.getAttribute("USER");
			int status = userService.deleteUser(Integer.parseInt(uid));
			if (status > 0) {
				sessionAttributes.remove("userupdatesuccess");
				getUsersList();
				if (currentUser.getUserid() == Integer.parseInt(uid)) {
					session.invalidate();
					return LOGIN;
				}
			}

		} catch (HibernateException e) {
			LOG.error("Exception in HibernateException", e);
			sessionAttributes.put(WebUtilityConstants.ERROR_KEY,
					WebUtilityConstants.ERROR_MESSAGE);
			return ERROR;
		}
		LOG.debug("End deleteUser method");
		return SUCCESS;
	}

}
