package com.webeligibility.comparator;

import java.util.Comparator;

import com.webeligibility.model.UserScreenmasterMap;

public class UserScreenMapComparator implements Comparator<UserScreenmasterMap>{

    @Override
    public int compare(UserScreenmasterMap o1, UserScreenmasterMap o2) {
        if(o1.getScreenid().getScreenid() > o2.getScreenid().getScreenid())
            return 1;
        else if(o1.getScreenid().getScreenid() < o2.getScreenid().getScreenid())
            return (-1);
        else
            return 0;
    }

}
