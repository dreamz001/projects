package com.webeligibility.listeners;

import java.sql.Timestamp;
import java.util.Date;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.webeligibility.dao.UserDao;
import com.webeligibility.dao.UserDaoImpl;
import com.webeligibility.model.User;

public class SessionListener implements HttpSessionListener{
    private static final Logger LOG = LoggerFactory.getLogger(SessionListener.class);
    @Override
    public void sessionCreated(HttpSessionEvent arg0) {
        // TODO Auto-generated method stub
    }

    @SuppressWarnings("rawtypes")
    @Override
    public void sessionDestroyed(HttpSessionEvent sessionEvent) {
        LOG.debug("Start sessionDestroyed method");
        HttpSession session = sessionEvent.getSession();
        User user = (User) session.getAttribute("USER");
        UserDao userDao=new UserDaoImpl();
        if (user != null) {
            Timestamp lastloggedin=new Timestamp(new Date().getTime());
            try {
                if(userDao.getSessionFactory()==null){
                    userDao.setSessionFactory((SessionFactory)WebApplicationContextUtils.getRequiredWebApplicationContext(session.getServletContext()).getBean("sessionFactory"));
                }
                userDao.updateLastLoggedIn(user.getEmail(), lastloggedin);
            } catch (Exception e) {
                LOG.error("Exception in sessionDestroyed method",e);
            }
        }
        LOG.debug("End sessionDestroyed method");
    }

}
