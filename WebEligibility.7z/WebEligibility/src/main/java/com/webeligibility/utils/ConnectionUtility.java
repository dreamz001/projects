package com.webeligibility.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ConnectionUtility {
    private static final Logger LOG = LoggerFactory.getLogger(ConnectionUtility.class);
    public static Connection getConnection(){
        LOG.debug("Start getConnection method");
        Connection con=null;
        Properties prop=new Properties();
        try {
            ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
            prop.load(classLoader.getResourceAsStream("config/database.properties"));
            Class.forName(prop.getProperty("jdbc.driverClassName"));
            con=DriverManager.getConnection(prop.getProperty("jdbc.databaseurl"), prop.getProperty("jdbc.username"), prop.getProperty("jdbc.password"));
        } catch (Exception e) {
            LOG.error("Exception in get connection", e);
        }
        LOG.debug("End getConnection method");
        return con;
    }
}
