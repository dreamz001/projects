package com.webeligibility.utils;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class EmailUtility {
    private static final Logger LOG = LoggerFactory.getLogger(EmailUtility.class);
    public static void sendEmail(String email,String tempPassword, boolean isNewAccount) throws Exception {
        LOG.debug("Start sendEmail method");
        Properties mailProp=new Properties();
            ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
            mailProp.load(classLoader.getResourceAsStream("mailexchangeconfiguration.properties"));
            final String username = mailProp.getProperty("smtp.username");
            final String password = mailProp.getProperty("smtp.password");

            Properties props = new Properties();
            props.put("mail.smtp.auth", mailProp.getProperty("mail.smtp.auth"));
            props.put("mail.smtp.starttls.enable", mailProp.getProperty("mail.smtp.starttls.enable"));
            props.put("mail.smtp.host", mailProp.getProperty("smtp.host"));
            props.put("mail.smtp.port", mailProp.getProperty("mail.smtp.port"));

            Session session = Session.getInstance(props, new javax.mail.Authenticator() {
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(username, password);
                }
            });
            
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(username));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(email));
            MimeBodyPart bodyPart=new MimeBodyPart();
            
            if(isNewAccount){
                message.setSubject("Welcome to Ezedi-Central");
                bodyPart.setText(getmailBodyForNewAccount(email, tempPassword),"UTF-8","html");
            }else{
                message.setSubject("Reset Password");
                bodyPart.setText(getmailBodyForResetPassword(email, tempPassword),"UTF-8","html");
            }
            Multipart multipart=new MimeMultipart();
            multipart.addBodyPart(bodyPart);
            message.setContent(multipart);
            Transport.send(message);
            LOG.debug("End sendEmail method");
        
    }
    private static String getURLPath(){
        LOG.debug("Start getURLPath method");
        HttpServletRequest request=ServletActionContext.getRequest();
        StringBuilder path=new StringBuilder();
        path.append(request.getScheme());
        path.append("://");
        path.append(request.getServerName());
        path.append(":");
        path.append(request.getServerPort());
        path.append(request.getContextPath());
        path.append("/login");
        LOG.debug("End getURLPath method");
        return path.toString();
    }
    private static String getmailBodyForNewAccount(String email,String tempPassword){
        LOG.debug("Start getmailBodyForNewAccount method");
        StringBuilder mailBody = new StringBuilder();
        mailBody.append("Greeting </br>");
        mailBody.append("Welcome to Ezedi-Central, your account has been created successfully.");
        mailBody.append("</br> </br>");
        mailBody.append("Please click on below link and use the following credential to login.</br></br>");
        mailBody.append("Email: "+email+"</br>");
        mailBody.append("Password: "+tempPassword+"</br></br><a href='"+getURLPath()+"'>Clik Here to Login</a>");
        LOG.debug("End getmailBodyForNewAccount method");
        return mailBody.toString();
    }
    private static String getmailBodyForResetPassword(String email,String tempPassword){
        LOG.debug("Start getmailBodyForResetPassword method");
        StringBuilder mailBody = new StringBuilder();
        mailBody.append("Greeting </br>");
        mailBody.append("Your password has been reset successfully.");
        mailBody.append("</br> </br>");
        mailBody.append("Please use the following credential for login and change your password.</br></br>");
        mailBody.append("Email: "+email+"</br>");
        mailBody.append("Password: "+tempPassword+"</br></br><a href='"+getURLPath()+"'>Clik Here to Login</a>");
        LOG.debug("End getmailBodyForResetPassword method");
        return mailBody.toString();
    }
}
