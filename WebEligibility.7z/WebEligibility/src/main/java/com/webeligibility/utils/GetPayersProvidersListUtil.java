package com.webeligibility.utils;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.struts2.ServletActionContext;
import org.hibernate.HibernateException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.eligibility270.dbentities.PayerDetails;
import com.eligibility270.dbentities.ProviderDetails;
import com.eligibility270.dbentities.ServiceTypeCodeLookUp;
import com.eligibility270.mastertables.entities.Deliverymethod;
import com.eligibility270.request.reponse.ack.IResponseAckErrorCode;
import com.eligibility270.writer.IConstants;
import com.eligibility271.constants.Ack999Constants;
import com.eligibility271.dbentities.Edi271shortdesc;
import com.webeligibility.service.UserService;

public class GetPayersProvidersListUtil {
    private static final Logger LOG = LoggerFactory.getLogger(GetPayersProvidersListUtil.class);

    @SuppressWarnings({ "rawtypes", "unchecked" })
    public static void getPayerList(UserService userService, boolean reset) throws HibernateException {
        LOG.debug("Start getPayerList method");
        Set<PayerDetails> payerInfoSet = null;
        payerInfoSet = (Set<PayerDetails>) ServletActionContext.getServletContext().getAttribute("PAYERINFOSET");
        if (payerInfoSet == null || reset) {
            List<PayerDetails> payerInfo = null;
            payerInfo = userService.getPayerInfo();
            payerInfoSet = new HashSet<PayerDetails>();
            for (PayerDetails payer : payerInfo) {
                payerInfoSet.add(payer);
            }
            ServletActionContext.getServletContext().setAttribute("PAYERINFOSET", payerInfoSet);
            LOG.debug("End getPayerList method");
        }
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    public static void getProviderList(UserService userService, boolean reset) throws HibernateException {
        LOG.debug("Start getProviderList method");
        Set<ProviderDetails> providerInfoSet = null;
        providerInfoSet = (Set<ProviderDetails>) ServletActionContext.getServletContext().getAttribute("PROVIDERINFOSET");
        if (providerInfoSet == null || reset) {
            List<ProviderDetails> providerInfo = null;
            providerInfo = userService.getProviderInfo();
            providerInfoSet = new HashSet<ProviderDetails>();
            for (ProviderDetails provider : providerInfo) {
                providerInfoSet.add(provider);
            }
            ServletActionContext.getServletContext().setAttribute("PROVIDERINFOSET", providerInfoSet);
            LOG.debug("End getProviderList method");
        }
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    public static void getServiceTypeCodes(UserService userService) throws HibernateException {
        LOG.debug("Start getServiceTypeCodes method");
        List<ServiceTypeCodeLookUp> serviceCodes = null;
        serviceCodes = (List<ServiceTypeCodeLookUp>) ServletActionContext.getServletContext().getAttribute("SERVICECODES");
        if (serviceCodes == null) {
            serviceCodes = userService.getServiceTypeCodes();
            ServletActionContext.getServletContext().setAttribute("SERVICECODES", serviceCodes);
            LOG.debug("End getServiceTypeCodes method");
        }
    }

    @SuppressWarnings("rawtypes")
    public static void getAccountSettings(UserService userService, boolean reset) throws HibernateException {
        LOG.debug("Start getAccountSettings method");
        Deliverymethod deliverymethod = (Deliverymethod) ServletActionContext.getRequest().getServletContext().getAttribute("DELIVERYMETHOD");
        if (deliverymethod == null || reset) {
            deliverymethod = userService.getDeliveryMethod(1);
            if (deliverymethod != null) {
                ServletActionContext.getRequest().getServletContext().setAttribute("DELIVERYMETHOD", deliverymethod);
            }
        }
        LOG.debug("End getAccountSettings method");
    }

    public static boolean getProductionStatus() {
        LOG.debug("Start getProductionStatus method");
        Deliverymethod deliverymethod = (Deliverymethod) ServletActionContext.getRequest().getServletContext().getAttribute("DELIVERYMETHOD");
        if (deliverymethod != null) {
            LOG.debug("End getProductionStatus method");
            return deliverymethod.getIsonproduction();
        }
        return false;
    }

    @SuppressWarnings("unchecked")
    public static List<String> getErrorsListFromContext() {
        LOG.debug("Start getErrorsListFromContext method");
        List<String> errorList = (List<String>) ServletActionContext.getRequest().getServletContext().getAttribute("ERRORSLIST");
        if (errorList == null || errorList.size() == 0) {
            errorList = new ArrayList<String>();
            errorList.add(IConstants.INVALID_REQUEST);
            errorList.add(IResponseAckErrorCode.DUPLICATE_TRACE_NUMBER_OR_DB_ERROR);
            errorList.add(IResponseAckErrorCode.IMPROPER_JSON_FORMAT);
            errorList.add(IResponseAckErrorCode.UNKNOWN);
            errorList.add(IResponseAckErrorCode.VALIDATION_ERROR);
            errorList.add(Ack999Constants.ERROR);
            errorList.add(Ack999Constants.UNAUTHORIZED);
            errorList.add(Ack999Constants.INVALID_REQUEST);

            ServletActionContext.getRequest().getServletContext().setAttribute("ERRORSLIST", errorList);
        }
        LOG.debug("End getErrorsListFromContext method");
        return errorList;
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
    public static void getShortReport(UserService userService) throws HibernateException {
        LOG.debug("Start getShortReport method");
        List<Edi271shortdesc> shortReport = userService.getShortReport();
        ServletActionContext.getRequest().getSession().setAttribute("SHORT_REPORT", shortReport);
        LOG.debug("End getShortReport method");
    }
}
