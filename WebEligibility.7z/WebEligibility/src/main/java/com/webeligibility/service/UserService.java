package com.webeligibility.service;

import java.io.Serializable;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

import org.hibernate.HibernateException;

import com.eligibility270.dbentities.FullDescription;
import com.eligibility270.dbentities.PayerDetails;
import com.eligibility270.dbentities.ProviderDetails;
import com.eligibility270.dbentities.ServiceTypeCodeLookUp;
import com.eligibility270.mastertables.entities.Deliverymethod;
import com.eligibility270.writer.DBSequenceType;
import com.eligibility271.dbentities.Edi271shortdesc;
import com.webeligibility.model.User;

public interface UserService<T, PK extends Serializable> {
    User getUserByEmailId(String emailId) throws HibernateException;

    int updatePassword(String email, String password) throws HibernateException;

    int updateLastLoggedIn(String email, Timestamp lastloggedin) throws HibernateException;

    List<PayerDetails> getPayerInfo() throws HibernateException;

    List<ProviderDetails> getProviderInfo() throws HibernateException;

    List<ServiceTypeCodeLookUp> getServiceTypeCodes() throws HibernateException;

    PayerDetails getPayerDetails(String payerId) throws HibernateException;

    void saveOrUpdate(T params) throws HibernateException;

    BigInteger nextVal(DBSequenceType sequenceType) throws HibernateException;

    ProviderDetails getProviderDetails(String providerId) throws HibernateException;
    
    void addUserDetail(User user) throws HibernateException;
    
    List<User> getUserList()throws HibernateException;
    
    boolean isEmailExist(String email)throws HibernateException;
    
    boolean isEmailExist(String email, int userid)throws HibernateException;
    
    User getUserByUserId(int userid)throws HibernateException;
    
    int deleteUser(int userid)throws HibernateException;
    
    Map<String, Map<String, List<FullDescription>>> getFullDescription(int longdescr)throws HibernateException;
    
    Deliverymethod getDeliveryMethod(int id)throws HibernateException;
    
    List<Edi271shortdesc> getShortReport()throws HibernateException;
    
}
