package com.webeligibility.service;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.eligibility270.dbentities.FullDescription;
import com.eligibility270.dbentities.NetworkIndicatorData;
import com.eligibility270.dbentities.PayerDetails;
import com.eligibility270.dbentities.ProviderDetails;
import com.eligibility270.dbentities.ServiceTypeCodeLookUp;
import com.eligibility270.mastertables.entities.Deliverymethod;
import com.eligibility270.writer.DBSequenceType;
import com.webeligibility.dao.UserDao;
import com.webeligibility.model.User;

@SuppressWarnings("rawtypes")
@Service("userService")
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class UserServiceImpl implements UserService {

    @Autowired
    private UserDao userDao;

    @Override
    public User getUserByEmailId(String emailId) throws HibernateException {
        return userDao.getUserByEmailId(emailId);
    }

    @Override
    public int updatePassword(String email, String password) throws HibernateException {
        return userDao.updatePassword(email, password);
    }

    @Override
    public int updateLastLoggedIn(String email, Timestamp lastloggedin) throws HibernateException {
        return userDao.updateLastLoggedIn(email, lastloggedin);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<PayerDetails> getPayerInfo() throws HibernateException {
        return userDao.getPayerInfo();
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<ProviderDetails> getProviderInfo() throws HibernateException {
        return userDao.getProviderInfo();
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<ServiceTypeCodeLookUp> getServiceTypeCodes() throws HibernateException {
        return userDao.getServiceTypeCodes();
    }

    @Override
    public PayerDetails getPayerDetails(String payerId) throws HibernateException {
        return userDao.getPayerDetails(payerId);
    }

    @SuppressWarnings("unchecked")
    @Override
    public void saveOrUpdate(Object params) throws HibernateException {
        userDao.saveOrUpdate(params);
    }

    @Override
    public BigInteger nextVal(DBSequenceType sequenceType) throws HibernateException {
        return userDao.nextVal(sequenceType);
    }

    @Override
    public ProviderDetails getProviderDetails(String providerId) throws HibernateException {
        return userDao.getProviderDetails(providerId);
    }

    @Override
    public void addUserDetail(User user) throws HibernateException {
        userDao.addUserDetail(user);

    }

    @SuppressWarnings("unchecked")
    @Override
    public List<User> getUserList() throws HibernateException {
        return userDao.getUserList();
    }

    @Override
    public boolean isEmailExist(String email) throws HibernateException {
        return userDao.isEmailExist(email);
    }

    @Override
    public boolean isEmailExist(String email, int userid) throws HibernateException {
        return userDao.isEmailExist(email, userid);
    }

    @Override
    public User getUserByUserId(int userid) throws HibernateException {
        return userDao.getUserByUserId(userid);
    }

    @Override
    public int deleteUser(int userid) throws HibernateException {
        return userDao.deleteUser(userid);
    }

    @SuppressWarnings("unchecked")
    @Override
    public Map<String, Map<String, List<NetworkIndicatorData>>> getFullDescription(int longdescr) throws HibernateException {
        List<FullDescription> fullDescriptionList = userDao.getFullDescription(longdescr);
        String eligibilitystatusinfo = null;
        Map<String, Map<String, List<NetworkIndicatorData>>> mainMap = new LinkedHashMap<String, Map<String, List<NetworkIndicatorData>>>();
        Map<String, List<NetworkIndicatorData>> internalMap = null;
        for (FullDescription mainFullDescription : fullDescriptionList) {
            String plan = null;
            String coveragecode = null;
            List<NetworkIndicatorData> internalList = null;
            if (mainFullDescription == null) {
                continue;
            }
            if (eligibilitystatusinfo == null) {
                eligibilitystatusinfo = mainFullDescription.getEligibilitystatusinfo().trim();
                internalMap = new LinkedHashMap<String, List<NetworkIndicatorData>>();
            } else if (mainFullDescription.getEligibilitystatusinfo().trim().equals(eligibilitystatusinfo)) {
                continue;
            } else if (!(mainFullDescription.getEligibilitystatusinfo().trim().equals(eligibilitystatusinfo))) {
                mainMap.put(eligibilitystatusinfo, internalMap);
                eligibilitystatusinfo = mainFullDescription.getEligibilitystatusinfo().trim();
                internalMap = new LinkedHashMap<String, List<NetworkIndicatorData>>();
            }
            NetworkIndicatorData networkIndicatorData = null;
            for (FullDescription internalFullDescription : fullDescriptionList) {
                if (internalFullDescription == null || !(internalFullDescription.getEligibilitystatusinfo().trim().equals(eligibilitystatusinfo))) {
                    continue;
                }

                if (coveragecode == null) {
                    coveragecode = internalFullDescription.getCoveragecode().trim();
                    internalList = new ArrayList<NetworkIndicatorData>();
                } else if (!(internalFullDescription.getCoveragecode().trim().equals(coveragecode))) {
                    internalMap.put(coveragecode, internalList);
                    coveragecode = internalFullDescription.getCoveragecode().trim();
                    plan = null;
                    internalList = new ArrayList<NetworkIndicatorData>();
                }
                // NetworkIndicatorData networkIndicatorData = new
                // NetworkIndicatorData();
                if (plan == null) {
                    networkIndicatorData = new NetworkIndicatorData();
                    plan = internalFullDescription.getPlan();
                    networkIndicatorData.setPlan(plan);
                    setNetworkIndicatorData(networkIndicatorData, internalFullDescription);
                    internalList.add(networkIndicatorData);
                } else {
                    if (plan.equals(internalFullDescription.getPlan())) {
                        setNetworkIndicatorData(networkIndicatorData, internalFullDescription);
                    } else {
                        networkIndicatorData = new NetworkIndicatorData();
                        plan = internalFullDescription.getPlan();
                        networkIndicatorData.setPlan(plan);
                        setNetworkIndicatorData(networkIndicatorData, internalFullDescription);
                        internalList.add(networkIndicatorData);
                    }
                }

                int index = fullDescriptionList.indexOf(internalFullDescription);
                fullDescriptionList.set(index, null);
            }
            if (coveragecode != null && internalList != null) {
                internalMap.put(coveragecode, internalList);
            }
        }
        if (eligibilitystatusinfo != null && internalMap != null) {
            mainMap.put(eligibilitystatusinfo, internalMap);
        }
        return mainMap;
    }

    void setNetworkIndicatorData(NetworkIndicatorData networkIndicatorData, FullDescription fullDescription) {
        networkIndicatorData.setPlan(fullDescription.getPlan());
        if (fullDescription.getNetworkindicator().equalsIgnoreCase("Y")) {
            networkIndicatorData.setInNetwork(fullDescription.getMonetaryamount().toString());
        } else if (fullDescription.getNetworkindicator().equalsIgnoreCase("N")) {
            networkIndicatorData.setOutofNetwork(fullDescription.getMonetaryamount().toString());
        }
        // return networkIndicatorData;
    }

    @Override
    public Deliverymethod getDeliveryMethod(int id) throws HibernateException {
        return userDao.getDeliveryMethod(id);
    }

    @Override
    public List getShortReport() throws HibernateException {
        return userDao.getShortReport();
    }
}
