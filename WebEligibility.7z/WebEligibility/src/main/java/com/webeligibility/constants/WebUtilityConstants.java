package com.webeligibility.constants;

public class WebUtilityConstants {

    public static final String ACK_999_277_PROCESS_PATH="ACK_999_277_PROCESS_PATH";
    public static final String EDI_837p_PROCESS_PATH="EDI_837p_PROCESS_PATH";
    public static final String REMITTANCE_835_PROCESS_PATH="REMITTANCE_835_PROCESS_PATH";
    public static final String ACK_999_277_PROCESS_STATUS="ACK_999_277_PROCESS_STATUS";
    public static final String EDI_837p_PROCESS_STATUS="EDI_837p_PROCESS_STATUS";
    public static final String REMITTANCE_835_PROCESS_STATUS="REMITTANCE_835_PROCESS_STATUS";
    public static final String PROCESSRUNNING="RUNNING";
    public static final String PROCESSSTOP="STOP";
    public static final String PROCESSSTART="START";
    public static final String COUNTCLAIMS="COUNTCLAIMS";
    public static final String CLAIM_837p_BATCH_SIZE ="837P_CLAIM_BATCH_SIZE";
    public static final String BATCH_SIZE_GROUPBY_PROVIDERID  ="BATCH_SIZE_GROUPBY_PROVIDERID";
    
    // sftpConfigurations
    public static final String FILEUPLOADDIRECTORY ="FILEUPLOADDIRECTORY";
    public static final String HOSTADDRESS ="HOSTADDRESS";
    public static final String PASSWORD ="PASSWORD";
    public static final String PORTADDRESS ="PORTADDRESS";
    public static final String SFTPUSER ="SFTPUSER";
    public static final String ISENABLE ="ISENABLE";
    public static final String FILE277DIRECTORY ="FILE277DIRECTORY";
    
    //permission constant
    public static final String DASHBOARD ="Dashboard";
    public static final String MANAGE_USER ="Manage User";
    public static final String MANAGE_PAYER ="Manage Payer";
    public static final String MANAGE_PROVIDER ="Manage Provider";
    public static final String ACCOUNT_SETTINGS ="Account Settings";
    public static final String HISTORY ="History";
    public static final String BATCH_PROCESS ="Batch Process";
    
    //error
    public static final String ERROR_KEY ="error";
    public static final String ERROR_MESSAGE ="We are not able to process your request due to network";
    
}
