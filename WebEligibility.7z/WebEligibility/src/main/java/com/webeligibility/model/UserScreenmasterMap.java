package com.webeligibility.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.MappedSuperclass;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "eligibility.user_screenmaster_map")
public class UserScreenmasterMap implements Serializable {

    private static final long serialVersionUID = 3708435766509167739L;
    @Id
    private Integer id;
    
    @ManyToOne
    @JoinColumn(name = "userid")
    private User user;
    private boolean ispermission;
    
    @ManyToOne
    @JoinColumn(name = "screenid")
    private ScreenMaster screenid;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }


    public User getUserid() {
        return user;
    }

    public void setUserid(User user) {
        this.user = user;
    }

    public boolean isIspermission() {
        return ispermission;
    }

    public void setIspermission(boolean ispermission) {
        this.ispermission = ispermission;
    }

    public ScreenMaster getScreenid() {
        return screenid;
    }

    public void setScreenid(ScreenMaster screenid) {
        this.screenid = screenid;
    }

    

    
}
