package com.webeligibility.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "eligibility.screenmaster")
public class ScreenMaster implements Serializable {

    private static final long serialVersionUID = 1532904805302936704L;
    @Id
    private Integer screenid;
    private String screenname;
    
    @OneToMany(mappedBy = "screenid", cascade = CascadeType.ALL) 
    private List<UserScreenmasterMap> userScreenmasterMaps;
    
    public Integer getScreenid() {
        return screenid;
    }

    public void setScreenid(Integer screenid) {
        this.screenid = screenid;
    }

    public String getScreenname() {
        return screenname;
    }

    public void setScreenname(String screenname) {
        this.screenname = screenname;
    }

    public List<UserScreenmasterMap> getUserScreenmasterMaps() {
        return userScreenmasterMaps;
    }

    public void setUserScreenmasterMaps(List<UserScreenmasterMap> userScreenmasterMaps) {
        this.userScreenmasterMaps = userScreenmasterMaps;
    }

    

}
