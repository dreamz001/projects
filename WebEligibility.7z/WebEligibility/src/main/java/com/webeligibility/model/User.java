package com.webeligibility.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import sun.java2d.pipe.SpanShapeRenderer.Simple;


@Entity
@Table(name = "eligibility.user")
public class User implements Serializable{

    
    /**
     * 
     */
    private static final long serialVersionUID = 7299313739097690800L;
    @Id
    private int userid;
    private String name;
    private String address;
    private long telephone;
    private String email;
    private String password;
    private Timestamp lastloggedin;
    private boolean isdeleted;
    
    @Transient
    private String newpassword;
    @Transient
    private String conformpassword;
    @Transient
    private String convertTelephone;
    @Transient
    private boolean dashboard;
    @Transient
    private boolean managepayer;
    @Transient
    private boolean manageprovider;
    @Transient
    private boolean manageuser;
    @Transient
    private boolean history;
    @Transient
    private boolean batchprocess;
    @Transient
    private String lastLoggedInTime;
    
    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL) 
    private List<UserScreenmasterMap> userScreenmasterMap;
    
    public int getUserid() {
        return userid;
    }

    
    public List<UserScreenmasterMap> getUserScreenmasterMap() {
        return userScreenmasterMap;
    }


    public void setUserScreenmasterMap(List<UserScreenmasterMap> userScreenmasterMap) {
        this.userScreenmasterMap = userScreenmasterMap;
    }


    public void setUserid(int userid) {
        this.userid = userid;
    }

    public String getName() {
        return name.trim();
    }

    public void setName(String name) {
        this.name = name.trim();
    }

    public String getAddress() {
        return address.trim();
    }

    public void setAddress(String address) {
        this.address = address.trim();
    }

    public long getTelephone() {
        return telephone;
    }

    public void setTelephone(long telephone) {
        this.telephone = telephone;
    }

    public String getEmail() {
        return email.trim();
    }

    public void setEmail(String email) {
        this.email = email.trim();
    }

    public String getPassword() {
        return password.trim();
    }

    public void setPassword(String password) {
        this.password = password.trim();
    }

    public Timestamp getLastloggedin() {
        return lastloggedin;
    }

    public void setLastloggedin(Timestamp lastloggedin) {
        this.lastloggedin = lastloggedin;
    }
    public boolean isDashboard() {
        return dashboard;
    }


    public void setDashboard(boolean dashboard) {
        this.dashboard = dashboard;
    }


    public boolean isManagepayer() {
        return managepayer;
    }


    public void setManagepayer(boolean managepayer) {
        this.managepayer = managepayer;
    }


    public boolean isManageprovider() {
        return manageprovider;
    }


    public void setManageprovider(boolean manageprovider) {
        this.manageprovider = manageprovider;
    }


    public boolean isManageuser() {
        return manageuser;
    }


    public void setManageuser(boolean manageuser) {
        this.manageuser = manageuser;
    }


    public boolean isHistory() {
        return history;
    }


    public void setHistory(boolean history) {
        this.history = history;
    }


    public boolean isBatchprocess() {
		return batchprocess;
	}


	public void setBatchprocess(boolean batchprocess) {
		this.batchprocess = batchprocess;
	}


	public String getConvertTelephone() {
        return convertTelephone.trim();
    }


    public void setConvertTelephone(String convertTelephone) {
        this.convertTelephone = convertTelephone;
    }


    public boolean isIsdeleted() {
        return isdeleted;
    }


    public void setIsdeleted(boolean isdeleted) {
        this.isdeleted = isdeleted;
    }
    
    public String getNewpassword() {
        return newpassword.trim();
    }


    public void setNewpassword(String newpassword) {
        this.newpassword = newpassword;
    }


    public String getConformpassword() {
        return conformpassword.trim();
    }


    public void setConformpassword(String conformpassword) {
        this.conformpassword = conformpassword;
    }

    
    public boolean isAnyPermission(){
        if(isDashboard() || isManagepayer() || isManageprovider() || isManageuser() || isHistory() || isBatchprocess()){
            return true;
        }
        return false;
    }


    public String getLastLoggedInTime() {
        lastLoggedInTime=new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a").format(new Date(lastloggedin.getTime()));
        return lastLoggedInTime;
    }
    
}
