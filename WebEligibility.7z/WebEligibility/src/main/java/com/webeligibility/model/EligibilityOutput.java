package com.webeligibility.model;

import java.io.Serializable;

//import com.eligibility270.dbentities.EligibilityBatchFile;

public class EligibilityOutput implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private Integer id;
    
    private String edimessage;
    
    private String eligibilitytracenumber;
    
    private String eligibilityoutcomecode;
    
    private String eligibilityoutcomemessage;
    
    private Integer transactionsetcontrolnumber;
    
    private String lastname="";
    
    private String firstname="";
    
    private String middleinitial="";
    
    private String ssn="";
    
    private String membernumber="";
    
    private String dateofbirth="";
    
    private String gender="";
    
   // private Integer transactionid;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getEdimessage() {
        return edimessage;
    }

    public void setEdimessage(String edimessage) {
        this.edimessage = edimessage;
    }

    public String getEligibilitytracenumber() {
        return eligibilitytracenumber;
    }

    public void setEligibilitytracenumber(String eligibilitytracenumber) {
        this.eligibilitytracenumber = eligibilitytracenumber;
    }

    public String getEligibilityoutcomecode() {
        return eligibilityoutcomecode;
    }

    public void setEligibilityoutcomecode(String eligibilityoutcomecode) {
        this.eligibilityoutcomecode = eligibilityoutcomecode;
    }

    public String getEligibilityoutcomemessage() {
        return eligibilityoutcomemessage;
    }

    public void setEligibilityoutcomemessage(String eligibilityoutcomemessage) {
        this.eligibilityoutcomemessage = eligibilityoutcomemessage;
    }

    public Integer getTransactionsetcontrolnumber() {
        return transactionsetcontrolnumber;
    }

    public void setTransactionsetcontrolnumber(Integer transactionsetcontrolnumber) {
        this.transactionsetcontrolnumber = transactionsetcontrolnumber;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getMiddleinitial() {
        return middleinitial;
    }

    public void setMiddleinitial(String middleinitial) {
        this.middleinitial = middleinitial;
    }

    public String getSsn() {
        return ssn;
    }

    public void setSsn(String ssn) {
        this.ssn = ssn;
    }

    public String getMembernumber() {
        return membernumber;
    }

    public void setMembernumber(String membernumber) {
        this.membernumber = membernumber;
    }

    public String getDateofbirth() {
        return dateofbirth;
    }

    public void setDateofbirth(String dateofbirth) {
        this.dateofbirth = dateofbirth;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    /*public EligibilityBatchFile getTransactionid() {
        return transactionid;
    }

    public void setTransactionid(EligibilityBatchFile transactionid) {
        this.transactionid = transactionid;
    }*/
   
   
}
