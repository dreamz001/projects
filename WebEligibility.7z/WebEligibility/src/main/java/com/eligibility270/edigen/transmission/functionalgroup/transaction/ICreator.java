package com.eligibility270.edigen.transmission.functionalgroup.transaction;

/**
 * It is for Some EDI segments creation prototype.
 * 
 * @author manishm3
 * @date NOV 28,2014
 */
public interface ICreator {
    /**
     * It generates segment speific string for 837p.
     * 
     * @return
     * @throws Exception
     */
    public String creator() throws Exception;

    /** Subscriber is a patient */
    String SELF = "18";

    String VERSION_NO = "005010X279A1";

    int FIRST_CLAIM = 0;

    public static final int MAX_RESULT = 50;
    public static final int NO_MAX_RESULT_DEFINED = 0;

    public static final String FUNCTIONAL_IDENTIFIER_CODE = "HS";
    public static final String RESPONSIBLE_AGENCY_CODE = "X";
}
