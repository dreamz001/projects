package com.eligibility270.edigen.transmission;

import java.math.BigInteger;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.eligibility.base.dao.impl.BaseDaoImpl;
import com.eligibility.common.utility.StringUtil;
import com.eligibility270.writer.IConstants;

/**
 * It creates IEA segment closing of ISA
 * 
 * @author manishm3
 * @date DEC 03,2014
 */
public class IEACreator {

    private BigInteger intercgangeControlNumber;
    private int numberOfIncludedFG; // Number of included Functional Group.

    private final int MAX_LENGTH = 9;

    public IEACreator(BigInteger intercgangeControlNumber, int numberOfIncludedFG) {
        super();
        this.intercgangeControlNumber = intercgangeControlNumber;
        this.numberOfIncludedFG = numberOfIncludedFG;
    }

    private static final Logger LOG = LoggerFactory.getLogger(IEACreator.class);

    public String creator() {
        LOG.debug("IEA creator.");
        StringBuilder sbIEA = new StringBuilder();

        /* IEA-00 Interchange COntrol Trailer. */
        sbIEA.append("IEA");
        sbIEA.append(IConstants.SEPARATOR);

        /* IEA-01 */
        sbIEA.append(String.valueOf(numberOfIncludedFG));
        sbIEA.append(IConstants.SEPARATOR);

        /* IEA-02 */
        if ((String.valueOf(intercgangeControlNumber)).length() == MAX_LENGTH) {
            sbIEA.append(String.valueOf(intercgangeControlNumber));
        } else if ((String.valueOf(intercgangeControlNumber)).length() < MAX_LENGTH) {
            sbIEA.append(StringUtil.zeros(MAX_LENGTH - (String.valueOf(intercgangeControlNumber)).length()) + intercgangeControlNumber);
        }
        sbIEA.append(IConstants.TERMINATOR);
        LOG.debug("IEA CREATER COMPLETED.");
        return sbIEA.toString();
    }

}
