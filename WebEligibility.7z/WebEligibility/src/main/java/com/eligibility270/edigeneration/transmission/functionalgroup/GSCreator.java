package com.eligibility270.edigeneration.transmission.functionalgroup;

import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.eligibility270.edigen.transmission.functionalgroup.transaction.ICreator;
import com.eligibility270.writer.IConstants;

/**
 * GS-Functional Group Header.
 * 
 * A Functional Group is a group of one or more related Transaction Sets sharing
 * the same Functional Group ID. Functional Groups start with a GS Functional
 * Group Header segment and end with a GE Functional Group Trailer segment.
 * 
 * @author manishm3
 * @date NOV 28,2014
 */
public class GSCreator implements ICreator {

    private BigInteger interchangeControlNumber;
    private Date date;
    private String interchangeSenderID;
    private String interchangeReceiverID;
    private String version;

    private static final Logger LOG = LoggerFactory.getLogger(GSCreator.class);

    public GSCreator(BigInteger interchangeControlNumber, Date date, String interchangeSenderID, String interchangeReceiverID) {
        super();
        this.interchangeControlNumber = interchangeControlNumber;
        this.date = date;
        this.interchangeSenderID = interchangeSenderID;
        this.interchangeReceiverID = interchangeReceiverID;
        this.version = ICreator.VERSION_NO;
    }

    @Override
    public String creator() {
        LOG.debug("GS CREATOR.");
        StringBuilder sbGS = new StringBuilder();

        /* GS-00 Functional Group Header */
        sbGS.append("GS");
        sbGS.append(IConstants.SEPARATOR);

        /* GS-01 Function Identifier Code */
        sbGS.append(FUNCTIONAL_IDENTIFIER_CODE);
        sbGS.append(IConstants.SEPARATOR);

        /* GS-02 Application's Application Sender’s Code */
        sbGS.append(interchangeSenderID.trim());
        sbGS.append(IConstants.SEPARATOR);

        /* GS-03 Application Receiver’s Code */
        sbGS.append(interchangeReceiverID.trim());
        sbGS.append(IConstants.SEPARATOR);

        /* GS-04 Date (yyyy mm dd) */
        SimpleDateFormat sd = new SimpleDateFormat("yyyyMMdd");
        sbGS.append(sd.format(date));
        sbGS.append(IConstants.SEPARATOR);

        /* GS-05 Time */
        SimpleDateFormat tf = new SimpleDateFormat("HHmm");
        sbGS.append(tf.format(date));
        sbGS.append(IConstants.SEPARATOR);

        /* GS-06 Group Control Number */
        sbGS.append(interchangeControlNumber);
        sbGS.append(IConstants.SEPARATOR);

        /* GS-07 Responsible Agency Code */
        sbGS.append(RESPONSIBLE_AGENCY_CODE);
        sbGS.append(IConstants.SEPARATOR);

        /* GS-08 Version/Release/No */
        sbGS.append(version);
        sbGS.append(IConstants.TERMINATOR);
        LOG.debug("GS CREATOR COMPLETED.");
        return sbGS.toString();
    }

}
