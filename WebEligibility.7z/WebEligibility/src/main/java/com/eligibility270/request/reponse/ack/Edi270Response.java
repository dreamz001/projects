package com.eligibility270.request.reponse.ack;

/**
 * It is for Edi 270 eligibility inquiry Response JSON.
 * 
 * @author manishm3
 *
 */
public class Edi270Response {

    private String eligibility_tracer_number;
    private String eligibility_status_code;
    private Errors errors;

    public String getEligibility_tracer_number() {
        return eligibility_tracer_number;
    }

    public void setEligibility_tracer_number(String eligibility_tracer_number) {
        this.eligibility_tracer_number = eligibility_tracer_number;
    }

    public String getEligibility_status_code() {
        return eligibility_status_code;
    }

    public void setEligibility_status_code(String eligibility_status_code) {
        this.eligibility_status_code = eligibility_status_code;
    }

    public Errors getErrors() {
        return errors;
    }

    public void setErrors(Errors errors) {
        this.errors = errors;
    }

}
