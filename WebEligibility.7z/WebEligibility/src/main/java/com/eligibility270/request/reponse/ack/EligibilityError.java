package com.eligibility270.request.reponse.ack;

/**
 * It for error in eligibility 270 inquiry response JOSN.
 * 
 * @author manishm3
 *
 */
public class EligibilityError {
    private String code;
    private String description;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String descriptiong) {
        this.description = descriptiong;
    }

}
