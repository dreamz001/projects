package com.eligibility270.request.reponse.ack;

/**
 * It contains response size and response for 270 eligibility inquiory
 * 
 * @author manishm3
 *
 */
public class EligiblityRequestResponseJson {

    private Edi270Response response;
    private String response_size;

    public Edi270Response getResponse() {
        return response;
    }

    public void setResponse(Edi270Response response) {
        this.response = response;
    }

    public String getResponse_size() {
        return response_size;
    }

    public void setResponse_size(String response_size) {
        this.response_size = response_size;
    }

}
