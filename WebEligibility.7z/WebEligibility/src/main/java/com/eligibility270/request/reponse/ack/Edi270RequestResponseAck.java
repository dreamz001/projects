package com.eligibility270.request.reponse.ack;

/**
 * It is for eligibility 270 request acknowledgement JSON.
 * 
 * @author manishm3
 *
 */
public class Edi270RequestResponseAck {
    EligiblityRequestResponseJson eligibility_request_response;

    public EligiblityRequestResponseJson getEligibility_request_response() {
        return eligibility_request_response;
    }

    public void setEligibility_request_response(EligiblityRequestResponseJson eligibility_request_response) {
        this.eligibility_request_response = eligibility_request_response;
    }
}
