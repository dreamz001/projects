package com.eligibility270.request.reponse.ack;
/**
 * @author Manish
 * @date MAR 20,2015
 */
public class Errors {
    private EligibilityError error;

    public EligibilityError getError() {
        return error;
    }

    public void setError(EligibilityError error) {
        this.error = error;
    }

}
