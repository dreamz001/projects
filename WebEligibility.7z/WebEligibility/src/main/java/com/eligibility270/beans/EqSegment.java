package com.eligibility270.beans;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.eligibility.common.utility.StringUtil;
import com.eligibility.shared.constants.EligibilityTagEnum;
import com.eligibility270.writer.IConstants;
import com.eligiblityshared.beans.Compositemedicalprocedure;
import com.eligiblityshared.beans.Diagnosiscodepointer;

/**
 * EQ Beans Segement.
 * 
 * @author manishm3
 * @date March 04,2015
 */
public class EqSegment {
    private static final Logger LOGGER = LoggerFactory.getLogger(EqSegment.class);
    
    /* EQ-01*/
    private String serviceTypeCode;
    
    /* EQ-02*/
    private Compositemedicalprocedure compMedProcId;
    
    /* EQ-03*/
    private String coverageLevelCode;
    
    /* EQ - 04*/
    private String insuranceTypeCode;
    
    /* EQ - 05*/
    private Diagnosiscodepointer compDiagCode;

    public String getServiceTypeCode() {
        return serviceTypeCode;
    }

    public void setServiceTypeCode(String serviceTypeCode) {
        this.serviceTypeCode = serviceTypeCode;
    }


    public String getCoverageLevelCode() {
        return coverageLevelCode;
    }

    public void setCoverageLevelCode(String coverageLevelCode) {
        this.coverageLevelCode = coverageLevelCode;
    }

    public String getInsuranceTypeCode() {
        return insuranceTypeCode;
    }

    public void setInsuranceTypeCode(String insuranceTypeCode) {
        this.insuranceTypeCode = insuranceTypeCode;
    }

    public Diagnosiscodepointer getCompDiagCode() {
        return compDiagCode;
    }

    public void setCompDiagCode(Diagnosiscodepointer compDiagCode) {
        this.compDiagCode = compDiagCode;
    }

    public Compositemedicalprocedure getCompMedProcId() {
        return compMedProcId;
    }

    public void setCompMedProcId(Compositemedicalprocedure compMedProcId) {
        this.compMedProcId = compMedProcId;
    }
    
    public String writer(){
        LOGGER.debug("EQ SEGMENT WRITER.");
        StringBuilder sb=new StringBuilder();
        sb.append(EligibilityTagEnum.EQ.value());
        sb.append(IConstants.SEPARATOR);
        
        /*EQ-01*/
        sb.append((serviceTypeCode!=null && !serviceTypeCode.trim().isEmpty()) ? serviceTypeCode.concat(IConstants.SEPARATOR) : IConstants.SEPARATOR);
        /*EQ-02*/
        if(compMedProcId!=null){
            /*EQ02-01*/
            String eq021=compMedProcId.getProductserviceidqualifier();
            String eq022 =compMedProcId.getProductserviceid1();
            String eq023=compMedProcId.getProceduremodifier1();
            String eq024=compMedProcId.getProceduremodifier2();
            String eq025=compMedProcId.getProceduremodifier3();
            String eq026=compMedProcId.getProceduremodifier4();
            String eq027=compMedProcId.getDescription();
            String eq028=compMedProcId.getProductserviceid2();
            
            if(!StringUtil.isNullOrEmpty(eq021) || !StringUtil.isNullOrEmpty(eq022) || !StringUtil.isNullOrEmpty(eq023) || !StringUtil.isNullOrEmpty(eq024)
                    || !StringUtil.isNullOrEmpty(eq025) || !StringUtil.isNullOrEmpty(eq026) || !StringUtil.isNullOrEmpty(eq027)){
                
            
                
            sb.append((eq021!=null && !eq021.trim().isEmpty()) ? eq021.concat(IConstants.REPEATITION_SEPARATOR) : IConstants.REPEATITION_SEPARATOR);
            /*EQ02-02*/
            
            sb.append((eq022!=null && !eq022.trim().isEmpty()) ? eq022.concat(IConstants.REPEATITION_SEPARATOR) : IConstants.REPEATITION_SEPARATOR);
            /*EQ02-03*/
            
            sb.append((eq023!=null && !eq023.trim().isEmpty()) ? eq023.concat(IConstants.REPEATITION_SEPARATOR) : IConstants.REPEATITION_SEPARATOR);
            /*EQ02-04*/
            
            sb.append((eq024!=null && !eq024.trim().isEmpty()) ? eq024.concat(IConstants.REPEATITION_SEPARATOR) : IConstants.REPEATITION_SEPARATOR);
            /*EQ02-05*/
            
            sb.append((eq025!=null && !eq025.trim().isEmpty()) ? eq025.concat(IConstants.REPEATITION_SEPARATOR) : IConstants.REPEATITION_SEPARATOR);
            /*EQ02-06*/
            
            sb.append((eq026!=null && !eq026.trim().isEmpty()) ? eq026.concat(IConstants.REPEATITION_SEPARATOR) : IConstants.REPEATITION_SEPARATOR);
            /*EQ02-07*/
            
            sb.append((eq027!=null && !eq027.trim().isEmpty()) ? eq027.concat(IConstants.REPEATITION_SEPARATOR) : IConstants.REPEATITION_SEPARATOR);
            /*EQ02-08*/
            
            sb.append((eq028!=null && !eq028.trim().isEmpty()) ? eq028.concat(IConstants.REPEATITION_SEPARATOR) : IConstants.REPEATITION_SEPARATOR);
            }
            int repind=sb.lastIndexOf(IConstants.REPEATITION_SEPARATOR);
            if(repind==sb.length()){
                sb.deleteCharAt(repind);
            }
            sb.append(IConstants.SEPARATOR);
        }else{
            sb.append(IConstants.SEPARATOR);
        }
        /*EQ-03*/
        sb.append((coverageLevelCode!=null && !coverageLevelCode.trim().isEmpty()) ? coverageLevelCode.concat(IConstants.SEPARATOR) : IConstants.SEPARATOR);
        /*EQ-04*/
        sb.append((insuranceTypeCode!=null && !insuranceTypeCode.trim().isEmpty()) ? insuranceTypeCode.concat(IConstants.SEPARATOR) : IConstants.SEPARATOR);
        /*EQ-05*/
        if(compDiagCode!=null){
            /*EQ-05-01*/
            Integer eq501=compDiagCode.getDiagnosiscodepointer1();
            sb.append(eq501 > 0 ? String.valueOf(eq501).concat(IConstants.REPEATITION_SEPARATOR) : IConstants.REPEATITION_SEPARATOR );
            /*EQ-05-02*/
            Integer eq502=compDiagCode.getDiagnosiscodepointer2();
            sb.append(eq502 > 0 ? String.valueOf(eq502).concat(IConstants.REPEATITION_SEPARATOR) : IConstants.REPEATITION_SEPARATOR );
            /*EQ-05-03*/
            Integer eq503=compDiagCode.getDiagnosiscodepointer3();
            sb.append(eq503 > 0 ? String.valueOf(eq503).concat(IConstants.REPEATITION_SEPARATOR) : IConstants.REPEATITION_SEPARATOR );
            /*EQ-05-04*/
            Integer eq504=compDiagCode.getDiagnosiscodepointer4();
            sb.append(eq504 > 0 ? String.valueOf(eq504).concat(IConstants.REPEATITION_SEPARATOR) : IConstants.REPEATITION_SEPARATOR );
            
            int repind=sb.lastIndexOf(IConstants.REPEATITION_SEPARATOR);
            if(repind==sb.length()){
                sb.deleteCharAt(repind);
            }
            sb.append(IConstants.TERMINATOR);
        }else{
            sb.append(IConstants.TERMINATOR);
        }
        
        if(StringUtil.isSegmentContainsData(sb.toString(), EligibilityTagEnum.EQ.value())){
             String seg= StringUtil.appendTerminatorIfNotFound(sb.toString());
             try {
                return StringUtil.removeUnusedAsterik(seg);
            } catch (Exception e) {
                LOGGER.error("Exception while removing unused Asterik",e);
            }
        }
        LOGGER.debug("EQ SEGMENT WRITER COMPLETE.");
        return new String("");
    }
}    
