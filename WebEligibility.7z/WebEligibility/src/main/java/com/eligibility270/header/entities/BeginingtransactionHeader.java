package com.eligibility270.header.entities;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * @author manishm3
 * 
 *         The persistent class for the edi_837_beginingtransactionheader
 *         database table.
 * 
 */
@Entity
@Table(name = "eligibility.eligibility_270_beginingtransactionheader")
@NamedQuery(name = "BeginingtransactionHeader.findAll", query = "SELECT b FROM BeginingtransactionHeader b")
public class BeginingtransactionHeader implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    private Integer referenceidentification;

    private Timestamp bhtdate;

    private String hierarchicalstructurecode;

    private Timestamp bhttime;

    private String transactionsetpurposecode;

    private String transactiontypecode;

    // bi-directional many-to-one association to TransactionsetHeader
    @ManyToOne
    @JoinColumn(name = "transactionsetcontrolnumber")
    private TransactionsetHeader transactionsetheader;

    public BeginingtransactionHeader() {
    }

    public Integer getReferenceidentification() {
        return this.referenceidentification;
    }

    public void setReferenceidentification(Integer referenceidentification) {
        this.referenceidentification = referenceidentification;
    }

    public Timestamp getBhtdate() {
        return this.bhtdate;
    }

    public void setBhtdate(Timestamp bhtdate) {
        this.bhtdate = bhtdate;
    }

    public String getHierarchicalstructurecode() {
        return this.hierarchicalstructurecode;
    }

    public void setHierarchicalstructurecode(String hierarchicalstructurecode) {
        this.hierarchicalstructurecode = hierarchicalstructurecode;
    }

    public String getTransactionsetpurposecode() {
        return this.transactionsetpurposecode;
    }

    public void setTransactionsetpurposecode(String transactionsetpurposecode) {
        this.transactionsetpurposecode = transactionsetpurposecode;
    }

    public String getTransactiontypecode() {
        return this.transactiontypecode;
    }

    public void setTransactiontypecode(String transactiontypecode) {
        this.transactiontypecode = transactiontypecode;
    }

    public TransactionsetHeader getTransactionsetheader() {
        return this.transactionsetheader;
    }

    public void setTransactionsetheader(TransactionsetHeader edi270Transactionsetheader) {
        this.transactionsetheader = edi270Transactionsetheader;
    }

    public Timestamp getBhttime() {
        return bhttime;
    }

    public void setBhttime(Timestamp bhttime) {
        this.bhttime = bhttime;
    }
}