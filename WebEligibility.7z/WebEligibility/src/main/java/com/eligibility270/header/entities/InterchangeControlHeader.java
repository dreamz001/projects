package com.eligibility270.header.entities;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.eligibility270.dbentities.Eligibility270withack;

/**
 * ISA – Interchange Control Header
 * 
 * @author manishm3
 * @date MAR 19,2015
 */
@Entity
@Table(name = "eligibility.eligibility_270_interchangecontrolheader")
@NamedQuery(name = "InterchangeControlHeader.findAll", query = "SELECT i FROM InterchangeControlHeader i")
public class InterchangeControlHeader implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    private Integer interchangecontrolnumber;

    private String ackrequiredornot;

    private String authinfo;

    private String authinfoqualifier;

    private String compelementseprator;

    private String iccontrolversionnum;

    private String icreceiveridqualifier;

    private String interchangecontrolversionnum;

    private String interchangeidqualifier;

    private String interchangereceiverid;

    private String interchangesenderid;

    private Timestamp interchangetime;

    private String repetitionseprator;

    private String securityinfo;

    private String securityinfoqualifier;

    private String usageindicator;

    // bi-directional many-to-one association to FunctionalgroupHeader
    @OneToMany(mappedBy = "interchangecontrolheader", cascade = CascadeType.ALL)
    private List<FunctionalgroupHeader> functionalgroupheaders;

    @OneToMany(mappedBy = "eligibility270Interchangecontrolheader")
    private List<Eligibility270withack> eligibility270withacks;

    public InterchangeControlHeader() {
    }

    public Integer getInterchangecontrolnumber() {
        return this.interchangecontrolnumber;
    }

    public void setInterchangecontrolnumber(Integer interchangecontrolnumber) {
        this.interchangecontrolnumber = interchangecontrolnumber;
    }

    public String getAckrequiredornot() {
        return this.ackrequiredornot;
    }

    public void setAckrequiredornot(String ackrequiredornot) {
        this.ackrequiredornot = ackrequiredornot;
    }

    public String getAuthinfo() {
        return this.authinfo;
    }

    public void setAuthinfo(String authinfo) {
        this.authinfo = authinfo;
    }

    public String getAuthinfoqualifier() {
        return this.authinfoqualifier;
    }

    public void setAuthinfoqualifier(String authinfoqualifier) {
        this.authinfoqualifier = authinfoqualifier;
    }

    public String getCompelementseprator() {
        return this.compelementseprator;
    }

    public void setCompelementseprator(String compelementseprator) {
        this.compelementseprator = compelementseprator;
    }

    public String getIccontrolversionnum() {
        return this.iccontrolversionnum;
    }

    public void setIccontrolversionnum(String iccontrolversionnum) {
        this.iccontrolversionnum = iccontrolversionnum;
    }

    public String getIcreceiveridqualifier() {
        return this.icreceiveridqualifier;
    }

    public void setIcreceiveridqualifier(String icreceiveridqualifier) {
        this.icreceiveridqualifier = icreceiveridqualifier;
    }

    public String getInterchangecontrolversionnum() {
        return this.interchangecontrolversionnum;
    }

    public void setInterchangecontrolversionnum(String interchangecontrolversionnum) {
        this.interchangecontrolversionnum = interchangecontrolversionnum;
    }

    public String getInterchangeidqualifier() {
        return this.interchangeidqualifier;
    }

    public void setInterchangeidqualifier(String interchangeidqualifier) {
        this.interchangeidqualifier = interchangeidqualifier;
    }

    public String getInterchangereceiverid() {
        return this.interchangereceiverid;
    }

    public void setInterchangereceiverid(String interchangereceiverid) {
        this.interchangereceiverid = interchangereceiverid;
    }

    public String getInterchangesenderid() {
        return this.interchangesenderid;
    }

    public void setInterchangesenderid(String interchangesenderid) {
        this.interchangesenderid = interchangesenderid;
    }

    public Timestamp getInterchangetime() {
        return this.interchangetime;
    }

    public void setInterchangetime(Timestamp interchangetime) {
        this.interchangetime = interchangetime;
    }

    public String getRepetitionseprator() {
        return this.repetitionseprator;
    }

    public void setRepetitionseprator(String repetitionseprator) {
        this.repetitionseprator = repetitionseprator;
    }

    public String getSecurityinfo() {
        return this.securityinfo;
    }

    public void setSecurityinfo(String securityinfo) {
        this.securityinfo = securityinfo;
    }

    public String getSecurityinfoqualifier() {
        return this.securityinfoqualifier;
    }

    public void setSecurityinfoqualifier(String securityinfoqualifier) {
        this.securityinfoqualifier = securityinfoqualifier;
    }

    public String getUsageindicator() {
        return this.usageindicator;
    }

    public void setUsageindicator(String usageindicator) {
        this.usageindicator = usageindicator;
    }

    public List<FunctionalgroupHeader> getFunctionalgroupheaders() {
        if (this.functionalgroupheaders == null) {
            functionalgroupheaders = new ArrayList<FunctionalgroupHeader>();
        }
        return this.functionalgroupheaders;
    }

    public void setFunctionalgroupheaders(List<FunctionalgroupHeader> functionalgroupheaders) {
        this.functionalgroupheaders = functionalgroupheaders;
    }

    public FunctionalgroupHeader addFunctionalgroupheader(FunctionalgroupHeader functionalgroupheader) {
        getFunctionalgroupheaders().add(functionalgroupheader);
        functionalgroupheader.setInterchangecontrolheader(this);

        return functionalgroupheader;
    }

    public FunctionalgroupHeader removeFunctionalgroupheader(FunctionalgroupHeader functionalgroupheader) {
        getFunctionalgroupheaders().remove(functionalgroupheader);
        functionalgroupheader.setInterchangecontrolheader(null);

        return functionalgroupheader;
    }

    public List<Eligibility270withack> getEligibility270withacks() {
        return this.eligibility270withacks;
    }

    public void setEligibility270withacks(List<Eligibility270withack> eligibility270withacks) {
        this.eligibility270withacks = eligibility270withacks;
    }

    public Eligibility270withack addEligibility270withack(Eligibility270withack eligibility270withack) {
        getEligibility270withacks().add(eligibility270withack);
        eligibility270withack.setInterchangeControlHeader(this);

        return eligibility270withack;
    }

    public Eligibility270withack removeEligibility270withack(Eligibility270withack eligibility270withack) {
        getEligibility270withacks().remove(eligibility270withack);
        eligibility270withack.setInterchangeControlHeader(null);

        return eligibility270withack;
    }

}