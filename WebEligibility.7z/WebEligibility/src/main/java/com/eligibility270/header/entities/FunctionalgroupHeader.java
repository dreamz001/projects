package com.eligibility270.header.entities;

import java.io.Serializable;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * @author manishm3
 * 
 *         The persistent class for the edi_837_functionalgroupheader database
 *         table.
 * 
 */
@Entity
@Table(name = "eligibility.eligibility_270_functionalgroupheader")
@NamedQuery(name = "FunctionalgroupHeader.findAll", query = "SELECT f FROM FunctionalgroupHeader f")
public class FunctionalgroupHeader implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    private Integer groupcontrolnumber;

    @Column(name = "application_receiver_code")
    private String applicationReceiverCode;

    private String applicationsendercode;

    private Time gsdate;

    private String functionalidentifiercode;

    private Timestamp gstime;

    private String responsibleagencycode;

    private String versionreleaseno;

    // bi-directional many-to-one association to InterchangeControlHeader
    @ManyToOne
    @JoinColumn(name = "interchangecontrolnumber")
    private InterchangeControlHeader interchangecontrolheader;

    // bi-directional many-to-one association to TransactionsetHeader
    @OneToMany(mappedBy = "functionalgroupheader", cascade = CascadeType.ALL)
    private List<TransactionsetHeader> transactionsetheaders;

    public FunctionalgroupHeader() {
    }

    public Integer getGroupcontrolnumber() {
        return this.groupcontrolnumber;
    }

    public void setGroupcontrolnumber(Integer groupcontrolnumber) {
        this.groupcontrolnumber = groupcontrolnumber;
    }

    public String getApplicationReceiverCode() {
        return this.applicationReceiverCode;
    }

    public void setApplicationReceiverCode(String applicationReceiverCode) {
        this.applicationReceiverCode = applicationReceiverCode;
    }

    public String getApplicationsendercode() {
        return this.applicationsendercode;
    }

    public void setApplicationsendercode(String applicationsendercode) {
        this.applicationsendercode = applicationsendercode;
    }

    public Time getGsdate() {
        return this.gsdate;
    }

    public void setGsdate(Time date) {
        this.gsdate = date;
    }

    public String getFunctionalidentifiercode() {
        return this.functionalidentifiercode;
    }

    public void setFunctionalidentifiercode(String functionalidentifiercode) {
        this.functionalidentifiercode = functionalidentifiercode;
    }

    public Timestamp getGstime() {
        return this.gstime;
    }

    public void setGstime(Timestamp gstime) {
        this.gstime = gstime;
    }

    public String getResponsibleagencycode() {
        return this.responsibleagencycode;
    }

    public void setResponsibleagencycode(String responsibleagencycode) {
        this.responsibleagencycode = responsibleagencycode;
    }

    public String getVersionreleaseno() {
        return this.versionreleaseno;
    }

    public void setVersionreleaseno(String versionreleaseno) {
        this.versionreleaseno = versionreleaseno;
    }

    public InterchangeControlHeader getInterchangecontrolheader() {
        return this.interchangecontrolheader;
    }

    public void setInterchangecontrolheader(InterchangeControlHeader interchangecontrolheader) {
        this.interchangecontrolheader = interchangecontrolheader;
    }

    public List<TransactionsetHeader> getTransactionsetheaders() {
        if (this.transactionsetheaders == null) {
            this.transactionsetheaders = new ArrayList<TransactionsetHeader>();
        }
        return this.transactionsetheaders;
    }

    public void setTransactionsetheaders(List<TransactionsetHeader> transactionsetheaders) {
        this.transactionsetheaders = transactionsetheaders;
    }

    public TransactionsetHeader addTransactionsetheader(TransactionsetHeader transactionsetheader) {
        getTransactionsetheaders().add(transactionsetheader);
        transactionsetheader.setFunctionalgroupheader(this);

        return transactionsetheader;
    }

    public TransactionsetHeader removeTransactionsetheader(TransactionsetHeader transactionsetheader) {
        getTransactionsetheaders().remove(transactionsetheader);
        transactionsetheader.setFunctionalgroupheader(null);

        return transactionsetheader;
    }

}