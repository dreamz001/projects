package com.eligibility270.header.entities;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * @author manishm3
 * 
 *         The persistent class for the edi_837_transactionsetheader database
 *         table.
 * 
 */
@Entity
@Table(name = "eligibility.eligibility_270_transactionsetheader")
@NamedQuery(name = "TransactionsetHeader.findAll", query = "SELECT t FROM TransactionsetHeader t")
public class TransactionsetHeader implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    private Integer transactionsetcontrolnumber;

    private String implementationconventionreference;

    private String transactionsetidentifier;

    // bi-directional many-to-one association to BeginingtransactionHeader
    @OneToMany(mappedBy = "transactionsetheader", cascade = CascadeType.ALL)
    private List<BeginingtransactionHeader> beginingtransactionheaders;

    // bi-directional many-to-one association to FunctionalgroupHeader
    @ManyToOne
    @JoinColumn(name = "groupcontrolnumber")
    private FunctionalgroupHeader functionalgroupheader;

    public TransactionsetHeader() {
    }

    public Integer getTransactionsetcontrolnumber() {
        return this.transactionsetcontrolnumber;
    }

    public void setTransactionsetcontrolnumber(Integer transactionsetcontrolnumber) {
        this.transactionsetcontrolnumber = transactionsetcontrolnumber;
    }

    public String getImplementationconventionreference() {
        return this.implementationconventionreference;
    }

    public void setImplementationconventionreference(String implementationconventionreference) {
        this.implementationconventionreference = implementationconventionreference;
    }

    public String getTransactionsetidentifier() {
        return this.transactionsetidentifier;
    }

    public void setTransactionsetidentifier(String transactionsetidentifier) {
        this.transactionsetidentifier = transactionsetidentifier;
    }

    public List<BeginingtransactionHeader> getBeginingtransactionheaders() {
        if (this.beginingtransactionheaders == null) {
            this.beginingtransactionheaders = new ArrayList<BeginingtransactionHeader>();
        }
        return this.beginingtransactionheaders;
    }

    public void setBeginingtransactionheaders(List<BeginingtransactionHeader> edi837Beginingtransactionheaders) {
        this.beginingtransactionheaders = edi837Beginingtransactionheaders;
    }

    public BeginingtransactionHeader addBeginingtransactionheader(BeginingtransactionHeader beginingtransactionheader) {
        getBeginingtransactionheaders().add(beginingtransactionheader);
        beginingtransactionheader.setTransactionsetheader(this);

        return beginingtransactionheader;
    }

    public BeginingtransactionHeader removeBeginingtransactionheader(BeginingtransactionHeader beginingtransactionheader) {
        getBeginingtransactionheaders().remove(beginingtransactionheader);
        beginingtransactionheader.setTransactionsetheader(null);

        return beginingtransactionheader;
    }

    public FunctionalgroupHeader getFunctionalgroupheader() {
        return this.functionalgroupheader;
    }

    public void setFunctionalgroupheader(FunctionalgroupHeader functionalgroupheader) {
        this.functionalgroupheader = functionalgroupheader;
    }

}