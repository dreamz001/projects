package com.eligibility270.writer;

import java.math.BigInteger;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Entity;

import org.hibernate.HibernateException;
import org.hibernate.exception.ConstraintViolationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.eligibility.base.dao.IBaseDao;
import com.eligibility.common.utility.HLUtil;
import com.eligibility.jsonschema270.beans.XsElement_;
import com.eligibility.shared.constants.EligibilityTagEnum;
import com.eligibility270.dbentities.Eligibility270withack;
//import com.eligibility270.dbentities.EligibilityBatchInput;
import com.eligibility270.edigen.transmission.IEACreator;
import com.eligibility270.edigen.transmission.ISACreator;
import com.eligibility270.edigen.transmission.functionalgroup.transaction.BHTCreator;
import com.eligibility270.edigen.transmission.functionalgroup.transaction.ICreator;
import com.eligibility270.edigen.transmission.functionalgroup.transaction.SECreator;
import com.eligibility270.edigen.transmission.functionalgroup.transaction.STCreator;
import com.eligibility270.edigeneration.transmission.functionalgroup.GECreator;
import com.eligibility270.edigeneration.transmission.functionalgroup.GSCreator;
//import com.eligibility270.exception.InvalidRequestDataException;
import com.eligibility270.header.entities.BeginingtransactionHeader;
import com.eligibility270.header.entities.FunctionalgroupHeader;
import com.eligibility270.header.entities.InterchangeControlHeader;
import com.eligibility270.header.entities.TransactionsetHeader;
import com.eligibility270.mastertables.entities.Deliverymethod;
import com.eligibility270.mastertables.entities.ISAEntity;
import com.eligibility270.parsing.error.Eligibility270ParserError;
import com.eligibility270.request.reponse.ack.IResponseAckErrorCode;
import com.eligibility271.beans.Ack999Errors;
import com.eligibility271.beans.FieldWithValueBean;
import com.eligibility271.beans.SegmentBean;
import com.eligibility271.common.utils.SegmentParseUtility;
import com.eligibility271.constants.Ack999Constants;
import com.eligibility271.constants.SegmentRefDesginatorConstants;
//import com.eligibility271.dbentities.Config;
import com.eligibility271.dbentities.Edi271shortdesc;
//import com.eligibility271.dbentities.EligibilityBatchOutput;
import com.eligibility271.dbentities.Emdeonrequestresponse;
import com.eligibility271.parser.Eligibility271Parser;
import com.webeligibility.actions.EligibilityProcessAction;
import com.webeligibility.model.EligibilityOutput;
//import com.fasterxml.jackson.core.JsonProcessingException;
//import com.fasterxml.jackson.databind.ObjectMapper;

import emdeon.client.CoreEmdeonRequestResponse;
import emdeon.client.EmdeonClient;
import emdeon.client.EmdeonConfiguration;

/**
 * It writes the 270 eligibility EDI.
 * 
 * @author manishm3
 * @date Mar 20,2015
 */
@Component
@Entity
public class Eligibility270Writer {
    private static final Logger LOG = LoggerFactory.getLogger(Eligibility270Writer.class);

    @SuppressWarnings("rawtypes")
    @Autowired
    IBaseDao baseDao;

    @Autowired
    private Eligibility271Parser eligibility271Parser;

    /*
     * @Autowired ConfigLookUp configLooUp;
     */
    private CoreEmdeonRequestResponse emdeon;
    private String traceNumber;
    private String errorCode = "";
    private boolean errorInResponse = false;
    private String errorDescription999 = null;
    // byte jsonBytes[];

    // private EligibilityBatchInput input;

    public static List<Eligibility270ParserError> parserErrors = new ArrayList<Eligibility270ParserError>();

    public Eligibility270Writer() {
    }

    public IBaseDao getBaseDao() {
        return baseDao;
    }

    public String getTraceNumber() {
        return traceNumber;
    }

    public void setTraceNumber(String traceNumber) {
        this.traceNumber = traceNumber;
    }

    public void writeAllLoop(XsElement_ element) throws Exception {
        traceNumber = element.getEligibilityTracerNumber();
        emdeon = new CoreEmdeonRequestResponse();
        Date date = new Date();
        String deliveryMethodNameStr = element.getDeliveryMethod();
        Deliverymethod deliverymethod = new Deliverymethod();
        if (deliveryMethodNameStr != null && !deliveryMethodNameStr.trim().isEmpty()) {
            deliverymethod = baseDao.byDeliveryMethodName(deliveryMethodNameStr);
            if (deliverymethod == null)
                return;
        }
        String senderId = deliverymethod.getSenderid().trim();
        String receiverID = deliverymethod.getReceiverid().trim();
        ISAEntity isa = baseDao.getISA();
        if (isa == null) {
            LOG.error("ISA segment not found in DB");
            return;
        }
        /* ISA */
        InterchangeControlHeader interchangeControlHeader = createInterchangeControlHeader(isa, deliverymethod);
        BigInteger interchangeControlNum = baseDao.nextVal(DBSequenceType.ISA_INTERCHANGE_CONTRON_NUMBER);
        ISACreator isaCreator = new ISACreator(interchangeControlHeader, interchangeControlNum, date);

        /* GS */
        BigInteger groupControlNumber = baseDao.nextVal(DBSequenceType.GS_GROUP_CONTROL_NUMBER);
        GSCreator gsCreator = new GSCreator(groupControlNumber, date, senderId, receiverID);
        FunctionalgroupHeader functionalgroupHeader = createFunctionalGroupHeader(groupControlNumber, date, senderId, receiverID);

        /* ST */
        BigInteger transactionSetControlNumber = baseDao.nextVal(DBSequenceType.ST_TRANSACTION_CONTROL_NUMBER);
        STCreator stCreator = new STCreator(String.valueOf(transactionSetControlNumber));
        TransactionsetHeader transactionsetHeader = createTransactionSetHeader(transactionSetControlNumber);

        /* BHT -03 */
        // it must be saved into database for edi tracking purpose.
        BigInteger referenceIdentification = baseDao.nextVal(DBSequenceType.BHT_REFERENCE_IDENTIFICATION);
        BHTCreator bhtCreator = new BHTCreator(date, String.valueOf(referenceIdentification));
        BeginingtransactionHeader beginingtransactionHeader = createBeginingtransactionHeader(date, referenceIdentification);

        // createGroupedFunctionalGroup(date, senderId,
        // receiverID,deliveryMethodNameStr);

        Eligibility270Loop2000AWriter eligibility270Loop2000AWriter = new Eligibility270Loop2000AWriter(element);
        Eligibility270Loop2000BWriter eligibility270Loop2000BWriter = new Eligibility270Loop2000BWriter(element);
        Eligibility270Loop2000CWriter eligibility270Loop2000CWriter = new Eligibility270Loop2000CWriter(element);
        Eligibility270Loop2000DWriter eligibility270Loop2000DWriter = new Eligibility270Loop2000DWriter(element);

        StringBuilder eligibility270 = new StringBuilder();
        eligibility270.append(isaCreator.creator());
        eligibility270.append(gsCreator.creator());
        eligibility270.append(stCreator.creator());
        eligibility270.append(bhtCreator.creator());
        eligibility270.append(eligibility270Loop2000AWriter.loopInformationSource());
        eligibility270.append(eligibility270Loop2000BWriter.loop2000BAnd2100B());
        eligibility270.append(eligibility270Loop2000CWriter.loop2000C_2100C_2110C());
        eligibility270.append(eligibility270Loop2000DWriter.loop2000D_2100D_2110D());

        /* SE */
        String[] lines = eligibility270.toString().split("~");
        int segmentCount = lines.length - 1;
        SECreator seCreator = new SECreator(interchangeControlNum, segmentCount);
        eligibility270.append(seCreator.creator());

        /* GE */
        GECreator geCreator = new GECreator(1, groupControlNumber);
        eligibility270.append(geCreator.creator());

        /* IEA */
        IEACreator ieaCreator = new IEACreator(interchangeControlNum, 1);
        eligibility270.append(ieaCreator.creator());

        HLUtil.resetValue();

        transactionsetHeader.addBeginingtransactionheader(beginingtransactionHeader);
        functionalgroupHeader.addTransactionsetheader(transactionsetHeader);
        interchangeControlHeader.addFunctionalgroupheader(functionalgroupHeader);

        Eligibility270withack eligibility270withack = null;
        if (element.getEligibilityTracerNumber() != null) {
            eligibility270withack = new Eligibility270withack();
            eligibility270withack.setEligibility270json("");
            eligibility270withack.setEligibilitytracenumber(element.getEligibilityTracerNumber());
            eligibility270withack.setRequestdate(new Timestamp(new java.util.Date().getTime()));

            if (parserErrors != null && parserErrors.isEmpty()) {
                eligibility270withack.setEligibilitystatuscode(IConstants.ACCEPTED); // Accepted
                eligibility270withack.setEdi270gen(eligibility270.toString());
                eligibility270withack.setEmdeonsubmissionstatus(Boolean.TRUE);
            } else {
                eligibility270withack.setEligibilitystatuscode(IConstants.REJECTED); // Rejected
                eligibility270withack.setEdi270gen(IConstants.NO_EDI);
                eligibility270withack.setEmdeonsubmissionstatus(Boolean.FALSE);
            }
            eligibility270withack.setError(parserErrors.toString());
            eligibility270withack.setErrorcode("");

            eligibility270withack.setInterchangeControlHeader(interchangeControlHeader);

            try {
                baseDao.saveWithAck(interchangeControlHeader, eligibility270withack);
            } catch (ConstraintViolationException cvExp) {
                String errorCode = IResponseAckErrorCode.DUPLICATE_TRACE_NUMBER_OR_DB_ERROR;
                errorDescription999 = cvExp.getCause().toString();
                processShortDescIfException(eligibility270.toString(), errorDescription999, errorCode, transactionSetControlNumber);
                return;
            }
            if (eligibility270withack.getEligibilitystatuscode().equalsIgnoreCase(IConstants.ACCEPTED)) {
                EmdeonConfiguration configuration = new EmdeonConfiguration();
                EmdeonClient emdeonClient = configuration.emdeonClient(configuration.marshaller());
                BigInteger emdeonRequestResponseId = baseDao.nextVal(DBSequenceType.EMDEON_REQUEST_RESPONSE);
                Emdeonrequestresponse emdeonrequestresponse = new Emdeonrequestresponse();
                emdeonrequestresponse.setId(emdeonRequestResponseId);
                emdeonrequestresponse.setEligibility270withack(eligibility270withack);
                emdeon.setEmdeon(emdeonrequestresponse);
                emdeon = emdeonClient.coreEnvelopeRealTimeResponse(emdeon, eligibility270.toString(), deliverymethod);
                baseDao.saveEmdeon(emdeon.getEmdeon());
                if (emdeon.isExceptionOccurred()) {
                    errorDescription999 = emdeon.getDescription();
                    processShortDescIfException(emdeon.getResponse().getPayload(), errorDescription999, Ack999Constants.ERROR, transactionSetControlNumber);
                    return;
                } else if (emdeon.getEmdeon().getResponsetype().equals(Ack999Constants.ERROR) || emdeon.getEmdeon().getResponsetype().equals(Ack999Constants.UNAUTHORIZED)) {
                    setErrorInResponse(true);
                    errorDescription999 = emdeon.getResponse().getErrorMessage();
                    errorCode = emdeon.getResponse().getErrorCode();
                    processShortDescIfException(emdeon.getResponse().getPayload(), errorDescription999, errorCode, transactionSetControlNumber);
                    return;
                } else {
                    processEDI271(emdeon.getResponse().getPayload(), eligibility270withack, transactionSetControlNumber);
                }
            }
        }
    }

    private InterchangeControlHeader createInterchangeControlHeader(ISAEntity isa, Deliverymethod deliverymethod) {
        LOG.debug("CREATE INTERCHANGE CONTROL HEADER.");
        InterchangeControlHeader interchangeControlHeader = new InterchangeControlHeader();

        interchangeControlHeader.setRepetitionseprator(isa.getRepetitionseprator());
        interchangeControlHeader.setAckrequiredornot(isa.getAckrequiredornot());
        interchangeControlHeader.setUsageindicator(isa.getUsageindicator());
        interchangeControlHeader.setCompelementseprator(isa.getCompelementseprator());
        interchangeControlHeader.setIccontrolversionnum(isa.getIccontrolversionnum());
        interchangeControlHeader.setInterchangeidqualifier(isa.getInterchangeIdQualifier());
        interchangeControlHeader.setIcreceiveridqualifier(isa.getIcReceiverIdQualifier());
        interchangeControlHeader.setInterchangereceiverid(deliverymethod.getReceiverid());
        interchangeControlHeader.setInterchangesenderid(deliverymethod.getSenderid());

        if ((deliverymethod.getUsername() != null && !deliverymethod.getUsername().trim().isEmpty()) && (deliverymethod.getPassword() != null && !deliverymethod.getPassword().trim().isEmpty())) {
            interchangeControlHeader.setAuthinfoqualifier(IConstants.AUTHRZATION_INFORMATION_QUALIFIER_YES);
            interchangeControlHeader.setSecurityinfoqualifier(IConstants.SECURITY_INFO_QUALIFIER_YES);
            interchangeControlHeader.setAuthinfo(deliverymethod.getUsername());
            interchangeControlHeader.setSecurityinfo(deliverymethod.getPassword());

        } else {
            interchangeControlHeader.setAuthinfoqualifier(isa.getAuthInfoQualifier());
            interchangeControlHeader.setSecurityinfoqualifier(isa.getSecurityInfoQualifier());
        }
        return interchangeControlHeader;
    }

    private FunctionalgroupHeader createFunctionalGroupHeader(BigInteger groupControlNum, Date date, String senderId, String receiverID) {
        LOG.debug("CREATE FUNCTION GROUP HEADER.");
        FunctionalgroupHeader functionalgroupHeader = new FunctionalgroupHeader();
        functionalgroupHeader.setFunctionalidentifiercode(GSCreator.FUNCTIONAL_IDENTIFIER_CODE);
        functionalgroupHeader.setApplicationsendercode(senderId);
        functionalgroupHeader.setApplicationReceiverCode(receiverID);
        Time gsDate = new Time(date.getTime());
        functionalgroupHeader.setGsdate(gsDate);
        functionalgroupHeader.setGstime(new Timestamp(date.getTime()));
        functionalgroupHeader.setGroupcontrolnumber(groupControlNum.intValue());
        functionalgroupHeader.setResponsibleagencycode(GSCreator.RESPONSIBLE_AGENCY_CODE);
        functionalgroupHeader.setVersionreleaseno(ICreator.VERSION_NO);
        return functionalgroupHeader;
    }

    private TransactionsetHeader createTransactionSetHeader(BigInteger interchangeControlNum) {
        LOG.debug("CREATE TRANSACTION SET HEADER.");
        TransactionsetHeader transactionsetHeader = new TransactionsetHeader();
        transactionsetHeader.setTransactionsetidentifier(STCreator.EDI_TYPE);
        transactionsetHeader.setTransactionsetcontrolnumber(interchangeControlNum.intValue());
        transactionsetHeader.setImplementationconventionreference(ICreator.VERSION_NO);
        LOG.info("CREATE TRANSACTION SET HEADER SUCCESS.");
        return transactionsetHeader;
    }

    private BeginingtransactionHeader createBeginingtransactionHeader(Date date, BigInteger referenceIdentification) {
        LOG.debug("CREATE BEGINING TRANSACTION SET HEADER.");
        BeginingtransactionHeader beginingtransactionHeader = new BeginingtransactionHeader();
        beginingtransactionHeader.setHierarchicalstructurecode(BHTCreator.HIERARCHICAL_STRUCTURE_CODE);
        beginingtransactionHeader.setTransactionsetpurposecode(BHTCreator.TRANSACTION_SET_PURPOSE_CODE_ORIGINAL);
        beginingtransactionHeader.setReferenceidentification(referenceIdentification.intValue());
        beginingtransactionHeader.setBhtdate(new Timestamp(date.getTime()));
        beginingtransactionHeader.setBhttime(new Timestamp(date.getTime()));
        beginingtransactionHeader.setTransactiontypecode(BHTCreator.TRANSACTION_TYPE_CODE);
        LOG.info("CREATE BEGINING TRANSACTIONSET HEADER SUCCESS.");
        return beginingtransactionHeader;
    }

    public static List<Eligibility270ParserError> getParserErrors() {
        return parserErrors;
    }

    public static void setParserErrors(List<Eligibility270ParserError> parserErrors) {
        Eligibility270Writer.parserErrors = parserErrors;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public boolean isErrorInResponse() {
        return errorInResponse;
    }

    public void setErrorInResponse(boolean errorInResponse) {
        this.errorInResponse = errorInResponse;
    }

    public String getErrorDescription999() {
        return errorDescription999;
    }

    public void setErrorDescription999(String errorDescription999) {
        this.errorDescription999 = errorDescription999;
    }

    public CoreEmdeonRequestResponse getEmdeon() {
        return emdeon;
    }

    public void setEmdeon(CoreEmdeonRequestResponse emdeon) {
        this.emdeon = emdeon;
    }

    public Eligibility271Parser getEligibility271Parser() {
        return eligibility271Parser;
    }

    public void setEligibility271Parser(Eligibility271Parser eligibility271Parser) {
        this.eligibility271Parser = eligibility271Parser;
    }

    /*
     * this method is used to parse the response EDI(999 OR 271)
     */
    public void processEDI271(String eligibility271, Eligibility270withack eligibility270withack, BigInteger transactionSetControlNumber) {
        LOG.debug("Parse the Responsei.");

        // String
        // eligibility271="ISA*00* *00* *ZZ*CMS *ZZ*SUBMITTERID *140831*0758*^*00501*111111111*0*P*|~GS*HB*CMS*SUBMITTERID*20140831*07580000*1*X*005010X279A1~ST*271*4322*005010X279~BHT*0022*11*10001235*20060501*1319~HL*1**20*1~NM1*PR*2*ABC COMPANY*****PI*842610001~HL*2*1*21*1~NM1*1P*2*BONE AND JOINT CLINIC*****SV*2000035~HL*3*2*22*1~NM1*IL*1*SMITH*JOHN****MI*123456789~N3*15197 BROADWAY AVENUE*APT 215~N4*KANSAS CITY*MO*64108~DMG*D8*19630519*M~HL*4*3*23*1~TRN*2*000000120*9877281234~NM1*03*1*SMITH*MARY~N3*15197 BROADWAY AVENUE*APT 215~N4*KANSAS CITY*MO*64108~DMG*D8*19981014*F~INS*N*19~DTP*346*D8*20060101~EB*1**32**GOLD 123 PLAN~MSG*Free form text is discouraged~EB*L~LS*2120~NM1*P3*1*JONES*MARCUS****SV*0202034~LE*2120~DTP*346*D8*20060101~EB*1**1^33^35^47^86^88^98^AL^MH^UC~EB*B**1^33^35^47^86^88^98^AL^MH^UC*HM*GOLD 123 PLAN*27*10*****Y~EB*B**1^33^35^47^86^88^98^AL^MH^UC*HM*GOLD 123 PLAN*27*30*****N~SE*28*4322~GE*1*1~IEA*1*111111111~";
        // eligibility271="ISA*00*          *00*          *ZZ*WEBMDDENTAL    *ZZ*416:123PATIENT *150826*1441*^*00501*414057917*0*P*:~GS*HB*WEBMDDENTAL*416:TEST001*20150826*1441*414057917*X*005010X279A1~ST*271*0001*005010X279A1~BHT*0022*11*001*20150826*1441~HL*1**20*1~NM1*PR*2*CGLIC*****PI*62308~PER*IC**TE*8002446224*UR*cignaforhcp.cigna.com~HL*2*1*21*1~NM1*1P*1*HERNAN*QUINTEROS****XX*1801194865~HL*3*2*22*0~TRN*1*"+traceNumber+"*9CT EMDEON*DENTAL~TRN*2*2170066168654126*9PATPORTAL~NM1*IL*1*ESCOBAR*JOSE****MI*U4435446702~REF*6P*3332199*MIAMI-DADE COUNTY PUBLIC SCHOOLS~REF*Q4*U44354467~N3*31 SE 5TH ST APT 1811~N4*MIAMI*FL*331312515~DMG*D8*19791218*M~INS*Y*18*001*25~DTP*356*D8*20140101~DTP*346*D8*20150101~DTP*347*D8*20151231~EB*1**30**Open Access Plus~MSG*PHS+~EB*I**35~EB*A*FAM*30*****.7****Y~MSG*This benefit does apply to member's out-of-pocket maximum~EB*G*FAM*30***23*8000*****Y~MSG*Accumulators are shared between Medical AND Mental Health~EB*C*FAM*30***23*1500*****Y~MSG*Benefit does apply to member's out-of-pocket maximum~MSG*Accumulators are shared between Medical AND Mental Health~EB*C*IND*30***23*750*****Y~MSG*Benefit does apply to member's out-of-pocket maximum~MSG*Accumulators are shared between Medical AND Mental Health~EB*G*IND*30***23*4000*****Y~MSG*Accumulators are shared between Medical AND Mental Health~EB*A*IND*30*****.7****Y~MSG*This benefit does apply to member's out-of-pocket maximum~EB*A*FAM*30*****.5****N~MSG*This benefit does apply to member's out-of-pocket maximum~EB*G*FAM*30***23*16000*****N~MSG*Accumulators are shared between Medical AND Mental Health~EB*C*FAM*30***23*3000*****N~MSG*Benefit does apply to member's out-of-pocket maximum~MSG*Accumulators are shared between Medical AND Mental Health~EB*G*IND*30***23*8000*****N~MSG*Accumulators are shared between Medical AND Mental Health~EB*A*IND*30*****.5****N~MSG*This benefit does apply to member's out-of-pocket maximum~EB*C*IND*30***23*1500*****N~MSG*Benefit does apply to member's out-of-pocket maximum~MSG*Accumulators are shared between Medical AND Mental Health~EB*G*FAM*30***29*7963.86*****Y~MSG*Accumulators are shared between Medical AND Mental Health~EB*C*FAM*30***29*1500*****Y~MSG*Benefit does apply to member's out-of-pocket maximum~MSG*Accumulators are shared between Medical AND Mental Health~EB*C*IND*30***29*750*****Y~MSG*Benefit does apply to member's out-of-pocket maximum~MSG*Accumulators are shared between Medical AND Mental Health~EB*G*IND*30***29*4000*****Y~MSG*Accumulators are shared between Medical AND Mental Health~EB*G*FAM*30***29*16000*****N~MSG*Accumulators are shared between Medical AND Mental Health~EB*C*FAM*30***29*3000*****N~MSG*Benefit does apply to member's out-of-pocket maximum~MSG*Accumulators are shared between Medical AND Mental Health~EB*G*IND*30***29*8000*****N~MSG*Accumulators are shared between Medical AND Mental Health~EB*C*IND*30***29*1500*****N~MSG*Benefit does apply to member's out-of-pocket maximum~MSG*Accumulators are shared between Medical AND Mental Health~SE*72*0001~GE*1*414057917~IEA*1*414057917~";
        // eligibility271="ISA*00*          *00*          *ZZ*263086998      *ZZ*b2bup6479      *150923*1212*^*00501*000000685*0*P*:~GS*HB*263086998*b2bup6479*20150923*12121741*684*X*005010X279A1~ST*271*0684*005010X279A1~BHT*0022*11*684*20150923*12121741~HL*1**20*1~NM1*PR*2*AETNA INC*****PI*953402799~HL*2*1*21*1~NM1*1P*2*Renew Clinic*****XX*1999999992~HL*3*2*22*0~TRN*2*"+traceNumber+"*EZDERM9999~NM1*IL*1*NARANJO*CLAUDIA****MI*W217231497~REF*18*F<@-%001~REF*6P*0592584014*DENTMALL MSO LLC~N3*16573 NW 23 ST~N4*PEMBROKE PINES*FL*33028~DMG*D8*19771211*F~DTP*346*D8*20150101~DTP*472*D8*20150607~DTP*356*D8*20111001~EB*L*FAM*30*PS~LS*2120~NM1*P3*2*PCP SELECTION NOT REQUIRED~LE*2120~EB*W~LS*2120~NM1*PR*2*Aetna~N3*PO Box 981106~N4*El Paso*TX*79998~LE*2120~EB*1*FAM*30*PS*Open Access Aetna Health Network Option~EB*C*FAM*30***23*2000*****Y~DTP*307*D8*20150101~MSG*Med Dent,In-Network Providers,DED INCLUDED IN OOP,Manipulation by Chiropractor,Occupational Therapy by Chiropractor,Physical Therapy by Chiropractor~EB*C*FAM*30***29*2000*****Y~MSG*Med Dent~EB*C*FAM*30***23*2000*****Y~DTP*307*D8*20150101~MSG*Med Dent,In-Network Providers,DED INCLUDED IN OOP,Outpatient Surgery Facility,Inpatient Medical Ancillary,Semi Private Room and Board,Intensive Care Room and Board,Medical Ancillary~EB*C*FAM*30***29*2000*****Y~MSG*Med Dent~EB*C*IND*30***23*1000*****Y~DTP*307*D8*20150101~MSG*Med Dent,In-Network Providers,DED INCLUDED IN OOP,Manipulation by Chiropractor,Occupational Therapy by Chiropractor,Physical Therapy by Chiropractor~EB*C*IND*30***29*1000*****Y~MSG*Med Dent~EB*C*IND*30***23*1000*****Y~DTP*307*D8*20150101~MSG*Med Dent,In-Network Providers,DED INCLUDED IN OOP,Outpatient Surgery Facility,Inpatient Medical Ancillary,Semi Private Room and Board,Intensive Care Room and Board,Medical Ancillary~EB*C*IND*30***29*1000*****Y~MSG*Med Dent~EB*G*IND*30****3500*****Y~MSG*In-Network Providers~MSG*INT MED AND RX~EB*G*IND*30***29*3450*****Y~EB*G*FAM*30****7000*****Y~MSG*In-Network Providers~MSG*INT MED AND RX~EB*G*FAM*30***29*6258.75*****Y~EB*C*FAM*30***23*4000*****N~DTP*307*D8*20150101~MSG*Med Dent,DED INCLUDED IN OOP,Chiropractor Visit or Evaluation,Lab Performed by Chiropractor in Office,Lab Performed by Chiropractor,Xray by Chiropractor in Office,Xray by Chiropractor,Manipulation by Chiropractor,Occupational Therapy by Chiropractor~MSG*Physical Therapy by Chiropractor,Urgent Care,GYN Visit,Specialist Visit or Evaluation,Primary Care Visit or Evaluation~EB*C*FAM*30***29*4000*****N~MSG*Med Dent~EB*C*FAM*30***23*4000*****N~DTP*307*D8*20150101~MSG*Med Dent,DED INCLUDED IN OOP,Outpatient Surgery Facility,Inpatient Medical Ancillary,Inpatient Semi Private Room and Board,Intensive Care Room and Board~EB*C*FAM*30***29*4000*****N~MSG*Med Dent~EB*C*IND*30***23*2000*****N~DTP*307*D8*20150101~MSG*Med Dent,DED INCLUDED IN OOP,Chiropractor Visit or Evaluation,Lab Performed by Chiropractor in Office,Lab Performed by Chiropractor,Xray by Chiropractor in Office,Xray by Chiropractor,Manipulation by Chiropractor,Occupational Therapy by Chiropractor~MSG*Physical Therapy by Chiropractor,Urgent Care,GYN Visit,Specialist Visit or Evaluation,Primary Care Visit or Evaluation~EB*C*IND*30***29*2000*****N~MSG*Med Dent~EB*C*IND*30***23*2000*****N~DTP*307*D8*20150101~MSG*Med Dent,DED INCLUDED IN OOP,Outpatient Surgery Facility,Inpatient Medical Ancillary,Inpatient Semi Private Room and Board,Intensive Care Room and Board~EB*C*IND*30***29*2000*****N~MSG*Med Dent~EB*G*IND*30****10500*****N~MSG*INT MED AND RX~EB*G*IND*30***29*10500*****N~EB*G*FAM*30****21000*****N~MSG*INT MED AND RX~EB*G*FAM*30***29*21000*****N~EB*F*FAM*30*********W~MSG*Plan Requires PreCert~EB*F*FAM*30~MSG*Commercial~EB*F*FAM*30***32~MSG*Unlimited Lifetime Benefits~EB*1*FAM*1^33^47^48^50^86^98^UC^35^AL^MH^88**Open Access Aetna Health Network Option~EB*A*FAM*33*****0****Y~MSG*In-Network Providers~MSG*Chiropractor Visit or Evaluation in Office~MSG*Chiropractor Visit or Evaluation~MSG*Lab Performed by Chiropractor in Office~MSG*Lab Performed by Chiropractor~MSG*Xray by Chiropractor in Office~MSG*Xray by Chiropractor~EB*A*FAM*33*****.2****Y~MSG*In-Network Providers~MSG*Manipulation by Chiropractor,COINS APPLIES TO OUT OF POCKET~MSG*Occupational Therapy by Chiropractor,COINS APPLIES TO OUT OF POCKET~MSG*Physical Therapy by Chiropractor,COINS APPLIES TO OUT OF POCKET~EB*A*FAM*48*****.2***Y*Y~MSG*In-Network Providers~MSG*Inpatient Medical Ancillary,COINS APPLIES TO OUT OF POCKET~MSG*Semi Private Room and Board,COINS APPLIES TO OUT OF POCKET~MSG*Intensive Care Room and Board,COINS APPLIES TO OUT OF POCKET~EB*A*FAM*48^50*****.2***Y*Y~MSG*In-Network Providers~MSG*Medical Ancillary,COINS APPLIES TO OUT OF POCKET~EB*A*FAM*50*****0****Y~MSG*In-Network Providers~MSG*Outpatient Surgery Facility~EB*A*FAM*86*****0****Y~MSG*In-Network Providers~MSG*Urgent Care~EB*A*FAM*98*****0****Y~MSG*In-Network Providers~MSG*GYN Visit when Performed in an Office~MSG*GYN Visit~MSG*Specialist Visit or Evaluation when Performed in an Office~MSG*Specialist Visit or Evaluation~MSG*Primary Care Visit or Evaluation in Office~MSG*Primary Care Visit or Evaluation~EB*A*FAM*UC*****0****Y~MSG*In-Network Providers~EB*B*FAM*33****50*****Y~MSG*In-Network Providers~MSG*Chiropractor Visit or Evaluation in Office,COPAY INCLUDED IN OOP~EB*B*FAM*48^50****0****Y*Y~MSG*In-Network Providers~MSG*Medical Ancillary~EB*B*FAM*48****0****Y*Y~MSG*In-Network Providers~MSG*Semi Private Room and Board~MSG*Intensive Care Room and Board~EB*B*FAM*50****500*****Y~MSG*In-Network Providers~MSG*Outpatient Surgery Facility,COPAY INCLUDED IN OOP~EB*B*FAM*86****75*****Y~MSG*In-Network Providers~MSG*Urgent Care,COPAY INCLUDED IN OOP~EB*B*FAM*98****50*****Y~MSG*In-Network Providers~MSG*GYN Visit when Performed in an Office,COPAY INCLUDED IN OOP~MSG*Specialist Visit or Evaluation when Performed in an Office,COPAY INCLUDED IN OOP~EB*B*FAM*98****25*****Y~MSG*In-Network Providers~MSG*Primary Care Visit or Evaluation in Office,COPAY INCLUDED IN OOP~MSG*Patient's Primary Care Physician~MSG*GYN Visit when Performed in an Office,COPAY INCLUDED IN OOP~EB*B*FAM*UC****75*****Y~MSG*In-Network Providers~MSG*COPAY INCLUDED IN OOP~EB*F*FAM*33*********Y~MSG*In-Network Providers~MSG*Chiropractor Visit or Evaluation in Office/Plan Ded Waived~MSG*Chiropractor Visit or Evaluation/Plan Ded Waived~MSG*Lab Performed by Chiropractor in Office/Plan Ded Waived~MSG*Lab Performed by Chiropractor/Plan Ded Waived~MSG*Xray by Chiropractor in Office/Plan Ded Waived~MSG*Xray by Chiropractor/Plan Ded Waived~EB*F*FAM*86^UC*********Y~MSG*In-Network Providers~MSG*Urgent Care/Plan Ded Waived~EB*F*FAM*98*********Y~MSG*In-Network Providers~MSG*GYN Visit when Performed in an Office/Plan Ded Waived~MSG*GYN Visit/Plan Ded Waived~MSG*Specialist Visit or Evaluation when Performed in an Office/Plan Ded Waived~MSG*Specialist Visit or Evaluation/Plan Ded Waived~MSG*Primary Care Visit or Evaluation in Office/Plan Ded Waived~MSG*Primary Care Visit or Evaluation/Plan Ded Waived~EB*A*FAM*86*****0***Y*W~MSG*Emergency Room Physician~MSG*Emergency use of Emergency Room~EB*B*FAM*33****0****Y*W~MSG*Chiropractor Visit or Evaluation~MSG*Lab Performed by Chiropractor in Office~MSG*Lab Performed by Chiropractor~MSG*Xray by Chiropractor in Office~MSG*Xray by Chiropractor~MSG*Manipulation by Chiropractor~MSG*Occupational Therapy by Chiropractor~MSG*Physical Therapy by Chiropractor~EB*B*FAM*48****0****Y*W~MSG*Inpatient Medical Ancillary~EB*B*FAM*86****0****Y*W~MSG*Emergency Room Physician~EB*B*FAM*86****300****Y*W~MSG*Emergency use of Emergency Room,COPAY INCLUDED IN OOP~EB*B*FAM*98****0****Y*W~MSG*GYN Visit~MSG*Specialist Visit or Evaluation~MSG*Primary Care Visit or Evaluation~EB*F*IND*33*********W~HSD*VS*35***21*1~MSG*SHRT TRM REHAB,Manipulation by Chiropractor,Occupational Therapy by Chiropractor,Physical Therapy by Chiropractor~EB*F*IND*33*********W~HSD*VS*35***29~MSG*SHRT TRM REHAB~EB*F*FAM*86*********W~MSG*Emergency Room Physician/Plan Ded Waived~MSG*Emergency use of Emergency Room/Plan Ded Waived~EB*A*FAM*33*****.5***Y*N~MSG*Chiropractor Visit or Evaluation,COINS APPLIES TO OUT OF POCKET~MSG*Lab Performed by Chiropractor in Office,COINS APPLIES TO OUT OF POCKET~MSG*Lab Performed by Chiropractor,COINS APPLIES TO OUT OF POCKET~MSG*Xray by Chiropractor in Office,COINS APPLIES TO OUT OF POCKET~MSG*Xray by Chiropractor,COINS APPLIES TO OUT OF POCKET~MSG*Manipulation by Chiropractor,COINS APPLIES TO OUT OF POCKET~MSG*Occupational Therapy by Chiropractor,COINS APPLIES TO OUT OF POCKET~MSG*Physical Therapy by Chiropractor,COINS APPLIES TO OUT OF POCKET~EB*A*FAM*48*****.5***Y*N~MSG*Inpatient Medical Ancillary,COINS APPLIES TO OUT OF POCKET~MSG*Inpatient Semi Private Room and Board,COINS APPLIES TO OUT OF POCKET~MSG*Intensive Care Room and Board,COINS APPLIES TO OUT OF POCKET~EB*A*FAM*50^UC*****.5***Y*N~MSG*COINS APPLIES TO OUT OF POCKET~EB*A*FAM*86*****.5***Y*N~MSG*Urgent Care,COINS APPLIES TO OUT OF POCKET~EB*A*FAM*98*****.5***Y*N~MSG*GYN Visit,COINS APPLIES TO OUT OF POCKET~MSG*Specialist Visit or Evaluation,COINS APPLIES TO OUT OF POCKET~MSG*Primary Care Visit or Evaluation,COINS APPLIES TO OUT OF POCKET~EB*B*FAM*48****0****Y*N~MSG*Inpatient Semi Private Room and Board~MSG*Intensive Care Room and Board~EB*B*FAM*50^UC****0****Y*N~EB*B*FAM*86****0****Y*N~MSG*Urgent Care~EB*I*FAM*86*********W~MSG*Non Emergency use of Emergency Room/EXCLUSION~EB*I*FAM*86^UC*********W~MSG*Non Urgent Services at an Urgent Care Facility/EXCLUSION~EB*F*FAM*1^33^48^50^86^98^UC~MSG*Plan includes NAP~EB*I*FAM*48*********N~MSG*Semi Private Room and Board/EXCLUSION~SE*242*0684~GE*1*684~IEA*1*000000685~";
        eligibility271Parser.setDtpDef();
        ArrayList<SegmentBean> segmentBeansList = SegmentParseUtility.parseEligibility271String(eligibility271);
        SegmentBean segmentBeanST = getSegmentBeanFromListBySegmentTag(EligibilityTagEnum.ST, segmentBeansList);
        if (isContent(Ack999Constants.ACK999, segmentBeanST)) {
            // if 999 then add errors in json
            processAndUpdateAck999Info(eligibility271, segmentBeansList, transactionSetControlNumber);
        } else if (isContent(Ack999Constants.EDI271, segmentBeanST)) {
            // if 271 then create shortDesc json
            SegmentBean segmentBeanAAA = getSegmentBeanFromListBySegmentTag(EligibilityTagEnum.AAA, segmentBeansList);
            eligibility271Parser.getShortDesc(segmentBeansList, eligibility271, eligibility270withack, segmentBeanAAA);
            if (segmentBeanAAA == null) {
                // if 271 then create LongDesc json
                eligibility271Parser.getLongDesc(segmentBeansList, eligibility271, eligibility270withack);
            }
        }
        LOG.debug("Parse the Response Completed.");
    }

    /*
     * this method is used to get a particular segment (elTag) from the list of
     * segments
     */
    public SegmentBean getSegmentBeanFromListBySegmentTag(EligibilityTagEnum elTag, ArrayList<SegmentBean> segmentBeanList) {
        SegmentBean segBean = null;
        for (SegmentBean segmentBean : segmentBeanList) {
            if (segmentBean.getSegmentName().equals(elTag)) {
                segBean = segmentBean;
                break;
            }
        }
        return segBean;
    }

    /*
     * this method is used to get all particular segment list (elTag) from the
     * list of segments
     */
    public ArrayList<SegmentBean> getSegmentBeansFromListBySegmentTag(EligibilityTagEnum elTag, ArrayList<SegmentBean> segmentBeanList) {
        ArrayList<SegmentBean> segBeans = new ArrayList<SegmentBean>();
        for (SegmentBean segmentBean : segmentBeanList) {
            if (segmentBean.getSegmentName().equals(elTag)) {
                segBeans.add(segmentBean);
            }
        }
        return segBeans;
    }

    /*
     * this method is to check the content type of ACK
     */
    public boolean isContent(String ack999Constants, SegmentBean stSegmentBean) {
        LOG.info("Check ACK Content Type.");
        FieldWithValueBean st01Field = stSegmentBean.getFieldBeanByFieldName(SegmentRefDesginatorConstants.ST01);
        if (st01Field.getFieldValue().equals(ack999Constants)) {
            return true;
        } else
            return false;
    }

    /*
     * This method shows 999 error if we receive 999 EDI in response
     */
    private void processAndUpdateAck999Info(String ack999String, ArrayList<SegmentBean> segmentBeanList, BigInteger transactionSetControlNumber) {
        LOG.debug("Parse the Response(999 EDI) and add errors in json .");
        errorCode = Ack999Constants.ACK999;
        setErrorInResponse(true);
        if (segmentBeanList != null && !segmentBeanList.isEmpty()) {
            SegmentBean stSegmentBean = getSegmentBeanFromListBySegmentTag(EligibilityTagEnum.ST, segmentBeanList);
            FieldWithValueBean st01Field = stSegmentBean.getFieldBeanByFieldName(SegmentRefDesginatorConstants.ST01);
            if (st01Field.getFieldValue().equals(Ack999Constants.ACK999)) {
                SegmentBean ak1SegmentBean = getSegmentBeanFromListBySegmentTag(EligibilityTagEnum.AK1, segmentBeanList);
                SegmentBean ak2SegmentBean = getSegmentBeanFromListBySegmentTag(EligibilityTagEnum.AK2, segmentBeanList);
                ArrayList<SegmentBean> ik3SegmentBeans = getSegmentBeansFromListBySegmentTag(EligibilityTagEnum.IK3, segmentBeanList);
                ArrayList<SegmentBean> ik4SegmentBeans = getSegmentBeansFromListBySegmentTag(EligibilityTagEnum.IK4, segmentBeanList);
                SegmentBean ik5SegmentBean = getSegmentBeanFromListBySegmentTag(EligibilityTagEnum.IK5, segmentBeanList);
                if (ak1SegmentBean != null && ak2SegmentBean != null) {
                    FieldWithValueBean edi270responseOrNot = ak2SegmentBean.getFieldBeanByFieldName(SegmentRefDesginatorConstants.AK201);
                    if (edi270responseOrNot.getFieldValue().equals(Ack999Constants.EDI270)) {

                        FieldWithValueBean ediAcceptOrReject = null;
                        if (ik5SegmentBean == null) {
                            SegmentBean ak9SegmentBean = getSegmentBeanFromListBySegmentTag(EligibilityTagEnum.AK9, segmentBeanList);
                            if (ak9SegmentBean != null) {
                                ediAcceptOrReject = ak9SegmentBean.getFieldBeanByFieldName(SegmentRefDesginatorConstants.AK901);
                            }
                        } else {
                            ediAcceptOrReject = ik5SegmentBean.getFieldBeanByFieldName(SegmentRefDesginatorConstants.IK501);
                        }
                        // String errorStr="";
                        if (ediAcceptOrReject != null) {
                            ArrayList<Ack999Errors> errors999 = new ArrayList<Ack999Errors>();
                            for (int i = 0; i < ik3SegmentBeans.size(); i++) {
                                Ack999Errors error999 = new Ack999Errors();
                                FieldWithValueBean ik301 = ik3SegmentBeans.get(i).getFieldBeanByFieldName(SegmentRefDesginatorConstants.IK301);
                                FieldWithValueBean ik303 = ik3SegmentBeans.get(i).getFieldBeanByFieldName(SegmentRefDesginatorConstants.IK303);
                                FieldWithValueBean ik401 = ik4SegmentBeans.get(i).getFieldBeanByFieldName(SegmentRefDesginatorConstants.IK401);
                                FieldWithValueBean ik404 = ik4SegmentBeans.get(i).getFieldBeanByFieldName(SegmentRefDesginatorConstants.IK404);
                                error999.setData(ik404.getFieldValue());
                                error999.setLoopid(ik303.getFieldValue());
                                error999.setElementPosition(ik401.getFieldValue());
                                error999.setSegmentName(ik301.getFieldValue());
                                errors999.add(error999);
                            }
                            setErrorDescription999(errors999.toString());
                            processShortDescIfException(ack999String, errors999.toString(), Ack999Constants.ACK999, transactionSetControlNumber);

                        }

                    }

                }

            }

        }
        LOG.debug("Parse the Response(999 EDI) Completed.");
    }

    public void processRequest(XsElement_ element) {

        try {
            eligibility271Parser.setInsuranceId(element.getPrimaryInsuredIdentifierCode());
            writeAllLoop(element);

        } catch (Exception e) {
            LOG.error("Error while generating and processing 270 EDI.", e);
            processShortDescIfException(null, IConstants.INVALID_DESCRIPTION, IConstants.INVALID_REQUEST, IConstants.MINUS_ONE);
        }

    }

    public void processShortDescIfException(String ediMessage, String errorMessage, String error, BigInteger transactionSetControlNumber) {
        Edi271shortdesc shortDesc = new Edi271shortdesc();
        shortDesc.setEligibilityoutcomemessage(errorMessage);
        shortDesc.setEligibilityoutcomecode(error);
        shortDesc.setTransactionsetcontrolnumber(transactionSetControlNumber.intValue());
        shortDesc.setEdimessage(ediMessage);
        shortDesc.setEligibilitytracernumber(traceNumber);

        EligibilityOutput output = new EligibilityOutput();
        output.setEdimessage(ediMessage);
        output.setEligibilitytracenumber(traceNumber);
        output.setEligibilityoutcomecode(error);
        output.setEligibilityoutcomemessage(errorMessage);
        output.setTransactionsetcontrolnumber(transactionSetControlNumber.intValue());
        EligibilityProcessAction.setEligibilityOutput(output);
        try {
            if (transactionSetControlNumber != IConstants.MINUS_ONE && !(error.equals(IResponseAckErrorCode.DUPLICATE_TRACE_NUMBER_OR_DB_ERROR))) {
                baseDao.save(shortDesc); // saving the short description of
                                         // Error in db if error is not from
                                         // Duplicate Key
            }

        } catch (HibernateException he) {
            LOG.error("Exception while saving short description from response", he);
        }

    }

}
