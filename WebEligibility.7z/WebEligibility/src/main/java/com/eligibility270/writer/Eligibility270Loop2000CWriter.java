package com.eligibility270.writer;

import static com.eligibility270.writer.IConstants.MAX_FIFTY;
import static com.eligibility270.writer.IConstants.MAX_NINE;
import static com.eligibility270.writer.IConstants.MAX_ONE;
import static com.eligibility270.writer.IConstants.MAX_TEN;
import static com.eligibility270.writer.IConstants.MAX_THIRTY;
import static com.eligibility270.writer.IConstants.MAX_THREE;
import static com.eligibility270.writer.IConstants.MAX_TWO;
import static com.eligibility270.writer.IConstants.MIN_ONE;
import static com.eligibility270.writer.IConstants.MIN_TEN;
import static com.eligibility270.writer.IConstants.MIN_THREE;
import static com.eligibility270.writer.IConstants.MIN_TWO;
import static com.eligibility270.writer.IConstants.SELF;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.eligibility.common.utility.HLUtil;
import com.eligibility.common.utility.StringUtil;
import com.eligibility.jsonschema270.beans.XsElement_;
import com.eligibility.shared.constants.EligibilityLoopEnum;
import com.eligibility.shared.constants.EligibilityTagEnum;
import com.eligibility.shared.constants.RefDesgEnum;
import com.eligibility270.beans.EqSegment;
import com.eligibility270.beans.InsSegment;
import com.eligibility270.parsing.error.Eligibility270JSOnScema;
import com.eligibility270.parsing.error.Eligibility270ParserError;
import com.eligibility270.parsing.error.IErrorCodeEnum;
import com.eligiblity271.beans.HlSegment;
import com.eligiblityshared.beans.AmtSegment;
import com.eligiblityshared.beans.Compositemedicalprocedure;
import com.eligiblityshared.beans.DmgSegment;
import com.eligiblityshared.beans.DtpSegment;
import com.eligiblityshared.beans.IiiSegment;
import com.eligiblityshared.beans.N3Segment;
import com.eligiblityshared.beans.N4Segment;
import com.eligiblityshared.beans.Nm1Segment;
import com.eligiblityshared.beans.PrvSegment;
import com.eligiblityshared.beans.RefSegment;
import com.eligiblityshared.beans.TrnSegment;
/**
 * @author Manish
 * @date MAR 20,2015
 */
public class Eligibility270Loop2000CWriter {
    private XsElement_ element;

    private static final Logger LOG = LoggerFactory.getLogger(Eligibility270Loop2000CWriter.class);

    public Eligibility270Loop2000CWriter(XsElement_ element) {
        this.element = element;
    }

    private String loop2000CWriter() {
        LOG.debug("Eligibility270Loop2000CWriter", "loop2000CWriter");
        HlSegment hL = new HlSegment();
        hL.setHierarchicalparentid(String.valueOf(HLUtil.HL_PARENT));
        HLUtil.HL_PARENT = HLUtil.VALUE;
        hL.setHierarchicalidno(String.valueOf(HLUtil.VALUE));
        HLUtil.nextVal();
        hL.setHierarchicallevelcode(String.valueOf(HLUtil.LEVEL_THREE));
        if (HLUtil.isSelf) {
            hL.setHierarchicalchildcode(String.valueOf(HLUtil.NO_CHILD));
        } else {
            hL.setHierarchicalchildcode(String.valueOf(HLUtil.YES_CHILD));
        }
        LOG.debug("Eligibility270Loop2000CWriter", "loop2000CWriter");
        return hL.writer();
    }

    private String trnMapperWriter() {
        LOG.debug("Eligibility270Loop2000CWriter", "trnMapperWriter");
        String codeVal = element.getRelationShipCode();
        if (!StringUtil.isNullOrEmpty(codeVal)) {
            try {
                int relationShipCode = Integer.valueOf(codeVal);
                if (relationShipCode == SELF) {
                    HLUtil.isSelf = Boolean.TRUE;

                    Eligibility270JSOnScema jsonScema = new Eligibility270JSOnScema();
                    Eligibility270ParserError eligibility270ParserError;

                    TrnSegment trn = new TrnSegment();

                    String trn01 = element.getEligibilityTracerCode();
                    String trn02 = element.getEligibilityTracerNumber();
                    String trn03 = element.getEligibilityEntityIdentifier();
                    String trn04 = element.getEligibilityEntityAdditionalIdentifier();

                    if (StringUtil.isNullOrEmpty(trn01) && StringUtil.isNullOrEmpty(trn02) && StringUtil.isNullOrEmpty(trn03) && StringUtil.isNullOrEmpty(trn04)) {
                        return new String("");
                    }

                    eligibility270ParserError = new Eligibility270ParserError();
                    eligibility270ParserError.setSegmentSituational(true);
                    eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2100C, EligibilityTagEnum.TRN, RefDesgEnum.TRN01, jsonScema.getEligibilityTracerCode());
                    if (StringUtil.isNullOrEmpty(trn01)) {
                        eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL.value());
                        eligibility270ParserError.setError(IErrorCodeEnum.C0001_VAL.value());
                        Eligibility270Writer.parserErrors.add(eligibility270ParserError);
                    } else if (StringUtil.isLengthExceeds(MIN_ONE, MAX_TWO, trn01)) {
                        eligibility270ParserError.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
                        eligibility270ParserError.setError(IErrorCodeEnum.C0002_VAL.value());
                        Eligibility270Writer.parserErrors.add(eligibility270ParserError);
                    } else {
                        trn.setTraceIdCode(trn01);
                    }

                    eligibility270ParserError = new Eligibility270ParserError();
                    eligibility270ParserError.setSegmentSituational(true);
                    eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2100C, EligibilityTagEnum.TRN, RefDesgEnum.TRN02, jsonScema.getEligibilityTracerNumber());
                    if (StringUtil.isNullOrEmpty(trn02)) {
                        eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL.value());
                        eligibility270ParserError.setError(IErrorCodeEnum.C0001_VAL.value());
                        Eligibility270Writer.parserErrors.add(eligibility270ParserError);
                    } else if (StringUtil.isLengthExceeds(MIN_ONE, MAX_FIFTY, trn02)) {
                        eligibility270ParserError.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
                        eligibility270ParserError.setError(IErrorCodeEnum.C0002_VAL.value());
                        Eligibility270Writer.parserErrors.add(eligibility270ParserError);
                    } else {
                        trn.setReferenceIden1(trn02);
                    }

                    eligibility270ParserError = new Eligibility270ParserError();
                    eligibility270ParserError.setSegmentSituational(true);
                    eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2100C, EligibilityTagEnum.TRN, RefDesgEnum.TRN03, jsonScema.getEligibilityEntityIdentifier());
                    if (StringUtil.isNullOrEmpty(trn03)) {
                        eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL.value());
                        eligibility270ParserError.setError(IErrorCodeEnum.C0001_VAL.value());
                        Eligibility270Writer.parserErrors.add(eligibility270ParserError);
                    } else if (StringUtil.isLengthExceeds(MIN_TEN, MAX_TEN, trn03)) {
                        eligibility270ParserError.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
                        eligibility270ParserError.setError(IErrorCodeEnum.C0002_VAL.value());
                        Eligibility270Writer.parserErrors.add(eligibility270ParserError);
                    } else {
                        trn.setOriginatingCompId(trn03);
                    }

                    if (!StringUtil.isNullOrEmpty(trn04)) {
                        trn.setReferenceIden2(trn04);
                    }

                    return trn.writer();
                }
            } catch (NumberFormatException ne) {
                LOG.error("Patient Subscriber not dependent. ", ne);
            }
        }
        LOG.debug("Eligibility270Loop2000CWriter", "trnMapperWriter");
        return new String();
    }

    public String nm1MapperWriter() {
        LOG.debug("Eligibility270Loop2000CWriter", "nm1MapperWriter");
        Nm1Segment nm1 = new Nm1Segment();

        Eligibility270JSOnScema jsonScema = new Eligibility270JSOnScema();
        Eligibility270ParserError eligibility270ParserError;

        /* NM-101 */
        String nm101 = element.getPrimaryInsuredEntityIdentifierCode();
        eligibility270ParserError = new Eligibility270ParserError();
        eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2100C, EligibilityTagEnum.NM1, RefDesgEnum.NM101, jsonScema.getPrimaryInsuredEntityIdentifierCode());
        if (StringUtil.isNullOrEmpty(nm101)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0001_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else if (StringUtil.isLengthExceeds(MIN_TWO, MAX_THREE, nm101)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0002_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else {
            nm1.setEntityidcode(nm101);
        }

        /* NM-102 */
        String nm102 = element.getPrimaryInsuredEntityTypeQualifier();
        eligibility270ParserError = new Eligibility270ParserError();
        eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2100C, EligibilityTagEnum.NM1, RefDesgEnum.NM102, jsonScema.getPrimaryInsuredEntityTypeQualifier());
        if (StringUtil.isNullOrEmpty(nm102)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0001_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else if (StringUtil.isLengthExceeds(IConstants.MIN_ONE, IConstants.MAX_ONE, nm102)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0002_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else {
            nm1.setEntitytypequalifier(nm102);
        }

        /* NM-103 */
        String nm103 = element.getPrimaryInsuredLastName();
        if (!StringUtil.isNullOrEmpty(nm103) && HLUtil.isSelf) {
            nm1.setNamelastorgname(nm103);
        } else {
            LOG.debug("Loop ID->2100C Segment ID-: NM RefDesg->NM103 Situational Rule->Required when the subscriber is the patient ");
        }

        /* NM-104 */
        String nm104 = element.getPrimaryInsuredFirstName();
        if (!StringUtil.isNullOrEmpty(nm104) && HLUtil.isSelf) {
            nm1.setFirstname(nm104);
        } else {
            LOG.debug("Loop ID->2100C Segment ID-: NM RefDesg->NM104 Situational Rule->Required when the subscriber is the patient ");
        }

        /* NM-105 */
        String nm105 = element.getPrimaryInsuredMiddleInitial();
        if (!StringUtil.isNullOrEmpty(nm105)) {
            nm1.setMiddlename(nm105);
        }
        /* NM-107 */
        String nm107 = element.getPrimaryInsuredSuffix();
        if (!StringUtil.isNullOrEmpty(nm107)) {
            nm1.setNamesuffix(nm107);
        }
        /* NM-108 */
        String nm108 = element.getPrimaryInsuredIdentifierCodeQualifier();
        if (!StringUtil.isNullOrEmpty(nm108)) {
            nm1.setIdcodequalifier(nm108);
        }
        /* NM-109 */
        String nm109 = element.getPrimaryInsuredIdentifierCode();
        if (!StringUtil.isNullOrEmpty(nm109)) {
            nm1.setIdcode(nm109);
        }
        LOG.debug("Eligibility270Loop2000CWriter", "nm1MapperWriter");
        return nm1.writer();
    }

    public String refMapperWrietr() {
        LOG.debug("Eligibility270Loop2000CWriter", "refMapperWrietr");
        RefSegment ref = new RefSegment();

        Eligibility270JSOnScema jsonScema = new Eligibility270JSOnScema();
        Eligibility270ParserError eligibility270ParserError;

        String ref01 = element.getPrimaryInsuredIdentificationQualifier();
        String ref02 = element.getPrimaryInsuredIdentification();
        if (StringUtil.isNullOrEmpty(ref01) && StringUtil.isNullOrEmpty(ref02)) {
            return new String("");
        }

        eligibility270ParserError = new Eligibility270ParserError();
        eligibility270ParserError.setSegmentSituational(true);
        eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2100C, EligibilityTagEnum.REF, RefDesgEnum.REF01, jsonScema.getPrimaryInsuredEntityTypeQualifier());
        if (StringUtil.isNullOrEmpty(ref01)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0001_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else if (StringUtil.isLengthExceeds(IConstants.MIN_TWO, IConstants.MAX_THREE, ref01)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0002_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else {
            ref.setRefidentificationqualifier(ref01);
        }

        eligibility270ParserError = new Eligibility270ParserError();
        eligibility270ParserError.setSegmentSituational(true);
        eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2100C, EligibilityTagEnum.REF, RefDesgEnum.REF02, jsonScema.getPrimaryInsuredIdentification());
        if (StringUtil.isNullOrEmpty(ref02)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0001_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else if (StringUtil.isLengthExceeds(IConstants.MIN_TWO, IConstants.MAX_FIFTY, ref02)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0002_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else {
            ref.setRefidentification(ref02);
        }

        LOG.debug("Eligibility270Loop2000CWriter", "refMapperWrietr");
        return ref.writer();
    }

    public String n3MapperWriter() {
        LOG.debug("Eligibility270Loop2000CWriter", "n3MapperWriter");
        N3Segment n3 = new N3Segment();

        Eligibility270JSOnScema jsonScema = new Eligibility270JSOnScema();
        Eligibility270ParserError eligibility270ParserError;

        String n301 = element.getPrimaryInsuredAddressLine1();
        String n302 = element.getPrimaryInsuredAddressLine2();

        if (StringUtil.isNullOrEmpty(n301) && StringUtil.isNullOrEmpty(n302)) {
            return new String("");
        }

        eligibility270ParserError = new Eligibility270ParserError();
        eligibility270ParserError.setSegmentSituational(true);
        eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2100C, EligibilityTagEnum.N3, RefDesgEnum.N301, jsonScema.getPrimaryInsuredAddressLine1());
        if (StringUtil.isNullOrEmpty(n301)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0001_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else if (StringUtil.isLengthExceeds(IConstants.MIN_ONE, IConstants.MAX_FIFTY_FIVE, n301)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0002_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else {
            n3.setAddressinfo1(n301);
        }

        if (!StringUtil.isNullOrEmpty(n302)) {
            n3.setAddressinfo2(n302);
        }
        LOG.debug("Eligibility270Loop2000CWriter", "n3MapperWriter");
        return n3.writer();
    }

    public String n4MapperWriter() {
        LOG.debug("Eligibility270Loop2000CWriter", "n4MapperWriter");
        N4Segment n4 = new N4Segment();

        Eligibility270JSOnScema jsonScema = new Eligibility270JSOnScema();
        Eligibility270ParserError eligibility270ParserError;

        String n401 = element.getPrimaryInsuredAddressCity();
        String n402 = element.getPrimaryInsuredAddressState();
        String n403 = element.getPrimaryInsuredAddressZipCode();
        String n404 = element.getPrimaryInsuredAddressCountry();
        if (StringUtil.isNullOrEmpty(n401) && StringUtil.isNullOrEmpty(n402) && StringUtil.isNullOrEmpty(n403) && StringUtil.isNullOrEmpty(n404)) {
            return new String("");
        }

        eligibility270ParserError = new Eligibility270ParserError();
        eligibility270ParserError.setSegmentSituational(true);
        eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2100C, EligibilityTagEnum.N4, RefDesgEnum.N401, jsonScema.getPrimaryInsuredAddressCity());
        if (StringUtil.isNullOrEmpty(n401)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0001_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else if (StringUtil.isLengthExceeds(MIN_TWO, MAX_THIRTY, n401)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0002_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else {
            n4.setCityname(n401);
        }

        if (!StringUtil.isNullOrEmpty(n402)) {
            n4.setStateorprovincecode(n402);
        }

        if (!StringUtil.isNullOrEmpty(n403)) {
            n4.setPostalcode(n403);
        }

        if (!StringUtil.isNullOrEmpty(n404)) {
            n4.setCountrycode(n404);
        }

        LOG.debug("Eligibility270Loop2000CWriter", "n4MapperWriter");
        return n4.writer();
    }

    public String prvWriterMapper() {
        LOG.debug("Eligibility270Loop2000CWriter", "prvWriterMapper");
        PrvSegment prv = new PrvSegment();

        Eligibility270JSOnScema jsonScema = new Eligibility270JSOnScema();
        Eligibility270ParserError eligibility270ParserError;

        String prv01 = element.getPrimaryInsuredProviderCode();
        String prv02 = element.getPrimaryInsuredProviderIdentificationQualifier();
        String prv03 = element.getPrimaryInsuredProviderIdentification();
        if (StringUtil.isNullOrEmpty(prv01) && StringUtil.isNullOrEmpty(prv02) && StringUtil.isNullOrEmpty(prv03)) {
            return new String("");
        }

        eligibility270ParserError = new Eligibility270ParserError();
        eligibility270ParserError.setSegmentSituational(true);
        eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2100C, EligibilityTagEnum.PRV, RefDesgEnum.PRV01, jsonScema.getPrimaryInsuredProviderCode());
        if (StringUtil.isNullOrEmpty(prv01)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0001_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else if (StringUtil.isLengthExceeds(MIN_ONE, MAX_THREE, prv01)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0002_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else {
            prv.setProvidercode(prv01);
        }

        boolean isPrv02 = false;

        if (!StringUtil.isNullOrEmpty(prv02)) {
            isPrv02 = true;
            prv.setRefidentificationqualifier(prv02);
        }

        if (!StringUtil.isNullOrEmpty(prv03) && isPrv02) {
            prv.setRefidentification(prv03);
        } else {
            LOG.debug("Loop ID->2100C Segment ID-: PRV RefDesg->PRV03 Situational Rule->Required when PRV02 is used.");
        }

        LOG.debug("Eligibility270Loop2000CWriter", "prvWriterMapper");
        return prv.writer();
    }

    public String dmgWriterMapper() {
        LOG.debug("Eligibility270Loop2000CWriter", "dmgWriterMapper");
        DmgSegment dmg = new DmgSegment();
        String dmg01 = element.getPrimaryInsuredDemographicsDateQualifier();
        if (dmg01 != null && !dmg01.trim().isEmpty()) {
            dmg.setDatetimeformatqualifier(dmg01);
        }
        String dmg02 = element.getPrimaryInsuredDemographicsDateOfBirth();
        if (dmg02 != null && !dmg02.trim().isEmpty()) {
            dmg.setDatetimeperiod(dmg02);
        }
        String dmg03 = element.getPrimaryInsuredDemographicsGenderCode();
        if (dmg03 != null && !dmg03.trim().isEmpty()) {
            dmg.setGendercode(dmg03);
        }

        LOG.debug("Eligibility270Loop2000CWriter", "dmgWriterMapper");
        return dmg.writer();
    }

    public String insWriterMapper() throws NumberFormatException {
        LOG.debug("Eligibility270Loop2000CWriter", "insWriterMapper");
        InsSegment ins = new InsSegment();

        Eligibility270JSOnScema jsonScema = new Eligibility270JSOnScema();
        Eligibility270ParserError eligibility270ParserError;

        String ins01 = element.getPrimaryInsuredIndicator();
        // String ins02=element.getPrimaryInsuredRelationshipCode();
        String ins02 = element.getRelationShipCode();
        String ins17 = element.getPrimaryInsuredBirthSequenceNumber();
        if (StringUtil.isNullOrEmpty(ins01) && StringUtil.isNullOrEmpty(ins17)) {
            return new String("");
        }

        eligibility270ParserError = new Eligibility270ParserError();
        eligibility270ParserError.setSegmentSituational(true);
        eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2100C, EligibilityTagEnum.INS, RefDesgEnum.INS01, jsonScema.getPrimaryInsuredIndicator());
        if (StringUtil.isNullOrEmpty(ins01)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0001_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else if (StringUtil.isLengthExceeds(MIN_ONE, MAX_ONE, ins01)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0002_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else {
            ins.setYesNoCondRespCode(ins01);
        }

        eligibility270ParserError = new Eligibility270ParserError();
        eligibility270ParserError.setSegmentSituational(true);
        eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2100C, EligibilityTagEnum.INS, RefDesgEnum.INS02, jsonScema.getPrimaryInsuredRelationshipCode());
        if (StringUtil.isNullOrEmpty(ins02)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0001_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else if (StringUtil.isLengthExceeds(MIN_TWO, MAX_TWO, ins02)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0002_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else {
            ins.setIndividualRelatCode(ins02);
        }

        eligibility270ParserError = new Eligibility270ParserError();
        eligibility270ParserError.setSegmentSituational(true);
        eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2100C, EligibilityTagEnum.INS, RefDesgEnum.INS17, jsonScema.getPrimaryInsuredBirthSequenceNumber());
        if (StringUtil.isNullOrEmpty(ins17)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0001_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else if (StringUtil.isLengthExceeds(MIN_ONE, MAX_NINE, ins17)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0002_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else {
            ins.setNumber(Integer.valueOf(ins17));
        }

        LOG.debug("Eligibility270Loop2000CWriter", "insWriterMapper");
        return ins.writer();
    }

    public String dtpWriterMapper() {
        LOG.debug("Eligibility270Loop2000CWriter", "dtpWriterMapper");
        DtpSegment dtp = new DtpSegment();

        Eligibility270JSOnScema jsonScema = new Eligibility270JSOnScema();
        Eligibility270ParserError eligibility270ParserError;

        String dtp01 = element.getPrimaryInsuredDateQualifier();
        String dtp02 = element.getPrimaryInsuredDateFormatQualifier();
        String dtp03 = element.getPrimaryInsuredDatePeriod();

        if (StringUtil.isNullOrEmpty(dtp01) && StringUtil.isNullOrEmpty(dtp02) && StringUtil.isNullOrEmpty(dtp03)) {
            return new String("");
        }

        eligibility270ParserError = new Eligibility270ParserError();
        eligibility270ParserError.setSegmentSituational(true);
        eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2100C, EligibilityTagEnum.DTP, RefDesgEnum.DTP01, jsonScema.getPrimaryInsuredDateQualifier());
        if (StringUtil.isNullOrEmpty(dtp01)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0001_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else if (StringUtil.isLengthExceeds(MIN_THREE, MAX_THREE, dtp01)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0002_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else {
            dtp.setDatetimequalifier(dtp01);
        }

        eligibility270ParserError = new Eligibility270ParserError();
        eligibility270ParserError.setSegmentSituational(true);
        eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2100C, EligibilityTagEnum.DTP, RefDesgEnum.DTP02, jsonScema.getPrimaryInsuredDateFormatQualifier());
        if (StringUtil.isNullOrEmpty(dtp02)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0001_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else if (StringUtil.isLengthExceeds(MIN_TWO, MAX_THREE, dtp02)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0002_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else {
            dtp.setDatetimeformatqualifier(dtp02);
        }

        eligibility270ParserError = new Eligibility270ParserError();
        eligibility270ParserError.setSegmentSituational(true);
        eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2100C, EligibilityTagEnum.DTP, RefDesgEnum.DTP03, jsonScema.getPrimaryInsuredDatePeriod());
        if (StringUtil.isNullOrEmpty(dtp03)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0001_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else if (StringUtil.isLengthExceeds(MIN_ONE, IConstants.MAX_THIRTY_FIVE, dtp03)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0002_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else {
            dtp.setDatetimeperiod(dtp03);
        }

        LOG.debug("Eligibility270Loop2000CWriter", "dtpWriterMapper");
        return dtp.writer();
    }

    public String dtpWriterMapperLoop2110C() {
        LOG.debug("Eligibility270Loop2000CWriter", "dtpWriterMapperLoop2110C");
        DtpSegment dtp = new DtpSegment();

        Eligibility270JSOnScema jsonScema = new Eligibility270JSOnScema();
        Eligibility270ParserError eligibility270ParserError;

        String dtp01 = element.getPrimaryInsuredEligibilityDateQualifier();
        String dtp02 = element.getPrimaryInsuredEligibilityDateFormatQualifier();
        String dtp03 = element.getPrimaryInsuredEligibilityDatePeriod();

        if (StringUtil.isNullOrEmpty(dtp01) && StringUtil.isNullOrEmpty(dtp02) && StringUtil.isNullOrEmpty(dtp03)) {
            return new String("");
        }

        eligibility270ParserError = new Eligibility270ParserError();
        eligibility270ParserError.setSegmentSituational(true);
        eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2100C, EligibilityTagEnum.DTP, RefDesgEnum.DTP01, jsonScema.getPrimaryInsuredEligibilityDateQualifier());
        if (StringUtil.isNullOrEmpty(dtp01)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0001_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else if (StringUtil.isLengthExceeds(MIN_THREE, MAX_THREE, dtp01)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0002_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else {
            dtp.setDatetimequalifier(dtp01);
        }

        eligibility270ParserError = new Eligibility270ParserError();
        eligibility270ParserError.setSegmentSituational(true);
        eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2110C, EligibilityTagEnum.DTP, RefDesgEnum.DTP02,
                jsonScema.getPrimaryInsuredEligibilityDateFormatQualifier());
        if (StringUtil.isNullOrEmpty(dtp02)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0001_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else if (StringUtil.isLengthExceeds(MIN_TWO, MAX_THREE, dtp02)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0002_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else {
            dtp.setDatetimeformatqualifier(dtp02);
        }

        eligibility270ParserError = new Eligibility270ParserError();
        eligibility270ParserError.setSegmentSituational(true);
        eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2110C, EligibilityTagEnum.DTP, RefDesgEnum.DTP03, jsonScema.getPrimaryInsuredEligibilityDatePeriod());
        if (StringUtil.isNullOrEmpty(dtp03)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0001_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else if (StringUtil.isLengthExceeds(MIN_ONE, IConstants.MAX_THIRTY_FIVE, dtp03)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0002_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else {
            dtp.setDatetimeperiod(dtp03);
        }

        LOG.debug("Eligibility270Loop2000CWriter", "dtpWriterMapperLoop2110C");
        return dtp.writer();
    }

    public String refMapperWrietrLoop2110C() {
        LOG.debug("Eligibility270Loop2000CWriter", "refMapperWrietrLoop2110C");
        RefSegment ref = new RefSegment();

        Eligibility270JSOnScema jsonScema = new Eligibility270JSOnScema();
        Eligibility270ParserError eligibility270ParserError;

        String ref01 = element.getPrimaryInsuredInformationIdentificationQualifier();
        String ref02 = element.getPrimaryInsuredInformationIdentification();

        if (StringUtil.isNullOrEmpty(ref01) && StringUtil.isNullOrEmpty(ref02)) {
            return new String("");
        }

        eligibility270ParserError = new Eligibility270ParserError();
        eligibility270ParserError.setSegmentSituational(true);
        eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2110C, EligibilityTagEnum.REF, RefDesgEnum.REF01,
                jsonScema.getPrimaryInsuredInformationIdentificationQualifier());
        if (StringUtil.isNullOrEmpty(ref01)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0001_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else if (StringUtil.isLengthExceeds(MIN_TWO, MAX_THREE, ref01)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0002_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else {
            ref.setRefidentificationqualifier(ref01);
        }

        eligibility270ParserError = new Eligibility270ParserError();
        eligibility270ParserError.setSegmentSituational(true);
        eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2110C, EligibilityTagEnum.REF, RefDesgEnum.REF02, jsonScema.getPrimaryInsuredInformationIdentification());
        if (StringUtil.isNullOrEmpty(ref02)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0001_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else if (StringUtil.isLengthExceeds(MIN_TWO, MAX_FIFTY, ref02)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0002_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else {
            ref.setRefidentification(ref02);
            ;
        }

        LOG.debug("Eligibility270Loop2000CWriter", "refMapperWrietrLoop2110C");
        return ref.writer();
    }

    public String iiiWriterMapperLoop2110C() {
        LOG.debug("Eligibility270Loop2000CWriter", "iiiWriterMapperLoop2110C");
        IiiSegment iii = new IiiSegment();

        Eligibility270JSOnScema jsonScema = new Eligibility270JSOnScema();
        Eligibility270ParserError eligibility270ParserError;

        String iii01 = element.getPrimaryInsuredListQualifierCode();
        String iii02 = element.getPrimaryInsuredIndustryCode();
        if (StringUtil.isNullOrEmpty(iii01) && StringUtil.isNullOrEmpty(iii01)) {
            return new String("");
        }

        eligibility270ParserError = new Eligibility270ParserError();
        eligibility270ParserError.setSegmentSituational(true);
        eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2110C, EligibilityTagEnum.III, RefDesgEnum.III01, jsonScema.getPrimaryInsuredListQualifierCode());
        if (StringUtil.isNullOrEmpty(iii01)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0001_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else if (StringUtil.isLengthExceeds(MIN_ONE, MAX_THREE, iii01)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0002_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else {
            iii.setCodeListQualCode(iii01);
        }

        eligibility270ParserError = new Eligibility270ParserError();
        eligibility270ParserError.setSegmentSituational(true);
        eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2110C, EligibilityTagEnum.III, RefDesgEnum.III02, jsonScema.getPrimaryInsuredIndustryCode());
        if (StringUtil.isNullOrEmpty(iii02)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0001_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else if (StringUtil.isLengthExceeds(MIN_ONE, MAX_THIRTY, iii02)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0002_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else {
            iii.setIndustryCode(iii02);
        }

        LOG.debug("Eligibility270Loop2000CWriter", "iiiWriterMapperLoop2110C");
        return iii.writer();
    }

    public String eqWriterMapperLoop2110C() {
        LOG.debug("Eligibility270Loop2000CWriter", "eqWriterMapperLoop2110C");
        EqSegment eq = new EqSegment();

        String eq01 = element.getPrimaryInsuredServiceTypeCode();
        if (eq01 != null && !eq01.trim().isEmpty()) {
            eq.setServiceTypeCode(eq01);
        }

        int flag = IConstants.NOT_CREATABLE;
        Compositemedicalprocedure compositemedicalprocedure = new Compositemedicalprocedure();
        String eq0201 = element.getPrimaryInsuredServiceIdentificationQualifier();
        if (eq0201 != null && !eq0201.trim().isEmpty()) {
            compositemedicalprocedure.setProductserviceidqualifier(eq0201);
            flag = IConstants.CREATABLE;
        }
        String eq0202 = element.getPrimaryInsuredProcedureCode();
        if (eq0202 != null && !eq0202.trim().isEmpty()) {
            compositemedicalprocedure.setProductserviceid1(eq0202);
            flag = IConstants.CREATABLE;
        }

        String eq0203 = element.getPrimaryInsuredProcedureMod1();
        if (eq0203 != null && !eq0203.trim().isEmpty()) {
            compositemedicalprocedure.setProceduremodifier1(eq0203);
            flag = IConstants.CREATABLE;
        }
        String eq0204 = element.getPrimaryInsuredProcedureMod2();
        if (eq0204 != null && !eq0204.trim().isEmpty()) {
            compositemedicalprocedure.setProceduremodifier2(eq0204);
            flag = IConstants.CREATABLE;
        }

        String eq0205 = element.getPrimaryInsuredProcedureMod3();
        if (eq0205 != null && !eq0205.trim().isEmpty()) {
            compositemedicalprocedure.setProceduremodifier3(eq0205);
            flag = IConstants.CREATABLE;
        }

        String eq0206 = element.getPrimaryInsuredProcedureMod4();
        if (eq0206 != null && !eq0206.trim().isEmpty()) {
            compositemedicalprocedure.setProceduremodifier4(eq0206);
            flag = IConstants.CREATABLE;
        }
        String eq0207 = element.getPrimaryInsuredDescription();
        if (eq0207 != null && !eq0207.trim().isEmpty()) {
            compositemedicalprocedure.setDescription(eq0207);
            flag = IConstants.CREATABLE;
        }
        if (flag == IConstants.CREATABLE) {
            eq.setCompMedProcId(compositemedicalprocedure);
        }

        String eq03 = element.getPrimaryInsuredInsuranceType();
        if (eq03 != null && !eq03.trim().isEmpty()) {
            eq.setCoverageLevelCode(eq03);
        }

        String eq04 = element.getPrimaryInsuredCoverageLevelCode();
        if (eq04 != null && !eq04.trim().isEmpty()) {
            eq.setInsuranceTypeCode(eq04);
        }

        LOG.debug("Eligibility270Loop2000CWriter", "eqWriterMapperLoop2110C");
        return eq.writer();
    }

    public String amtWriterMapperLoop2110C() {
        LOG.debug("Eligibility270Loop2000CWriter", "amtWriterMapperLoop2110C");
        AmtSegment amt = new AmtSegment();

        Eligibility270JSOnScema jsonScema = new Eligibility270JSOnScema();
        Eligibility270ParserError eligibility270ParserError;

        String amt01 = element.getPrimaryInsuredSpendAmountQualifierCode();
        String amt02 = element.getPrimaryInsuredSpendMonetaryAmount();

        if (StringUtil.isNullOrEmpty(amt01) && StringUtil.isNullOrEmpty(amt02)) {
            return new String("");
        }

        eligibility270ParserError = new Eligibility270ParserError();
        eligibility270ParserError.setSegmentSituational(true);
        eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2110C, EligibilityTagEnum.AMT, RefDesgEnum.AMT01, jsonScema.getPrimaryInsuredSpendAmountQualifierCode());
        if (StringUtil.isNullOrEmpty(amt01)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0001_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else if (StringUtil.isLengthExceeds(IConstants.MIN_ONE, IConstants.MAX_THREE, amt01)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0002_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else {
            amt.setAmountqualifiercode(amt01);
        }

        eligibility270ParserError = new Eligibility270ParserError();
        eligibility270ParserError.setSegmentSituational(true);
        eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2110C, EligibilityTagEnum.AMT, RefDesgEnum.AMT02, jsonScema.getPrimaryInsuredSpendMonetaryAmount());
        if (StringUtil.isNullOrEmpty(amt02)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0001_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else if (StringUtil.isLengthExceeds(IConstants.MIN_ONE, IConstants.MAX_EIGHTEEN, amt02)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0002_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else {
            amt.setMonetaryamount(amt02);
        }

        LOG.debug("Eligibility270Loop2000CWriter", "amtWriterMapperLoop2110C");
        return amt.writer();
    }

    public String loop2000C_2100C_2110C() {
        LOG.debug("Eligibility270Loop2000CWriter", "loop2000C_2100C_2110C");
        StringBuilder sb = new StringBuilder();
        String trnStr = trnMapperWriter();

        sb.append(loop2000CWriter());
        sb.append(trnStr);

        /* Loop 2100C */
        sb.append(nm1MapperWriter());
        sb.append(refMapperWrietr());
        sb.append(n3MapperWriter());
        sb.append(n4MapperWriter());
        sb.append(prvWriterMapper());
        sb.append(dmgWriterMapper());
        sb.append(insWriterMapper());
        sb.append(dtpWriterMapper());

        /* Loop 2110C */
        sb.append(eqWriterMapperLoop2110C());
        sb.append(amtWriterMapperLoop2110C());
        sb.append(iiiWriterMapperLoop2110C());
        sb.append(refMapperWrietrLoop2110C());
        sb.append(dtpWriterMapperLoop2110C());

        LOG.debug("Eligibility270Loop2000CWriter", "loop2000C_2100C_2110C");
        return sb.toString();
    }

}
