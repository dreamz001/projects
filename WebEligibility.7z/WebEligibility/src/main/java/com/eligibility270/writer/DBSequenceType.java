package com.eligibility270.writer;

/**
 * 
 * @author Manish Mishra Purpose : Enum contains constants related to database
 *         sequence name used to hold primary id for related table
 *
 */

public enum DBSequenceType {
    ISA_INTERCHANGE_CONTRON_NUMBER("eligibility.eligibility_270_Interchange_Control_Num_seq"), // ISA
    GS_GROUP_CONTROL_NUMBER("eligibility.eligibility_270_Group_Control_Number_seq"), // GS
    ST_TRANSACTION_CONTROL_NUMBER("eligibility.eligibility_270_Transaction_Set_Control_Num_seq"), // ST
    BHT_REFERENCE_IDENTIFICATION("eligibility.eligibility_270_reference_identification_seq"), // BHT
    PAYERDETAILS_ID("eligibility.payerdetails_id_seq"), // PayerDetails_id
    PROVIDERDETAILS_ID("eligibility.providerdetails_id_seq"), // ProviderDetails_id
    USER_ID("eligibility.user_userid_seq"), // User_id
    USER_SCREENMASTER_MAP_ID("eligibility.user_screenmaster_map_id_seq"), // User_sercreen_master_map_id 
    TRACERNUMBER("eligibility.eligibility_tracernumber"), // eligibility.eligibility_tracernumber
    EMDEON_REQUEST_RESPONSE("eligibility.emdeonrequestresponse_id_seq"); // emdeonrequestresponse_id_seq

    private String sequence;

    private DBSequenceType(String sequence) {
        this.sequence = sequence;
    }

    public String value() {
        return sequence;
    }
}
