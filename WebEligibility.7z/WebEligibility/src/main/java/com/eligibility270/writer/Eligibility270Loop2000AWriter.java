package com.eligibility270.writer;

import static com.eligibility270.writer.IConstants.MAX_EIGHTY;
import static com.eligibility270.writer.IConstants.MAX_THREE;
import static com.eligibility270.writer.IConstants.MIN_TWO;
import static com.eligibility270.writer.IConstants.PERSON;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.eligibility.base.dao.impl.BaseDaoImpl;
import com.eligibility.common.utility.HLUtil;
import com.eligibility.common.utility.StringUtil;
import com.eligibility.jsonschema270.beans.XsElement_;
import com.eligibility.shared.constants.EligibilityLoopEnum;
import com.eligibility.shared.constants.EligibilityTagEnum;
import com.eligibility.shared.constants.RefDesgEnum;
import com.eligibility270.parsing.error.Eligibility270JSOnScema;
import com.eligibility270.parsing.error.Eligibility270ParserError;
import com.eligibility270.parsing.error.IErrorCodeEnum;
import com.eligiblity271.beans.HlSegment;
import com.eligiblityshared.beans.Nm1Segment;

/**
 * 
 * @author manishm3
 * @date MAR 13,2014
 */
public class Eligibility270Loop2000AWriter {

    private XsElement_ element;

    private static final Logger LOG = LoggerFactory.getLogger(Eligibility270Loop2000AWriter.class);

    public Eligibility270Loop2000AWriter(XsElement_ element) {
        this.element = element;
    }

    private String loop2000AWriter() {
        HlSegment hL = new HlSegment();
        HLUtil.HL_PARENT = HLUtil.VALUE;
        hL.setHierarchicalidno(String.valueOf(HLUtil.VALUE));
        HLUtil.nextVal();
        hL.setHierarchicallevelcode(String.valueOf(HLUtil.LEVEL_ONE));
        hL.setHierarchicalchildcode(String.valueOf(HLUtil.YES_CHILD));

        return hL.writer();
    }

    public String loop2100AWriter() {
        Eligibility270JSOnScema jsonScema = new Eligibility270JSOnScema();
        Eligibility270ParserError eligibility270ParserError;

        boolean isNM104SituationalFlag = false;

        Nm1Segment nm1 = new Nm1Segment();

        /* NM-101 */
        String nm101 = element.getSourceEntityIdentifierCode();

        eligibility270ParserError = new Eligibility270ParserError();
        eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2100A, EligibilityTagEnum.NM1, RefDesgEnum.NM101, jsonScema.getSourceEntityIdentifierCode());
        if (StringUtil.isNullOrEmpty(nm101)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0001_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else if (StringUtil.isLengthExceeds(MIN_TWO, MAX_THREE, nm101)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0002_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else {
            nm1.setEntityidcode(nm101);
        }

        /* NM-102 */
        String nm102 = element.getSourceEntityTypeQualifier();

        eligibility270ParserError = new Eligibility270ParserError();
        eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2100A, EligibilityTagEnum.NM1, RefDesgEnum.NM102, jsonScema.getSourceEntityTypeQualifier());
        if (StringUtil.isNullOrEmpty(nm102)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0001_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else if (StringUtil.isLengthExceeds(IConstants.MIN_ONE, IConstants.MAX_ONE, nm102)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0002_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else {
            if (nm102.equals(PERSON)) {
                isNM104SituationalFlag = Boolean.TRUE;
            }
            nm1.setEntitytypequalifier(nm102);
        }

        /* NM-103 */
        String nm103 = element.getSourceNameLast();

        eligibility270ParserError = new Eligibility270ParserError();
        eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2100A, EligibilityTagEnum.NM1, RefDesgEnum.NM103, jsonScema.getSourceNameLast());
        if (StringUtil.isNullOrEmpty(nm103)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0001_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else if (StringUtil.isLengthExceeds(IConstants.MIN_ONE, IConstants.MAX_SIXTY, nm103)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0002_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else {
            nm1.setNamelastorgname(nm103);
        }

        /* SITUATIONAL RULE: Required when NM102 = 1 (person) */
        if (isNM104SituationalFlag) {
            /* NM-104 */
            String nm104 = element.getSourceNameFirst();
            if (!StringUtil.isNullOrEmpty(nm104)) {
                nm1.setFirstname(nm104);
            }

            /* NM-105 */
            String nm105 = element.getSourceNameMiddle();
            if (!StringUtil.isNullOrEmpty(nm105)) {
                nm1.setMiddlename(nm105);
            }
            /* NM-107 */
            String nm107 = element.getSourceNameSuffix();
            if (!StringUtil.isNullOrEmpty(nm107)) {
                nm1.setNamesuffix(nm107);
            }
        } else {
            LOG.debug("Can't send value for NM104, NM105, NM107 for LOOP- 2100A because As per situational reule NM102 is must be Person(1). ");
        }

        /* NM-108 */
        String nm108 = element.getSourceIdentificationCodeQualifier();

        eligibility270ParserError = new Eligibility270ParserError();
        eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2100A, EligibilityTagEnum.NM1, RefDesgEnum.NM108, jsonScema.getSourceIdentificationCodeQualifier());
        if (StringUtil.isNullOrEmpty(nm108)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0001_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else if (StringUtil.isLengthExceeds(IConstants.MIN_ONE, IConstants.MAX_TWO, nm108)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0002_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else {
            nm1.setIdcodequalifier(nm108);
        }

        /* NM-109 */
        String nm109 = element.getSourceIdentificationCode();

        eligibility270ParserError = new Eligibility270ParserError();
        eligibility270ParserError.setErrorDesc(EligibilityLoopEnum.LOOP2100A, EligibilityTagEnum.NM1, RefDesgEnum.NM109, jsonScema.getSourceIdentificationCode());
        if (StringUtil.isNullOrEmpty(nm109)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0001_MISSING_VAL.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0001_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else if (StringUtil.isLengthExceeds(IConstants.MIN_TWO, MAX_EIGHTY, nm109)) {
            eligibility270ParserError.setCode(IErrorCodeEnum.C0002_INVALID_LENGTH.value());
            eligibility270ParserError.setError(IErrorCodeEnum.C0002_VAL.value());
            Eligibility270Writer.parserErrors.add(eligibility270ParserError);
        } else {
            nm1.setIdcode(nm109);
        }

        return nm1.writer();
    }

    public String loopInformationSource() {
        StringBuilder sb = new StringBuilder();
        sb.append(loop2000AWriter());
        sb.append(loop2100AWriter());
        return sb.toString();
    }

}
