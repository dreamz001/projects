package com.eligibility270.parsing.error;

/**
 * It contains all JSON schema fields.
 * 
 * @author manishm3
 * @date MAR 23,2015
 */
public class Eligibility270JSOnScema {

    private final String systemErrorCode = "system_error_code";

    private final String systemErrorGenericDescription = "system_error_generic_description";

    private final String responseMessage = "response_message";

    private final String deliveryMethod = "delivery_method";

    private final String eligibilityTracerCode = "eligibility_tracer_code";

    private final String eligibilityTracerNumber = "eligibility_tracer_number";

    private final String sourceEntityIdentifierCode = "source_entity_identifier_code";

    private final String sourceEntityTypeQualifier = "source_entity_type_qualifier";

    private final String sourceNameLast = "source_name_last";

    private final String sourceNameFirst = "source_name_first";

    private final String sourceNameMiddle = "source_name_middle";

    private final String sourceNameSuffix = "source_name_suffix";

    private final String sourceIdentificationCodeQualifier = "source_identification_code_qualifier";

    private final String sourceIdentificationCode = "source_identification_code";

    private final String receiverEntityIdentifierCode = "receiver_entity_identifier_code";

    private final String receiverEntityTypeQualifier = "receiver_entity_type_qualifier";

    private final String receiverLastName = "receiver_last_name";

    private final String receiverFirstName = "receiver_first_name";

    private final String receiverMiddleName = "receiver_middle_name";

    private final String receiverSuffix = "receiver_suffix";

    private final String receiverIdentifierCodeQualifier = "receiver_identifier_code_qualifier";

    private final String receiverIdentifierCode = "receiver_identifier_code";

    private final String receiverAddressLine1 = "receiver_address_line1";

    private final String receiverAddressLine2 = "receiver_address_line2";

    private final String receiverAddressCity = "receiver_address_city";

    private final String receiverAddressState = "receiver_address_state";

    private final String receiverAddressZipCode = "receiver_address_zip_code";

    private final String receiverAddressCountry = "receiver_address_country";

    private final String receiverIdentificationQualifier = "receiver_identification_qualifier";

    private final String receiverIdentification = "receiver_identification";

    private final String receiverDescription = "receiver_description";

    private final String receiverFunctionCode = "receiver_function_code";

    private final String receiverName = "receiver_name";

    private final String receiverCommNoQualifier1 = "receiver_comm_no_qualifier1";

    private final String receiverCommNo1 = "receiver_comm_no1";

    private final String receiverCommNoQualifier2 = "receiver_comm_no_qualifier2";

    private final String receiverCommNo2 = "receiver_comm_no2";

    private final String receiverCommNoQualifier3 = "receiver_comm_no_qualifier3";

    private final String receiverCommNo3 = "receiver_comm_no3";

    private final String receiverProviderCode = "receiver_provider_code";

    private final String receiverProviderIdentificationQualifier = "receiver_provider_identification_qualifier";

    private final String receiverProviderIdentification = "receiver_provider_identification";

    private final String eligibilityEntityIdentifier = "eligibility_entity_identifier";

    private final String eligibilityEntityAdditionalIdentifier = "eligibility_entity_additional_identifier";

    private final String primaryInsuredEntityIdentifierCode = "primary_insured_entity_identifier_code";

    private final String primaryInsuredEntityTypeQualifier = "primary_insured_entity_type_qualifier";

    private final String primaryInsuredLastName = "primary_insured_last_name";

    private final String primaryInsuredFirstName = "primary_insured_first_name";

    private final String primaryInsuredMiddleInitial = "primary_insured_middle_initial";

    private final String primaryInsuredSuffix = "primary_insured_suffix";

    private final String primaryInsuredIdentifierCodeQualifier = "primary_insured_identifier_code_qualifier";

    private final String primaryInsuredIdentifierCode = "primary_insured_identifier_code";

    private final String primaryInsuredAddressLine1 = "primary_insured_address_line1";

    private final String primaryInsuredAddressLine2 = "primary_insured_address_line2";

    private final String primaryInsuredAddressCity = "primary_insured_address_city";

    private final String primaryInsuredAddressState = "primary_insured_address_state";

    private final String primaryInsuredAddressZipCode = "primary_insured_address_zip_code";

    private final String primaryInsuredAddressCountry = "primary_insured_address_country";

    private final String primaryInsuredIdentificationQualifier = "primary_insured_identification_qualifier";

    private final String primaryInsuredIdentification = "primary_insured_identification";

    private final String primaryInsuredProviderCode = "primary_insured_provider_code";

    private final String primaryInsuredProviderIdentificationQualifier = "primary_insured_provider_identification_qualifier";

    private final String primaryInsuredProviderIdentification = "primary_insured_provider_identification";

    private final String primaryInsuredDemographicsDateQualifier = "primary_insured_demographics_date_qualifier";

    private final String primaryInsuredDemographicsDateOfBirth = "primary_insured_demographics_date_of_birth";

    private final String primaryInsuredDemographicsGenderCode = "primary_insured_demographics_gender_code";

    private final String primaryInsuredIndicator = "primary_insured_indicator";

    private final String primaryInsuredRelationshipCode = "primary_insured_relationship_code";

    private final String primaryInsuredBirthSequenceNumber = "primary_insured_birth_sequence_number";

    private final String primaryInsuredDateQualifier = "primary_insured_date_qualifier";

    private final String primaryInsuredDateFormatQualifier = "primary_insured_date_format_qualifier";

    private final String primaryInsuredDatePeriod = "primary_insured_date_period";

    private final String primaryInsuredServiceTypeCode = "primary_insured_service_type_code";

    private final String primaryInsuredServiceIdentificationQualifier = "primary_insured_service_identification_qualifier";

    private final String primaryInsuredProcedureCode = "primary_insured_procedure_code";

    private final String primaryInsuredProcedureMod1 = "primary_insured_procedure_mod1";

    private final String primaryInsuredProcedureMod2 = "primary_insured_procedure_mod2";

    private final String primaryInsuredProcedureMod3 = "primary_insured_procedure_mod3";

    private final String primaryInsuredProcedureMod4 = "primary_insured_procedure_mod4";

    private final String primaryInsuredDescription = "primary_insured_description";

    private final String primaryInsuredInsuranceType = "primary_insured_insurance_type";

    private final String primaryInsuredCoverageLevelCode = "primary_insured_coverage_level_code";

    private final String primaryInsuredSpendAmountQualifierCode = "primary_insured_spend_amount_qualifier_code";

    private final String primaryInsuredSpendMonetaryAmount = "primary_insured_spend_monetary_amount";

    private final String primaryInsuredListQualifierCode = "primary_insured_list_qualifier_code";

    private final String primaryInsuredIndustryCode = "primary_insured_industry_code";

    private final String primaryInsuredInformationIdentificationQualifier = "primary_insured_information_identification_qualifier";

    private final String primaryInsuredInformationIdentification = "primary_insured_information_identification";

    private final String primaryInsuredEligibilityDateQualifier = "primary_insured_eligibility_date_qualifier";

    private final String primaryInsuredEligibilityDateFormatQualifier = "primary_insured_eligibility_date_format_qualifier";

    private final String primaryInsuredEligibilityDatePeriod = "primary_insured_eligibility_date_period";

    private String dependentEntityIdentifierCode = "dependent_entity_identifier_code";

    private final String dependentEntityTypeQualifier = "dependent_entity_type_qualifier";

    private final String dependentLastName = "dependent_last_name";

    private final String dependentFirstName = "dependent_first_name";

    private final String dependentMiddleInitial = "dependent_middle_initial";

    private final String dependentSuffix = "dependent_suffix";

    private final String dependentAddressLine1 = "dependent_address_line1";

    private final String dependentAddressLine2 = "dependent_address_line2";

    private final String dependentAddressCity = "dependent_address_city";

    private final String dependentAddressState = "dependent_address_state";

    private final String dependentAddressZipCode = "dependent_address_zip_code";

    private final String dependentAddressCountry = "dependent_address_country";

    private final String dependentIdentificationQualifier = "dependent_identification_qualifier";

    private final String dependentIdentification = "dependent_identification";

    private final String dependentProviderCode = "dependent_provider_code";

    private final String dependentProviderIdentificationQualifier = "dependent_provider_identification_qualifier";

    private final String dependentProviderIdentification = "dependent_provider_identification";

    private final String dependentDemographicsDateQualifier = "dependent_demographics_date_qualifier";

    private final String dependentDemographicsDateOfBirth = "dependent_demographics_date_of_birth";

    private final String dependentDemographicsGenderCode = "dependent_demographics_gender_code";

    private final String dependentInsuredIndicator = "dependent_insured_indicator";

    private final String dependentIndividualRelationshipCode = "dependent_individual_relationship_code";

    private final String dependentBirthSequenceNumber = "dependent_birth_sequence_number";

    private final String dependentDateQualifier = "dependent_date_qualifier";

    private final String dependentDateFormatQualifier = "dependent_date_format_qualifier";

    private final String dependentDatePeriod = "dependent_date_period";

    private final String dependentServiceTypeCode = "dependent_service_type_code";

    private final String dependentServiceIdentificationQualifier = "dependent_service_identification_qualifier";

    private final String dependentProcedureCode = "dependent_procedure_code";

    private final String dependentProcedureMod1 = "dependent_procedure_mod1";

    private final String dependentProcedureMod2 = "dependent_procedure_mod2";

    private final String dependentProcedureMod3 = "dependent_procedure_mod3";

    private final String dependentProcedureMod4 = "dependent_procedure_mod4";

    private final String dependentDescription = "dependent_description";

    private final String dependentInsuranceType = "dependent_insurance_type";

    private final String dependentCoverageLevelCode = "dependent_coverage_level_code";

    private final String dependentListQualifierCode = "dependent_list_qualifier_code";

    private final String dependentIndustryCode = "dependent_industry_code";

    private final String dependentInformationIdentificationQualifier = "dependent_information_identification_qualifier";

    private final String dependentInformationIdentification = "dependent_information_identification";

    private final String dependentEligibilityDateQualifier = "dependent_eligibility_date_qualifier";

    private final String dependentEligibilityDateFormatQualifier = "dependent_eligibility_date_format_qualifier";

    private final String dependentEligibilityDatePeriod = "dependent_eligibility_date_period";

    public String getSystemErrorCode() {
        return systemErrorCode;
    }

    public String getSystemErrorGenericDescription() {
        return systemErrorGenericDescription;
    }

    public String getResponseMessage() {
        return responseMessage;
    }

    public String getDeliveryMethod() {
        return deliveryMethod;
    }

    public String getEligibilityTracerCode() {
        return eligibilityTracerCode;
    }

    public String getEligibilityTracerNumber() {
        return eligibilityTracerNumber;
    }

    public String getSourceEntityIdentifierCode() {
        return sourceEntityIdentifierCode;
    }

    public String getSourceEntityTypeQualifier() {
        return sourceEntityTypeQualifier;
    }

    public String getSourceNameLast() {
        return sourceNameLast;
    }

    public String getSourceNameFirst() {
        return sourceNameFirst;
    }

    public String getSourceNameMiddle() {
        return sourceNameMiddle;
    }

    public String getSourceNameSuffix() {
        return sourceNameSuffix;
    }

    public String getSourceIdentificationCodeQualifier() {
        return sourceIdentificationCodeQualifier;
    }

    public String getSourceIdentificationCode() {
        return sourceIdentificationCode;
    }

    public String getReceiverEntityIdentifierCode() {
        return receiverEntityIdentifierCode;
    }

    public String getReceiverEntityTypeQualifier() {
        return receiverEntityTypeQualifier;
    }

    public String getReceiverLastName() {
        return receiverLastName;
    }

    public String getReceiverFirstName() {
        return receiverFirstName;
    }

    public String getReceiverMiddleName() {
        return receiverMiddleName;
    }

    public String getReceiverSuffix() {
        return receiverSuffix;
    }

    public String getReceiverIdentifierCodeQualifier() {
        return receiverIdentifierCodeQualifier;
    }

    public String getReceiverIdentifierCode() {
        return receiverIdentifierCode;
    }

    public String getReceiverAddressLine1() {
        return receiverAddressLine1;
    }

    public String getReceiverAddressLine2() {
        return receiverAddressLine2;
    }

    public String getReceiverAddressCity() {
        return receiverAddressCity;
    }

    public String getReceiverAddressState() {
        return receiverAddressState;
    }

    public String getReceiverAddressZipCode() {
        return receiverAddressZipCode;
    }

    public String getReceiverAddressCountry() {
        return receiverAddressCountry;
    }

    public String getReceiverIdentificationQualifier() {
        return receiverIdentificationQualifier;
    }

    public String getReceiverIdentification() {
        return receiverIdentification;
    }

    public String getReceiverDescription() {
        return receiverDescription;
    }

    public String getReceiverFunctionCode() {
        return receiverFunctionCode;
    }

    public String getReceiverName() {
        return receiverName;
    }

    public String getReceiverCommNoQualifier1() {
        return receiverCommNoQualifier1;
    }

    public String getReceiverCommNo1() {
        return receiverCommNo1;
    }

    public String getReceiverCommNoQualifier2() {
        return receiverCommNoQualifier2;
    }

    public String getReceiverCommNo2() {
        return receiverCommNo2;
    }

    public String getReceiverCommNoQualifier3() {
        return receiverCommNoQualifier3;
    }

    public String getReceiverCommNo3() {
        return receiverCommNo3;
    }

    public String getReceiverProviderCode() {
        return receiverProviderCode;
    }

    public String getReceiverProviderIdentificationQualifier() {
        return receiverProviderIdentificationQualifier;
    }

    public String getReceiverProviderIdentification() {
        return receiverProviderIdentification;
    }

    public String getEligibilityEntityIdentifier() {
        return eligibilityEntityIdentifier;
    }

    public String getEligibilityEntityAdditionalIdentifier() {
        return eligibilityEntityAdditionalIdentifier;
    }

    public String getPrimaryInsuredEntityIdentifierCode() {
        return primaryInsuredEntityIdentifierCode;
    }

    public String getPrimaryInsuredEntityTypeQualifier() {
        return primaryInsuredEntityTypeQualifier;
    }

    public String getPrimaryInsuredLastName() {
        return primaryInsuredLastName;
    }

    public String getPrimaryInsuredFirstName() {
        return primaryInsuredFirstName;
    }

    public String getPrimaryInsuredMiddleInitial() {
        return primaryInsuredMiddleInitial;
    }

    public String getPrimaryInsuredSuffix() {
        return primaryInsuredSuffix;
    }

    public String getPrimaryInsuredIdentifierCodeQualifier() {
        return primaryInsuredIdentifierCodeQualifier;
    }

    public String getPrimaryInsuredIdentifierCode() {
        return primaryInsuredIdentifierCode;
    }

    public String getPrimaryInsuredAddressLine1() {
        return primaryInsuredAddressLine1;
    }

    public String getPrimaryInsuredAddressLine2() {
        return primaryInsuredAddressLine2;
    }

    public String getPrimaryInsuredAddressCity() {
        return primaryInsuredAddressCity;
    }

    public String getPrimaryInsuredAddressState() {
        return primaryInsuredAddressState;
    }

    public String getPrimaryInsuredAddressZipCode() {
        return primaryInsuredAddressZipCode;
    }

    public String getPrimaryInsuredAddressCountry() {
        return primaryInsuredAddressCountry;
    }

    public String getPrimaryInsuredIdentificationQualifier() {
        return primaryInsuredIdentificationQualifier;
    }

    public String getPrimaryInsuredIdentification() {
        return primaryInsuredIdentification;
    }

    public String getPrimaryInsuredProviderCode() {
        return primaryInsuredProviderCode;
    }

    public String getPrimaryInsuredProviderIdentificationQualifier() {
        return primaryInsuredProviderIdentificationQualifier;
    }

    public String getPrimaryInsuredProviderIdentification() {
        return primaryInsuredProviderIdentification;
    }

    public String getPrimaryInsuredDemographicsDateQualifier() {
        return primaryInsuredDemographicsDateQualifier;
    }

    public String getPrimaryInsuredDemographicsDateOfBirth() {
        return primaryInsuredDemographicsDateOfBirth;
    }

    public String getPrimaryInsuredDemographicsGenderCode() {
        return primaryInsuredDemographicsGenderCode;
    }

    public String getPrimaryInsuredIndicator() {
        return primaryInsuredIndicator;
    }

    public String getPrimaryInsuredRelationshipCode() {
        return primaryInsuredRelationshipCode;
    }

    public String getPrimaryInsuredBirthSequenceNumber() {
        return primaryInsuredBirthSequenceNumber;
    }

    public String getPrimaryInsuredDateQualifier() {
        return primaryInsuredDateQualifier;
    }

    public String getPrimaryInsuredDateFormatQualifier() {
        return primaryInsuredDateFormatQualifier;
    }

    public String getPrimaryInsuredDatePeriod() {
        return primaryInsuredDatePeriod;
    }

    public String getPrimaryInsuredServiceTypeCode() {
        return primaryInsuredServiceTypeCode;
    }

    public String getPrimaryInsuredServiceIdentificationQualifier() {
        return primaryInsuredServiceIdentificationQualifier;
    }

    public String getPrimaryInsuredProcedureCode() {
        return primaryInsuredProcedureCode;
    }

    public String getPrimaryInsuredProcedureMod1() {
        return primaryInsuredProcedureMod1;
    }

    public String getPrimaryInsuredProcedureMod2() {
        return primaryInsuredProcedureMod2;
    }

    public String getPrimaryInsuredProcedureMod3() {
        return primaryInsuredProcedureMod3;
    }

    public String getPrimaryInsuredProcedureMod4() {
        return primaryInsuredProcedureMod4;
    }

    public String getPrimaryInsuredDescription() {
        return primaryInsuredDescription;
    }

    public String getPrimaryInsuredInsuranceType() {
        return primaryInsuredInsuranceType;
    }

    public String getPrimaryInsuredCoverageLevelCode() {
        return primaryInsuredCoverageLevelCode;
    }

    public String getPrimaryInsuredSpendAmountQualifierCode() {
        return primaryInsuredSpendAmountQualifierCode;
    }

    public String getPrimaryInsuredSpendMonetaryAmount() {
        return primaryInsuredSpendMonetaryAmount;
    }

    public String getPrimaryInsuredListQualifierCode() {
        return primaryInsuredListQualifierCode;
    }

    public String getPrimaryInsuredIndustryCode() {
        return primaryInsuredIndustryCode;
    }

    public String getPrimaryInsuredInformationIdentificationQualifier() {
        return primaryInsuredInformationIdentificationQualifier;
    }

    public String getPrimaryInsuredInformationIdentification() {
        return primaryInsuredInformationIdentification;
    }

    public String getPrimaryInsuredEligibilityDateQualifier() {
        return primaryInsuredEligibilityDateQualifier;
    }

    public String getPrimaryInsuredEligibilityDateFormatQualifier() {
        return primaryInsuredEligibilityDateFormatQualifier;
    }

    public String getPrimaryInsuredEligibilityDatePeriod() {
        return primaryInsuredEligibilityDatePeriod;
    }

    public String getDependentEntityIdentifierCode() {
        return dependentEntityIdentifierCode;
    }

    public String getDependentEntityTypeQualifier() {
        return dependentEntityTypeQualifier;
    }

    public String getDependentLastName() {
        return dependentLastName;
    }

    public String getDependentFirstName() {
        return dependentFirstName;
    }

    public String getDependentMiddleInitial() {
        return dependentMiddleInitial;
    }

    public String getDependentSuffix() {
        return dependentSuffix;
    }

    public String getDependentAddressLine1() {
        return dependentAddressLine1;
    }

    public String getDependentAddressLine2() {
        return dependentAddressLine2;
    }

    public String getDependentAddressCity() {
        return dependentAddressCity;
    }

    public String getDependentAddressState() {
        return dependentAddressState;
    }

    public String getDependentAddressZipCode() {
        return dependentAddressZipCode;
    }

    public String getDependentAddressCountry() {
        return dependentAddressCountry;
    }

    public String getDependentIdentificationQualifier() {
        return dependentIdentificationQualifier;
    }

    public String getDependentIdentification() {
        return dependentIdentification;
    }

    public String getDependentProviderCode() {
        return dependentProviderCode;
    }

    public String getDependentProviderIdentificationQualifier() {
        return dependentProviderIdentificationQualifier;
    }

    public String getDependentProviderIdentification() {
        return dependentProviderIdentification;
    }

    public String getDependentDemographicsDateQualifier() {
        return dependentDemographicsDateQualifier;
    }

    public String getDependentDemographicsDateOfBirth() {
        return dependentDemographicsDateOfBirth;
    }

    public String getDependentDemographicsGenderCode() {
        return dependentDemographicsGenderCode;
    }

    public String getDependentInsuredIndicator() {
        return dependentInsuredIndicator;
    }

    public String getDependentIndividualRelationshipCode() {
        return dependentIndividualRelationshipCode;
    }

    public String getDependentBirthSequenceNumber() {
        return dependentBirthSequenceNumber;
    }

    public String getDependentDateQualifier() {
        return dependentDateQualifier;
    }

    public String getDependentDateFormatQualifier() {
        return dependentDateFormatQualifier;
    }

    public String getDependentDatePeriod() {
        return dependentDatePeriod;
    }

    public String getDependentServiceTypeCode() {
        return dependentServiceTypeCode;
    }

    public String getDependentServiceIdentificationQualifier() {
        return dependentServiceIdentificationQualifier;
    }

    public String getDependentProcedureCode() {
        return dependentProcedureCode;
    }

    public String getDependentProcedureMod1() {
        return dependentProcedureMod1;
    }

    public String getDependentProcedureMod2() {
        return dependentProcedureMod2;
    }

    public String getDependentProcedureMod3() {
        return dependentProcedureMod3;
    }

    public String getDependentProcedureMod4() {
        return dependentProcedureMod4;
    }

    public String getDependentDescription() {
        return dependentDescription;
    }

    public String getDependentInsuranceType() {
        return dependentInsuranceType;
    }

    public String getDependentCoverageLevelCode() {
        return dependentCoverageLevelCode;
    }

    public String getDependentListQualifierCode() {
        return dependentListQualifierCode;
    }

    public String getDependentIndustryCode() {
        return dependentIndustryCode;
    }

    public String getDependentInformationIdentificationQualifier() {
        return dependentInformationIdentificationQualifier;
    }

    public String getDependentInformationIdentification() {
        return dependentInformationIdentification;
    }

    public String getDependentEligibilityDateQualifier() {
        return dependentEligibilityDateQualifier;
    }

    public String getDependentEligibilityDateFormatQualifier() {
        return dependentEligibilityDateFormatQualifier;
    }

    public String getDependentEligibilityDatePeriod() {
        return dependentEligibilityDatePeriod;
    }
}
