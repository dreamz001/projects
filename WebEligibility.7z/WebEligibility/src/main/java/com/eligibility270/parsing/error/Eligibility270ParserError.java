package com.eligibility270.parsing.error;

import static com.eligibility270.writer.IConstants.ERROR_SEPRATOR;

import com.eligibility.shared.constants.EligibilityLoopEnum;
import com.eligibility.shared.constants.EligibilityTagEnum;
import com.eligibility.shared.constants.RefDesgEnum;

/**
 * It is for record error which is checked during parsing JSON 270 eligbility.
 * 
 * @author manishm3
 * @date MAR 20,2015
 *
 */
public class Eligibility270ParserError {
    private String code;
    private String error;
    private String description;
    private boolean isRequiredField;
    private boolean isSegmentSituational;
    private String segmentName;
    private String refdesg;
    private String loopId;

    public Eligibility270ParserError(String code, String error) {
        super();
        this.code = code;
        this.error = error;
    }

    public Eligibility270ParserError() {

    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public boolean isRequiredField() {
        return isRequiredField;
    }

    public void setRequiredField(boolean isRequiredField) {
        this.isRequiredField = isRequiredField;
    }

    @Override
    public String toString() {
        return "Eligibility270ParserError [code=" + code + ", error=" + error + ", description=" + description + ", isRequiredField=" + isRequiredField + "]";
    }

    public void setErrorDesc(EligibilityLoopEnum loopid, EligibilityTagEnum tag, RefDesgEnum refdesg, String jsonSchema) {
        setRequiredField(Boolean.TRUE);
        setRefdesg(refdesg.value());
        setSegmentName(tag.value());
        setLoopId(loopid.value());
        StringBuilder descError = new StringBuilder();
        descError.append(loopid.value());
        descError.append(ERROR_SEPRATOR);
        descError.append(tag.value());
        descError.append(ERROR_SEPRATOR);
        descError.append(refdesg.value());
        descError.append(ERROR_SEPRATOR);
        descError.append(jsonSchema);
        setDescription(descError.toString());
    }

    public boolean isSegmentSituational() {
        return isSegmentSituational;
    }

    public void setSegmentSituational(boolean isSegmentSituational) {
        this.isSegmentSituational = isSegmentSituational;
    }

    public String getSegmentName() {
        return segmentName;
    }

    public void setSegmentName(String segmentName) {
        this.segmentName = segmentName;
    }

    public String getRefdesg() {
        return refdesg;
    }

    public void setRefdesg(String refdesg) {
        this.refdesg = refdesg;
    }

    public String getLoopId() {
        return loopId;
    }

    public void setLoopId(String loopId) {
        this.loopId = loopId;
    }

}
