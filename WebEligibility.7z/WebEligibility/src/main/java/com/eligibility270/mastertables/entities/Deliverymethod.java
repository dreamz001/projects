package com.eligibility270.mastertables.entities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * @author manishm3
 * 
 *         The persistent class for the edi_837_deliverymethod database table.
 * 
 */
@Entity
@Table(name = "eligibility.eligibility_270_deliverymethod")
@NamedQuery(name = "Deliverymethod.findAll", query = "SELECT d FROM Deliverymethod d")
public class Deliverymethod implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    private Integer id;

    private String deliverymethod;

    private String description;

    private String receiverid;

    private String senderid;

    private Boolean status;

    private String username;

    private String password;

    private Boolean dxperiodallowed;

    private Boolean useleadingzero;

    private String ruleversion;

    private String processingmode;

    private String payloadtype;
    
    private Boolean isonproduction;

    public Deliverymethod() {
    }

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDeliverymethod() {
        return this.deliverymethod;
    }

    public void setDeliverymethod(String deliverymethod) {
        this.deliverymethod = deliverymethod;
    }

    public String getDescription() {
        return this.description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getReceiverid() {
        return this.receiverid;
    }

    public void setReceiverid(String receiverid) {
        this.receiverid = receiverid;
    }

    public String getSenderid() {
        return this.senderid;
    }

    public void setSenderid(String senderid) {
        this.senderid = senderid;
    }

    public Boolean getStatus() {
        return this.status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }

    public String getUsername() {
        return username.trim();
    }

    public void setUsername(String username) {
        this.username = username.trim();
    }

    public String getPassword() {
        return password.trim();
    }

    public void setPassword(String password) {
        this.password = password.trim();
    }

    public Boolean getDxperiodallowed() {
        return dxperiodallowed;
    }

    public void setDxperiodallowed(Boolean dxperiodallowed) {
        this.dxperiodallowed = dxperiodallowed;
    }

    public Boolean getUseleadingzero() {
        return useleadingzero;
    }

    public void setUseleadingzero(Boolean useleadingzero) {
        this.useleadingzero = useleadingzero;
    }

    public String getRuleversion() {
        return ruleversion;
    }

    public void setRuleversion(String ruleversion) {
        this.ruleversion = ruleversion;
    }

    public String getProcessingmode() {
        return processingmode;
    }

    public void setProcessingmode(String processingmode) {
        this.processingmode = processingmode;
    }

    public String getPayloadtype() {
        return payloadtype;
    }

    public void setPayloadtype(String payloadtype) {
        this.payloadtype = payloadtype;
    }

    public Boolean getIsonproduction() {
        return isonproduction;
    }

    public void setIsonproduction(Boolean isonproduction) {
        this.isonproduction = isonproduction;
    }

    
}