package com.eligibility270.mastertables.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * @author manishm3
 * 
 *         The persistent class for the "edi_837_ISA" database table.
 * 
 */
@Entity
@Table(name = "eligibility.eligibility_270_isa")
@NamedQuery(name = "ISAEntity.findAll", query = "SELECT i FROM ISAEntity i")
public class ISAEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    public Integer getIsaid() {
        return isaid;
    }

    public void setIsaid(Integer isaid) {
        this.isaid = isaid;
    }

    @Id
    private Integer isaid;

    private String ackrequiredornot;

    @Column(name = "auth_info")
    private String authInfo;

    @Column(name = "auth_info_qualifier")
    private String authInfoQualifier;

    private String compelementseprator;

    @Column(name = "ic_receiver_id_qualifier")
    private String icReceiverIdQualifier;

    private String iccontrolversionnum;

    @Column(name = "interchange_id_qualifier")
    private String interchangeIdQualifier;

    @Column(name = "interchange_receiverid")
    private String interchangeReceiverid;

    @Column(name = "interchange_senderid")
    private String interchangeSenderid;

    private String repetitionseprator;

    @Column(name = "security_info")
    private String securityInfo;

    @Column(name = "security_info_qualifier")
    private String securityInfoQualifier;

    private String usageindicator;

    public ISAEntity() {
    }

    public String getAckrequiredornot() {
        return this.ackrequiredornot;
    }

    public void setAckrequiredornot(String ackrequiredornot) {
        this.ackrequiredornot = ackrequiredornot;
    }

    public String getAuthInfo() {
        return this.authInfo;
    }

    public void setAuthInfo(String authInfo) {
        this.authInfo = authInfo;
    }

    public String getAuthInfoQualifier() {
        return this.authInfoQualifier;
    }

    public void setAuthInfoQualifier(String authInfoQualifier) {
        this.authInfoQualifier = authInfoQualifier;
    }

    public String getCompelementseprator() {
        return this.compelementseprator;
    }

    public void setCompelementseprator(String compelementseprator) {
        this.compelementseprator = compelementseprator;
    }

    public String getIcReceiverIdQualifier() {
        return this.icReceiverIdQualifier;
    }

    public void setIcReceiverIdQualifier(String icReceiverIdQualifier) {
        this.icReceiverIdQualifier = icReceiverIdQualifier;
    }

    public String getIccontrolversionnum() {
        return this.iccontrolversionnum;
    }

    public void setIccontrolversionnum(String iccontrolversionnum) {
        this.iccontrolversionnum = iccontrolversionnum;
    }

    public String getInterchangeIdQualifier() {
        return this.interchangeIdQualifier;
    }

    public void setInterchangeIdQualifier(String interchangeIdQualifier) {
        this.interchangeIdQualifier = interchangeIdQualifier;
    }

    public String getInterchangeReceiverid() {
        return this.interchangeReceiverid;
    }

    public void setInterchangeReceiverid(String interchangeReceiverid) {
        this.interchangeReceiverid = interchangeReceiverid;
    }

    public String getInterchangeSenderid() {
        return this.interchangeSenderid;
    }

    public void setInterchangeSenderid(String interchangeSenderid) {
        this.interchangeSenderid = interchangeSenderid;
    }

    public String getRepetitionseprator() {
        return this.repetitionseprator;
    }

    public void setRepetitionseprator(String repetitionseprator) {
        this.repetitionseprator = repetitionseprator;
    }

    public String getSecurityInfo() {
        return this.securityInfo;
    }

    public void setSecurityInfo(String securityInfo) {
        this.securityInfo = securityInfo;
    }

    public String getSecurityInfoQualifier() {
        return this.securityInfoQualifier;
    }

    public void setSecurityInfoQualifier(String securityInfoQualifier) {
        this.securityInfoQualifier = securityInfoQualifier;
    }

    public String getUsageindicator() {
        return this.usageindicator;
    }

    public void setUsageindicator(String usageindicator) {
        this.usageindicator = usageindicator;
    }

    @Override
    public String toString() {
        return "ISAEntity [isaid=" + isaid + ", ackrequiredornot=" + ackrequiredornot + ", authInfo=" + authInfo + ", authInfoQualifier=" + authInfoQualifier
                + ", compelementseprator=" + compelementseprator + ", icReceiverIdQualifier=" + icReceiverIdQualifier + ", iccontrolversionnum=" + iccontrolversionnum
                + ", interchangeIdQualifier=" + interchangeIdQualifier + ", interchangeReceiverid=" + interchangeReceiverid + ", interchangeSenderid=" + interchangeSenderid
                + ", repetitionseprator=" + repetitionseprator + ", securityInfo=" + securityInfo + ", securityInfoQualifier=" + securityInfoQualifier + ", usageindicator="
                + usageindicator + "]";
    }

}