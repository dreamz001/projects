package com.eligibility270.dbentities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * The persistent class for the payerdetails database table.
 * 
 * @author Rajinder Singh
 */
@Entity
@Table(name = "eligibility.payerdetails")
public class PayerDetails implements Serializable {

    private static final long serialVersionUID = 9076089485326433185L;
    @Id
    private Integer id;
    private String sourcename;
    private String sourceidentificationcodequalifier;
    private String sourceidentificationcode;
    private String sourceentityidentifiercode;
    private String sourceentitytypequalifier;

    @Transient
    private String newpayerid;
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSourcename() {
        return sourcename.trim();
    }

    public void setSourcename(String sourcename) {
        this.sourcename = sourcename.trim();
    }

    public String getSourceidentificationcodequalifier() {
        return sourceidentificationcodequalifier;
    }

    public void setSourceidentificationcodequalifier(String sourceidentificationcodequalifier) {
        this.sourceidentificationcodequalifier = sourceidentificationcodequalifier.trim();
    }

    public String getSourceidentificationcode() {
        return sourceidentificationcode;
    }

    public void setSourceidentificationcode(String sourceidentificationcode) {
        this.sourceidentificationcode = sourceidentificationcode;
    }

    public String getSourceentityidentifiercode() {
        return sourceentityidentifiercode;
    }

    public void setSourceentityidentifiercode(String sourceentityidentifiercode) {
        this.sourceentityidentifiercode = sourceentityidentifiercode;
    }

    public String getSourceentitytypequalifier() {
        return sourceentitytypequalifier;
    }

    public void setSourceentitytypequalifier(String sourceentitytypequalifier) {
        this.sourceentitytypequalifier = sourceentitytypequalifier;
    }

    
    public String getNewpayerid() {
        return newpayerid.trim();
    }

    public void setNewpayerid(String newpayerid) {
        this.newpayerid = newpayerid;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((sourceidentificationcode == null) ? 0 : sourceidentificationcode.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        PayerDetails other = (PayerDetails) obj;
        if (sourceidentificationcode == null) {
            if (other.sourceidentificationcode != null)
                return false;
        } else if (!sourceidentificationcode.equals(other.sourceidentificationcode))
            return false;
        return true;
    }

}
