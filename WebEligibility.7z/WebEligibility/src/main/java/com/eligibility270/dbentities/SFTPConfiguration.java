package com.eligibility270.dbentities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The persistent class for the eligibility.eligibility_clientsftp database
 * table.
 * 
 */
@Entity
@Table(name = "eligibility.eligibility_clientsftp")
@NamedQuery(name = "SFTPConfiguration.findAll", query = "SELECT s FROM SFTPConfiguration s")
public class SFTPConfiguration implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    private Integer configid;

    private String hostaddress;

    private String password;

    private Integer portaddress;

    private String sftpuser;

    private boolean isenable;

    private String requestdirectory;

    private String responsedirectory;

    public SFTPConfiguration() {
    }

    public Integer getConfigid() {
        return this.configid;
    }

    public void setConfigid(Integer configid) {
        this.configid = configid;
    }

    public String getRequestdirectory() {
        return requestdirectory;
    }

    public void setRequestdirectory(String requestdirectory) {
        this.requestdirectory = requestdirectory;
    }

    public String getResponsedirectory() {
        return responsedirectory;
    }

    public void setResponsedirectory(String responsedirectory) {
        this.responsedirectory = responsedirectory;
    }

    public String getHostaddress() {
        return this.hostaddress;
    }

    public void setHostaddress(String hostaddress) {
        this.hostaddress = hostaddress;
    }

    public String getPassword() {
        return this.password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Integer getPortaddress() {
        return this.portaddress;
    }

    public void setPortaddress(Integer portaddress) {
        this.portaddress = portaddress;
    }

    public String getSftpuser() {
        return this.sftpuser;
    }

    public void setSftpuser(String sftpuser) {
        this.sftpuser = sftpuser;
    }

    public boolean isIsenable() {
        return isenable;
    }

    public void setIsenable(boolean isenable) {
        this.isenable = isenable;
    }

}