package com.eligibility270.dbentities;

import java.io.Serializable;

import javax.persistence.*;

import java.sql.Timestamp;
import java.util.List;

/**
 * The persistent class for the eligibilitysummary database table.
 * 
 * @author manishm3
 */
@Entity
@Table(name = "eligibility.eligibilitysummary")
@NamedQuery(name = "Eligibilitysummary.findAll", query = "SELECT e FROM Eligibilitysummary e")
public class Eligibilitysummary implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String eligibilitybegindate;

    private Timestamp eligibilityrequestdate;

    private Timestamp eligibilityrequestdateofservice;

    private String eligibilitystatus;

    private String policydescription;

    private String policytype;

    // bi-directional many-to-one association to Edi271longdesc
    @OneToMany(mappedBy = "eligibilitysummary")
    private List<Edi271longdesc> edi271longdescs;

    public Eligibilitysummary() {
    }

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getEligibilitybegindate() {
        return this.eligibilitybegindate;
    }

    public void setEligibilitybegindate(String eligibilitybegindate) {
        this.eligibilitybegindate = eligibilitybegindate;
    }

    public Timestamp getEligibilityrequestdate() {
        return this.eligibilityrequestdate;
    }

    public void setEligibilityrequestdate(Timestamp eligibilityrequestdate) {
        this.eligibilityrequestdate = eligibilityrequestdate;
    }

    public Timestamp getEligibilityrequestdateofservice() {
        return this.eligibilityrequestdateofservice;
    }

    public void setEligibilityrequestdateofservice(Timestamp eligibilityrequestdateofservice) {
        this.eligibilityrequestdateofservice = eligibilityrequestdateofservice;
    }

    public String getEligibilitystatus() {
        return this.eligibilitystatus;
    }

    public void setEligibilitystatus(String eligibilitystatus) {
        this.eligibilitystatus = eligibilitystatus;
    }

    public String getPolicydescription() {
        return this.policydescription;
    }

    public void setPolicydescription(String policydescription) {
        this.policydescription = policydescription;
    }

    public String getPolicytype() {
        return this.policytype;
    }

    public void setPolicytype(String policytype) {
        this.policytype = policytype;
    }

    public List<Edi271longdesc> getEdi271longdescs() {
        return this.edi271longdescs;
    }

    public void setEdi271longdescs(List<Edi271longdesc> edi271longdescs) {
        this.edi271longdescs = edi271longdescs;
    }

    public Edi271longdesc addEdi271longdesc(Edi271longdesc edi271longdesc) {
        getEdi271longdescs().add(edi271longdesc);
        edi271longdesc.setEligibilitysummary(this);

        return edi271longdesc;
    }

    public Edi271longdesc removeEdi271longdesc(Edi271longdesc edi271longdesc) {
        getEdi271longdescs().remove(edi271longdesc);
        edi271longdesc.setEligibilitysummary(null);

        return edi271longdesc;
    }

}