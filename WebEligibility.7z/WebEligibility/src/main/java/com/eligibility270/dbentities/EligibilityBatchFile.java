package com.eligibility270.dbentities;

import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "eligibility.eligibility_batch_file")
public class EligibilityBatchFile {
    @Id
    private Integer id;
    private String inputfilename;
    private Timestamp createdon;
    private String outputfilename;
    private Timestamp uploadedon;
    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }
    public String getInputfilename() {
        return inputfilename;
    }
    public void setInputfilename(String inputfilename) {
        this.inputfilename = inputfilename;
    }
    public Timestamp getCreatedon() {
        return createdon;
    }
    public void setCreatedon(Timestamp createdon) {
        this.createdon = createdon;
    }
    public String getOutputfilename() {
        return outputfilename;
    }
    public void setOutputfilename(String outputfilename) {
        this.outputfilename = outputfilename;
    }
    public Timestamp getUploadedon() {
        return uploadedon;
    }
    public void setUploadedon(Timestamp uploadedon) {
        this.uploadedon = uploadedon;
    }
   

    
}
