package com.eligibility270.dbentities;

import java.io.Serializable;

import javax.persistence.*;

import java.util.List;

/**
 * The persistent class for the subscribersummary database table.
 * 
 * @author manishm3
 */
@Entity
@Table(name = "eligibility.subscribersummary")
@NamedQuery(name = "Subscribersummary.findAll", query = "SELECT s FROM Subscribersummary s")
public class Subscribersummary implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String addressline1;

    private String addressline2;

    private String city;

    private String country;

    private String dateofbirth;

    private String gender;

    private String groupname;

    private String groupnumber;

    private String memberid;

    private String newmemberid;

    private String policynumber;

    private String relationshiptopatient;

    private String ssn;

    private String state;

    private String subscriberdate;

    private String subscriberdatequalifier;

    private String subscriberdatetimequalifier;

    private String subscribername;

    private String zipcode;

    // bi-directional many-to-one association to Edi271longdesc
    @OneToMany(mappedBy = "subscribersummary")
    private List<Edi271longdesc> edi271longdescs;

    public Subscribersummary() {
    }

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getAddressline1() {
        return this.addressline1;
    }

    public void setAddressline1(String addressline1) {
        this.addressline1 = addressline1;
    }

    public String getAddressline2() {
        return this.addressline2;
    }

    public void setAddressline2(String addressline2) {
        this.addressline2 = addressline2;
    }

    public String getCity() {
        return this.city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCountry() {
        return this.country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getDateofbirth() {
        return this.dateofbirth;
    }

    public void setDateofbirth(String dateofbirth) {
        this.dateofbirth = dateofbirth;
    }

    public String getGender() {
        return this.gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getGroupname() {
        return this.groupname;
    }

    public void setGroupname(String groupname) {
        this.groupname = groupname;
    }

    public String getGroupnumber() {
        return this.groupnumber;
    }

    public void setGroupnumber(String groupnumber) {
        this.groupnumber = groupnumber;
    }

    public String getMemberid() {
        return this.memberid;
    }

    public void setMemberid(String memberid) {
        this.memberid = memberid;
    }

    public String getNewmemberid() {
        return this.newmemberid;
    }

    public void setNewmemberid(String newmemberid) {
        this.newmemberid = newmemberid;
    }

    public String getPolicynumber() {
        return this.policynumber;
    }

    public void setPolicynumber(String policynumber) {
        this.policynumber = policynumber;
    }

    public String getRelationshiptopatient() {
        return this.relationshiptopatient;
    }

    public void setRelationshiptopatient(String relationshiptopatient) {
        this.relationshiptopatient = relationshiptopatient;
    }

    public String getSsn() {
        return this.ssn;
    }

    public void setSsn(String ssn) {
        this.ssn = ssn;
    }

    public String getState() {
        return this.state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getSubscriberdate() {
        return this.subscriberdate;
    }

    public void setSubscriberdate(String subscriberdate) {
        this.subscriberdate = subscriberdate;
    }

    public String getSubscriberdatequalifier() {
        return this.subscriberdatequalifier;
    }

    public void setSubscriberdatequalifier(String subscriberdatequalifier) {
        this.subscriberdatequalifier = subscriberdatequalifier;
    }

    public String getSubscriberdatetimequalifier() {
        return this.subscriberdatetimequalifier;
    }

    public void setSubscriberdatetimequalifier(String subscriberdatetimequalifier) {
        this.subscriberdatetimequalifier = subscriberdatetimequalifier;
    }

    public String getSubscribername() {
        return this.subscribername;
    }

    public void setSubscribername(String subscribername) {
        this.subscribername = subscribername;
    }

    public String getZipcode() {
        return this.zipcode;
    }

    public void setZipcode(String zipcode) {
        this.zipcode = zipcode;
    }

    public List<Edi271longdesc> getEdi271longdescs() {
        return this.edi271longdescs;
    }

    public void setEdi271longdescs(List<Edi271longdesc> edi271longdescs) {
        this.edi271longdescs = edi271longdescs;
    }

    public Edi271longdesc addEdi271longdesc(Edi271longdesc edi271longdesc) {
        getEdi271longdescs().add(edi271longdesc);
        edi271longdesc.setSubscribersummary(this);

        return edi271longdesc;
    }

    public Edi271longdesc removeEdi271longdesc(Edi271longdesc edi271longdesc) {
        getEdi271longdescs().remove(edi271longdesc);
        edi271longdesc.setSubscribersummary(null);

        return edi271longdesc;
    }

}