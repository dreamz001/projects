package com.eligibility270.dbentities;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the benefitsinformation database table.
 * 
 * @author manishm3
 */
@Entity
@Table(name = "eligibility.benefitsinformation")
@NamedQuery(name = "Benefitsinformation.findAll", query = "SELECT b FROM Benefitsinformation b")
public class Benefitsinformation implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "benefitsinformation_id_seq")
    @SequenceGenerator(name = "benefitsinformation_id_seq", sequenceName = "eligibility.benefitsinformation_id_seq")
    private Integer id;

    private String authorizationindicator;

    private String coveragecode;

    @Column(name = "industry_code")
    private String industryCode;

    private String modifier1;

    private String modifier2;

    private String modifier3;

    private String modifier4;

    private BigDecimal monetaryamount;

    private String networkindicator;

    private BigDecimal percentage;

    private String plan;

    private String procedurecode;

    private String quantityandqualifier;

    private String servicetypecodelist;

    private String eligibilitystatusinfo;

    private String timeperiodqualifiermonetaryamountpercentageasdecimal;

    // bi-directional many-to-one association to Edi271longdesc
    @ManyToOne
    @JoinColumn(name = "longdescid")
    private Edi271longdesc edi271longdesc;

    public Benefitsinformation() {
    }

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getAuthorizationindicator() {
        return this.authorizationindicator;
    }

    public void setAuthorizationindicator(String authorizationindicator) {
        this.authorizationindicator = authorizationindicator;
    }

    public String getCoveragecode() {
        return this.coveragecode;
    }

    public void setCoveragecode(String coveragecode) {
        this.coveragecode = coveragecode;
    }

    public String getIndustryCode() {
        return this.industryCode;
    }

    public void setIndustryCode(String industryCode) {
        this.industryCode = industryCode;
    }

    public String getModifier1() {
        return this.modifier1;
    }

    public void setModifier1(String modifier1) {
        this.modifier1 = modifier1;
    }

    public String getModifier2() {
        return this.modifier2;
    }

    public void setModifier2(String modifier2) {
        this.modifier2 = modifier2;
    }

    public String getModifier3() {
        return this.modifier3;
    }

    public void setModifier3(String modifier3) {
        this.modifier3 = modifier3;
    }

    public String getModifier4() {
        return this.modifier4;
    }

    public void setModifier4(String modifier4) {
        this.modifier4 = modifier4;
    }

    public BigDecimal getMonetaryamount() {
        return this.monetaryamount;
    }

    public void setMonetaryamount(BigDecimal monetaryamount) {
        this.monetaryamount = monetaryamount;
    }

    public String getNetworkindicator() {
        return this.networkindicator;
    }

    public void setNetworkindicator(String networkindicator) {
        this.networkindicator = networkindicator;
    }

    public BigDecimal getPercentage() {
        return this.percentage;
    }

    public void setPercentage(BigDecimal percentage) {
        this.percentage = percentage;
    }

    public String getPlan() {
        return this.plan;
    }

    public void setPlan(String plan) {
        this.plan = plan;
    }

    public String getProcedurecode() {
        return this.procedurecode;
    }

    public void setProcedurecode(String procedurecode) {
        this.procedurecode = procedurecode;
    }

    public String getQuantityandqualifier() {
        return this.quantityandqualifier;
    }

    public void setQuantityandqualifier(String quantityandqualifier) {
        this.quantityandqualifier = quantityandqualifier;
    }

    public String getServicetypecodelist() {
        return this.servicetypecodelist;
    }

    public void setServicetypecodelist(String servicetypecodelist) {
        this.servicetypecodelist = servicetypecodelist;
    }

    public Edi271longdesc getEdi271longdesc() {
        return this.edi271longdesc;
    }

    public void setEdi271longdesc(Edi271longdesc edi271longdesc) {
        this.edi271longdesc = edi271longdesc;
    }

    public String getEligibilitystatusinfo() {
        return eligibilitystatusinfo;
    }

    public void setEligibilitystatusinfo(String eligibilitystatusinfo) {
        this.eligibilitystatusinfo = eligibilitystatusinfo;
    }

    public String getTimeperiodqualifiermonetaryamountpercentageasdecimal() {
        return timeperiodqualifiermonetaryamountpercentageasdecimal;
    }

    public void setTimeperiodqualifiermonetaryamountpercentageasdecimal(String timeperiodqualifiermonetaryamountpercentageasdecimal) {
        this.timeperiodqualifiermonetaryamountpercentageasdecimal = timeperiodqualifiermonetaryamountpercentageasdecimal;
    }

}