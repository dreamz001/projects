package com.eligibility270.dbentities;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.Id;


@Entity
public class FullDescription implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    private Integer id;

    private String coveragecode;

    private BigDecimal monetaryamount;

    private String networkindicator;

    private String plan;

    private String eligibilitystatusinfo;

    public FullDescription() {
    }

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCoveragecode() {
        return this.coveragecode.trim();
    }

    public void setCoveragecode(String coveragecode) {
        this.coveragecode = coveragecode;
    }

    public BigDecimal getMonetaryamount() {
        return this.monetaryamount;
    }

    public void setMonetaryamount(BigDecimal monetaryamount) {
        this.monetaryamount = monetaryamount;
    }

    public String getNetworkindicator() {
        return this.networkindicator.trim();
    }

    public void setNetworkindicator(String networkindicator) {
        this.networkindicator = networkindicator;
    }

    public String getPlan() {
        return this.plan.trim();
    }

    public void setPlan(String plan) {
        this.plan = plan;
    }

    public String getEligibilitystatusinfo() {
        return eligibilitystatusinfo;
    }

    public void setEligibilitystatusinfo(String eligibilitystatusinfo) {
        this.eligibilitystatusinfo = eligibilitystatusinfo;
    }

}