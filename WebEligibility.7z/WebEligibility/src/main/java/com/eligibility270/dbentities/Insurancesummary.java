package com.eligibility270.dbentities;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * The persistent class for the insurancesummary database table.
 * 
 * @author manishm3
 */
@Entity
@Table(name = "eligibility.insurancesummary")
public class Insurancesummary implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String addressline1;

    private String addressline2;

    private String city;

    private String country;

    private String payeridentificationcode;

    private String payeridentificationqualifier;

    private String payername;

    private String state;

    private String zipcode;
     
    @Transient
    private String telephone;
    
    @Transient
    private String url;
    
    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    // bi-directional many-to-one association to Edi271longdesc
    @OneToMany(mappedBy = "insurancesummary")
    private List<Edi271longdesc> edi271longdescs;

    public Insurancesummary() {
    }

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getAddressline1() {
        return this.addressline1;
    }

    public void setAddressline1(String addressline1) {
        this.addressline1 = addressline1;
    }

    public String getAddressline2() {
        return this.addressline2;
    }

    public void setAddressline2(String addressline2) {
        this.addressline2 = addressline2;
    }

    public String getCity() {
        return this.city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCountry() {
        return this.country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getPayeridentificationcode() {
        return this.payeridentificationcode;
    }

    public void setPayeridentificationcode(String payeridentificationcode) {
        this.payeridentificationcode = payeridentificationcode;
    }

    public String getPayeridentificationqualifier() {
        return this.payeridentificationqualifier;
    }

    public void setPayeridentificationqualifier(String payeridentificationqualifier) {
        this.payeridentificationqualifier = payeridentificationqualifier;
    }

    public String getPayername() {
        return this.payername;
    }

    public void setPayername(String payername) {
        this.payername = payername;
    }

    public String getState() {
        return this.state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getZipcode() {
        return this.zipcode;
    }

    public void setZipcode(String zipcode) {
        this.zipcode = zipcode;
    }

    public List<Edi271longdesc> getEdi271longdescs() {
        return this.edi271longdescs;
    }

    public void setEdi271longdescs(List<Edi271longdesc> edi271longdescs) {
        this.edi271longdescs = edi271longdescs;
    }

    public Edi271longdesc addEdi271longdesc(Edi271longdesc edi271longdesc) {
        getEdi271longdescs().add(edi271longdesc);
        edi271longdesc.setInsurancesummary(this);

        return edi271longdesc;
    }

    public Edi271longdesc removeEdi271longdesc(Edi271longdesc edi271longdesc) {
        getEdi271longdescs().remove(edi271longdesc);
        edi271longdesc.setInsurancesummary(null);

        return edi271longdesc;
    }

   
    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }


}