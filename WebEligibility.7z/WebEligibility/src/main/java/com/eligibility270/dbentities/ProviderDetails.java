package com.eligibility270.dbentities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * The persistent class for the providerdetails database table.
 * 
 * @author Rajinder Singh
 */
@Entity
@Table(name = "eligibility.providerdetails")
public class ProviderDetails implements Serializable{
    
    private static final long serialVersionUID = 3316213875628465974L;

    @Id
    private Integer id;
    
    private String receivername;
    
    private String receiveridentifiercodequalifier;
    
    private String receiveridentifiercode;
    
    private String receiverentityidentifiercode;
    
    private String receiverentitytypequalifier;
    
    @Transient
    private String newproviderid;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getReceivername() {
        return receivername.trim();
    }

    public void setReceivername(String receivername) {
        this.receivername = receivername;
    }

    public String getReceiveridentifiercodequalifier() {
        return receiveridentifiercodequalifier;
    }

    public void setReceiveridentifiercodequalifier(String receiveridentifiercodequalifier) {
        this.receiveridentifiercodequalifier = receiveridentifiercodequalifier;
    }

    public String getReceiveridentifiercode() {
        return receiveridentifiercode;
    }

    public void setReceiveridentifiercode(String receiveridentifiercode) {
        this.receiveridentifiercode = receiveridentifiercode.trim();
    }

    public String getReceiverentityidentifiercode() {
        return receiverentityidentifiercode;
    }

    public void setReceiverentityidentifiercode(String receiverentityidentifiercode) {
        this.receiverentityidentifiercode = receiverentityidentifiercode;
    }

    public String getReceiverentitytypequalifier() {
        return receiverentitytypequalifier;
    }

    public void setReceiverentitytypequalifier(String receiverentitytypequalifier) {
        this.receiverentitytypequalifier = receiverentitytypequalifier;
    }

    public String getNewproviderid() {
        return newproviderid.trim();
    }

    public void setNewproviderid(String newproviderid) {
        this.newproviderid = newproviderid;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((receiveridentifiercode == null) ? 0 : receiveridentifiercode.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        ProviderDetails other = (ProviderDetails) obj;
        if (receiveridentifiercode == null) {
            if (other.receiveridentifiercode != null)
                return false;
        } else if (!receiveridentifiercode.equals(other.receiveridentifiercode))
            return false;
        return true;
    }
    
}
