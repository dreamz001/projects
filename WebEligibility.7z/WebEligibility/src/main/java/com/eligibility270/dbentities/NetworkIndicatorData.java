package com.eligibility270.dbentities;

import java.io.Serializable;


public class NetworkIndicatorData implements Serializable {
    private static final long serialVersionUID = 1L;
    private String inNetwork;
    private String outofNetwork;
    private String plan;
    
    public String getInNetwork() {
        return inNetwork;
    }
    public void setInNetwork(String inNetwork) {
        this.inNetwork = inNetwork;
    }
    public String getOutofNetwork() {
        return outofNetwork;
    }
    public void setOutofNetwork(String outofNetwork) {
        this.outofNetwork = outofNetwork;
    }
    public String getPlan() {
        return plan;
    }
    public void setPlan(String plan) {
        this.plan = plan;
    }

}