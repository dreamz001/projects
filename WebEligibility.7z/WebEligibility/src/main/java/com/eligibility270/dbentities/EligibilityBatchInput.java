package com.eligibility270.dbentities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="eligibility.eligibility_batch_input")
@NamedQuery(name="EligibilityBatchInput.findAll", query="SELECT e FROM EligibilityBatchInput e")
public class EligibilityBatchInput implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    private Integer id;
    
    private String inputcsv;
    
    private String status;
    
    @ManyToOne
    @JoinColumn(name="transaction_id")
    private EligibilityBatchFile transactionid;

   
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getInputcsv() {
        return inputcsv;
    }

    public void setInputcsv(String inputcsv) {
        this.inputcsv = inputcsv;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public EligibilityBatchFile getTransactionid() {
        return transactionid;
    }

    public void setTransactionid(EligibilityBatchFile transactionid) {
        this.transactionid = transactionid;
    }
}
