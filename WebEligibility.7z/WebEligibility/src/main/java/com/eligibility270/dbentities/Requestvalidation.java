package com.eligibility270.dbentities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The persistent class for the requestvalidations database table.
 * 
 * @author manishm3
 */
@Entity
@Table(name = "eligibility.requestvalidations")
@NamedQuery(name = "Requestvalidation.findAll", query = "SELECT r FROM Requestvalidation r")
public class Requestvalidation implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String followupcode;

    private String rejectreasoncode;

    private String responsecode;

    private String validationlevel;

    // bi-directional many-to-one association to Edi271longdesc
    @ManyToOne
    @JoinColumn(name = "longdescid")
    private Edi271longdesc edi271longdesc;

    public Requestvalidation() {
    }

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getFollowupcode() {
        return this.followupcode;
    }

    public void setFollowupcode(String followupcode) {
        this.followupcode = followupcode;
    }

    public String getRejectreasoncode() {
        return this.rejectreasoncode;
    }

    public void setRejectreasoncode(String rejectreasoncode) {
        this.rejectreasoncode = rejectreasoncode;
    }

    public String getResponsecode() {
        return this.responsecode;
    }

    public void setResponsecode(String responsecode) {
        this.responsecode = responsecode;
    }

    public String getValidationlevel() {
        return this.validationlevel;
    }

    public void setValidationlevel(String validationlevel) {
        this.validationlevel = validationlevel;
    }

    public Edi271longdesc getEdi271longdesc() {
        return this.edi271longdesc;
    }

    public void setEdi271longdesc(Edi271longdesc edi271longdesc) {
        this.edi271longdesc = edi271longdesc;
    }

}