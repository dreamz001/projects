package com.eligibility270.dbentities;

import java.io.Serializable;

import javax.persistence.*;

import java.util.ArrayList;
import java.util.List;

/**
 * @author manishm3
 * 
 *         The persistent class for the edi271longdesc database table.
 */

@Entity
@Table(name = "eligibility.edi271longdesc")
@NamedQuery(name = "Edi271longdesc.findAll", query = "SELECT e FROM Edi271longdesc e")
public class Edi271longdesc implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String eligibilitytracernumber;

    private Integer emdeinrequestresponseid;

    private Integer generaleligibilityinformationid;

    private Integer patientsummaryid;

    // bi-directional many-to-one association to Benefitsinformation
    @OneToMany(mappedBy = "edi271longdesc", cascade = { CascadeType.ALL })
    private List<Benefitsinformation> benefitsinformations;

    // bi-directional many-to-one association to Eligibilitysummary
    @ManyToOne
    @JoinColumn(name = "eligibilitysummaryid")
    private Eligibilitysummary eligibilitysummary;

    // bi-directional many-to-one association to Insurancesummary
    @ManyToOne
    @JoinColumn(name = "insurancesummaryid")
    private Insurancesummary insurancesummary;

    // bi-directional many-to-one association to Providersummary
    @ManyToOne
    @JoinColumn(name = "providersummaryid")
    private Providersummary providersummary;

    // bi-directional many-to-one association to Subscribersummary
    @ManyToOne
    @JoinColumn(name = "subscribersummaryid")
    private Subscribersummary subscribersummary;

    // bi-directional many-to-one association to Requestvalidation
    @OneToMany(mappedBy = "edi271longdesc", cascade = { CascadeType.ALL })
    private List<Requestvalidation> requestvalidations;

    public Edi271longdesc() {
    }

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getEligibilitytracernumber() {
        return this.eligibilitytracernumber;
    }

    public void setEligibilitytracernumber(String eligibilitytracernumber) {
        this.eligibilitytracernumber = eligibilitytracernumber;
    }

    public Integer getEmdeinrequestresponseid() {
        return this.emdeinrequestresponseid;
    }

    public void setEmdeinrequestresponseid(Integer emdeinrequestresponseid) {
        this.emdeinrequestresponseid = emdeinrequestresponseid;
    }

    public Integer getGeneraleligibilityinformationid() {
        return this.generaleligibilityinformationid;
    }

    public void setGeneraleligibilityinformationid(Integer generaleligibilityinformationid) {
        this.generaleligibilityinformationid = generaleligibilityinformationid;
    }

    public Integer getPatientsummaryid() {
        return this.patientsummaryid;
    }

    public void setPatientsummaryid(Integer patientsummaryid) {
        this.patientsummaryid = patientsummaryid;
    }

    public List<Benefitsinformation> getBenefitsinformations() {
        if (this.benefitsinformations == null) {
            this.benefitsinformations = new ArrayList<Benefitsinformation>();
        }
        return this.benefitsinformations;
    }

    public void setBenefitsinformations(List<Benefitsinformation> benefitsinformations) {
        this.benefitsinformations = benefitsinformations;
    }

    public Benefitsinformation addBenefitsinformation(Benefitsinformation benefitsinformation) {
        getBenefitsinformations().add(benefitsinformation);
        benefitsinformation.setEdi271longdesc(this);

        return benefitsinformation;
    }

    public Benefitsinformation removeBenefitsinformation(Benefitsinformation benefitsinformation) {
        getBenefitsinformations().remove(benefitsinformation);
        benefitsinformation.setEdi271longdesc(null);

        return benefitsinformation;
    }

    public Eligibilitysummary getEligibilitysummary() {
        return this.eligibilitysummary;
    }

    public void setEligibilitysummary(Eligibilitysummary eligibilitysummary) {
        this.eligibilitysummary = eligibilitysummary;
    }

    public Insurancesummary getInsurancesummary() {
        return this.insurancesummary;
    }

    public void setInsurancesummary(Insurancesummary insurancesummary) {
        this.insurancesummary = insurancesummary;
    }

    public Providersummary getProvidersummary() {
        return this.providersummary;
    }

    public void setProvidersummary(Providersummary providersummary) {
        this.providersummary = providersummary;
    }

    public Subscribersummary getSubscribersummary() {
        return this.subscribersummary;
    }

    public void setSubscribersummary(Subscribersummary subscribersummary) {
        this.subscribersummary = subscribersummary;
    }

    public List<Requestvalidation> getRequestvalidations() {
        if (this.requestvalidations == null) {
            this.requestvalidations = new ArrayList<Requestvalidation>();
        }
        return this.requestvalidations;
    }

    public void setRequestvalidations(List<Requestvalidation> requestvalidations) {
        this.requestvalidations = requestvalidations;
    }

    public Requestvalidation addRequestvalidation(Requestvalidation requestvalidation) {
        getRequestvalidations().add(requestvalidation);
        requestvalidation.setEdi271longdesc(this);

        return requestvalidation;
    }

    public Requestvalidation removeRequestvalidation(Requestvalidation requestvalidation) {
        getRequestvalidations().remove(requestvalidation);
        requestvalidation.setEdi271longdesc(null);

        return requestvalidation;
    }

}