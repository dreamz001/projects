package com.eligibility270.dbentities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name = "eligibility.servicetypecodelookuptable")
public class ServiceTypeCodeLookUp implements Serializable{
    
    private static final long serialVersionUID = 3834320422053952748L;
    @Id
    private String code;
    private String defination;
    
    public String getCode() {
        return code;
    }
    public void setCode(String code) {
        this.code = code;
    }
    public String getDefination() {
        return defination;
    }
    public void setDefination(String defination) {
        this.defination = defination;
    }    
    
}
