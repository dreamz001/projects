package com.eligibility270.dbentities;

import java.io.Serializable;

import javax.persistence.*;

import java.util.List;

/**
 * The persistent class for the providersummary database table.
 * 
 * @author manishm3
 */
@Entity
@Table(name = "eligibility.providersummary")
@NamedQuery(name = "Providersummary.findAll", query = "SELECT p FROM Providersummary p")
public class Providersummary implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String addressline1;

    private String addressline2;

    private String city;

    private String country;

    private String provideridentificationcode;

    private String provideridentificationqualifier;

    private String providername;

    private String state;

    private String zipcode;

    // bi-directional many-to-one association to Edi271longdesc
    @OneToMany(mappedBy = "providersummary")
    private List<Edi271longdesc> edi271longdescs;

    public Providersummary() {
    }

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getAddressline1() {
        return this.addressline1;
    }

    public void setAddressline1(String addressline1) {
        this.addressline1 = addressline1;
    }

    public String getAddressline2() {
        return this.addressline2;
    }

    public void setAddressline2(String addressline2) {
        this.addressline2 = addressline2;
    }

    public String getCity() {
        return this.city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCountry() {
        return this.country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getProvideridentificationcode() {
        return this.provideridentificationcode;
    }

    public void setProvideridentificationcode(String provideridentificationcode) {
        this.provideridentificationcode = provideridentificationcode;
    }

    public String getProvideridentificationqualifier() {
        return this.provideridentificationqualifier;
    }

    public void setProvideridentificationqualifier(String provideridentificationqualifier) {
        this.provideridentificationqualifier = provideridentificationqualifier;
    }

    public String getProvidername() {
        return this.providername;
    }

    public void setProvidername(String providername) {
        this.providername = providername;
    }

    public String getState() {
        return this.state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getZipcode() {
        return this.zipcode;
    }

    public void setZipcode(String zipcode) {
        this.zipcode = zipcode;
    }

    public List<Edi271longdesc> getEdi271longdescs() {
        return this.edi271longdescs;
    }

    public void setEdi271longdescs(List<Edi271longdesc> edi271longdescs) {
        this.edi271longdescs = edi271longdescs;
    }

    public Edi271longdesc addEdi271longdesc(Edi271longdesc edi271longdesc) {
        getEdi271longdescs().add(edi271longdesc);
        edi271longdesc.setProvidersummary(this);

        return edi271longdesc;
    }

    public Edi271longdesc removeEdi271longdesc(Edi271longdesc edi271longdesc) {
        getEdi271longdescs().remove(edi271longdesc);
        edi271longdesc.setProvidersummary(null);

        return edi271longdesc;
    }

}