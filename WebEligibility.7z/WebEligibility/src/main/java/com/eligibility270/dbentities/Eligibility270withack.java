package com.eligibility270.dbentities;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.eligibility270.header.entities.InterchangeControlHeader;
import com.eligibility271.dbentities.Emdeonrequestresponse;

/**
 * @author manishm3
 * 
 *         The persistent class for the eligibility270withack database table.
 * 
 */
@Entity
@Table(name = "eligibility.eligibility270withack")
@NamedQuery(name = "Eligibility270withack.findAll", query = "SELECT e FROM Eligibility270withack e")
public class Eligibility270withack implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String edi270gen;

    private String eligibilitytracenumber;

    private String eligibility270json;

    private String eligibilitystatuscode;

    private Boolean emdeonsubmissionstatus;

    private String error;

    private String errorcode;

    private Timestamp requestdate;

    // bi-directional many-to-one association to Emdeonrequestresponse
    @OneToMany(mappedBy = "eligibility270withack")
    private List<Emdeonrequestresponse> emdeonrequestresponses;

    // bi-directional many-to-one association to
    // Eligibility270Interchangecontrolheader
    @ManyToOne
    @JoinColumn(name = "interchangecontrolnumber")
    private InterchangeControlHeader eligibility270Interchangecontrolheader;

    @Column(name="transaction_id")
    private Integer transactionid;
    
    public Eligibility270withack() {
    }

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getEdi270gen() {
        return this.edi270gen;
    }

    public void setEdi270gen(String edi270gen) {
        this.edi270gen = edi270gen;
    }

    public String getEligibilitytracenumber() {
        return eligibilitytracenumber;
    }

    public void setEligibilitytracenumber(String eligibilitytracenumber) {
        this.eligibilitytracenumber = eligibilitytracenumber;
    }

    public String getEligibility270json() {
        return this.eligibility270json;
    }

    public void setEligibility270json(String eligibility270json) {
        this.eligibility270json = eligibility270json;
    }

    public String getEligibilitystatuscode() {
        return this.eligibilitystatuscode;
    }

    public void setEligibilitystatuscode(String eligibilitystatuscode) {
        this.eligibilitystatuscode = eligibilitystatuscode;
    }

    public Boolean getEmdeonsubmissionstatus() {
        return this.emdeonsubmissionstatus;
    }

    public void setEmdeonsubmissionstatus(Boolean emdeonsubmissionstatus) {
        this.emdeonsubmissionstatus = emdeonsubmissionstatus;
    }

    public String getError() {
        return this.error;
    }

    public void setError(String error) {
        this.error = error;
    }

    public String getErrorcode() {
        return this.errorcode;
    }

    public void setErrorcode(String errorcode) {
        this.errorcode = errorcode;
    }

    public List<Emdeonrequestresponse> getEmdeonrequestresponses() {
        return this.emdeonrequestresponses;
    }

    public void setEmdeonrequestresponses(List<Emdeonrequestresponse> emdeonrequestresponses) {
        this.emdeonrequestresponses = emdeonrequestresponses;
    }

    public Emdeonrequestresponse addEmdeonrequestrespons(Emdeonrequestresponse emdeonrequestrespons) {
        getEmdeonrequestresponses().add(emdeonrequestrespons);
        emdeonrequestrespons.setEligibility270withack(this);

        return emdeonrequestrespons;
    }

    public Emdeonrequestresponse removeEmdeonrequestrespons(Emdeonrequestresponse emdeonrequestrespons) {
        getEmdeonrequestresponses().remove(emdeonrequestrespons);
        emdeonrequestrespons.setEligibility270withack(null);

        return emdeonrequestrespons;
    }

    public InterchangeControlHeader getInterchangeControlHeader() {
        return this.eligibility270Interchangecontrolheader;
    }

    public void setInterchangeControlHeader(InterchangeControlHeader eligibility270Interchangecontrolheader) {
        this.eligibility270Interchangecontrolheader = eligibility270Interchangecontrolheader;
    }

    public Timestamp getRequestdate() {
        return requestdate;
    }

    public void setRequestdate(Timestamp requestdate) {
        this.requestdate = requestdate;
    }

    public Integer getTransactionid() {
        return transactionid;
    }

    public void setTransactionid(Integer transactionid) {
        this.transactionid = transactionid;
    }

    
}